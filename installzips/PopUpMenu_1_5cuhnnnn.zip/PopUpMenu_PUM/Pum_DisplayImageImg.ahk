﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\Pum_ColorVarConvert.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_ResizePng.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_Combine.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Pum_WinInWinMaxSize.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_ResizeImg.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_GuiControl.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\l_543.ahk ; (543_1)(_Msg 8_)(_w300 x h300_)_Sanding_Man)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Pum_DisplayImageImg(DataArray) ; > DataArray
{
  ; -------------------------------------------
  ScriptType := DataArray.366.5 ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
  ; -------------------------------------------
  if (InStr(ScriptType, "pumBgImage") > 0)
  {
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    { ; [START UP]  Vars
      ; -------------------------------------------
      { ; [GET] Vars
        ; -------------------------------------------
        ThisPumProcessFolder := DataArray.361.8 ; (361)(8)(ThisPumProcessFolder [Pum Folder Path])
        ScriptType := DataArray.366.5 ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        ; -------------------------------------------
        XmlIconSize    := DataArray.362.14 ; (362_14)(XmlIconSize [Displaymode iconsize] [32,48,64])
        XmlColumnsX   := DataArray.362.4 ; (362_4)(XmlColumnsX [Pum (X) Columns])
        XmlRowsY      := DataArray.362.3 ; (362_3)(XmlRowsY [Pum (Y) Rows])
        ; -------------------------------------------
        Pum_W          := DataArray.362.36 ; (362_36)(Pum_W)
        Pum_H          := DataArray.362.37 ; (362_37)(Pum_H)
        bg_Image_Type  := DataArray.362.38 ; (362_38)(Bg_Image_Type [C=Crop,F=Fit])
        Img_Gui_W      := DataArray.362.39 ; (362_39)(Img_Gui_W)
        Img_Gui_H      := DataArray.362.40 ; (362_40)(Img_Gui_H)
        Img_Gui_X      := DataArray.362.41 ; (362_41)(Img_Gui_X)
        Img_Gui_Y      := DataArray.362.42 ; (362_42)(Img_Gui_Y)
        Pum_Gui_W      := DataArray.362.44 ; (362_44)(Pum_Gui_W)
        Pum_Gui_H      := DataArray.362.45 ; (362_45)(Pum_Gui_H)
        Pum_Gui_X      := DataArray.362.46 ; (362_46)(Pum_Gui_X)
        Pum_Gui_Y      := DataArray.362.47 ; (362_47)(Pum_Gui_Y)
        Pum_Gui_Max_W  := DataArray.362.48 ; (362_48)(Pum_Gui_Max_W)
        Pum_Gui_Max_H  := DataArray.362.49 ; (362_49)(Pum_Gui_Max_H)
        Pum_Gui_Min_W  := DataArray.362.50 ; (362_50)(Pum_Gui_Min_W)
        Pum_Gui_Min_H  := DataArray.362.51 ; (362_51)(Pum_Gui_Min_H)
        ; -------------------------------------------
        XmlBgColor := DataArray.362.27 ; (362_27)(XmlBgColor [Background color])
        Color_Array := Pum_ColorVarConvert("MsColor", XmlBgColor, DataArray)
        Pum_BgColor_GridNum      := Color_Array.2
        ; -------------------------------------------
      } ; End [GET] Vars
      ; -------------------------------------------
      File_PumFrame := A_ProgramFiles "\PopUpMenu_PUM\image\pum\PumFrame.png" ; (365_2)(Current User language)
      ; -------------------------------------------
      Temp_Selected_Gui   := ThisPumProcessFolder "\image\Temp_Selected_Gui.png" ; (361)(8)(Pum [Specific Folder Path])
      Temp_Selected_Fit   := ThisPumProcessFolder "\image\Temp_Selected_Fit.png" ; (361)(8)(Pum [Specific Folder Path])
      ; -------------------------------------------
      Temp_Display_Img     := ThisPumProcessFolder "\image\Temp_Display_Img.png" ; (361)(8)(Pum [Specific Folder Path])
      ; -------------------------------------------
      File_Pum_Gui       := ThisPumProcessFolder "\image\File_Pum_Gui.png" ; (361)(8)(Pum [Specific Folder Path])
      ; -------------------------------------------
    } ; End [START UP] Vars
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; -------------------------------------------
    ImageTemp1 := ThisPumProcessFolder "\image\ImageTemp1.png"
    ; -------------------------------------------
    FileDelete, %ImageTemp1%
    ; -------------------------------------------
    ;
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Start (Animate) Sanding_Man
    global n_543 := 0 ; Start Frame Number
    global s_543 := 1 ; Show
    SetTimer, l_543, 100 ; (543_1)(_Msg 8_)(_w300 x h300_)_Sanding_Man)
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Start (Animate) Sanding_Man
    ;
    ; -------------------------------------------
    { ; [COMMON] [NEED] (XmlColumnsX)(XmlRowsY)(XmlIconSize) | [SET] (Pum_[W,H])
      ; -------------------------------------------
      ;
      Pum_W := XmlColumnsX * XmlIconSize
      Pum_H := XmlRowsY * XmlIconSize
      ;
      ; -------------------------------------------
    } ; End [COMMON] [NEED] (XmlColumnsX)(XmlRowsY)(XmlIconSize) | [SET] (Pum_[W,H])
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (bg_Image_Type == "C") ; [CREATE] (Temp_Display_Img.png)
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; [NEED] (Center_100_" Pum_BgColor_GridNum ".png") (Pum_Gui_[W,H) | [CREATE] (ImageTemp1.png) Pum Color Background
      ; -------------------------------------------
      Center_Opicity_GridNum := A_ProgramFiles "\PopUpMenu_PUM\image\pum\pum_" Pum_BgColor_GridNum "_100.png"
      ; -------------------------------------------
      Image_ResizePng(Img_Gui_W , Img_Gui_H, Center_Opicity_GridNum, ImageTemp1) ; Resize_W, Resize_H, ImageIn, ImageOut > 1 / 0
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ;
      ; -------------------------------------------
      FileDelete, %File_Pum_Gui%
      Image_ResizePng(Pum_Gui_W, Pum_Gui_H, File_PumFrame, File_Pum_Gui) ; Resize_W, Resize_H, ImageIn, ImageOut > 1 / 0
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; [NEED] (Pum_Gui_[W,H]) (Pum_Gui_[X,Y]) | [SET] (Spacer_Img_[X,Y]) | [SET] (Spacer_Pum_[X,Y])
      ; -------------------------------------------
      Spacer_Img_X := (300 - Img_Gui_W) / 2
      Spacer_Img_Y := (300 - Img_Gui_H) / 2
      ; -------------------------------------------
      Spacer_Pum_X := (Pum_Gui_X + Spacer_Img_X)
      Spacer_Pum_Y := (Pum_Gui_Y + Spacer_Img_Y)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; [NEED] (Temp_Selected_Gui.png) (File_Pum_Gui.png) (Spacer_[X,Y])) | [CREATE] (Temp_Display_Img.png)
      ; -------------------------------------------
      FileDelete, %Temp_Display_Img%
      Image_Array := [300, 300, Temp_Display_Img, ImageTemp1, Spacer_Img_X, Spacer_Img_Y, Temp_Selected_Gui, Spacer_Img_X, Spacer_Img_Y, File_Pum_Gui, Spacer_Pum_X, Spacer_Pum_Y]
      Image_Combine(Image_Array)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
    } ; End (bg_Image_Type == "C")
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (bg_Image_Type == "F") ; [CREATE] (Temp_Display_Img.png)
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; [NEED] (Center_100_" Pum_BgColor_GridNum ".png") (Pum_Gui_Max_[W,H]) | [CREATE] (ImageTemp1.png) Pum Color Background
      ; -------------------------------------------
      Center_Opicity_GridNum := A_ProgramFiles "\PopUpMenu_PUM\image\pum\pum_" Pum_BgColor_GridNum "_100.png"
      ; -------------------------------------------
      WinInWin_Array := Pum_WinInWinMaxSize(300, 300, Pum_Gui_W, Pum_Gui_H) ; OuterWin_W, OuterWin_H, InnerWin_W, InnerWin_H > [Max_W, Max_H]
      Pum_Gui_Max_W := WinInWin_Array.1
      Pum_Gui_Max_H := WinInWin_Array.2
      Image_ResizePng(Pum_Gui_Max_W, Pum_Gui_Max_H, Center_Opicity_GridNum, ImageTemp1) ; Resize_W, Resize_H, ImageIn, ImageOut > 1 / 0
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; [NEED] (File_PumFrame.png) (Pum_Gui_Max_[W,H]) | [CREATE] (File_Pum_Gui.png) | [SET] (Pum_Gui_[X,Y])
      ; -------------------------------------------
      FileDelete, %File_Pum_Gui%
      Image_ResizeImg(Pum_Gui_Max_W, Pum_Gui_Max_H, File_PumFrame, File_Pum_Gui) ; New_W, New_H, ImageIn, ImageOut > 1 / 0
      ; -------------------------------------------
      Pum_Gui_X := 0
      Pum_Gui_Y := 0
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; [NEED] (Pum_Gui_Max_[W,H]) | [SET] (Img_Gui_[W,H,X,Y])
      ; -------------------------------------------
      Img_Gui_W := Pum_Gui_Max_W
      Img_Gui_H := Pum_Gui_Max_H
      ; -------------------------------------------
      if (Img_Gui_W > Img_Gui_H)
      {
        ; -------------------------------------------
        Img_Gui_X := 0
        Img_Gui_Y := (300 - Img_Gui_H) / 2
        ; -------------------------------------------
      } ; End (Img_Gui_W > Img_Gui_H)
      else if (Img_Gui_W < Img_Gui_H)
      {
        ; -------------------------------------------
        Img_Gui_X := (300 - Img_Gui_W) / 2
        Img_Gui_Y := 0
        ; -------------------------------------------
      } ; End (Img_Gui_W < Img_Gui_H)
      else if (Img_Gui_W == Img_Gui_H)
      {
        ; -------------------------------------------
        Img_Gui_X := 0
        Img_Gui_Y := 0
        ; -------------------------------------------
      } ; End (Img_Gui_W == Img_Gui_H)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; [NEED] (Pum_Gui_Max_[W,H]) | [SET] (Spacer_[X,Y])
      ; -------------------------------------------
      Spacer_X := (300 - Pum_Gui_Max_W) / 2
      Spacer_Y := (300 - Pum_Gui_Max_H) / 2
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; (_03-Aug-2021_09-16-56_) to Fix Fit Image Error
      ; Resize Temp_Selected_Fit
      ; to File_Pum_Gui
      ; -------------------------------------------
      Gui, ImageSize:Add, Picture, hwndJustForSize, %File_Pum_Gui% ; (368_5)(Selected Pum Background [Full Path])
      ControlGetPos, , , Temp1_W, Temp1_H, , ahk_id %JustForSize% ; (368_6)(Pum Background Image X_Width)/(368_7)(Pum Background Image Y_Height)
      ; -------------------------------------------
      Gui, ImageSize:Add, Picture, hwndJustForSize, %Temp_Selected_Fit% ; (368_5)(Selected Pum Background [Full Path])
      ControlGetPos, , , Temp2_W, Temp2_H, , ahk_id %JustForSize% ; (368_6)(Pum Background Image X_Width)/(368_7)(Pum Background Image Y_Height)
      ; -------------------------------------------
      if (Temp1_W != Temp2_W or Temp1_H != Temp2_H)
      {
        Image_ResizeImg(Temp1_W, Temp1_H, Temp_Selected_Fit, Temp_Selected_Fit) ; New_W, New_H, ImageIn, ImageOut > 1 / 0
      }
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; [NEED] (Temp_Selected_Fit.png) (File_Pum_Gui.png) (Spacer_[X,Y])) | [CREATE] (Temp_Display_Img.png)
      ; -------------------------------------------
      FileDelete, %Temp_Display_Img%
      Image_Array := [300, 300, Temp_Display_Img, ImageTemp1, Spacer_X, Spacer_Y, Temp_Selected_Fit, Spacer_X, Spacer_Y, File_Pum_Gui, Spacer_X, Spacer_Y]
      Image_Combine(Image_Array)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
    } ; End (bg_Image_Type == "F")
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    FileDelete, %ImageTemp1%
    ; -------------------------------------------
    ;
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Stop (Animate) Sanding_Man
    global s_543 := 0 ; Hide
    SetTimer, l_543, Off ; (543_1)(_Msg 8_)(_w300 x h300_)_Sanding_Man)
    global ShowAnimationChange := 0
    Sleep, 110
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Stop (Animate) Sanding_Man
    ;
    ; -------------------------------------------
    DataArray.254.3 := Temp_Display_Img ; (254_3)(Obj_MsgImg300x300_Img [Image Path])
    GuiControl, PopUpMenu:, g_254, %Temp_Display_Img% ; (254_1)(Obj_MsgImg300x300)
    GuiControl, PopUpMenu:Show, g_254 ; (254_1)(Obj_MsgImg300x300)
    ; -------------------------------------------
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    { ; [SHOW-HIDE] Controls
      ; -------------------------------------------
      DataArray := Image_GuiControl("182", 1, 0, DataArray) ; (182_1)(Obj_Pum_BgRotateLeft)
      DataArray := Image_GuiControl("183", 1, 0, DataArray) ; (183_1)(Obj_Pum_BgRotateRight)
      ; -------------------------------------------
      if (bg_Image_Type == "C") ; Image is a Crop
      {
        ; -------------------------------------------
        DataArray.241.3 := "" ; (241_3)(Obj_Pum_CropLeft_Img [Image Path])
        DataArray.242.3 := "" ; (242_3)(Obj_Pum_CropRight_Img [Image Path])
        DataArray.243.3 := "" ; (243_3)(Obj_Pum_CropUp_Img [Image Path])
        DataArray.244.3 := "" ; (244_3)(Obj_Pum_CropDown_Img [Image Path])
        DataArray.245.3 := "" ; (245_3)(Obj_Pum_CropCenter_Img [Image Path])
        DataArray.246.3 := "" ; (246_3)(Obj_Pum_ZoomIn_Img [Image Path])
        DataArray.247.3 := "" ; (247_3)(Obj_Pum_ZoomOut_Img [Image Path])
        ; -------------------------------------------
        DataArray := Image_GuiControl("167", 1, 1, DataArray) ; (167_1)(Obj_Pum_BgFitImage)
        ; -------------------------------------------
        if (Pum_Gui_X <= 0.9999999999999999999999999999999999999999)
        {
          Pum_Gui_X := 0
        }
        if (Pum_Gui_Y <= 0.9999999999999999999999999999999999999999)
        {
          Pum_Gui_Y := 0
        }
        ; -------------------------------------------
        if (Pum_Gui_X == 0)
        {
          DataArray := Image_GuiControl("241", 0, 0, DataArray) ; (241_1)(Obj_Pum_CropLeft)
        }
        else
        {
          DataArray := Image_GuiControl("241", 1, 0, DataArray) ; (241_1)(Obj_Pum_CropLeft)
        }
        ; -------------------------------------------
        if ((Pum_Gui_X + Pum_Gui_W) >= Img_Gui_W)
        {
          DataArray := Image_GuiControl("242", 0, 0, DataArray) ; (242_1)(Obj_Pum_CropRight)
        }
        else
        {
          DataArray := Image_GuiControl("242", 1, 0, DataArray) ; (242_1)(Obj_Pum_CropRight)
        }
        ; -------------------------------------------
        if (Pum_Gui_Y == 0)
        {
          DataArray := Image_GuiControl("243", 0, 0, DataArray) ; (243_1)(Obj_Pum_CropUp)
        }
        else
        {
          DataArray := Image_GuiControl("243", 1, 0, DataArray) ; (243_1)(Obj_Pum_CropUp)
        }
        ; -------------------------------------------
        if ((Pum_Gui_Y + Pum_Gui_H) >= Img_Gui_H)
        {
          DataArray := Image_GuiControl("244", 0, 0, DataArray) ; (244_1)(Obj_Pum_CropDown)
        }
        else
        {
          DataArray := Image_GuiControl("244", 1, 0, DataArray) ; (244_1)(Obj_Pum_CropDown)
        }
        ; -------------------------------------------
        DataArray := Image_GuiControl("245", 1, 0, DataArray) ; (245_1)(Obj_Pum_CropCenter)
        ; -------------------------------------------
        if ((Pum_Gui_W > Pum_Gui_Min_W && Pum_Gui_W < Pum_Gui_Max_W) && (Pum_Gui_H > Pum_Gui_Min_H && Pum_Gui_H < Pum_Gui_Max_H))
        {
          DataArray := Image_GuiControl("246", 1, 0, DataArray) ; (246_1)(Obj_Pum_ZoomIn)
          DataArray := Image_GuiControl("247", 1, 0, DataArray) ; (247_1)(Obj_Pum_ZoomOut)
        }
        else if ((Pum_Gui_W > Pum_Gui_Min_W) && (Pum_Gui_H > Pum_Gui_Min_H))
        {
          DataArray := Image_GuiControl("246", 1, 0, DataArray) ; (246_1)(Obj_Pum_ZoomIn)
          DataArray := Image_GuiControl("247", 0, 0, DataArray) ; (247_1)(Obj_Pum_ZoomOut)
        }
        else if ((Pum_Gui_W < Pum_Gui_Max_W) && (Pum_Gui_H < Pum_Gui_Max_H))
        {
          DataArray := Image_GuiControl("246", 0, 0, DataArray) ; (246_1)(Obj_Pum_ZoomIn)
          DataArray := Image_GuiControl("247", 1, 0, DataArray) ; (247_1)(Obj_Pum_ZoomOut)
        }
        ; -------------------------------------------
      }
      ; -------------------------------------------
      else if (bg_Image_Type == "F") ; Image is a Crop
      {
        ; -------------------------------------------
        DataArray := Image_GuiControl("167", 2, 1, DataArray) ; (167_1)(Obj_Pum_BgFitImage)
        ; -------------------------------------------
        DataArray := Image_GuiControl("241", 0, 0, DataArray) ; (241_1)(Obj_Pum_CropLeft)
        DataArray := Image_GuiControl("242", 0, 0, DataArray) ; (242_1)(Obj_Pum_CropRight)
        DataArray := Image_GuiControl("243", 0, 0, DataArray) ; (243_1)(Obj_Pum_CropUp)
        DataArray := Image_GuiControl("244", 0, 0, DataArray) ; (244_1)(Obj_Pum_CropDown)
        DataArray := Image_GuiControl("245", 0, 0, DataArray) ; (245_1)(Obj_Pum_CropCenter)
        DataArray := Image_GuiControl("246", 0, 0, DataArray) ; (246_1)(Obj_Pum_ZoomIn)
        DataArray := Image_GuiControl("247", 0, 0, DataArray) ; (247_1)(Obj_Pum_ZoomOut)
      } ; End (bg_Image_Type == "F")
      ; -------------------------------------------
    } ; End [SHOW-HIDE] Controls
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    { ; [UPDATE] Vars
      ; -------------------------------------------
      DataArray.361.8  := ThisPumProcessFolder ; (361)(8)(ThisPumProcessFolder [Pum Folder Path])
      DataArray.366.5  := ScriptType ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      ; -------------------------------------------
      DataArray.362.14 := XmlIconSize ; (362_14)(XmlIconSize [Displaymode iconsize] [32,48,64])
      DataArray.362.4  := XmlColumnsX ; (362_4)(XmlColumnsX [Pum (X) Columns])
      DataArray.362.3  := XmlRowsY ; (362_3)(XmlRowsY [Pum (Y) Rows])
      ; -------------------------------------------
      DataArray.362.36 := Pum_W ; (362_36)(Pum_W)
      DataArray.362.37 := Pum_H ; (362_37)(Pum_H)
      DataArray.362.38 := bg_Image_Type ; (362_38)(Bg_Image_Type [C=Crop,F=Fit])
      DataArray.362.39 := Img_Gui_W ; (362_39)(Img_Gui_W)
      DataArray.362.40 := Img_Gui_H ; (362_40)(Img_Gui_H)
      DataArray.362.41 := Img_Gui_X ; (362_41)(Img_Gui_X)
      DataArray.362.42 := Img_Gui_Y ; (362_42)(Img_Gui_Y)
      DataArray.362.44 := Pum_Gui_W ; (362_44)(Pum_Gui_W)
      DataArray.362.45 := Pum_Gui_H ; (362_45)(Pum_Gui_H)
      DataArray.362.46 := Pum_Gui_X ; (362_46)(Pum_Gui_X)
      DataArray.362.47 := Pum_Gui_Y ; (362_47)(Pum_Gui_Y)
      DataArray.362.48 := Pum_Gui_Max_W ; (362_48)(Pum_Gui_Max_W)
      DataArray.362.49 := Pum_Gui_Max_H ; (362_49)(Pum_Gui_Max_H)
      DataArray.362.50 := Pum_Gui_Min_W ; (362_50)(Pum_Gui_Min_W)
      DataArray.362.51 := Pum_Gui_Min_H ; (362_51)(Pum_Gui_Min_H)
      ; -------------------------------------------
      DataArray.362.27 := XmlBgColor ; (362_27)(XmlBgColor [Background color])
      ; -------------------------------------------
    } ; End [UPDATE] Vars
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
  } ; End (InStr(ScriptType, "pumBgImage") > 0)
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
} ; End Pum_DisplayImageImg(DataArray) ; > DataArray
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
