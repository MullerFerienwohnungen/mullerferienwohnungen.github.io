﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\Sys_EnableDisable.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_GuiControl.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Pum_ColorVarConvert.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
f_178(DataArray) ; (178_1)(Obj_Pum_BgOpacityUp)
{
  ; -------------------------------------------
  global PumLock
  if (PumLock == "")
  {
    ; -------------------------------------------
    global PumLock := 0
    ; -------------------------------------------
  }
  ; -------------------------------------------
  if (PumLock == 0)
  {
    ; -------------------------------------------
    global PumLock := 1
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    BgColor_Opicity     := DataArray.362.30 ; (362_30)(XmlBgOpacity [Background opacity] [0 - 100])
    XmlBgColor := DataArray.362.27 ; (362_27)(XmlBgColor [Background color])
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    GuiControl, PopUpMenu:Hide, g_102 ; (102_1)(Obj_DisplayedIcon)
    ; -------------------------------------------
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (BgColor_Opicity < 100)
    {
      ; -------------------------------------------
      Sys_EnableDisable("Disable") ; "Enable" or "Disable"
      ; -------------------------------------------
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      DataArray := Image_GuiControl("004", 3, 0, DataArray) ; (004_1)(Obj_ok)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ;
      ; (Transparency Arrow Up)
      ;
      if (DataArray.362.54 == "") ; (362_54)(bg_Selected_Rotate)
      {
        DataArray.362.54 := 0 ; (362_54)(bg_Selected_Rotate)
      }
      ; -------------------------------------------
      if (DataArray.362.52 == "" or DataArray.362.52 == 0) ; (362_52)(bg_Selected_Change)
      {
        DataArray.362.52 := 1 ; (362_52)(bg_Selected_Change)
      }
      Pum_Factor := DataArray.362.34 / DataArray.362.39 ; (362_34)(Img_W)/(362_39)(Img_Gui_W)
      DataArray.362.55 := Pum_Factor * DataArray.362.46 ; (362_55)(Pum_X)/(362_46)(Pum_Gui_X)
      DataArray.362.56 := Pum_Factor * DataArray.362.47 ; (362_56)(Pum_Y)/(362_47)(Pum_Gui_Y)
      ; -------------------------------------------
      DataArray := Image_GuiControl("004", 1, 0, DataArray) ; (004_1)(Obj_ok)
      ; -------------------------------------------
      ;
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ;
      ;
      ; -------------------------------------------
      DataArray := Image_GuiControl("178", 2, 0, DataArray) ; (178_1)(Obj_Pum_BgOpacityUp)
      ; -------------------------------------------
      ThisPumProcessFolder := DataArray.361.8 ; (361)(8)(ThisPumProcessFolder [Pum Folder Path])
      Temp_Display_Txt_Img := ThisPumProcessFolder "\image\Temp_Display_Txt_Img.png" ; (361)(8)(Pum [Specific Folder Path])
      FileDelete, %Temp_Display_Txt_Img%
      Temp_Display_Txt_Col := ThisPumProcessFolder "\image\Temp_Display_Txt_Col.png" ; (361)(8)(Pum [Specific Folder Path])
      FileDelete, %Temp_Display_Txt_Col%
      ; -------------------------------------------
      BgColor_Opicity  := BgColor_Opicity + 10
      DataArray.362.30 := BgColor_Opicity ; (362_30)(XmlBgOpacity [Background opacity] [0 - 100])
      ; -------------------------------------------
      Color_Array         := Pum_ColorVarConvert("MsColor", XmlBgColor, DataArray)
      Pum_BgColor_GridNum := Color_Array.2
      ; -------------------------------------------
      if (BgColor_Opicity == 0)
      {
        DataArray := Image_GuiControl("181", "Zero", 0, DataArray) ; (181_1)(Obj_Pum_Opacity)
      }
      else
      {
        Opicity_GridNum  := BgColor_Opicity "_" Pum_BgColor_GridNum
        DataArray := Image_GuiControl("181", Opicity_GridNum, 0, DataArray) ; (181_1)(Obj_Pum_Opacity)
      }
      ; -------------------------------------------
      GuiControl, PopUpMenu:, g_180, %BgColor_Opicity% ; (180_1)(Obj_Pum_DisplayText_Opacity)
      GuiControl, PopUpMenu:Show, g_180 ; (180_1)(Obj_Pum_DisplayText_Opacity)
      ; -------------------------------------------
      Sleep, 100 ; Sleep, Here to Animate Button Press
      DataArray := Image_GuiControl("178", 1, 0, DataArray) ; (178_1)(Obj_Pum_BgOpacityUp)
      ; -------------------------------------------
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      DataArray := Image_GuiControl("004", 1, 0, DataArray) ; (004_1)(Obj_ok)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; -------------------------------------------
      Sys_EnableDisable("Enable") ; "Enable" or "Disable"
      ; -------------------------------------------
    } ; End (BgColor_Opicity < 100)
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    global PumLock := 0
    ; -------------------------------------------
  } ; End (PumLock == 0)
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
} ; End (178_1)(GUI Object: [pum] [pumBgColor] Transparency Arrow Up)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
