﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\KeyArray_Display.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Pum_DisplayPumApp.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\MenuSizeLang.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\_S1_C.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\_S2_H.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\_S3_S.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
f_101(DataArray) ; (101_1)(Obj_LangFlag)
{
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; [SET] UserLang (Run Gui_Language)
  ; -------------------------------------------
  RunWait, %A_ProgramFiles%\PopUpMenu_PUM\Gui_Language.ahk
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; [GET] UserLang from (File_UserLang.txt)
  ; -------------------------------------------
  File_UserLang := A_AppData "\PopUpMenu_PUM\system\File_UserLang.txt"
  ; -------------------------------------------
  FileReadLINE, UserLang, %File_UserLang%, 1
  ; -------------------------------------------
  DataArray.365.2 := UserLang ; (365_2)(UserLang [Current User language])
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
  {
    if (DataArray.301.2.1 != "") ; (301_2)(Key_ArrayNumbers [Array])
    {
      ; -------------------------------------------
      ; Creates
      ; (301_7)([key] KeyArray_Display [String] [by Lang])
      ; From
      ; (301_2)([key] KeyArray_Numbers [Array])
      DataArray := KeyArray_Display(DataArray) ; > DataArray
      ; -------------------------------------------
    }
  }
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  DataArray.302.6 := MenuSizeLang(DataArray) ; (302_6)(Mnu_MenuSize [#])
  ; -------------------------------------------
  if (DataArray.302.6 == 0) ; (302_6)(Mnu_MenuSize [#])
  {
    ; -------------------------------------------
    if (DataArray.366.5 == "mnu") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
    {
      DataArray.366.5 := "mnu_cpl_key" ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
    }
    ; -------------------------------------------
  }
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ScriptType := DataArray.366.5 ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
  ; -------------------------------------------
  if (InStr(ScriptType, "pum") > 0)
  {
    ; -------------------------------------------
    DataArray.366.5 := "pumtom" ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
    ; -------------------------------------------
    DataArray := Image_GuiControl("184", 0, 0, DataArray) ; (184_1)(Obj_Pum_ImageText_EmailAddress)
    DataArray := Image_GuiControl("185", 0, 0, DataArray) ; (185_1)(Obj_Pum_ImageText_ContactName)
    DataArray := Image_GuiControl("186", 0, 0, DataArray) ; (186_1)(Obj_Pum_ImageText_PopUpMenuEmail)
    ; -------------------------------------------
    if (DataArray.83.2 == 1) ; (083_2)(Obj_Tom_Pum_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      DataArray.366.5 := "pumtom" ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      ; -------------------------------------------
      DataArray := _S1_C(DataArray)
      DataArray := _S2_H(DataArray)
      ; ------------------------------------------
      DataArray := Image_GuiControl("254", 0, 0, DataArray) ; (254_1)(Obj_MsgImg300x300)
      ; -------------------------------------------
      ;
      ; -------------------------------------------
      HasConnection := Url_ConnectCheck(flag=0x40)
      ; -------------------------------------------
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      if (HasConnection == 0)
      {
        DataArray := Image_GuiControl("084", "1b", 1, DataArray) ; (084_1)(Obj_Tom_FileUrlFolder)
      }
      else
      {
        DataArray := Image_GuiControl("084", "1a", 1, DataArray) ; (084_1)(Obj_Tom_FileUrlFolder)
      }
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; -------------------------------------------
      DataArray := Image_GuiControl("086", 1, 1, DataArray) ; (086_1)(Obj_Tom_MenuControlKey)
      ; -------------------------------------------
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      if (HasConnection == 0)
      {
        DataArray := Image_GuiControl("083", "2b", 1, DataArray) ; (083_1)(Obj_Tom_Pum)
      }
      else
      {
        DataArray := Image_GuiControl("083", "2a", 1, DataArray) ; (083_1)(Obj_Tom_Pum)
      }
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; -------------------------------------------
      DataArray := Image_GuiControl("114", 0, 1, DataArray) ; (114_1)(Obj_DisplayText_Title1)
      DataArray := Image_GuiControl("115", 0, 1, DataArray) ; (115_1)(Obj_DisplayText_Title2)
      DataArray := Image_GuiControl("141", 0, 1, DataArray) ; (141_1)(Obj_DisplayText_Title3)
      ; -------------------------------------------
      DataArray := Image_GuiControl("134", 0, 0, DataArray) ; (134_1)(Obj_ImageSelect1)
      DataArray := Image_GuiControl("135", 0, 0, DataArray) ; (135_1)(Obj_ImageSelect2)
      DataArray := Image_GuiControl("136", 0, 0, DataArray) ; (136_1)(Obj_ImageSelect3)
      ; -------------------------------------------
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; (Image_PathFolderOrName) This Script just sets Paths
      ; -------------------------------------------
      ArrayIn := [DataArray.367.5, DataArray.367.1, DataArray.290.2, "FileRunPng", DataArray.365.2, DataArray.363.12]
      ArrayOut := Image_PathFolderOrName(ArrayIn)
      FileRunPng := ArrayOut.1
      ; -------------------------------------------
      ; (Image_PathFolderOrName) This Script just sets Paths
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; (Image_PathFolderOrName) This Script just sets Paths
      ; -------------------------------------------
      ArrayIn := [DataArray.367.5, DataArray.367.1, DataArray.290.2, "FileNew135", DataArray.365.2, DataArray.363.12]
      ArrayOut := Image_PathFolderOrName(ArrayIn)
      FileNew135 := ArrayOut.1
      ; -------------------------------------------
      ; (Image_PathFolderOrName) This Script just sets Paths
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; (Image_PathFolderOrName) This Script just sets Paths
      ; -------------------------------------------
      ArrayIn := [DataArray.367.5, DataArray.367.1, DataArray.290.2, "FileDel135", DataArray.365.2, DataArray.363.12]
      ArrayOut := Image_PathFolderOrName(ArrayIn)
      FileDel135 := ArrayOut.1
      ; -------------------------------------------
      ; (Image_PathFolderOrName) This Script just sets Paths
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      global PopUpMenuAnimateNew135 := 0
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      if (!FileExist(FileNew135) or !FileExist(File135) or !FileExist(FileRunPng))
      {
        ;
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Start/Show (Jackhammer)
        global n_523 := 1 ; Start Frame Number
        global s_523 := 1 ; Show
        ; (523_1)(_Msg 4_)(_w480 x h270_)_Jackhammer)
        SetTimer, l_523, 150 ; (523_1)(_Msg 4_)(_w480 x h270_)_Jackhammer)
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Start/Show (Jackhammer)
        ;
      }
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; -------------------------------------------
      DataArray := _S3_S(DataArray)
      ; -------------------------------------------
      ;
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Stop (Animate) Jackhammer
      global s_523 := 0 ; Hide
      SetTimer, l_523, Off ; (523_1)(_Msg 4_)(_w480 x h270_)_Jackhammer)
      global ShowAnimationChange := 0
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Stop (Animate) Jackhammer
      ;
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Start/Stop (Animate) Pum_Building_Construct
      if (n_521 == 170)
      {
        ; -------------------------------------------
        DataArray := Image_GuiControl("521_137", 169, 0, DataArray) ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
        global s_521 := 0 ; Hide
        SetTimer, l_521, Off ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
        global ShowAnimationChange := 0
        ; -------------------------------------------
      }
      else
      {
        global s_521 := 1 ; Show
        SetTimer, l_521, 350 ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
      }
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Start/Stop (Animate) Pum_Building_Construct
      ;
    } ; (083_2)([ToM] Pum) is in Normal State
    ; -------------------------------------------
  } ; [End] if (InStr(ScriptType, "pum") > 0)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; -------------------------------------------
  DataArray := _S1_C(DataArray)
  DataArray := _S2_H(DataArray)
  DataArray := _S3_S(DataArray)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
