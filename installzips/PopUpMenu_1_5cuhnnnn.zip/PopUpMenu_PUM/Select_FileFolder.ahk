﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\Folder_WindowsUser.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Script_Running.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Splash_Script.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Script_Close.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Run_GetLink.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
global SelectFileFolderType
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Select_FileFolder(Lang, SelectFileFolderType, StartFolder, ThisPumPath) ; SelectFileFolderType(Lang, ["Folder"or"AnyFile"or"AnyImage"or"Application"or"Browser"], StartFolder, ThisPumPath) > ; [OutTarget, Arguments, UseLink (0,1), Selected_File, SelectedItems_LinkIcon]
{
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; 1 = A window's title must start with the specified WinTitle to be a match.
  SetTitleMatchMode, 1
  WinGet, Gui_Id, ID , Shortcut_Pop_Up_Menu ahk_class AutoHotkeyGUI
  WinSet, AlwaysOnTop, Off, ahk_id %Gui_Id%
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  CoordMode, Mouse , Screen
  MouseGetPos, CurrentPos_X, CurrentPos_Y
  ; -------------------------------------------
  File_SelectFileFolderType := A_AppData "\PopUpMenu_PUM\temp\File_SelectFileFolderType.txt"
  FileDelete, %File_SelectFileFolderType%
  ; -------------------------------------------
  FileEncoding, UTF-8 ; UTF-8
  FileAppend, %SelectFileFolderType%`n, %File_SelectFileFolderType% ; UTF-8
  FileAppend, %CurrentPos_X%`n, %File_SelectFileFolderType% ; UTF-8
  FileAppend, %CurrentPos_Y%`n, %File_SelectFileFolderType% ; UTF-8
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; -------------------------------------------
  WinGetClass, This_Class, A
  WinGet, This_Id , ID, ahk_class %This_Class%
  ; -------------------------------------------
  ;
  ; =============================================================================================
  ; LOCALISATION
  ; =============================================================================================
  ApplyBText  := "&1"
  CancelBText := "&0"
  ; [SETS]
  ;
  ; =============================================================================================
  if (SelectFileFolderType == "Folder") ; "PUM - Select a Folder"
  {
    ; -------------------------------------------
    SelectFileType := "egdsgdsgdgds.sdgsdgsfehdf"
    FileOrFolder := "Folder"
    ; -------------------------------------------
    if (StartFolder == "")
    {
      StartFolder := "c:\" 
    } ; [End] if (StartFolder == "")
    ; -------------------------------------------
    ; "PUM - Select a Folder"
    ; -------------------------------------------
    if (Lang == "de") ; (de German)
    {
      WindowTitle := "PUM - Wählen Sie einen Ordner aus"
    } ; End (de German)
    else if (Lang == "en") ; (en English)
    {
      WindowTitle := "PUM - Select a Folder"
    } ; End (en English)
    else if (Lang == "es") ; (es Spanish)
    {
      WindowTitle := "PUM - Seleccione una carpeta"
      FolderTitle := "PUM - Seleccione una carpeta"
    } ; End (es Spanish)
    else if (Lang == "fr") ; (fr French)
    {
      WindowTitle := "PUM - Sélectionnez un dossier"
    } ; End (fr French)
    else if (Lang == "it") ; (it Italian)
    {
      WindowTitle := "PUM - Seleziona una cartella"
    } ; End (it Italian)
    else if (Lang == "pl") ; (pl Polish)
    {
      WindowTitle := "PUM - Wybierz folder"
    } ; End (pl Polish)
    else if (Lang == "pt") ; (pt Portuguese)
    {
      WindowTitle := "PUM - Selecione uma pasta"
    } ; End (pt Portuguese)
    else if (Lang == "ru") ; (ru Russian)
    {
      WindowTitle := "PUM - Выберите папку"
    } ; End (ru Russian)
    else if (Lang == "sv") ; (sv Swedish)
    {
      WindowTitle := "PUM - Välj en mapp"
    } ; End (sv Swedish)
    else if (Lang == "tr") ; (tr Turkish)
    {
      WindowTitle := "PUM - Bir klasör seçin"
    } ; End (tr Turkish)
    ; -------------------------------------------
  } ; End (SelectFileFolderType == "Folder")
  ; -------------------------------------------
  else if (SelectFileFolderType == "AnyFile") ; "PUM - Select a Application or File" (Any File)
  {
    ; -------------------------------------------
    SelectFileType  := "*.*"  ; Any File
    FileOrFolder := "File"
    ; -------------------------------------------
    if (StartFolder == "")
    {
      StartFolder := A_ProgramsCommon ; Common Start Menu
      IfNotExist, %StartFolder%
      {
        StartFolder := A_Programs ; User Spicifc Start Menu
        IfNotExist, %StartFolder%
        {
          StartFolder := A_ProgramFiles ; Installed Programs Directory
          IfNotExist, %StartFolder%
          {
            StartFolder := A_WinDir
          } ; End IfNotExist, %StartFolder%
        } ; End IfNotExist, %StartFolder%
      } ; End IfNotExist, %StartFolder%
    } ; [End] if (StartFolder == "")
    ; -------------------------------------------
    ; "PUM - Select an Application or File"
    ; -------------------------------------------
    if (Lang == "de") ; (de German)
    {
      WindowTitle := "PUM - Wählen Sie eine Anwendung oder Datei aus"
    } ; End (de German)
    else if (Lang == "en") ; (en English)
    {
      WindowTitle := "PUM - Select an Application or File"
    } ; End (en English)
    else if (Lang == "es") ; (es Spanish)
    {
      WindowTitle := "PUM - Seleccione una aplicación o archivo"
    } ; End (es Spanish)
    else if (Lang == "fr") ; (fr French)
    {
      WindowTitle := "PUM - Sélectionnez une application ou un fichier"
    } ; End (fr French)
    else if (Lang == "it") ; (it Italian)
    {
      WindowTitle := "PUM - Seleziona un'applicazione o un file"
    } ; End (it Italian)
    else if (Lang == "pl") ; (pl Polish)
    {
      WindowTitle := "PUM - Wybierz aplikacje lub plik"
    } ; End (pl Polish)
    else if (Lang == "pt") ; (pt Portuguese)
    {
      WindowTitle := "PUM - Selecione um aplicativo ou arquivo"
    } ; End (pt Portuguese)
    else if (Lang == "ru") ; (ru Russian)
    {
      WindowTitle := "PUM - Выберите приложение или файл"
    } ; End (ru Russian)
    else if (Lang == "sv") ; (sv Swedish)
    {
      WindowTitle := "PUM - Välj ett program eller en fil"
    } ; End (sv Swedish)
    else if (Lang == "tr") ; (tr Turkish)
    {
      WindowTitle := "PUM - Bir uygulama veya dosya seçin"
    } ; End (tr Turkish)
    ; -------------------------------------------
  } ; End (SelectFileFolderType == "AnyFile")
  ; -------------------------------------------
  else if (SelectFileFolderType == "IcoImage") ; Special Folder Icons
  {
    ; -------------------------------------------
    SelectFileType  := "*.ico" ; ICO Image File
    FileOrFolder := "File"
    ; -------------------------------------------
    if (StartFolder == "")
    {
      RegRead, StartFolder, HKEY_CURRENT_USER, Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders, My Pictures
    } ; [End] if (StartFolder == "")
    ; -------------------------------------------
    ; "PUM - Special Folder Icons"
    ; -------------------------------------------
    if (Lang == "de") ; (de German)
    {
      WindowTitle := "PUM - Spezielle Ordner-Icons."
    } ; End (de German)
    else if (Lang == "en") ; (en English)
    {
      WindowTitle := "PUM - Special Folder Icons"
    } ; End (en English)
    else if (Lang == "es") ; (es Spanish)
    {
      WindowTitle := "PUM - Iconos de carpeta especiales"
    } ; End (es Spanish)
    else if (Lang == "fr") ; (fr French)
    {
      WindowTitle := "PUM - Icônes de dossiers spéciaux"
    } ; End (fr French)
    else if (Lang == "it") ; (it Italian)
    {
      WindowTitle := "PUM - Icone della cartella speciale"
    } ; End (it Italian)
    else if (Lang == "pl") ; (pl Polish)
    {
      WindowTitle := "PUM - Specjalne ikony folderów."
    } ; End (pl Polish)
    else if (Lang == "pt") ; (pt Portuguese)
    {
      WindowTitle := "PUM - Ícones especiais de pasta"
    } ; End (pt Portuguese)
    else if (Lang == "ru") ; (ru Russian)
    {
      WindowTitle := "PUM - Специальные значки папок"
    } ; End (ru Russian)
    else if (Lang == "sv") ; (sv Swedish)
    {
      WindowTitle := "PUM - Special mapp ikoner"
    } ; End (sv Swedish)
    else if (Lang == "tr") ; (tr Turkish)
    {
      WindowTitle := "PUM - Özel Klasör Simgeleri"
    } ; End (tr Turkish)
    ; -------------------------------------------
  } ; [End] else if (SelectFileFolderType == "IcoImage")
  ; -------------------------------------------
  else if (SelectFileFolderType == "AnyImage") ; SelectFileType  := "*.apng; *.avif; *.bmp; *.gif; *.ico; *.jfif; *.jpeg; *.jpg; *.png; *.svg; *.tif; *.tiff; *.webp" ; Image File
  {
    ; -------------------------------------------
    SelectFileType  := "*.apng; *.avif; *.bmp; *.gif; *.ico; *.jfif; *.jpeg; *.jpg; *.png; *.svg; *.tif; *.tiff; *.webp" ; Image File
    FileOrFolder := "File"
    ; -------------------------------------------
    if (StartFolder == "")
    {
      RegRead, StartFolder, HKEY_CURRENT_USER, Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders, My Pictures
    } ; [End] if (StartFolder == "")
    ; -------------------------------------------
    ; "PUM - Select an Image"
    ; -------------------------------------------
    if (Lang == "de") ; (de German)
    {
      WindowTitle := "PUM - Wählen Sie ein Bild aus"
    } ; End (de German)
    else if (Lang == "en") ; (en English)
    {
      WindowTitle := "PUM - Select an Image"
    } ; End (en English)
    else if (Lang == "es") ; (es Spanish)
    {
      WindowTitle := "PUM - Seleccione una imagen"
    } ; End (es Spanish)
    else if (Lang == "fr") ; (fr French)
    {
      WindowTitle := "PUM - Sélectionnez une image"
    } ; End (fr French)
    else if (Lang == "it") ; (it Italian)
    {
      WindowTitle := "PUM - Seleziona un'immagine"
    } ; End (it Italian)
    else if (Lang == "pl") ; (pl Polish)
    {
      WindowTitle := "PUM - Wybierz obraz"
    } ; End (pl Polish)
    else if (Lang == "pt") ; (pt Portuguese)
    {
      WindowTitle := "PUM - Selecione uma imagem."
    } ; End (pt Portuguese)
    else if (Lang == "ru") ; (ru Russian)
    {
      WindowTitle := "PUM - Выберите изображение"
    } ; End (ru Russian)
    else if (Lang == "sv") ; (sv Swedish)
    {
      WindowTitle := "PUM - Choose a picture"
    } ; End (sv Swedish)
    else if (Lang == "tr") ; (tr Turkish)
    {
      WindowTitle := "PUM - Bir resim seçin"
    } ; End (tr Turkish)
    ; -------------------------------------------
  } ; End (SelectFileFolderType == "AnyImage")
  ; -------------------------------------------
  else if (SelectFileFolderType == "Application") ; "PUM - Open file with this Application"
  {
    ; -------------------------------------------
    SelectFileType  := "*.bat; *.cmd; *.com; *.exe; *.lnk" ; Application File
    FileOrFolder := "File"
    ; -------------------------------------------
    if (StartFolder == "")
    {
      StartFolder := A_ProgramsCommon ; Common Start Menu
      IfNotExist, %StartFolder%
      {
        StartFolder := A_Programs ; User Spicifc Start Menu
        IfNotExist, %StartFolder%
        {
          StartFolder := A_ProgramFiles ; Installed Programs Directory
          IfNotExist, %StartFolder%
          {
            StartFolder := A_WinDir
          } ; End IfNotExist, %StartFolder%
        } ; End IfNotExist, %StartFolder%
      } ; End IfNotExist, %StartFolder%
    } ; [End] if (StartFolder == "")
    ; -------------------------------------------
    ; "PUM - Select an Application"
    ; -------------------------------------------
    if (Lang == "de") ; (de German)
    {
      WindowTitle := "PUM - Wählen Sie einen Antrag aus"
    } ; End (de German)
    else if (Lang == "en") ; (en English)
    {
      WindowTitle := "PUM - Select an Application"
    } ; End (en English)
    else if (Lang == "es") ; (es Spanish)
    {
      WindowTitle := "PUM - Seleccione una aplicación"
    } ; End (es Spanish)
    else if (Lang == "fr") ; (fr French)
    {
      WindowTitle := "PUM - Sélectionnez une application"
    } ; End (fr French)
    else if (Lang == "it") ; (it Italian)
    {
      WindowTitle := "PUM - Seleziona un'applicazione"
    } ; End (it Italian)
    else if (Lang == "pl") ; (pl Polish)
    {
      WindowTitle := "PUM - Wybierz aplikacje"
    } ; End (pl Polish)
    else if (Lang == "pt") ; (pt Portuguese)
    {
      WindowTitle := "PUM - Selecione um aplicativo"
    } ; End (pt Portuguese)
    else if (Lang == "ru") ; (ru Russian)
    {
      WindowTitle := "PUM - Выберите приложение"
    } ; End (ru Russian)
    else if (Lang == "sv") ; (sv Swedish)
    {
      WindowTitle := "PUM - Välj en applikation"
    } ; End (sv Swedish)
    else if (Lang == "tr") ; (tr Turkish)
    {
      WindowTitle := "PUM - Bir uygulama seçin"
    } ; End (tr Turkish)
    ; -------------------------------------------
  } ; End (SelectFileFolderType == "Application")
  ; -------------------------------------------
  else if (SelectFileFolderType == "Browser") ; "PUM - Open URL with this Internet Browser"
  {
    ; -------------------------------------------
    SelectFileType  := "avantvw.exe; brave.exe; browser.exe;chrome.exe; Cyberfox.exe; dragon.exe; firefox.exe; waterfox.exe; icedragon.exe; iexplore.exe; iridium.exe; Kingpin Private Browser.exe; k-meleon.exe; Safari.exe; seamonkey.exe; SlimBoat.exe; slimbrowser.exe; slimjet.exe; Spark.exe; Maxthon.exe; msedge.exe; opera.exe; palemoon.exe; UCBrowser.exe; vivaldi.exe; waterfox.exe; *.lnk" ; Internet Browsers
    FileOrFolder := "File"
    ; -------------------------------------------
    if (StartFolder == "")
    {
      StartFolder := A_ProgramsCommon ; Common Start Menu
      IfNotExist, %StartFolder%
      {
        StartFolder := A_Programs ; User Spicifc Start Menu
        IfNotExist, %StartFolder%
        {
          StartFolder := A_ProgramFiles ; Installed Programs Directory
          IfNotExist, %StartFolder%
          {
            StartFolder := A_WinDir
          } ; End IfNotExist, %StartFolder%
        } ; End IfNotExist, %StartFolder%
      } ; End IfNotExist, %StartFolder%
    } ; [End] if (StartFolder == "")
    ; -------------------------------------------
    ; "PUM - Select an Internet Browser"
    ; -------------------------------------------
    if (Lang == "de") ; (de German)
    {
      WindowTitle := "PUM - Wählen Sie einen Internetbrowser aus"
    } ; End (de German)
    else if (Lang == "en") ; (en English)
    {
      WindowTitle := "PUM - Select an Internet Browser"
    } ; End (en English)
    else if (Lang == "es") ; (es Spanish)
    {
      WindowTitle := "PUM - Seleccione un navegador de Internet"
    } ; End (es Spanish)
    else if (Lang == "fr") ; (fr French)
    {
      WindowTitle := "PUM - Sélectionnez un navigateur Internet"
    } ; End (fr French)
    else if (Lang == "it") ; (it Italian)
    {
      WindowTitle := "PUM - Seleziona un browser Internet"
    } ; End (it Italian)
    else if (Lang == "pl") ; (pl Polish)
    {
      WindowTitle := "PUM - Wybierz przegladarke internetowa"
    } ; End (pl Polish)
    else if (Lang == "pt") ; (pt Portuguese)
    {
      WindowTitle := "PUM - Selecione um navegador da Internet"
    } ; End (pt Portuguese)
    else if (Lang == "ru") ; (ru Russian)
    {
      WindowTitle := "PUM - Выберите интернет-браузер"
    } ; End (ru Russian)
    else if (Lang == "sv") ; (sv Swedish)
    {
      WindowTitle := "PUM - Välj en webbläsare"
    } ; End (sv Swedish)
    else if (Lang == "tr") ; (tr Turkish)
    {
      WindowTitle := "PUM - Bir Internet tarayicisi seçin"
    } ; End (tr Turkish)
    ; -------------------------------------------
  } ; [End] (SelectFileFolderType == "Browser")
  ; -------------------------------------------
  else if (SelectFileFolderType == "PumRestore") ; PopUpMenu_Pum_(DATE TIME).zip
  {
    ; -------------------------------------------
    ;~ SelectFileType  := "PopUpMenu_Pum_(*.zip"  ; PopUpMenu_Pum_(DATE TIME).zip
    SelectFileType  := "*.zip"  ; PopUpMenu_Pum_(DATE TIME).zip
    FileOrFolder := "File"
    ; -------------------------------------------
    if (ThisPumPath == "")
    {
      ThisPumPath := A_AppData "\PopUpMenu_PUM\pums\pumdefault"
    }
    ; -------------------------------------------
    if (StartFolder == "")
    {
      StartFolder := A_Desktop
    } ; [End] if (StartFolder == "")
    ; -------------------------------------------
    if (Lang == "de") ; (de German)
    {
      WindowTitle := "PUM - Wählen Sie PopUpMenu_Pum_(Datum Uhrzeit).zip"
    } ; End (de German)
    else if (Lang == "en") ; (en English)
    {
      WindowTitle := "PUM - Select PopUpMenu_Pum_(Date Time).zip"
    } ; End (en English)
    else if (Lang == "es") ; (es Spanish)
    {
      WindowTitle := "PUM - Seleccione PopUpMenu_Pum_(Fecha Hora).zip"
    } ; End (es Spanish)
    else if (Lang == "fr") ; (fr French)
    {
      WindowTitle := "PUM - Sélectionnez PopUpMenu_Pum_(Date Heure).zip"
    } ; End (fr French)
    else if (Lang == "it") ; (it Italian)
    {
      WindowTitle := "PUM - Selezionare PopUpMenu_Pum_(Data Ora).zip"
    } ; End (it Italian)
    else if (Lang == "pl") ; (pl Polish)
    {
      WindowTitle := "PUM - Wybierz PopUpMenu_Pum_(Data Godzina).zip"
    } ; End (pl Polish)
    else if (Lang == "pt") ; (pt Portuguese)
    {
      WindowTitle := "PUM - Selecione PopUpMenu_Pum_(Data Hora).zip"
    } ; End (pt Portuguese)
    else if (Lang == "ru") ; (ru Russian)
    {
      WindowTitle := "PUM - Выберите PopUpMenu_Pum_(дата и время).zip"
    } ; End (ru Russian)
    else if (Lang == "sv") ; (sv Swedish)
    {
      WindowTitle := "PUM - Välj PopUpMenu_Pum_(Datum Time).zip"
    } ; End (sv Swedish)
    else if (Lang == "tr") ; (tr Turkish)
    {
      WindowTitle := "PUM - PopUpMenu_Pum_(Tarih Saat).zip'i seçin"
    } ; End (tr Turkish)
    ; -------------------------------------------
  } ; (SelectFileFolderType == "PumRestore")
  ; =============================================================================================
  ;
  ; =============================================================================================
  ; INDIVIDUAL SETTINGS
  ; =============================================================================================
  ; Button arrangement: 1 = (Cancel - Apply), 0 = (Apply - Cancel)
  Static CancelApply := 1
  ; Option = I & No File is selected
  ; (1 = show MsgBox) (0 = only sound)
  Static WarnMsgB    := 0
  ; =============================================================================================
  ;
  ; =============================================================================================
  ; WINDOWS-VERSION ISSUES
  ; =============================================================================================
  Static WinVer := DllCall("GetVersion") & 0xff
  if (WinVer < 6) ; Win XP
  {
    List := "SysListView321", AltProb := 1, ButA := 2, ButB := 3
  }
  ; -------------------------------------------
  if (WinVer >= 6) ;  Win 10
  {
    List := "DirectUIHWND2", AltProb := 0, ButA := 1, ButB := 2  
  }
  ; =============================================================================================
  ;
  ; =============================================================================================
  ; PROCESSING THE PARAMETERS
  ; =============================================================================================
  if !(WindowTitle)
  {
    WindowTitle := "PUM - "
  }
  ; -------------------------------------------
  if !(StartFolder)
  {
    StartFolder := "c:"
  }
  ; -------------------------------------------
  if (Apply)
  {
    ApplyBText := Apply
  }
  ; -------------------------------------------
  if (Cancel)
  {
    CancelBText := Cancel
  }
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (PosA := InStr(ApplyBText, "&"))
  {
    LetA := SubStr(ApplyBText, PosA + 1, 1)
  }
  ; -------------------------------------------
  if (PosC := InStr(CancelBText, "&"))
  {
    LetC := SubStr(CancelBText, PosC + 1, 1)
  }
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  SetTimer, SIWaitAndAdapt, 20
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ScriptPath := A_ProgramFiles "\PopUpMenu_PUM\Config_SelectFileFolder.ahk"
  ; -------------------------------------------
  if (Script_Running(ScriptPath) == 0) ; (FileSelectGui)
  {
    Run, %ScriptPath%
  }
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  FileSelectFile, DoubleClick, , %StartFolder%, %WindowTitle%, %SelectFileType%
  ; -------------------------------------------
  ;
  ; -------------------------------------------
  WinWaitClose, %WindowTitle%
  ; =============================================================================================
  ;
  ; =============================================================================================
  ; Tidying up, returning SelectedItems
  ; =============================================================================================
  Hotkey, !%LetA%,  Off, UseErrorLevel
  Hotkey, !%LetC%,  Off, UseErrorLevel
  Hotkey, Enter,    Off, UseErrorLevel
  Gui ButA: Destroy
  Gui ButB: Destroy
  ; -------------------------------------------
  WinActivate, ahk_id %This_Id%
  ; -------------------------------------------
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Return This
  ;
  if (SelectedItems_OutTarget == "")
  {
    SelectedItems_OutTarget := SelectedItems
  }
  ; -------------------------------------------
  if (SelectedItems_UseLink == "")
  {
    if (InStr(SelectedItems_LinkIcon, "`{") > 0)
    {
      SelectedItems_UseLink := 1
    }
    else
    {
      SelectedItems_UseLink := 0
    }
  }
  else if (SelectedItems_UseLink == 1)
  {
    SelectedItems_RunArguments := ""
  }
  ; -------------------------------------------
  ReturnArray := [SelectedItems_OutTarget, SelectedItems_RunArguments, SelectedItems_UseLink, SelectedItems, SelectedItems_LinkIcon, SelectedItems_LinkName]
  return ReturnArray
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Return This
  ; =============================================================================================
  ;
  ; =============================================================================================
  ; ADAPTING THE DIALOG WINDOW
  ; =============================================================================================
  ; Timer
  SIWaitAndAdapt:
  {
    ; Wait for the dialog window
    if !(IdDialog := WinExist(WindowTitle))
    {
      return
    }
    ; -------------------------------------------
	  ; and go on!
    SetTimer, , Off
    ; -------------------------------------------
	  ; Getting the coordinates/size of the
	  ; dialog window (relative to screen)
    WinGetPos, , , WinW, WinH, %WindowTitle%
    ; -------------------------------------------
	  ; and of its controls (relative to window)
    ControlGetPos, , ListY, , ListH, %List%
    ControlGet, IdButA, Hwnd, , Button%ButA%
    ControlGet, IdButB, Hwnd, , Button%ButB%
    WinGetPos, ButAX, ButAY, ButAW, ButAH, ahk_id %IdButA%
    WinGetPos, ButBX, ButBY, ButBW, ButBH, ahk_id %IdButB%
    ; -------------------------------------------
	  ; Calculating the coordinates of the
    AreaX1 := 35, AreaX2 := WinW - 35
    ; -------------------------------------------
	  ; adaptation area (inside window)
    AreaY1 := ListY + ListH, AreaY2 := WinH
    ; -------------------------------------------
	  ; Hiding all controls present
    WinGet, ControlList, ControlList, %WindowTitle%
    ; -------------------------------------------
    Loop, Parse, ControlList, `n
    {
      ControlGetPos, x, y, , , %A_LoopField%, %WindowTitle%
      if ((x > AreaX1) && (x < AreaX2) && (y > AreaY1) && (y < AreaY2) && (SubStr(A_LoopField, 1, 7) != "Button" . ButA) && (SubStr(A_LoopField, 1, 7) != "Button" . ButB))
      {
        Control, Hide, , %A_LoopField%, %WindowTitle%
      }
    }
    ; -------------------------------------------
	  ; Disabling the shortcut letters of the
    ControlGetText, TextA, , ahk_id %IdButA%
	  ; two buttons to be used for the
    ControlGetText, TextB, , ahk_id %IdButB%
	  ; Apply and Cancel buttons
    TextA := RegExReplace(TextA, "&")
    TextB := RegExReplace(TextB, "&")
    ControlSetText, , %TextA%, ahk_id %IdButA%
    ControlSetText, , %TextB%, ahk_id %IdButB%
    ; -------------------------------------------
	  ; Setting the border of the
    Brdr := 2
	  ; Apply and Cancel buttons
    BtnAW := ButAW - 2*Brdr, BtnAH := ButAH - 2*Brdr
    BtnBW := ButBW - 2*Brdr, BtnBH := ButBH - 2*Brdr
    ; -------------------------------------------
	  ; Assigning the Apply and
    if (CancelApply) ; Cancel buttons to
    {
      LabA := "SICancel"
      LabB := "SIApply"
      BolA := "normal"
      BolB := "bold"
      TxtA := CancelBText
      TxtB := ApplyBText
    }
    else
    {
      LabA := "SIApply"
      LabB := "SICancel"
      BolA := "bold"
      BolB := "normal"
      TxtA := ApplyBText
      TxtB := CancelBText
     }
    ; -------------------------------------------
    Gui, ButA: +ToolWindow -Caption -DPIScale ; Creating a child gui
    Gui, ButA: +Parent%IdButA% ; of the ButtonA
    Gui, ButA: Font, %BolA%
    Gui, ButA: Add, Picture, x2 y2 w%BtnAW% h%BtnAH% g%LabA%, %A_ProgramFiles%\PopUpMenu_PUM\image\gui\Select_FileFolder_Cancel.png
    Gui, ButA: Show, x0 y0 w%ButAW% h%ButAH%
    ; -------------------------------------------
    Gui, ButB: +ToolWindow -Caption -DPIScale ; Creating a child gui
    Gui, ButB: +Parent%IdButB% ; of the ButtonB
    Gui, ButB: Font, %BolB%
    Gui, ButB: Add, Picture, x2 y2 w%BtnBW% h%BtnBH% g%LabB%, %A_ProgramFiles%\PopUpMenu_PUM\image\gui\Select_FileFolder_Ok.png
    Gui, ButB: Show, x0 y0 w%ButBW% h%ButBH% ; End Cancel.png
    ; -------------------------------------------
    WinActivate, %WindowTitle%
    SelectedItems := ""
    ; -------------------------------------------
    ;~ Hotkey, if WinActive(WindowTitle)
    Hotkey, IfWinActive, %WindowTitle% ; Defining shortcut-letter hotkeys which
    ; -------------------------------------------
    if (LetA) ; are active in the dialog window
    {
      Hotkey, !%LetA%, SIApply,  On UseErrorLevel
    }
    ; -------------------------------------------
    if (LetC)
    {
      Hotkey, !%LetC%, SICancel, On UseErrorLevel
    }
    ; -------------------------------------------
    Hotkey, Enter, SIEnter, On UseErrorLevel
    ; -------------------------------------------
  } ; End SIWaitAndAdapt:
  return
  ; =============================================================================================
  ;
  ; =============================================================================================
  ; BUTTON AND HOTKEY ACTIONS
  ; =============================================================================================
  SIApply: ; Button and hotkey
  {
    ; -------------------------------------------
    WinActivate, %WindowTitle%
	  ; -------------------------------------------
    if (SelectedItems == "") ; Nothing Selected (or Folder is Selected)
    {
      ; -------------------------------------------
      ClipboardIs := ClipboardAll ; Getting the selected item(s)
      Clipboard := "" ; using Ctrl+c and Clipboard
      WinWaitActive, %WindowTitle%
      ControlFocus, %List%
      SendInput, ^c
      ClipWait, 0.5
      SelectedItems := Clipboard
      ; -------------------------------------------
      if (SelectedItems == "") ; Nothing Selected (Clipboard is Empty)
      {
        ; -------------------------------------------
        if (SelectFileFolderType == "Folder") ; SelectFileType := "egdsgdsgdgds.sdgsdgsfehdf" 
        {
          ; -------------------------------------------
          Clipboard := ""
          Send, {Ctrl Down}l{Ctrl Up}
          Sleep, 100
          Send, {Ctrl Down}c{Ctrl Up}
          ClipWait, 0.5
          ThisPath := Clipboard
          Send, {Tab 3}
          ; -------------------------------------------
          if (ThisPath == "Music" or ThisPath == "Pictures" or ThisPath == "Videos" or ThisPath == "Documents" or ThisPath == "Start Menu" or ThisPath == "Desktop" or ThisPath == "Downloads")
          {
            ; Resets ThisPath From Above
            ThisPath := Folder_WindowsUser(ThisPath, 0) ; Folder, Public [ 0/1] > FoundFolder
          }
          ; -------------------------------------------
          DriveLetter := SubStr(ThisPath, 1, 2)
          StringLower, DriveLetter, DriveLetter
          if (DriveLetter != "a:" && DriveLetter != "b:" && DriveLetter != "c:" && DriveLetter != "d:" && DriveLetter != "e:" && DriveLetter != "f:" && DriveLetter != "g:" && DriveLetter != "h:" && DriveLetter != "i:" && DriveLetter != "j:" && DriveLetter != "k:" && DriveLetter != "l:" && DriveLetter != "m:" && DriveLetter != "n:" && DriveLetter != "o:" && DriveLetter != "p:" && DriveLetter != "q:" && DriveLetter != "r:" && DriveLetter != "s:" && DriveLetter != "t:" && DriveLetter != "u:" && DriveLetter != "v:" && DriveLetter != "w:" && DriveLetter != "x:" && DriveLetter != "y:" && DriveLetter != "z:")
          {
            ; -------------------------------------------
            SetTitleMatchMode, 1
            WinGet, FileSelectGui_Id, ID , PUM -  ahk_class #32770
            WinSet, AlwaysOnTop, Off, ahk_id %FileSelectGui_Id%
            ; -------------------------------------------
            Splash_Script("407", 1000) ; (407)(Splash Error Image File: A Folder is Not Selected)
            ; -------------------------------------------
            WinSet, AlwaysOnTop, On, ahk_id %FileSelectGui_Id%
            ; -------------------------------------------
          } ; [End] if (DriveLetter != "DriveLetter")
          ; -------------------------------------------
          else ; OK
          {
            SelectedItems := ThisPath
          } ; [End] else ; OK
          ; -------------------------------------------
        } ; End (SelectFileFolderType == "Folder") ; SelectFileType := "egdsgdsgdgds.sdgsdgsfehdf" 
        ; -------------------------------------------
        else if (SelectFileFolderType == "IcoImage") ; SelectFileType := "*.ico"
        {
          ; -------------------------------------------
          SetTitleMatchMode, 1
          WinGet, FileSelectGui_Id, ID , PUM -  ahk_class #32770
          WinSet, AlwaysOnTop, Off, ahk_id %FileSelectGui_Id%
          ; -------------------------------------------
          Splash_Script("442", 1000) ; (442)(Splash Error Image File: Icon Not Select)
          ; -------------------------------------------
          WinSet, AlwaysOnTop, On, ahk_id %FileSelectGui_Id%
          ; -------------------------------------------
        } ; [End] else if (SelectFileFolderType == "IcoImage") ; SelectFileType := "*.ico"
        ; -------------------------------------------
        else if (SelectFileFolderType == "PumRestore") ; PopUpMenu_Pum_(DATE TIME).zip
        {
          ; -------------------------------------------
          SetTitleMatchMode, 1
          WinGet, FileSelectGui_Id, ID , PUM -  ahk_class #32770
          WinSet, AlwaysOnTop, Off, ahk_id %FileSelectGui_Id%
          ; -------------------------------------------
          Splash_Script("490", 1000) ; (490)(Splash Error: [pum Logo Image] pum Backup Zip Not Selected)
          ; -------------------------------------------
          WinSet, AlwaysOnTop, On, ahk_id %FileSelectGui_Id%
          ; -------------------------------------------
        } ; else if (SelectFileFolderType == "PumRestore") ; PopUpMenu_Pum_(DATE TIME).zip
        ; -------------------------------------------
        else if (SelectFileFolderType == "AnyFile") ; SelectFileType := "*.*"
        {
          ; -------------------------------------------
          SetTitleMatchMode, 1
          WinGet, FileSelectGui_Id, ID , PUM -  ahk_class #32770
          WinSet, AlwaysOnTop, Off, ahk_id %FileSelectGui_Id%
          ; -------------------------------------------
          Splash_Script("412", 1000) ; (412)(Splash Error Image File: A File is Not Selected)
          ; -------------------------------------------
          WinSet, AlwaysOnTop, On, ahk_id %FileSelectGui_Id%
          ; -------------------------------------------
        } ; End (SelectFileFolderType == "AnyFile") ; SelectFileType := "*.*"
        ; -------------------------------------------
        else if (SelectFileFolderType == "AnyImage") ; SelectFileType := "*.apng; *.bmp; *.gif; *.ico; *.jfif; *.jpeg; *.jpg; *.png; *.svg; *.tif; *.tiff; *.webp"
        {
          ; -------------------------------------------
          SetTitleMatchMode, 1
          WinGet, FileSelectGui_Id, ID , PUM -  ahk_class #32770
          WinSet, AlwaysOnTop, Off, ahk_id %FileSelectGui_Id%
          ; -------------------------------------------
          Splash_Script("418", 1000) ; (418)(Splash Error Image File: No Image Selected)
          ; -------------------------------------------
          WinSet, AlwaysOnTop, On, ahk_id %FileSelectGui_Id%
          ; -------------------------------------------
        } ; End (SelectFileFolderType == "AnyImage") ; SelectFileType  := "*.apng; *.bmp; *.gif; *.ico; *.jfif; *.jpeg; *.jpg; *.png; *.svg; *.tif; *.tiff; *.webp"
        ; -------------------------------------------
        else if (SelectFileFolderType == "Application") ; SelectFileType  := "*.bat; *.cmd; *.com; *.exe; *.lnk"
        {
          ; -------------------------------------------
          SetTitleMatchMode, 1
          WinGet, FileSelectGui_Id, ID , PUM -  ahk_class #32770
          WinSet, AlwaysOnTop, Off, ahk_id %FileSelectGui_Id%
          ; -------------------------------------------
          Splash_Script("433", 1000) ; (433)(Splash Error Image File: The Selected is Not a Application)
          ; -------------------------------------------
          WinSet, AlwaysOnTop, On, ahk_id %FileSelectGui_Id%
          ; -------------------------------------------
        } ; End (SelectFileFolderType == "Application") ; SelectFileType  := "*.bat; *.cmd; *.com; *.exe; *.lnk"
        ; -------------------------------------------
        else if (SelectFileFolderType == "Browser") ; SelectFileType := Browser List and (*.lnk)
        {
          ; -------------------------------------------
          SetTitleMatchMode, 1
          WinGet, FileSelectGui_Id, ID , PUM -  ahk_class #32770
          WinSet, AlwaysOnTop, Off, ahk_id %FileSelectGui_Id%
          ; -------------------------------------------
          Splash_Script("431", 1000) ; (431)(Splash Error Image File: Internet Browser Not Selected)
          ; -------------------------------------------
          WinSet, AlwaysOnTop, On, ahk_id %FileSelectGui_Id%
          ; -------------------------------------------
        } ; [End] else if (SelectFileFolderType == "Browser") ; SelectFileType := Browser List and (*.lnk)
        ; -------------------------------------------
      } ; [End] else if (SelectedItems == "") ; Nothing Selected (Clipboard is Empty)
      else if (SelectedItems != "") ; Something Is Selected
      {
        ; -------------------------------------------
        if (SelectFileFolderType == "Folder") ; SelectFileType := "egdsgdsgdgds.sdgsdgsfehdf" 
        {
        ; -------------------------------------------
          SplitPath, SelectedItems, , , SelectedItems_Ext
          StringLower, SelectedItems_Ext, SelectedItems_Ext
          ; -------------------------------------------
          if (SelectedItems_Ext == "lnk")
          {
            ; -------------------------------------------
            LinkArray:= Run_GetLink(SelectedItems, ThisPumPath) ; ThisLink, StringLink["Link","String"] > [Target, Arguments, UseLink, LinkIcon, NameLink]
            SelectedItems_OutTarget      := LinkArray.1
            SelectedItems_RunArguments   := LinkArray.2
            SelectedItems_UseLink        := LinkArray.3
            SelectedItems_LinkIcon       := LinkArray.4
            SelectedItems_LinkName       := LinkArray.5
            SelectedItems_OutTargetExt   := LinkArray.6
            SelectedItems_OutTargetDrive := LinkArray.7
            ; -------------------------------------------
            if (SelectedItems_OutTargetExt != "")
            {
              ; -------------------------------------------
              SetTitleMatchMode, 1
              WinGet, FileSelectGui_Id, ID , PUM -  ahk_class #32770
              WinSet, AlwaysOnTop, Off, ahk_id %FileSelectGui_Id%
              ; -------------------------------------------
              Splash_Script("407", 1000) ; (407)(Splash Error Image File: A Folder is Not Selected)
              ; -------------------------------------------
              WinSet, AlwaysOnTop, On, ahk_id %FileSelectGui_Id%
              ; -------------------------------------------                            
              SelectedItems := ""
              SelectedItems_OutTarget    := ""
              SelectedItems_RunArguments := ""
              SelectedItems_UseLink      := 0
              SelectedItems_LinkIcon     := ""
              SelectedItems_LinkName     := ""
              ; -------------------------------------------
            } ; [End] if (OutTarget_Ext != "")
            ; -------------------------------------------
            else if (SelectedItems_OutTargetDrive != "a:" && SelectedItems_OutTargetDrive != "b:" && SelectedItems_OutTargetDrive != "c:" && SelectedItems_OutTargetDrive != "d:" && SelectedItems_OutTargetDrive != "e:" && SelectedItems_OutTargetDrive != "f:" && SelectedItems_OutTargetDrive != "g:" && SelectedItems_OutTargetDrive != "h:" && SelectedItems_OutTargetDrive != "i:" && SelectedItems_OutTargetDrive != "j:" && SelectedItems_OutTargetDrive != "k:" && SelectedItems_OutTargetDrive != "l:" && SelectedItems_OutTargetDrive != "m:" && SelectedItems_OutTargetDrive != "n:" && SelectedItems_OutTargetDrive != "o:" && SelectedItems_OutTargetDrive != "p:" && SelectedItems_OutTargetDrive != "q:" && SelectedItems_OutTargetDrive != "r:" && SelectedItems_OutTargetDrive != "s:" && SelectedItems_OutTargetDrive != "t:" && SelectedItems_OutTargetDrive != "u:" && SelectedItems_OutTargetDrive != "v:" && SelectedItems_OutTargetDrive != "w:" && SelectedItems_OutTargetDrive != "x:" && SelectedItems_OutTargetDrive != "y:" && SelectedItems_OutTargetDrive != "z:")
            {
              ; -------------------------------------------
              SetTitleMatchMode, 1
              WinGet, FileSelectGui_Id, ID , PUM -  ahk_class #32770
              WinSet, AlwaysOnTop, Off, ahk_id %FileSelectGui_Id%
              ; -------------------------------------------
              Splash_Script("407", 1000) ; (407)(Splash Error Image File: A Folder is Not Selected)
              ; -------------------------------------------
              WinSet, AlwaysOnTop, On, ahk_id %FileSelectGui_Id%
              ; -------------------------------------------                            
              SelectedItems := ""
              SelectedItems_OutTarget    := ""
              SelectedItems_RunArguments := ""
              SelectedItems_UseLink      := 0
              SelectedItems_LinkIcon     := ""
              SelectedItems_LinkName     := ""
              ; -------------------------------------------
            } ; [End] OutTarget_Drive is NOT a Drive Letter
            else ; OK
            {
              ; -------------------------------------------
              SelectedItems := SelectedItems_OutTarget ; SelectedItems_OutTarget is a Link to a Folder
              ; -------------------------------------------
            } ; [End] else ; OK
            ; -------------------------------------------
          } ; [End] if (SelectedItems_Ext == "lnk")
          ; -------------------------------------------
          else if (SelectedItems_Ext == "url")
          {
            ; -------------------------------------------
            SetTitleMatchMode, 1
            WinGet, FileSelectGui_Id, ID , PUM -  ahk_class #32770
            WinSet, AlwaysOnTop, Off, ahk_id %FileSelectGui_Id%
            ; -------------------------------------------
            Splash_Script("407", 1000) ; (407)(Splash Error Image File: A Folder is Not Selected)
            ; -------------------------------------------
            WinSet, AlwaysOnTop, On, ahk_id %FileSelectGui_Id%
            ; -------------------------------------------                                                
            SelectedItems := ""
            SelectedItems_OutTarget    := ""
            SelectedItems_RunArguments := ""
            SelectedItems_UseLink      := 0
            SelectedItems_LinkIcon     := ""
            SelectedItems_LinkName     := ""
            ; -------------------------------------------
          } ; [End] else if (SelectedItems_Ext == "url")
          ; -------------------------------------------
        } ; [End] if (SelectFileFolderType == "Folder" && SelectedItems != "")
        ; -------------------------------------------
        else if (SelectFileFolderType == "IcoImage") ; SelectFileType := "*.ico"
        {
          ; -------------------------------------------
          SplitPath, SelectedItems, , , SelectedItems_Ext
          StringLower, SelectedItems_Ext, SelectedItems_Ext
          ; -------------------------------------------
          if (SelectedItems_Ext == "") ; (SelectedItems is a Folder) (Send ENTER)
          {
            ; -------------------------------------------
            SelectedItems := ""
            SelectedItems_OutTarget    := ""
            SelectedItems_RunArguments := ""
            SelectedItems_UseLink      := 0
            SelectedItems_LinkIcon     := ""
            SelectedItems_LinkName     := ""
            Send, {Enter}
            ; -------------------------------------------
          } ; End (SelectedItems_Ext == "")
          ; -------------------------------------------
          else if (SelectedItems_Ext != "ico") ; (ERROR) 442 (Icon Not Select)
          {
            ; -------------------------------------------
            SelectedItems := ""
            SelectedItems_OutTarget    := ""
            SelectedItems_RunArguments := ""
            SelectedItems_UseLink      := 0
            SelectedItems_LinkIcon     := ""
            SelectedItems_LinkName     := ""
            ; -------------------------------------------
            SetTitleMatchMode, 1
            WinGet, FileSelectGui_Id, ID , PUM -  ahk_class #32770
            WinSet, AlwaysOnTop, Off, ahk_id %FileSelectGui_Id%
            ; -------------------------------------------
            Splash_Script("442", 1000) ; (442)(Splash Error Image File: Icon Not Select)
            ; -------------------------------------------
            WinSet, AlwaysOnTop, On, ahk_id %FileSelectGui_Id%
            ; -------------------------------------------                                                
          } ; [End] else if (SelectedItems_Ext != "ico")
          ; -------------------------------------------
        } ; [End] else if (SelectFileFolderType == "IcoImage") ; SelectFileType := "*.ico"
        ; -------------------------------------------
        else if (SelectFileFolderType == "PumRestore") ; PopUpMenu_Pum_(DATE TIME).zip
        {
          ; -------------------------------------------
          SplitPath, SelectedItems, , , SelectedItems_Ext, SelectedItems_Name
          StringLower, SelectedItems_Ext, SelectedItems_Ext
          ; -------------------------------------------
          if (SelectedItems_Ext == "") ; (SelectedItems is a Folder) (Send ENTER)
          {
            ; -------------------------------------------
            SelectedItems := ""
            SelectedItems_OutTarget    := ""
            SelectedItems_RunArguments := ""
            SelectedItems_UseLink      := 0
            SelectedItems_LinkIcon     := ""
            SelectedItems_LinkName     := ""
            Send, {Enter}
            ; -------------------------------------------
          } ; End (SelectedItems_Ext == "")
          ; -------------------------------------------
          else if (SelectedItems_Ext != "zip") ; (ERROR) 490 (pum Backup Zip Not Selected)
          {
            ; -------------------------------------------
            SelectedItems := ""
            SelectedItems_OutTarget    := ""
            SelectedItems_RunArguments := ""
            SelectedItems_UseLink      := 0
            SelectedItems_LinkIcon     := ""
            SelectedItems_LinkName     := ""
            ; -------------------------------------------
            SetTitleMatchMode, 1
            WinGet, FileSelectGui_Id, ID , PUM -  ahk_class #32770
            WinSet, AlwaysOnTop, Off, ahk_id %FileSelectGui_Id%
            ; -------------------------------------------
            Splash_Script("490", 1000) ; (490)(Splash Error: [pum Logo Image] pum Backup Zip Not Selected)
            ; -------------------------------------------
            WinSet, AlwaysOnTop, On, ahk_id %FileSelectGui_Id%
            ; -------------------------------------------                                                
          } ; (SelectedItems_Ext != "zip")
          ; -------------------------------------------
          else if (SubStr(SelectedItems_Name, 1, 15) != "PopUpMenu_Pum_(")
          {
            ; -------------------------------------------
            SelectedItems := ""
            SelectedItems_OutTarget    := ""
            SelectedItems_RunArguments := ""
            SelectedItems_UseLink      := 0
            SelectedItems_LinkIcon     := ""
            SelectedItems_LinkName     := ""
            ; -------------------------------------------
            SetTitleMatchMode, 1
            WinGet, FileSelectGui_Id, ID , PUM -  ahk_class #32770
            WinSet, AlwaysOnTop, Off, ahk_id %FileSelectGui_Id%
            ; -------------------------------------------
            Splash_Script("490", 1000) ; (490)(Splash Error: [pum Logo Image] pum Backup Zip Not Selected)
            ; -------------------------------------------
            WinSet, AlwaysOnTop, On, ahk_id %FileSelectGui_Id%
            ; -------------------------------------------                                                
          } ; (SubStr(SelectedItems_Name, 1, 15) != "PopUpMenu_Pum_(")
          ; -------------------------------------------
        } ; else if (SelectFileFolderType == "PumRestore") ; PopUpMenu_Pum_(DATE TIME).zip
        ; -------------------------------------------
        else if (SelectFileFolderType == "AnyFile") ; SelectFileType := "*.*"
        {
          ; -------------------------------------------
          SplitPath, SelectedItems, , , SelectedItems_Ext
          StringLower, SelectedItems_Ext, SelectedItems_Ext
          ; -------------------------------------------
          if (SelectedItems_Ext == "") ; (SelectedItems is a Folder) (Send ENTER)
          {
            ; -------------------------------------------
            SelectedItems := ""
            SelectedItems_OutTarget    := ""
            SelectedItems_RunArguments := ""
            SelectedItems_UseLink      := 0
            SelectedItems_LinkIcon     := ""
            SelectedItems_LinkName     := ""
            Send, {Enter}
            ; -------------------------------------------
          } ; End (SelectedItems_Ext == "")
          ; -------------------------------------------
          else if (SelectedItems_Ext == "lnk")
          {
            ; -------------------------------------------
            LinkArray:= Run_GetLink(SelectedItems, ThisPumPath) ; ThisLink, StringLink["Link","String"] > [Target, Arguments, UseLink, LinkIcon, NameLink]
            SelectedItems_OutTarget     := LinkArray.1
            SelectedItems_RunArguments  := LinkArray.2
            SelectedItems_UseLink       := LinkArray.3
            SelectedItems_LinkIcon      := LinkArray.4
            SelectedItems_LinkName      := LinkArray.5
            SelectedItems_OutTarget_Ext := LinkArray.6
            ; -------------------------------------------
            if (SelectedItems_OutTarget == "") ;  ; (ERROR) 412 (A File is Not Selected)
            {
              ; -------------------------------------------
              SelectedItems := ""
              SelectedItems_OutTarget    := ""
              SelectedItems_RunArguments := ""
              SelectedItems_UseLink      := 0
              SelectedItems_LinkIcon     := ""
              SelectedItems_LinkName     := ""
              ; -------------------------------------------
              SetTitleMatchMode, 1
              WinGet, FileSelectGui_Id, ID , PUM -  ahk_class #32770
              WinSet, AlwaysOnTop, Off, ahk_id %FileSelectGui_Id%
              ; -------------------------------------------
              Splash_Script("412", 1000) ; (412)(Splash Error Image File: A File is Not Selected)
              ; -------------------------------------------
              WinSet, AlwaysOnTop, On, ahk_id %FileSelectGui_Id%
              ; -------------------------------------------                                                                                    
            } ; [End] if (SelectedItems_RunArguments == "")
            else if (SelectedItems_OutTarget_Ext == "") ; The Link File is to a Folder
            {
              SelectedItems := ""
              SelectedItems_OutTarget    := ""
              SelectedItems_RunArguments := ""
              SelectedItems_UseLink      := 0
              SelectedItems_LinkIcon     := ""
              SelectedItems_LinkName     := ""
              Send, {Enter}
            }
            else if (SelectedItems_UseLink == 1) ; Office 2013
            {
              SelectedItems_OutTarget := SelectedItems
            }
            ; -------------------------------------------
          } ; [End] else if (SelectedItems_Ext == "lnk")
          ; -------------------------------------------
          else if (SelectedItems_Ext == "url") ; (ERROR) 443 (Can Not Select URL)
          {
            ; -------------------------------------------
            SelectedItems := ""
            SelectedItems_OutTarget    := ""
            SelectedItems_RunArguments := ""
            SelectedItems_UseLink      := 0
            SelectedItems_LinkIcon     := ""
            SelectedItems_LinkName     := ""
            ; -------------------------------------------
            SetTitleMatchMode, 1
            WinGet, FileSelectGui_Id, ID , PUM -  ahk_class #32770
            WinSet, AlwaysOnTop, Off, ahk_id %FileSelectGui_Id%
            ; -------------------------------------------
            Splash_Script("443", 1000) ; (443)(Splash Error Image File: Can Not Select a URL)
            ; -------------------------------------------
            WinSet, AlwaysOnTop, On, ahk_id %FileSelectGui_Id%
            ; -------------------------------------------                                                                        
          } ; [End] else else if (SelectedItems_Ext == "url")
          ; -------------------------------------------
        } ; End (SelectFileFolderType == "AnyFile") ; SelectFileType := "*.*"
        ; -------------------------------------------
        else if (SelectFileFolderType == "AnyImage") ; SelectFileType  := "*.apng; *.bmp; *.gif; *.ico; *.jfif; *.jpeg; *.jpg; *.png; *.svg; *.tif; *.tiff; *.webp"
        {
          ; -------------------------------------------
          SplitPath, SelectedItems, , , SelectedItems_Ext
          StringLower, SelectedItems_Ext, SelectedItems_Ext
          ; -------------------------------------------
          if (SelectedItems_Ext == "") ; (SelectedItems is a Folder) (Send ENTER)
          {
            ; -------------------------------------------
            SelectedItems := ""
            SelectedItems_OutTarget    := ""
            SelectedItems_RunArguments := ""
            SelectedItems_UseLink      := 0
            SelectedItems_LinkIcon     := ""
            SelectedItems_LinkName     := ""
            Send, {Enter}
            ; -------------------------------------------
          } ; [End] if (SelectedItems_Ext == "")
          ; -------------------------------------------
          else if (SelectedItems_Ext == "lnk")
          {
            ; -------------------------------------------
            FileGetShortcut, %SelectedItems%, SelectedItems_OutTarget ; (305_5)(Selected Opening Application [Full File Path])
            ; -------------------------------------------
            SplitPath, SelectedItems_OutTarget , , , Outtarget_Ext
            StringLower, Outtarget_Ext, Outtarget_Ext
            ; -------------------------------------------
            if (Outtarget_Ext == "") ; (ERROR) 432 (The Selected is Not a Image)
            {
              ; -------------------------------------------
              SelectedItems := ""
              SelectedItems_OutTarget    := ""
              SelectedItems_RunArguments := ""
              SelectedItems_UseLink      := 0
              SelectedItems_LinkIcon     := ""
              SelectedItems_LinkName     := ""
              ; -------------------------------------------
              SetTitleMatchMode, 1
              WinGet, FileSelectGui_Id, ID , PUM -  ahk_class #32770
              WinSet, AlwaysOnTop, Off, ahk_id %FileSelectGui_Id%
              ; -------------------------------------------
              Splash_Script("432", 1000) ; (432)(Splash Error Image File: The Selected is Not a Image)
              ; -------------------------------------------
              WinSet, AlwaysOnTop, On, ahk_id %FileSelectGui_Id%
              ; -------------------------------------------
            } ; [End] if (Outtarget_Ext == "")
            ; -------------------------------------------
            else if (Outtarget_Ext != "apng" && Outtarget_Ext != "avif" && Outtarget_Ext != "bmp" && Outtarget_Ext != "gif" && Outtarget_Ext != "ico" && Outtarget_Ext != "jfif" && Outtarget_Ext != "jpeg" && Outtarget_Ext != "jpg" && Outtarget_Ext != "png" && Outtarget_Ext != "svg" && Outtarget_Ext != "tif" && Outtarget_Ext != "tiff" && Outtarget_Ext != "webp")
            {
              ; -------------------------------------------
              SelectedItems := ""
              SelectedItems_OutTarget    := ""
              SelectedItems_RunArguments := ""
              SelectedItems_UseLink      := 0
              SelectedItems_LinkIcon     := ""
              SelectedItems_LinkName     := ""
              ; -------------------------------------------
              SetTitleMatchMode, 1
              WinGet, FileSelectGui_Id, ID , PUM -  ahk_class #32770
              WinSet, AlwaysOnTop, Off, ahk_id %FileSelectGui_Id%
              ; -------------------------------------------
              Splash_Script("432", 1000) ; (432)(Splash Error Image File: The Selected is Not a Image)
              ; -------------------------------------------
              WinSet, AlwaysOnTop, On, ahk_id %FileSelectGui_Id%                                          
              ; -------------------------------------------
            }  ; End Is a Image
            ; -------------------------------------------
          } ; [End] else if (SelectedItems_Ext == "lnk")
          ; -------------------------------------------
          else if (SelectedItems_Ext == "url") ; (ERROR) 432 (The Selected is Not a Image)
          {
            ; -------------------------------------------
            SelectedItems := ""
            SelectedItems_OutTarget    := ""
            SelectedItems_RunArguments := ""
            SelectedItems_UseLink      := 0
            SelectedItems_LinkIcon     := ""
            SelectedItems_LinkName     := ""
            ; -------------------------------------------
            SetTitleMatchMode, 1
            WinGet, FileSelectGui_Id, ID , PUM -  ahk_class #32770
            WinSet, AlwaysOnTop, Off, ahk_id %FileSelectGui_Id%
            ; -------------------------------------------
            Splash_Script("432", 1000) ; (432)(Splash Error Image File: The Selected is Not a Image)
            ; -------------------------------------------
            WinSet, AlwaysOnTop, On, ahk_id %FileSelectGui_Id%                                    
            ; -------------------------------------------
          } ; [End] else if (SelectedItems_Ext == "url")
          ; -------------------------------------------
        } ; End (SelectFileFolderType == "AnyImage") ; SelectFileType  := "*.apng; *.bmp; *.gif; *.ico; *.jfif; *.jpeg; *.jpg; *.png; *.svg; *.tif; *.tiff; *.webp"
        ; -------------------------------------------
        else if (SelectFileFolderType == "Application") ; SelectFileType  := "*.bat; *.cmd; *.com; *.exe; *.lnk"
        {
          ; -------------------------------------------
          SplitPath, SelectedItems, , , SelectedItems_Ext
          StringLower, SelectedItems_Ext, SelectedItems_Ext
          ; -------------------------------------------
          if (SelectedItems_Ext == "") ; (SelectedItems is a Folder) (Send ENTER)
          {
            ; -------------------------------------------
            SelectedItems := ""
            SelectedItems_OutTarget    := ""
            SelectedItems_RunArguments := ""
            SelectedItems_UseLink      := 0
            SelectedItems_LinkIcon     := ""
            SelectedItems_LinkName     := ""
            Send, {Enter}
            ; -------------------------------------------
          } ; End (SelectedItems_Ext == "")
          ;
          else if (SelectedItems_Ext == "lnk")
          {
            ; -------------------------------------------
            LinkArray:= Run_GetLink(SelectedItems, ThisPumPath) ; ThisLink, StringLink["Link","String"] > [Target, Arguments, UseLink, LinkIcon, NameLink]
            SelectedItems_OutTarget    := LinkArray.1
            SelectedItems_RunArguments := LinkArray.2
            SelectedItems_UseLink      := LinkArray.3
            SelectedItems_LinkIcon     := LinkArray.4
            SelectedItems_LinkName     := LinkArray.5
            ; -------------------------------------------
            if (SelectedItems_UseLink == 1)
            {
              SelectedItems_OutTarget := SelectedItems
            } ; [End] (SelectedItems_UseLink == 1)
            else if (SelectedItems_UseLink == 0)
            {
              ; -------------------------------------------
              FileGetShortcut, %SelectedItems%, SelectedItems_OutTarget, , OutTarget_OutArgs
              ; -------------------------------------------
              SplitPath, OutTarget_OutArgs , , , OutTarget_OutArgs_Ext
              StringLower, OutTarget_OutArgs_Ext, OutTarget_OutArgs_Ext
              ; -------------------------------------------
              SplitPath, SelectedItems_OutTarget , , , Outtarget_Ext
              StringLower, Outtarget_Ext, Outtarget_Ext
              ; -------------------------------------------
              if (OutTarget_OutArgs_Ext != "")
              {
                ; -------------------------------------------
                if (OutTarget_OutArgs_Ext != "bat" && OutTarget_OutArgs_Ext != "cmd" && OutTarget_OutArgs_Ext != "com" && OutTarget_OutArgs_Ext != "exe") ; (ERROR) 433 (TThe Selected is Not a Application)
                {
                  ; -------------------------------------------
                  SelectedItems := ""
                  SelectedItems_OutTarget    := ""
                  SelectedItems_RunArguments := ""
                  SelectedItems_UseLink      := 0
                  SelectedItems_LinkIcon     := ""
                  SelectedItems_LinkName     := ""
                  ; -------------------------------------------
                  SetTitleMatchMode, 1
                  WinGet, FileSelectGui_Id, ID , PUM -  ahk_class #32770
                  WinSet, AlwaysOnTop, Off, ahk_id %FileSelectGui_Id%
                  ; -------------------------------------------
                  Splash_Script("433", 1000) ; (433)(Splash Error Image File: The Selected is Not a Application)
                  ; -------------------------------------------
                  WinSet, AlwaysOnTop, On, ahk_id %FileSelectGui_Id%                                                                        
                  ; -------------------------------------------
                }  ; End Is a (bat,cmd,com,exe)
                else ; OK
                {
                  ; -------------------------------------------
                  SelectedItems_OutTarget := OutTarget_OutArgs
                  ; -------------------------------------------
                }
              }
              ; -------------------------------------------
              else if (Outtarget_Ext == "") ; (ERROR) 433 (TThe Selected is Not a Application)
              {
                ; -------------------------------------------
                SelectedItems := ""
                SelectedItems_OutTarget    := ""
                SelectedItems_RunArguments := ""
                SelectedItems_UseLink      := 0
                SelectedItems_LinkIcon     := ""
                SelectedItems_LinkName     := ""
                ; -------------------------------------------
                SetTitleMatchMode, 1
                WinGet, FileSelectGui_Id, ID , PUM -  ahk_class #32770
                WinSet, AlwaysOnTop, Off, ahk_id %FileSelectGui_Id%
                ; -------------------------------------------
                Splash_Script("433", 1000) ; (433)(Splash Error Image File: The Selected is Not a Application)
                ; -------------------------------------------
                WinSet, AlwaysOnTop, On, ahk_id %FileSelectGui_Id%                                                
                ; -------------------------------------------
              } ; [End] if (Outtarget_Ext == "") ; (The Selected LINK is to a Folder)
              ; -------------------------------------------
              else if (Outtarget_Ext != "bat" && Outtarget_Ext != "cmd" && Outtarget_Ext != "com" && Outtarget_Ext != "exe") ; (ERROR) 433 (TThe Selected is Not a Application)
              {
                ; -------------------------------------------
                SelectedItems := ""
                SelectedItems_OutTarget    := ""
                SelectedItems_RunArguments := ""
                SelectedItems_UseLink      := 0
                SelectedItems_LinkIcon     := ""
                SelectedItems_LinkName     := ""
                ; -------------------------------------------
                SetTitleMatchMode, 1
                WinGet, FileSelectGui_Id, ID , PUM -  ahk_class #32770
                WinSet, AlwaysOnTop, Off, ahk_id %FileSelectGui_Id%
                ; -------------------------------------------
                Splash_Script("433", 1000) ; (433)(Splash Error Image File: The Selected is Not a Application)
                ; -------------------------------------------
                WinSet, AlwaysOnTop, On, ahk_id %FileSelectGui_Id%                                                
                ; -------------------------------------------
              }  ; End Is a (bat,cmd,com,exe)
              ; -------------------------------------------
              else
              {
                ; -------------------------------------------
                SelectedItems := SelectedItems_OutTarget
                ; -------------------------------------------
              } ; [End] else if (Outtarget_Ext != (bat,cmd,com,exe))
              ; -------------------------------------------
            } ; [End] else if (SelectedItems_UseLink == 0)
            ; -------------------------------------------
          } ; [End] else if (SelectedItems_Ext == "lnk")
          ; -------------------------------------------
          else if (SelectedItems_Ext == "url") ; (ERROR) 433 (The Selected is Not a Application)
          {
            ; -------------------------------------------
            SelectedItems := ""
            SelectedItems_OutTarget    := ""
            SelectedItems_RunArguments := ""
            SelectedItems_UseLink      := 0
            SelectedItems_LinkIcon     := ""
            SelectedItems_LinkName     := ""
            ; -------------------------------------------
            SetTitleMatchMode, 1
            WinGet, FileSelectGui_Id, ID , PUM -  ahk_class #32770
            WinSet, AlwaysOnTop, Off, ahk_id %FileSelectGui_Id%
            ; -------------------------------------------
            Splash_Script("433", 1000) ; (433)(Splash Error Image File: The Selected is Not a Application)
            ; -------------------------------------------
            WinSet, AlwaysOnTop, On, ahk_id %FileSelectGui_Id%                        
            ; -------------------------------------------
          } ; [End] else else if (SelectedItems_Ext == "url")
          ; -------------------------------------------
        } ; End (SelectFileFolderType == "Application") ; SelectFileType  := "*.bat; *.cmd; *.com; *.exe; *.lnk"
        ; -------------------------------------------
        else if (SelectFileFolderType == "Browser") ; SelectFileType := Browser List and (*.lnk)
        {
          ; -------------------------------------------
          SplitPath, SelectedItems, , , SelectedItems_Ext
          StringLower, SelectedItems_Ext, SelectedItems_Ext
          ; -------------------------------------------
          if (SelectedItems_Ext == "") ; (SelectedItems is a Folder) (Send ENTER)
          {
            ; -------------------------------------------
            SelectedItems := ""
            SelectedItems_OutTarget    := ""
            SelectedItems_RunArguments := ""
            SelectedItems_UseLink      := 0
            SelectedItems_LinkIcon     := ""
            SelectedItems_LinkName     := ""
            Send, {Enter}
            ; -------------------------------------------
          } ; End (SelectedItems_Ext == "")
          ; -------------------------------------------
          else if (SelectedItems_Ext == "lnk")
          {
            ; -------------------------------------------
            LinkArray:= Run_GetLink(SelectedItems, ThisPumPath) ; ThisLink, StringLink["Link","String"] > [Target, Arguments, UseLink, LinkIcon, NameLink]
            SelectedItems_OutTarget    := LinkArray.1
            SelectedItems_RunArguments := LinkArray.2
            SelectedItems_UseLink      := LinkArray.3
            SelectedItems_LinkIcon     := LinkArray.4
            SelectedItems_LinkName     := LinkArray.5
            ; -------------------------------------------
            if (SelectedItems_OutTarget == "") ; (ERROR) 434 (The Selected is Not a Internet Browser)
            {
              ; -------------------------------------------
              SelectedItems := ""
              SelectedItems_OutTarget    := ""
              SelectedItems_RunArguments := ""
              SelectedItems_UseLink      := 0
              SelectedItems_LinkIcon     := ""
              SelectedItems_LinkName     := ""
              ; -------------------------------------------
              SetTitleMatchMode, 1
              WinGet, FileSelectGui_Id, ID , PUM -  ahk_class #32770
              WinSet, AlwaysOnTop, Off, ahk_id %FileSelectGui_Id%
              ; -------------------------------------------
              Splash_Script("434", 1000) ; (434)(Splash Error Image File: The Selected is Not a Internet Browser)
              ; -------------------------------------------
              WinSet, AlwaysOnTop, On, ahk_id %FileSelectGui_Id%                                          
              ; -------------------------------------------
            } ; [End] if (OutTarget_Ext == "")
            ; -------------------------------------------
            else ; The SelectedItems_OutTarget is Link File, NOT URL
            {
              ; -------------------------------------------
              ; The SelectedItems_OutTarget is Link File
              ; The SelectedItems_OutTarget is NOT a Link File to a URL
              ; -------------------------------------------
              SplitPath, SelectedItems_OutTarget, SelectedItems_OutTarget_ExtName
              ; -------------------------------------------
              if (SelectedItems_OutTarget_ExtName != "avantvw.exe" && SelectedItems_OutTarget_ExtName != "brave.exe" && SelectedItems_OutTarget_ExtName != "browser.exe" && SelectedItems_OutTarget_ExtName != "chrome.exe" && SelectedItems_OutTarget_ExtName != "cyberfox.exe" && SelectedItems_OutTarget_ExtName != "dragon.exe" && SelectedItems_OutTarget_ExtName != "firefox.exe" && SelectedItems_OutTarget_ExtName != "waterfox.exe" && SelectedItems_OutTarget_ExtName != "icedragon.exe" && SelectedItems_OutTarget_ExtName != "iexplore.exe" && SelectedItems_OutTarget_ExtName != "iridium.exe" && SelectedItems_OutTarget_ExtName != "kingpinprivatebrowser.exe" && SelectedItems_OutTarget_ExtName != "k-meleon.exe" && SelectedItems_OutTarget_ExtName != "safari.exe" && SelectedItems_OutTarget_ExtName != "seamonkey.exe" && SelectedItems_OutTarget_ExtName != "slimboat.exe" && SelectedItems_OutTarget_ExtName != "slimbrowser.exe" && SelectedItems_OutTarget_ExtName != "slimjet.exe" && SelectedItems_OutTarget_ExtName != "spark.exe" && SelectedItems_OutTarget_ExtName != "maxthon.exe" && SelectedItems_OutTarget_ExtName != "msedge.exe" && SelectedItems_OutTarget_ExtName != "opera.exe" && SelectedItems_OutTarget_ExtName != "palemoon.exe" && SelectedItems_OutTarget_ExtName != "ucbrowser.exe" && SelectedItems_OutTarget_ExtName != "vivaldi.exe" && SelectedItems_OutTarget_ExtName != "waterfox.exe")
              {
                ; -------------------------------------------
                SelectedItems := ""
                SelectedItems_OutTarget    := ""
                SelectedItems_RunArguments := ""
                SelectedItems_UseLink      := 0
                SelectedItems_LinkIcon     := ""
                SelectedItems_LinkName     := ""
                ; -------------------------------------------
                SetTitleMatchMode, 1
                WinGet, FileSelectGui_Id, ID , PUM -  ahk_class #32770
                WinSet, AlwaysOnTop, Off, ahk_id %FileSelectGui_Id%
                ; -------------------------------------------
                Splash_Script("434", 1000) ; (434)(Splash Error Image File: The Selected is Not a Internet Browser)
                ; -------------------------------------------
                WinSet, AlwaysOnTop, On, ahk_id %FileSelectGui_Id%                                                
                ; -------------------------------------------
              } ; [End] The SelectedItems_OutTarget is Link File, NOT URL
            } ; [End] The Link is Not a URL Link
            ; -------------------------------------------
          } ; [End] if (SelectedItems_Ext == "lnk")
          ; -------------------------------------------
          else if (SelectedItems_Ext == "url") ; (ERROR) 434 (The Selected is Not a Internet Browser)
          {
            ; -------------------------------------------
            SelectedItems := ""
            SelectedItems_OutTarget    := ""
            SelectedItems_RunArguments := ""
            SelectedItems_UseLink      := 0
            SelectedItems_LinkIcon     := ""
            SelectedItems_LinkName     := ""
            ; -------------------------------------------
            SetTitleMatchMode, 1
            WinGet, FileSelectGui_Id, ID , PUM -  ahk_class #32770
            WinSet, AlwaysOnTop, Off, ahk_id %FileSelectGui_Id%
            ; -------------------------------------------
            Splash_Script("434", 1000) ; (434)(Splash Error Image File: The Selected is Not a Internet Browser)
            ; -------------------------------------------
            WinSet, AlwaysOnTop, On, ahk_id %FileSelectGui_Id%                                    
            ; -------------------------------------------
          } ; [End] if (OutTarget_Ext == "")
          ; -------------------------------------------
        } ; End (SelectFileFolderType == "Browser") ; SelectFileType := Browser List and (*.lnk)
        ; -------------------------------------------
      } ; [End] else if (SelectedItems != "")
      ; -------------------------------------------
      Clipboard := ClipboardIs
      ; -------------------------------------------
      if (SelectedItems == "")
      {
        ; -------------------------------------------
        return
        ; -------------------------------------------
      } ; [End] if (SelectedItems == "")
      ; -------------------------------------------
    } ; [End] if (SelectedItems == "") ; Nothing Selected (or Folder is Selected)
    ; -------------------------------------------
    else if (SelectedItems != "") ; Something is Selected
    {
      ; -------------------------------------------
      if (SelectFileFolderType == "Folder") ; SelectFileType := "egdsgdsgdgds.sdgsdgsfehdf" 
      {
        ; -------------------------------------------
        SplitPath, SelectedItems, , , SelectedItems_Ext
        StringLower, SelectedItems_Ext, SelectedItems_Ext
        ; -------------------------------------------
        if (SelectedItems_Ext == "lnk")
        {
          ; -------------------------------------------
          FileGetShortcut, %SelectedItems%, SelectedItems_OutTarget ; (305_5)(Selected Opening Application [Full File Path])
          ; -------------------------------------------
          SplitPath, SelectedItems_OutTarget, , , OutTarget_Ext
          StringLower, OutTarget_Ext, OutTarget_Ext
          ; -------------------------------------------
          if (OutTarget_Ext != "") ; SelectedItems_Ext is a "lnk" 
          {
            ; -------------------------------------------
            SelectedItems := ""
            SelectedItems_OutTarget    := ""
            SelectedItems_RunArguments := ""
            SelectedItems_UseLink      := 0
            SelectedItems_LinkIcon     := ""
            SelectedItems_LinkName     := ""
            ; -------------------------------------------
            SetTitleMatchMode, 1
            WinGet, FileSelectGui_Id, ID , PUM -  ahk_class #32770
            WinSet, AlwaysOnTop, Off, ahk_id %FileSelectGui_Id%
            ; -------------------------------------------
            Splash_Script("407", 1000) ; (407)(Splash Error Image File: A Folder is Not Selected)
            ; -------------------------------------------
            WinSet, AlwaysOnTop, On, ahk_id %FileSelectGui_Id%                                    
            ; -------------------------------------------
          } ; [End] if (OutTarget_Ext != "")
          ; -------------------------------------------
        } ; [End] if (SelectedItems_Ext == "lnk")
        ; -------------------------------------------
        else if (SelectedItems_Ext == "url") ; "Splash Error 407 : A Folder is Not Selected"
        {
          ; -------------------------------------------
          SelectedItems := ""
          SelectedItems_OutTarget    := ""
          SelectedItems_RunArguments := ""
          SelectedItems_UseLink      := 0
          SelectedItems_LinkIcon     := ""
          SelectedItems_LinkName     := ""
          ; -------------------------------------------
          SetTitleMatchMode, 1
          WinGet, FileSelectGui_Id, ID , PUM -  ahk_class #32770
          WinSet, AlwaysOnTop, Off, ahk_id %FileSelectGui_Id%
          ; -------------------------------------------
          Splash_Script("407", 1000) ; (407)(Splash Error Image File: A Folder is Not Selected)
          ; -------------------------------------------
          WinSet, AlwaysOnTop, On, ahk_id %FileSelectGui_Id%                              
          ; -------------------------------------------
        } ; [End] else if (SelectedItems_Ext == "url")
        ; -------------------------------------------
      } ; [End] if (SelectFileFolderType == "Folder") ; SelectFileType := "egdsgdsgdgds.sdgsdgsfehdf" 
      ; -------------------------------------------
      else if (SelectFileFolderType == "IcoImage") ; SelectFileType := "*.ico"
      {
        ; -------------------------------------------
        SplitPath, SelectedItems, , , SelectedItems_Ext
        StringLower, SelectedItems_Ext, SelectedItems_Ext
        ; -------------------------------------------
        if (SelectedItems_Ext == "") ; (SelectedItems is a Folder) (Send ENTER)
        {
          ; -------------------------------------------
          SelectedItems := ""
          SelectedItems_OutTarget    := ""
          SelectedItems_RunArguments := ""
          SelectedItems_UseLink      := 0
          SelectedItems_LinkIcon     := ""
          SelectedItems_LinkName     := ""
          Send, {Enter}
          ; -------------------------------------------
        } ; End (SelectedItems_Ext == "")
        ; -------------------------------------------
        else if (SelectedItems_Ext != "ico") ; (ERROR) 442 (Icon Not Select)
        {
          ; -------------------------------------------
          SelectedItems := ""
          SelectedItems_OutTarget    := ""
          SelectedItems_RunArguments := ""
          SelectedItems_UseLink      := 0
          SelectedItems_LinkIcon     := ""
          SelectedItems_LinkName     := ""
          ; -------------------------------------------
          SetTitleMatchMode, 1
          WinGet, FileSelectGui_Id, ID , PUM -  ahk_class #32770
          WinSet, AlwaysOnTop, Off, ahk_id %FileSelectGui_Id%
          ; -------------------------------------------
          Splash_Script("442", 1000) ; (442)(Splash Error Image File: Icon Not Select)
          ; -------------------------------------------
          WinSet, AlwaysOnTop, On, ahk_id %FileSelectGui_Id%                              
          ; -------------------------------------------
        } ; [End] else if (SelectedItems_Ext != "ico")
        ; -------------------------------------------
      } ; [End] else if (SelectFileFolderType == "IcoImage") ; SelectFileType := "*.ico"
      ; -------------------------------------------
      else if (SelectFileFolderType == "PumRestore") ; PopUpMenu_Pum_(DATE TIME).zip
      {
        ; -------------------------------------------
        SplitPath, SelectedItems, , , SelectedItems_Ext, SelectedItems_Name
        StringLower, SelectedItems_Ext, SelectedItems_Ext
        ; -------------------------------------------
        if (SelectedItems_Ext == "") ; (SelectedItems is a Folder) (Send ENTER)
        {
          ; -------------------------------------------
          SelectedItems := ""
          SelectedItems_OutTarget    := ""
          SelectedItems_RunArguments := ""
          SelectedItems_UseLink      := 0
          SelectedItems_LinkIcon     := ""
          SelectedItems_LinkName     := ""
          Send, {Enter}
          ; -------------------------------------------
        } ; End (SelectedItems_Ext == "")
        ; -------------------------------------------
        else if (SelectedItems_Ext != "zip") ; (ERROR) 490 (pum Backup Zip Not Selected)
        {
          ; -------------------------------------------
          SelectedItems := ""
          SelectedItems_OutTarget    := ""
          SelectedItems_RunArguments := ""
          SelectedItems_UseLink      := 0
          SelectedItems_LinkIcon     := ""
          SelectedItems_LinkName     := ""
          ; -------------------------------------------
          SetTitleMatchMode, 1
          WinGet, FileSelectGui_Id, ID , PUM -  ahk_class #32770
          WinSet, AlwaysOnTop, Off, ahk_id %FileSelectGui_Id%
          ; -------------------------------------------
          Splash_Script("490", 1000) ; (490)(Splash Error: [pum Logo Image] pum Backup Zip Not Selected)
          ; -------------------------------------------
          WinSet, AlwaysOnTop, On, ahk_id %FileSelectGui_Id%                              
          ; -------------------------------------------
        } ; (SelectedItems_Ext != "zip")
        ; -------------------------------------------
        else if (SubStr(SelectedItems_Name, 1, 15) != "PopUpMenu_Pum_(")
        {
          ; -------------------------------------------
          SelectedItems := ""
          SelectedItems_OutTarget    := ""
          SelectedItems_RunArguments := ""
          SelectedItems_UseLink      := 0
          SelectedItems_LinkIcon     := ""
          SelectedItems_LinkName     := ""
          ; -------------------------------------------
          SetTitleMatchMode, 1
          WinGet, FileSelectGui_Id, ID , PUM -  ahk_class #32770
          WinSet, AlwaysOnTop, Off, ahk_id %FileSelectGui_Id%
          ; -------------------------------------------
          Splash_Script("490", 1000) ; (490)(Splash Error: [pum Logo Image] pum Backup Zip Not Selected)
          ; -------------------------------------------
          WinSet, AlwaysOnTop, On, ahk_id %FileSelectGui_Id%
          ; -------------------------------------------                                                
        } ; (SubStr(SelectedItems_Name, 1, 15) != "PopUpMenu_Pum_(")
        ; -------------------------------------------
      } ; else if (SelectFileFolderType == "PumRestore") ; PopUpMenu_Pum_(DATE TIME).zip
      ; -------------------------------------------
      else if (SelectFileFolderType == "AnyFile") ; SelectFileType := "*.*"
      {
        ; -------------------------------------------
        SplitPath, SelectedItems, , , SelectedItems_Ext
        StringLower, SelectedItems_Ext, SelectedItems_Ext
        ; -------------------------------------------
        if (SelectedItems_Ext == "") ; (SelectedItems is a Folder) (Send ENTER)
        {
          ; -------------------------------------------
          SelectedItems := ""
          SelectedItems_OutTarget    := ""
          SelectedItems_RunArguments := ""
          SelectedItems_UseLink      := 0
          SelectedItems_LinkIcon     := ""
          SelectedItems_LinkName     := ""
          Send, {Enter}
          ; -------------------------------------------
        } ; End (SelectedItems_Ext == "")
        else if (SelectedItems_Ext == "lnk")
        {
          ; -------------------------------------------
          LinkArray:= Run_GetLink(SelectedItems, ThisPumPath) ; ThisLink, StringLink["Link","String"] > [Target, Arguments, UseLink, LinkIcon, NameLink]
          SelectedItems_OutTarget    := LinkArray.1
          SelectedItems_RunArguments := LinkArray.2
          SelectedItems_UseLink      := LinkArray.3
          SelectedItems_LinkIcon     := LinkArray.4
          SelectedItems_LinkName     := LinkArray.5
          ; -------------------------------------------
          if (SelectedItems_OutTarget == "") ;  ; (ERROR) 412 (A File is Not Selected)
          {
            ; -------------------------------------------
            SelectedItems := ""
            SelectedItems_OutTarget    := ""
            SelectedItems_RunArguments := ""
            SelectedItems_UseLink      := 0
            SelectedItems_LinkIcon     := ""
            SelectedItems_LinkName     := ""
            ; -------------------------------------------
            SetTitleMatchMode, 1
            WinGet, FileSelectGui_Id, ID , PUM -  ahk_class #32770
            WinSet, AlwaysOnTop, Off, ahk_id %FileSelectGui_Id%
            ; -------------------------------------------
            Splash_Script("412", 1000) ; (412)(Splash Error Image File: A File is Not Selected)
            ; -------------------------------------------
            WinSet, AlwaysOnTop, On, ahk_id %FileSelectGui_Id%                                    
            ; -------------------------------------------
          } ; [End] (SelectedItems_OutTarget == "")
          else
          {
            ; -------------------------------------------
            SelectedItems := ""
            SelectedItems_OutTarget    := ""
            SelectedItems_RunArguments := ""
            SelectedItems_UseLink      := 0
            SelectedItems_LinkIcon     := ""
            SelectedItems_LinkName     := ""
            Send, {Enter}
            ; -------------------------------------------
          }
          ; -------------------------------------------
        } ; [End] else if (SelectedItems_Ext == "lnk")
        ; -------------------------------------------
        else if (SelectedItems_Ext == "url") ; (ERROR) 443 (Can Not Select URL)
        {
          ; -------------------------------------------
          SelectedItems := ""
          SelectedItems_OutTarget    := ""
          SelectedItems_RunArguments := ""
          SelectedItems_UseLink      := 0
          SelectedItems_LinkIcon     := ""
          SelectedItems_LinkName     := ""
          ; -------------------------------------------
          SetTitleMatchMode, 1
          WinGet, FileSelectGui_Id, ID , PUM -  ahk_class #32770
          WinSet, AlwaysOnTop, Off, ahk_id %FileSelectGui_Id%
          ; -------------------------------------------
          Splash_Script("443", 1000) ; (443)(Splash Error Image File: Can Not Select a URL)
          ; -------------------------------------------
          WinSet, AlwaysOnTop, On, ahk_id %FileSelectGui_Id%                              
          ; -------------------------------------------
        } ; [End] else else if (SelectedItems_Ext == "url")
        ; -------------------------------------------
      } ; End (SelectFileFolderType == "AnyFile") ; SelectFileType := "*.*"
      ; -------------------------------------------
      else if (SelectFileFolderType == "AnyImage") ; SelectFileType  := "*.apng; *.bmp; *.gif; *.ico; *.jfif; *.jpeg; *.jpg; *.png; *.svg; *.tif; *.tiff; *.webp"
      {
        ; -------------------------------------------
        SplitPath, SelectedItems, , , SelectedItems_Ext
        StringLower, SelectedItems_Ext, SelectedItems_Ext
        ; -------------------------------------------
        if (SelectedItems_Ext == "") ; (SelectedItems is a Folder) (Send ENTER)
        {
          ; -------------------------------------------
          SelectedItems := ""
          SelectedItems_OutTarget    := ""
          SelectedItems_RunArguments := ""
          SelectedItems_UseLink      := 0
          SelectedItems_LinkIcon     := ""
          SelectedItems_LinkName     := ""
          Send, {Enter}
          ; -------------------------------------------
        } ; [End] if (SelectedItems_Ext == "")
        ; -------------------------------------------
        else if (SelectedItems_Ext == "lnk")
        {
          ; -------------------------------------------
          FileGetShortcut, %SelectedItems%, SelectedItems_OutTarget ; (305_5)(Selected Opening Application [Full File Path])
          ; -------------------------------------------
          SplitPath, SelectedItems_OutTarget , , , Outtarget_Ext
          StringLower, Outtarget_Ext, Outtarget_Ext
          ; -------------------------------------------
          if (Outtarget_Ext == "") ; (ERROR) 432 (The Selected is Not a Image)
          {
            ; -------------------------------------------
            SelectedItems := ""
            SelectedItems_OutTarget    := ""
            SelectedItems_RunArguments := ""
            SelectedItems_UseLink      := 0
            SelectedItems_LinkIcon     := ""
            SelectedItems_LinkName     := ""
            ; -------------------------------------------
            SetTitleMatchMode, 1
            WinGet, FileSelectGui_Id, ID , PUM -  ahk_class #32770
            WinSet, AlwaysOnTop, Off, ahk_id %FileSelectGui_Id%
            ; -------------------------------------------
            Splash_Script("432", 1000) ; (432)(Splash Error Image File: The Selected is Not a Image)
            ; -------------------------------------------
            WinSet, AlwaysOnTop, On, ahk_id %FileSelectGui_Id%                                    
            ; -------------------------------------------
          } ; [End] if (Outtarget_Ext == "")
          ; -------------------------------------------
          else if (Outtarget_Ext != "apng" && Outtarget_Ext != "avif" && Outtarget_Ext != "bmp" && Outtarget_Ext != "gif" && Outtarget_Ext != "ico" && Outtarget_Ext != "jfif" && Outtarget_Ext != "jpeg" && Outtarget_Ext != "jpg" && Outtarget_Ext != "png" && Outtarget_Ext != "svg" && Outtarget_Ext != "tif" && Outtarget_Ext != "tiff" && Outtarget_Ext != "webp")
          {
            ; -------------------------------------------
            SelectedItems := ""
            SelectedItems_OutTarget    := ""
            SelectedItems_RunArguments := ""
            SelectedItems_UseLink      := 0
            SelectedItems_LinkIcon     := ""
            SelectedItems_LinkName     := ""
            ; -------------------------------------------
            SetTitleMatchMode, 1
            WinGet, FileSelectGui_Id, ID , PUM -  ahk_class #32770
            WinSet, AlwaysOnTop, Off, ahk_id %FileSelectGui_Id%
            ; -------------------------------------------
            Splash_Script("432", 1000) ; (432)(Splash Error Image File: The Selected is Not a Image)
            ; -------------------------------------------
            WinSet, AlwaysOnTop, On, ahk_id %FileSelectGui_Id%                                    
            ; -------------------------------------------
          }  ; End Is a Image
          ; -------------------------------------------
        } ; [End] else if (SelectedItems_Ext == "lnk")
        ; -------------------------------------------
        else if (SelectedItems_Ext == "url") ; (ERROR) 432 (The Selected is Not a Image)
        {
          ; -------------------------------------------
          SelectedItems := ""
          SelectedItems_OutTarget    := ""
          SelectedItems_RunArguments := ""
          SelectedItems_UseLink      := 0
          SelectedItems_LinkIcon     := ""
          SelectedItems_LinkName     := ""
          ; -------------------------------------------
          SetTitleMatchMode, 1
          WinGet, FileSelectGui_Id, ID , PUM -  ahk_class #32770
          WinSet, AlwaysOnTop, Off, ahk_id %FileSelectGui_Id%
          ; -------------------------------------------
          Splash_Script("432", 1000) ; (432)(Splash Error Image File: The Selected is Not a Image)
          ; -------------------------------------------
          WinSet, AlwaysOnTop, On, ahk_id %FileSelectGui_Id%                              
          ; -------------------------------------------
        } ; [End] else if (SelectedItems_Ext == "url")
        ; -------------------------------------------
      } ; End (SelectFileFolderType == "AnyImage") ; SelectFileType  := "*.apng; *.bmp; *.gif; *.ico; *.jfif; *.jpeg; *.jpg; *.png; *.svg; *.tif; *.tiff; *.webp"
      ; -------------------------------------------
      else if (SelectFileFolderType == "Application") ; SelectFileType  := "*.bat; *.cmd; *.com; *.exe; *.lnk"
      {
        ; -------------------------------------------
        SplitPath, SelectedItems, , , SelectedItems_Ext
        StringLower, SelectedItems_Ext, SelectedItems_Ext
        ; -------------------------------------------
        if (SelectedItems_Ext == "") ; (SelectedItems is a Folder) (Send ENTER)
        {
          ; -------------------------------------------
          SelectedItems := ""
          SelectedItems_OutTarget    := ""
          SelectedItems_RunArguments := ""
          SelectedItems_UseLink      := 0
          SelectedItems_LinkIcon     := ""
          SelectedItems_LinkName     := ""
          Send, {Enter}
          ; -------------------------------------------
        } ; End (SelectedItems_Ext == "")
        ;
        else if (SelectedItems_Ext == "lnk")
        {
          ; -------------------------------------------
          LinkArray:= Run_GetLink(SelectedItems, ThisPumPath) ; ThisLink, StringLink["Link","String"] > [Target, Arguments, UseLink, LinkIcon, NameLink]
          SelectedItems_OutTarget    := LinkArray.1
          SelectedItems_RunArguments := LinkArray.2
          SelectedItems_UseLink      := LinkArray.3
          SelectedItems_LinkIcon     := LinkArray.4
          SelectedItems_LinkName     := LinkArray.5
          ; -------------------------------------------
          if (SelectedItems_UseLink == 1)
          {
            SelectedItems_OutTarget := SelectedItems
          } ; [End] (SelectedItems_UseLink == 1)
          else if (SelectedItems_UseLink == 0)
          {
            ; -------------------------------------------
            FileGetShortcut, %SelectedItems%, SelectedItems_OutTarget, , OutTarget_OutArgs
            ; -------------------------------------------
            SplitPath, OutTarget_OutArgs , , , OutTarget_OutArgs_Ext
            StringLower, OutTarget_OutArgs_Ext, OutTarget_OutArgs_Ext
            ; -------------------------------------------
            SplitPath, SelectedItems_OutTarget , , , Outtarget_Ext
            StringLower, Outtarget_Ext, Outtarget_Ext
            ; -------------------------------------------
            if (OutTarget_OutArgs_Ext != "")
            {
              ; -------------------------------------------
              if (OutTarget_OutArgs_Ext != "bat" && OutTarget_OutArgs_Ext != "cmd" && OutTarget_OutArgs_Ext != "com" && OutTarget_OutArgs_Ext != "exe") ; (ERROR) 433 (TThe Selected is Not a Application)
              {
                ; -------------------------------------------
                SelectedItems := ""
                SelectedItems_OutTarget    := ""
                SelectedItems_RunArguments := ""
                SelectedItems_UseLink      := 0
                SelectedItems_LinkIcon     := ""
                SelectedItems_LinkName     := ""
                ; -------------------------------------------
                SetTitleMatchMode, 1
                WinGet, FileSelectGui_Id, ID , PUM -  ahk_class #32770
                WinSet, AlwaysOnTop, Off, ahk_id %FileSelectGui_Id%
                ; -------------------------------------------
                Splash_Script("433", 1000) ; (433)(Splash Error Image File: The Selected is Not a Application)
                ; -------------------------------------------
                WinSet, AlwaysOnTop, On, ahk_id %FileSelectGui_Id%                                
                ; -------------------------------------------
              }  ; End Is a (bat,cmd,com,exe)
              else ; OK
              {
                ; -------------------------------------------
                SelectedItems_OutTarget := OutTarget_OutArgs
                ; -------------------------------------------
              } ; [End] else ; OK
            } ; [End] if (OutTarget_OutArgs_Ext != "")
            ; -------------------------------------------
            else if (Outtarget_Ext == "") ; (ERROR) 433 (TThe Selected is Not a Application)
            {
              ; -------------------------------------------
              SelectedItems := ""
              SelectedItems_OutTarget    := ""
              SelectedItems_RunArguments := ""
              SelectedItems_UseLink      := 0
              SelectedItems_LinkIcon     := ""
              SelectedItems_LinkName     := ""
              ; -------------------------------------------
              SetTitleMatchMode, 1
              WinGet, FileSelectGui_Id, ID , PUM -  ahk_class #32770
              WinSet, AlwaysOnTop, Off, ahk_id %FileSelectGui_Id%
              ; -------------------------------------------
              Splash_Script("433", 1000) ; (433)(Splash Error Image File: The Selected is Not a Application)
              ; -------------------------------------------
              WinSet, AlwaysOnTop, On, ahk_id %FileSelectGui_Id%                                          
              ; -------------------------------------------
            } ; [End] if (Outtarget_Ext == "") ; (The Selected LINK is to a Folder)
            ; -------------------------------------------
            else if (Outtarget_Ext != "bat" && Outtarget_Ext != "cmd" && Outtarget_Ext != "com" && Outtarget_Ext != "exe") ; (ERROR) 433 (TThe Selected is Not a Application)
            {
              ; -------------------------------------------
              SelectedItems := ""
              SelectedItems_OutTarget    := ""
              SelectedItems_RunArguments := ""
              SelectedItems_UseLink      := 0
              SelectedItems_LinkIcon     := ""
              SelectedItems_LinkName     := ""
              ; -------------------------------------------
              SetTitleMatchMode, 1
              WinGet, FileSelectGui_Id, ID , PUM -  ahk_class #32770
              WinSet, AlwaysOnTop, Off, ahk_id %FileSelectGui_Id%
              ; -------------------------------------------
              Splash_Script("433", 1000) ; (433)(Splash Error Image File: The Selected is Not a Application)
              ; -------------------------------------------
              WinSet, AlwaysOnTop, On, ahk_id %FileSelectGui_Id%                                          
              ; -------------------------------------------
            }  ; End Is a (bat,cmd,com,exe)
            ; -------------------------------------------
            else if (Outtarget_Ext != "bat" && Outtarget_Ext != "cmd" && Outtarget_Ext != "com" && Outtarget_Ext != "exe") ; (ERROR) 433 (TThe Selected is Not a Application)
            {
              ; -------------------------------------------
              SelectedItems := SelectedItems_OutTarget
              ; -------------------------------------------
            } ; [End] else if (Outtarget_Ext != (bat,cmd,com,exe))
            ; -------------------------------------------
          } ; [End] else if (SelectedItems_UseLink == 0)
          ; -------------------------------------------
        } ; [End] else if (SelectedItems_Ext == "lnk")
        ; -------------------------------------------
        else if (SelectedItems_Ext == "url") ; (ERROR) 433 (The Selected is Not a Application)
        {
          ; -------------------------------------------
          SelectedItems := ""
          SelectedItems_OutTarget    := ""
          SelectedItems_RunArguments := ""
          SelectedItems_UseLink      := 0
          SelectedItems_LinkIcon     := ""
          SelectedItems_LinkName     := ""
          ; -------------------------------------------
          SetTitleMatchMode, 1
          WinGet, FileSelectGui_Id, ID , PUM -  ahk_class #32770
          WinSet, AlwaysOnTop, Off, ahk_id %FileSelectGui_Id%
          ; -------------------------------------------
          Splash_Script("433", 1000) ; (433)(Splash Error Image File: The Selected is Not a Application)
          ; -------------------------------------------
          WinSet, AlwaysOnTop, On, ahk_id %FileSelectGui_Id%                              
          ; -------------------------------------------
        } ; [End] else else if (SelectedItems_Ext == "url")
        ; -------------------------------------------
      } ; End (SelectFileFolderType == "Application") ; SelectFileType  := "*.bat; *.cmd; *.com; *.exe; *.lnk"
      ; -------------------------------------------
      else if (SelectFileFolderType == "Browser") ; SelectFileType := Browser List and (*.lnk)
      {
        ; -------------------------------------------
        SplitPath, SelectedItems, , , SelectedItems_Ext
        StringLower, SelectedItems_Ext, SelectedItems_Ext
        ; -------------------------------------------
        if (SelectedItems_Ext == "") ; (SelectedItems is a Folder) (Send ENTER)
        {
          ; -------------------------------------------
          SelectedItems := ""
          SelectedItems_OutTarget    := ""
          SelectedItems_RunArguments := ""
          SelectedItems_UseLink      := 0
          SelectedItems_LinkIcon     := ""
          SelectedItems_LinkName     := ""
          Send, {Enter}
          ; -------------------------------------------
        } ; End (SelectedItems_Ext == "")
        ; -------------------------------------------
        if (SelectedItems_Ext == "lnk")
        {
          ; -------------------------------------------
          LinkArray:= Run_GetLink(SelectedItems, ThisPumPath) ; ThisLink, StringLink["Link","String"] > [Target, Arguments, UseLink, LinkIcon, NameLink]
          SelectedItems_OutTarget    := LinkArray.1
          SelectedItems_RunArguments := LinkArray.2
          SelectedItems_UseLink      := LinkArray.3
          SelectedItems_LinkIcon     := LinkArray.4
          SelectedItems_LinkName     := LinkArray.5
          ; -------------------------------------------
          if (SelectedItems_OutTarget == "") ; (ERROR) 434 (The Selected is Not a Internet Browser)
          {
            ; -------------------------------------------
            SelectedItems := ""
            SelectedItems_OutTarget    := ""
            SelectedItems_RunArguments := ""
            SelectedItems_UseLink      := 0
            SelectedItems_LinkIcon     := ""
            SelectedItems_LinkName     := ""
            ; -------------------------------------------
            SetTitleMatchMode, 1
            WinGet, FileSelectGui_Id, ID , PUM -  ahk_class #32770
            WinSet, AlwaysOnTop, Off, ahk_id %FileSelectGui_Id%
            ; -------------------------------------------
            Splash_Script("434", 1000) ; (434)(Splash Error Image File: The Selected is Not a Internet Browser)
            ; -------------------------------------------
            WinSet, AlwaysOnTop, On, ahk_id %FileSelectGui_Id%                                    
            ; -------------------------------------------
          } ; [End] if (OutTarget_Ext == "")
          ; -------------------------------------------
          else ; The SelectedItems_OutTarget is Link File, NOT URL
          {
            ; -------------------------------------------
            ; The SelectedItems_OutTarget is Link File
            ; The SelectedItems_OutTarget is NOT a Link File to a URL
            ; -------------------------------------------
            SplitPath, SelectedItems_OutTarget, SelectedItems_OutTarget_ExtName
            ; -------------------------------------------
            if (SelectedItems_OutTarget_ExtName != "avantvw.exe" && SelectedItems_OutTarget_ExtName != "brave.exe" && SelectedItems_OutTarget_ExtName != "browser.exe" && SelectedItems_OutTarget_ExtName != "chrome.exe" && SelectedItems_OutTarget_ExtName != "cyberfox.exe" && SelectedItems_OutTarget_ExtName != "dragon.exe" && SelectedItems_OutTarget_ExtName != "firefox.exe" && SelectedItems_OutTarget_ExtName != "waterfox.exe" && SelectedItems_OutTarget_ExtName != "icedragon.exe" && SelectedItems_OutTarget_ExtName != "iexplore.exe" && SelectedItems_OutTarget_ExtName != "iridium.exe" && SelectedItems_OutTarget_ExtName != "kingpinprivatebrowser.exe" && SelectedItems_OutTarget_ExtName != "k-meleon.exe" && SelectedItems_OutTarget_ExtName != "safari.exe" && SelectedItems_OutTarget_ExtName != "seamonkey.exe" && SelectedItems_OutTarget_ExtName != "slimboat.exe" && SelectedItems_OutTarget_ExtName != "slimbrowser.exe" && SelectedItems_OutTarget_ExtName != "slimjet.exe" && SelectedItems_OutTarget_ExtName != "spark.exe" && SelectedItems_OutTarget_ExtName != "maxthon.exe" && SelectedItems_OutTarget_ExtName != "msedge.exe" && SelectedItems_OutTarget_ExtName != "opera.exe" && SelectedItems_OutTarget_ExtName != "palemoon.exe" && SelectedItems_OutTarget_ExtName != "ucbrowser.exe" && SelectedItems_OutTarget_ExtName != "vivaldi.exe" && SelectedItems_OutTarget_ExtName != "waterfox.exe")
            {
              ; -------------------------------------------
              SelectedItems := ""
              SelectedItems_OutTarget    := ""
              SelectedItems_RunArguments := ""
              SelectedItems_UseLink      := 0
              SelectedItems_LinkIcon     := ""
              SelectedItems_LinkName     := ""
              ; -------------------------------------------
              SetTitleMatchMode, 1
              WinGet, FileSelectGui_Id, ID , PUM -  ahk_class #32770
              WinSet, AlwaysOnTop, Off, ahk_id %FileSelectGui_Id%
              ; -------------------------------------------
              Splash_Script("434", 1000) ; (434)(Splash Error Image File: The Selected is Not a Internet Browser)
              ; -------------------------------------------
              WinSet, AlwaysOnTop, On, ahk_id %FileSelectGui_Id%                                          
              ; -------------------------------------------
            } ; [End] The SelectedItems_OutTarget is Link File, NOT URL
          } ; [End] The Link is Not a URL Link
          ; -------------------------------------------
        } ; [End] if (SelectedItems_Ext == "lnk")
        ; -------------------------------------------
      } ; End (SelectFileFolderType == "Browser") ; SelectFileType := Browser List and (*.lnk)
      ; -------------------------------------------
    } ; [End] else if (SelectedItems != "")
    ; -------------------------------------------
    SelectedItems := RegExReplace(SelectedItems, "`r")
    ; -------------------------------------------
    if (FileOrFolder == "File") ; if files only:
    {
      FoldFound := 0, SelIt := ""
      Loop, Parse, SelectedItems, `n
      {
        if !(InStr(FileExist(A_LoopField), "D")) ; eliminating folders from SelectedItems
        {
          SelIt .= "`n" . A_LoopField
        }
        else
        {
          FoldFound := 1
        }
      } ; End Loop, Parse, SelectedItems, `n
      SelectedItems := SubStr(SelIt, 2)
      if (FoldFound)
      {
        if !(SelectedItems) ; and possibly MsgBox
        {
          if (WarnMsgB) ; if no file is selected 
          {
            MsgBox, , , %Warning%
          } ; End if (WarnMsgB) ; if no file is selected 
        } ; End if !(SelectedItems) ; and possibly MsgBox
      } ; End if (FoldFound)
    }
	  ; -------------------------------------------
    if (SelectedItems) ; Valid selection:
    {
      WinClose, %WindowTitle% ; triggering 'return SelectedItems'
    }
    ; -------------------------------------------
  } ; End SIApply: ; Button and hotkey
  return
  ; =============================================================================================
  ;
  ; =============================================================================================
  SICancel:
  {
    ; -------------------------------------------
    WinActivate, %WindowTitle%
    SelectedItems := ""
    SelectedItems_OutTarget    := ""
    SelectedItems_RunArguments := ""
    SelectedItems_UseLink      := 0
    SelectedItems_LinkIcon     := ""
    SelectedItems_LinkName     := ""
    WinClose, %WindowTitle% ; Triggering 'return SelectedItems'
    ; -------------------------------------------
  } ; End SICancel:
  return
  ; =============================================================================================
  SIEnter:
  {
    ; -------------------------------------------
    WinActivate, %WindowTitle%
    ; -------------------------------------------
    ControlGetFocus, FocusedCtrl, %WindowTitle%
    if (FocusedCtrl != List) ; Outside List: normal action
    {
      SendInput {Enter}
    }
    else ; Inside List and 
    { 
      ClipboardIs := ClipboardAll
      Clipboard := ""
      SendInput, ^c
      ClipWait, 0.5
      SelectedItems := Clipboard
      Clipboard := ClipboardIs
      SelectedItems := RegExReplace(SelectedItems, "`r")
      ; -------------------------------------------
      if !(SelectedItems) ; nothing selected: do nothing
      {
        return
      }
	    ; -------------------------------------------
      if InStr(SelectedItems, "`n") ; multiple selection: Apply
      {
        GoSub SIApply
      }
      else
      {
        if InStr(FileExist(SelectedItems), "D") ; single selected folder: open folder
        {
          SendInput {Enter}
          SelItem := ""
        }
        else
        {
          WinClose, %WindowTitle% ; single selected file: Apply
        }
      }
    }
  } ; End SIEnter:
  return
  ;=================================================================================================================;
} ; [End] Select_FileFolder(Lang, SelectFileFolderType, StartFolder)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
