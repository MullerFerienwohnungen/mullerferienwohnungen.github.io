﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_GuiControl.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Email_Validate.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
f_159(DataArray) ; (159_1)(Obj_Pum_Contact)
{
  ; -------------------------------------------
  GuiControl, PopUpMenu:Hide, g_102 ; (102_1)(Obj_DisplayedIcon)
  ; -------------------------------------------
  if (DataArray.159.2 == "" or DataArray.159.2 == 1) ; (159_2)(Obj_Pum_Contact_Sel [0,1,2,3])
  {
    ; -------------------------------------------
    DataArray := Image_GuiControl("254", 0, 0, DataArray) ; (254_1)(Obj_MsgImg300x300)
    DataArray := Image_GuiControl("137", 0, 0, DataArray) ; (137_1)(Obj_MsgImg480x270)
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    DataArray := Image_GuiControl("134", 0, 0, DataArray) ; (134_1)(Obj_ImageSelect1)
    DataArray := Image_GuiControl("135", 0, 0, DataArray) ; (135_1)(Obj_ImageSelect2)
    DataArray := Image_GuiControl("136", 0, 0, DataArray) ; (136_1)(Obj_ImageSelect3)
    ; -------------------------------------------
    ;
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Hide/Stop (Animate) Pum_Building_Construct
    global s_521 := 0 ; Hide
    SetTimer, l_521, Off ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
    global ShowAnimationChange := 0
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Hide/Stop (Animate) Pum_Building_Construct
    ;
    ; -------------------------------------------
    DataArray.366.5 := "pum_pumContact" ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    File_ContactInfo := A_AppData "\PopUpMenu_PUM\system\Contact.txt"
    ; -------------------------------------------
    if FileExist(File_ContactInfo)
    {
      ; -------------------------------------------
      FileReadLine, ContactName, %File_ContactInfo%, 1
      FileReadLine, ContactEmail, %File_ContactInfo%, 2
      ; -------------------------------------------
      DataArray.359.1 := ContactName ; (359_1)(Pum_ContactName [Email Contact Name])
      DataArray.359.2 := ContactEmail ; (359_2)(Pum_ContactEmail [Contact Email Address])
      ; -------------------------------------------
      GuiControl, PopUpMenu:, g_188, %ContactEmail% ; (188_1)(Obj_Pum_EditFeild_EmailAddress)
      GuiControl, PopUpMenu:, g_189, %ContactName% ; (189_1)(Obj_Pum_EditFeild_ContactName)
      ; -------------------------------------------
    }
    else
    {
      ContactName := A_UserName
      ; -------------------------------------------
      FileEncoding, UTF-8
      FileAppend, %ContactName%`n, %File_ContactInfo% ; UTF-8
      ; -------------------------------------------
      GuiControl, PopUpMenu:, g_189, %ContactName% ; (189_1)(Obj_Pum_EditFeild_ContactName)
    }
    ; -------------------------------------------
    { ; Hide
      ; -------------------------------------------
      DataArray := Image_GuiControl("154", 0, 0, DataArray) ; (154_1)(Obj_Pum_BgImage)
      DataArray := Image_GuiControl("155", 0, 0, DataArray) ; (155_1)(Obj_Pum_BgText)
      DataArray := Image_GuiControl("156", 0, 0, DataArray) ; (156_1)(Obj_Pum_BgDim)
      ; -------------------------------------------
      ; [pum] > [pumSetting] > [pumBgImage]
      DataArray := Image_GuiControl("165", 0, 1, DataArray) ; (165_1)(Obj_Pum_BgImageSelect)
      DataArray := Image_GuiControl("167", 0, 0, DataArray) ; (167_1)(Obj_Pum_BgFitImage)
      DataArray := Image_GuiControl("182", 0, 0, DataArray) ; (182_1)(Obj_Pum_BgRotateLeft)
      DataArray := Image_GuiControl("183", 0, 0, DataArray) ; (183_1)(Obj_Pum_BgRotateRight)
      DataArray := Image_GuiControl("241", 0, 0, DataArray) ; (241_1)(Obj_Pum_CropLeft)
      DataArray := Image_GuiControl("242", 0, 0, DataArray) ; (242_1)(Obj_Pum_CropRight)
      DataArray := Image_GuiControl("243", 0, 0, DataArray) ; (243_1)(Obj_Pum_CropUp)
      DataArray := Image_GuiControl("244", 0, 0, DataArray) ; (244_1)(Obj_Pum_CropDown)
      DataArray := Image_GuiControl("245", 0, 0, DataArray) ; (245_1)(Obj_Pum_CropCenter)
      DataArray := Image_GuiControl("246", 0, 0, DataArray) ; (246_1)(Obj_Pum_ZoomIn)
      DataArray := Image_GuiControl("247", 0, 0, DataArray) ; (247_1)(Obj_Pum_ZoomOut)
      ; -------------------------------------------
      ; [pum] > [pumSetting] > [pumBgText]
      GuiControl, PopUpMenu:Hide, g_164 ; (164_1)(Obj_Pum_BgTxtImg)
      DataArray := Image_GuiControl("166", 0, 0, DataArray) ; (166_1)(Obj_Pum_BgColor)
      DataArray := Image_GuiControl("172", 0, 0, DataArray) ; (172_1)(Obj_Pum_MobileText)
      DataArray := Image_GuiControl("173", 0, 0, DataArray) ; (173_1)(Obj_Pum_MobileTxtColor)
      DataArray := Image_GuiControl("174", 0, 0, DataArray) ; (174_1)(Obj_Pum_MobileBgColor)
      DataArray := Image_GuiControl("177", 0, 1, DataArray) ; (177_1)(Obj_Pum_BgTrans)
      DataArray := Image_GuiControl("178", 0, 0, DataArray) ; (178_1)(Obj_Pum_BgOpacityUp)
      DataArray := Image_GuiControl("179", 0, 0, DataArray) ; (179_1)(Obj_Pum_BgOpacityDown)
      DataArray := Image_GuiControl("180", 0, 0, DataArray) ; (180_1)(Obj_Pum_DisplayText_Opacity)
      DataArray := Image_GuiControl("181", 0, 0, DataArray) ; (181_1)(Obj_Pum_Opacity)
      ; -------------------------------------------
      ; [pum] > [pumSetting] > [pumDimension]
      DataArray := Image_GuiControl("260", 0, 0, DataArray) ; (260_1)(Obj_Pum_IconSize)
      DataArray := Image_GuiControl("261", 0, 0, DataArray) ; (261_1)(Obj_Pum_IconUp)
      DataArray := Image_GuiControl("262", 0, 0, DataArray) ; (262_1)(Obj_Pum_IconDown)
      DataArray := Image_GuiControl("263", 0, 0, DataArray) ; (263_1)(Obj_Pum_ImageText_IconSize)
      DataArray := Image_GuiControl("266", 0, 0, DataArray) ; (266_1)(Obj_Pum_PumRow)
      DataArray := Image_GuiControl("267", 0, 0, DataArray) ; (267_1)(Obj_Pum_PumRowUp)
      DataArray := Image_GuiControl("268", 0, 0, DataArray) ; (268_1)(Obj_Pum_PumRowDown)
      DataArray := Image_GuiControl("269", 0, 0, DataArray) ; (269_1)(Obj_Pum_DisplayText_Vertical)
      DataArray := Image_GuiControl("272", 0, 0, DataArray) ; (272_1)(Obj_Pum_PumColumn)
      DataArray := Image_GuiControl("273", 0, 0, DataArray) ; (273_1)(Obj_Pum_PumColumnUp)
      DataArray := Image_GuiControl("274", 0, 0, DataArray) ; (274_1)(Obj_Pum_PumColumnDown)
      DataArray := Image_GuiControl("275", 0, 0, DataArray) ; (275_1)(Obj_Pum_DisplayText_Horizontal)
      ; -------------------------------------------
      ; Hide Color Picker
      Num_Hide := 190
      Loop 48
      {
        Num_Hide := Num_Hide + 1
        DataArray := Image_GuiControl(Num_Hide, 0, 0, DataArray)
      }
      ; -------------------------------------------
    } ; End Hide
    ; -------------------------------------------
    { ; Show
      ; -------------------------------------------
      DataArray := Image_GuiControl("157", 1, 1, DataArray) ; (157_1)(Obj_Pum_Setting)
      ; -------------------------------------------
      AppName := DataArray.367.1 ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
      ; -------------------------------------------
      v_365_2 := DataArray.365.2 ; (365_2)(UserLang [Current User language])
      ThisPumProcessXml := DataArray.361.9 ; (361)(9)(ThisPumProcessXml [Full File Path])
      ; -------------------------------------------
      ;
      ; -------------------------------------------
      if (AppName == "windows") ; (367_2)([Line 1] Active Process Name [NO Ext] [NO Path])
      {
        ; -------------------------------------------
        DataArray := Image_GuiControl("160", 0, 1, DataArray) ; (160_1)(Obj_Pum_App))
        DataArray := Image_GuiControl("161", 0, 1, DataArray) ; (161_1)(Obj_Pum_Del)
        ; -------------------------------------------
      } ; End (367_2)([Line 1] Active Process Name [NO Ext] [NO Path])
      else if (InStr(ThisPumProcessXml, "\pumdefault\") > 0) ; Default Pum Active (Application Pum)
      {
        ; -------------------------------------------
        DataArray := Image_GuiControl("161", 0, 1, DataArray) ; (161_1)(Obj_Pum_Del)
        DataArray := Image_GuiControl("160", 1, 1, DataArray) ; (160_1)(Obj_Pum_App))
        ; -------------------------------------------
      }
      else
      {
        ; -------------------------------------------
        DataArray := Image_GuiControl("160", 0, 1, DataArray) ; (160_1)(Obj_Pum_App))
        DataArray := Image_GuiControl("161", 1, 1, DataArray) ; (161_1)(Obj_Pum_Del)
        ; -------------------------------------------
      }
      ; -------------------------------------------
      ;
      ; -------------------------------------------
      DataArray := Image_GuiControl("159", 2, 1, DataArray) ; (159_1)(Obj_Pum_Contact)
      ; -------------------------------------------
      DataArray := Image_GuiControl("184", 1, 1, DataArray) ; (184_1)(Obj_Pum_ImageText_EmailAddress)
      DataArray := Image_GuiControl("185", 1, 1, DataArray) ; (185_1)(Obj_Pum_ImageText_ContactName)
      DataArray := Image_GuiControl("186", 1, 0, DataArray) ; (186_1)(Obj_Pum_ImageText_PopUpMenuEmail)
      ; -------------------------------------------
      GuiControl, PopUpMenu:Show, g_188 ; (188_1)(Obj_Pum_EditFeild_EmailAddress)
      GuiControl, PopUpMenu:Show, g_189 ; (189_1)(Obj_Pum_EditFeild_ContactName)
      GuiControl, PopUpMenu:Show, g_190 ; (190_1)(Obj_Pum_EditFeild_EmailBody)
      ; -------------------------------------------
    } ; End Show
    ; -------------------------------------------
    Sleep, 500
    ImageNoContent :=  A_ProgramFiles "\PopUpMenu_PUM\image\gui\(187)_NoContent.png"
    GuiControl, PopUpMenu:, g_187, %ImageNoContent% ; (187_1)(Obj_Pum_SendEmailAnimate)
    GuiControl, PopUpMenu:Show, g_187 ; (187_1)(Obj_Pum_SendEmailAnimate)
    ; -------------------------------------------
    GuiControl, Focus, g_190 ; (190_1)(Obj_Pum_EditFeild_EmailBody)
   ; -------------------------------------------
  } ; if Button in Normal State
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
