﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\_S1_C.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\_S2_H.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\_S3_S.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Img_New135.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Img_Del135.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\l_521.ahk ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
; -------------------------------------------
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_PathFolderOrName.ahk
; -------------------------------------------
#Include %A_ProgramFiles%\PopUpMenu_PUM\Url_GetUrl.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
f_083(DataArray) ; (083_1)(Obj_Tom_Pum)
{
  ; -------------------------------------------
  if (DataArray.83.2 == 1) ; (083_2)(Obj_Tom_Pum_Sel [0,1,2,3])
  {
    ; -------------------------------------------
    DataArray := Image_GuiControl("137", 0, 0, DataArray) ; (137_1)(Obj_MsgImg480x270)
    ; -------------------------------------------
    DataArray := Image_GuiControl("254", 0, 0, DataArray) ; (254_1)(Obj_MsgImg300x300)
    ; -------------------------------------------
    DataArray.187.2 := 0 ; (187_2)(Obj_Pum_SendEmailAnimate_Sel [0,1,2])
    DataArray.187.3 := "" ; (187_3)(Obj_Pum_SendEmailAnimate_Img [Image Path])
    GuiControl, PopUpMenu:Hide, g_187 ; (187_1)(Obj_Pum_SendEmailAnimate)
    GuiControl, PopUpMenu:, g_187, ; (187_1)(Obj_Pum_SendEmailAnimate)
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    DataArray.366.5 := "pumtom" ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
    ; -------------------------------------------
    DataArray := _S1_C(DataArray)
    DataArray := _S2_H(DataArray)
    ; -------------------------------------------
    DataArray.187.2 := 0 ; (187_2)(Obj_Pum_SendEmailAnimate_Sel [0,1,2])
    DataArray.187.3 := "" ; (187_3)(Obj_Pum_SendEmailAnimate_Img [Image Path])
    GuiControl, PopUpMenu:Hide, g_187 ; (187_1)(Obj_Pum_SendEmailAnimate)
    GuiControl, PopUpMenu:, g_187, ; (187_1)(Obj_Pum_SendEmailAnimate)
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    HasConnection := Url_ConnectCheck(flag=0x40)
    ; -------------------------------------------
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (HasConnection == 0)
    {
      DataArray := Image_GuiControl("084", "1b", 1, DataArray) ; (084_1)(Obj_Tom_FileUrlFolder)
    }
    else
    {
      DataArray := Image_GuiControl("084", "1a", 1, DataArray) ; (084_1)(Obj_Tom_FileUrlFolder)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; -------------------------------------------
    DataArray := Image_GuiControl("086", 1, 1, DataArray) ; (086_1)(Obj_Tom_MenuControlKey)
    ; -------------------------------------------
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (HasConnection == 0)
    {
      DataArray := Image_GuiControl("083", "2b", 1, DataArray) ; (083_1)(Obj_Tom_Pum)
    }
    else
    {
      DataArray := Image_GuiControl("083", "2a", 1, DataArray) ; (083_1)(Obj_Tom_Pum)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; -------------------------------------------
    DataArray := Image_GuiControl("114", 0, 1, DataArray) ; (114_1)(Obj_DisplayText_Title1)
    DataArray := Image_GuiControl("115", 0, 1, DataArray) ; (115_1)(Obj_DisplayText_Title2)
    DataArray := Image_GuiControl("141", 0, 1, DataArray) ; (141_1)(Obj_DisplayText_Title3)
    ; -------------------------------------------
    ; (134_1)(Obj_ImageSelect1)
    DataArray := Image_GuiControl("135", 0, 0, DataArray) ; (135_1)(Obj_ImageSelect2)
    ; (136_1)(Obj_ImageSelect3)
    ; -------------------------------------------
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; (Image_PathFolderOrName) This Script just sets Paths
    ; -------------------------------------------
    ArrayIn := [DataArray.367.5, DataArray.367.1, DataArray.290.2, "FileRunPng", DataArray.365.2, DataArray.363.12]
    ArrayOut := Image_PathFolderOrName(ArrayIn)
    FileRunPng := ArrayOut.1
    ; -------------------------------------------
    ; (Image_PathFolderOrName) This Script just sets Paths
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; (Image_PathFolderOrName) This Script just sets Paths
    ; -------------------------------------------
    ArrayIn := [DataArray.367.5, DataArray.367.1, DataArray.290.2, "FileNew135", DataArray.365.2, DataArray.363.12]
    ArrayOut := Image_PathFolderOrName(ArrayIn)
    FileNew135 := ArrayOut.1
    ; -------------------------------------------
    ; (Image_PathFolderOrName) This Script just sets Paths
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; (Image_PathFolderOrName) This Script just sets Paths
    ; -------------------------------------------
    ArrayIn := [DataArray.367.5, DataArray.367.1, DataArray.290.2, "FileDel135", DataArray.365.2, DataArray.363.12]
    ArrayOut := Image_PathFolderOrName(ArrayIn)
    FileDel135 := ArrayOut.1
    ; -------------------------------------------
    ; (Image_PathFolderOrName) This Script just sets Paths
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (IsInternetBrowser(DataArray.367.1, DataArray.367.3, DataArray.367.4) == 1) ; All Supported Internet Browsers
    {
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ; [Internet Browser Application Active]
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ;
      ; -------------------------------------------
      if (DataArray.290.2 == 1) ; [UseCommonBrowser = 1][All Browsers Same Pum]
      {
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        ; [UseCommonBrowser = 1][All Browsers Same Pum]
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        ;
        ; -------------------------------------------
        ThisAppPath := A_ProgramFiles "\PopUpMenu_PUM\image\ico\pumcommonbrowser.txt"
        ArrayIn := [ThisAppPath, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
        New135 := Img_New135(ArrayIn)
        Del135 := Img_Del135(ArrayIn)
        ; -------------------------------------------
      } ; [UseCommonBrowser = 1][All Browsers Same Pum]
      else if (DataArray.290.2 == 2) ; [UseCommonBrowser = 2][Each Browser Different pum]
      {
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        ; [UseCommonBrowser = 2][Each Browser Different pum]
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        ;
        ; -------------------------------------------
        ThisAppPath := DataArray.367.5
        ArrayIn := [ThisAppPath, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
        New135 := Img_New135(ArrayIn)
        Del135 := Img_Del135(ArrayIn)
        ; -------------------------------------------
      } ; [UseCommonBrowser = 2][Each Browser Different pum]
      ; -------------------------------------------
    } ; [Internet Browser Application Active]
    ; -------------------------------------------
    else ; [Any Other Application (Non-Internet Browser) Active]
    {
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ; [Any Other Application (Non-Internet Browser) Active]
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ;
      ; -------------------------------------------
      ThisAppPath := DataArray.367.5
      ArrayIn := [ThisAppPath, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
      New135 := Img_New135(ArrayIn)
      Del135 := Img_Del135(ArrayIn)
      ; -------------------------------------------
    } ; [Any Other Application (Non-Internet Browser) Active]
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    global PopUpMenuAnimateNew135 := 0
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (!FileExist(FileNew135) or !FileExist(File135) or !FileExist(FileRunPng))
    {
      ;
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Start/Show (Jackhammer)
      global n_523 := 1 ; Start Frame Number
      global s_523 := 1 ; Show
      ; (523_1)(_Msg 4_)(_w480 x h270_)_Jackhammer)
      SetTimer, l_523, 150 ; (523_1)(_Msg 4_)(_w480 x h270_)_Jackhammer)
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Start/Show (Jackhammer)
      ;
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; -------------------------------------------
    DataArray := _S3_S(DataArray)
    ; -------------------------------------------
    ;
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Stop (Animate) Jackhammer
    global s_523 := 0 ; Hide
    SetTimer, l_523, Off ; (523_1)(_Msg 4_)(_w480 x h270_)_Jackhammer)
    global ShowAnimationChange := 0
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Stop (Animate) Jackhammer
    ;
    ; -------------------------------------------
    DataArray.187.2 := 0 ; (187_2)(Obj_Pum_SendEmailAnimate_Sel [0,1,2])
    DataArray.187.3 := "" ; (187_3)(Obj_Pum_SendEmailAnimate_Img [Image Path])
    GuiControl, PopUpMenu:Hide, g_187 ; (187_1)(Obj_Pum_SendEmailAnimate)
    GuiControl, PopUpMenu:, g_187, ; (187_1)(Obj_Pum_SendEmailAnimate)
    ; -------------------------------------------
    ;
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Start/Stop (Animate) Pum_Building_Construct
    if (n_521 == 170)
    {
      ; -------------------------------------------
      DataArray := Image_GuiControl("521_137", 169, 0, DataArray) ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
      global s_521 := 0 ; Hide
      SetTimer, l_521, Off ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
      global ShowAnimationChange := 0
      ; -------------------------------------------
    }
    else
    {
      global s_521 := 1 ; Show
      SetTimer, l_521, 350 ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
    }
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Start/Stop (Animate) Pum_Building_Construct
    ;
  } ; (083_2)([ToM] Pum) is in Normal State
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
