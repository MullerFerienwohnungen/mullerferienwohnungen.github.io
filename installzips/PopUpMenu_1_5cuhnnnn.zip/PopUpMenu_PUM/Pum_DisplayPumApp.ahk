﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\Img_New254.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Img_Del254.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_GuiControl.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\l_522.ahk ; (522_1)(_Msg 4_)(_w480 x h270_)_Nailing_Man)
#Include %A_ProgramFiles%\PopUpMenu_PUM\Pum_Close.ahk
; -------------------------------------------
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_PathFolderOrName.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Img_RunPng.ahk
; -------------------------------------------
#Include %A_ProgramFiles%\PopUpMenu_PUM\Url_GetUrl.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Pum_DisplayPumApp(ThisType, DataArray) ; > DataArray
{
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (IsInternetBrowser(DataArray.367.1, DataArray.367.3, DataArray.367.4) == 1) ; All Supported Internet Browsers
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ; [Internet Browser Application Active]
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ;
    ; -------------------------------------------
    if (DataArray.290.2 == 1) ; [UseCommonBrowser = 1][All Browsers Same Pum]
    {
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ; [Internet Browser Application Active]
      ;
      ; [UseCommonBrowser = 1][All Browsers Same Pum]
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ;
      ; -------------------------------------------
      FileRunPng := A_ProgramFiles "\PopUpMenu_PUM\image\ico\CommonBrowser_Png.png"
      FileNew254 := A_ProgramFiles "\PopUpMenu_PUM\image\ico\CommonBrowser_New254_" DataArray.365.2 ".png"
      FileDel254 := A_ProgramFiles "\PopUpMenu_PUM\image\ico\CommonBrowser_Del254_" DataArray.365.2 ".png"
      ; -------------------------------------------
    } ; [UseCommonBrowser = 1][All Browsers Same Pum]
    else if (DataArray.290.2 == 2) ; [UseCommonBrowser = 2][Each Browser Different pum]
    {
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ; [Internet Browser Application Active]
      ;
      ; [UseCommonBrowser = 2][Each Browser Different pum]
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ;
      ; -------------------------------------------
      ArrayIn    := [DataArray.367.5, DataArray.367.1, DataArray.290.2, "FileRunPng", DataArray.365.2, DataArray.363.12]
      ArrayOut   := Image_PathFolderOrName(ArrayIn)
      FileRunPng := ArrayOut.1
      ; -------------------------------------------
      if !FileExist(FileRunPng)
      {
        ; -------------------------------------------
        ArrayIn := [DataArray.367.5, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
        FileRunPng := Img_RunPng(ArrayIn)
        ; -------------------------------------------
      } ; [End] if !FileExist(FileRunPng)
      ; -------------------------------------------
      ;
      ; -------------------------------------------
      ArrayIn    := [DataArray.367.5, DataArray.367.1, DataArray.290.2, "FileNew254", DataArray.365.2, DataArray.363.12]
      ArrayOut   := Image_PathFolderOrName(ArrayIn)
      FileNew254 := ArrayOut.1
      ; -------------------------------------------
      ;
      ; -------------------------------------------
      ArrayIn    := [DataArray.367.5, DataArray.367.1, DataArray.290.2, "FileDel254", DataArray.365.2, DataArray.363.12]
      ArrayOut   := Image_PathFolderOrName(ArrayIn)
      FileDel254 := ArrayOut.1      
      ; -------------------------------------------
    } ; [UseCommonBrowser = 2][Each Browser Different pum]
    ; -------------------------------------------
  } ; [Internet Browser Application Active]
  else ; [Any Other Application (Non Internet Browser) Active]
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ; [Any Other Application (Non Internet Browser) Active]
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ;
    ; -------------------------------------------
    ArrayIn    := [DataArray.367.5, DataArray.367.1, DataArray.290.2, "FileRunPng", DataArray.365.2, DataArray.363.12]
    ArrayOut   := Image_PathFolderOrName(ArrayIn)
    FileRunPng := ArrayOut.1
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    if !FileExist(FileRunPng)
    {
      ; -------------------------------------------
      ArrayIn := [DataArray.367.5, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
      FileRunPng := Img_RunPng(ArrayIn)
      ; -------------------------------------------
    } ; [End] if !FileExist(FileRunPng)
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    ArrayIn    := [DataArray.367.5, DataArray.367.1, DataArray.290.2, "FileNew254", DataArray.365.2, DataArray.363.12]
    ArrayOut   := Image_PathFolderOrName(ArrayIn)
    FileNew254 := ArrayOut.1
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    ArrayIn    := [DataArray.367.5, DataArray.367.1, DataArray.290.2, "FileDel254", DataArray.365.2, DataArray.363.12]
    ArrayOut   := Image_PathFolderOrName(ArrayIn)
    FileDel254 := ArrayOut.1
    ; -------------------------------------------    
  } ; [Any Other Application (Non Internet Browser) Active]
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [CHECK] Image Exist, [CREATE] Image, [ANIMATE] run
  if (ThisType == "New")
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ; (ThisType == "New") > Change Image (Obj_MsgImg300x300)
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ;
    ; -------------------------------------------
    GuiControl, PopUpMenu:Hide, g_102 ; (102_1)(Obj_DisplayedIcon)
    ; -------------------------------------------
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [CHECK] Image Exist, [CREATE] Image, [ANIMATE] run
    if !FileExist(FileNew254)
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [GET] Current Var Value, [HIDE] Vars
      Pre_134 := DataArray.134.2 ; (134_2)(Obj_ImageSelect1_Sel [0,1,2,3])
      Pre_135 := DataArray.135.2 ; (135_2)(Obj_ImageSelect2_Sel [0,1,2,3])
      Pre_136 := DataArray.136.2 ; (136_2)(Obj_ImageSelect3_Sel [0,1,2,3])
      ; -------------------------------------------
      if (Pre_134 == "")
      {
        Pre_134 := 0 ; Set Here if Value is Blank
        DataArray.134.2 := Pre_134 ; (134_2)(Obj_ImageSelect1_Sel [0,1,2,3])
      }
      if (Pre_135 == "")
      {
        Pre_135 := 0 ; Set Here if Value is Blank
        DataArray.135.2 := Pre_135 ; (135_2)(Obj_ImageSelect2_Sel [0,1,2,3])
      }
      if (Pre_136 == "")
      {
        Pre_136 := 0 ; Set Here if Value is Blank
        DataArray.136.2 := Pre_136 ; (136_2)(Obj_ImageSelect3_Sel [0,1,2,3])
      }
      ; -------------------------------------------
      ; (134_1)(Obj_ImageSelect1)
      ; (135_1)(Obj_ImageSelect2)
      ; (136_1)(Obj_ImageSelect3)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [GET] Current Var Value, [HIDE] Vars
      ;
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Start/Show (Nailing_Man)
      global n_522 := 1 ; Start Frame Number
      global s_522 := 1 ; Show
      SetTimer, l_522, 100 ; (522_1)(_Msg 4_)(_w480 x h270_)_Nailing_Man)
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Start/Show (Nailing_Man)
      ;
      ; -------------------------------------------
      if (DataArray.290.2 == 1) ; [UseCommonBrowser = 1][All Browsers Same Pum]
      {
        ; -------------------------------------------
        CommonBrowserTextFile := A_AppData "\PopUpMenu_PUM\pums\pumcommonbrowser\pum_pumcommonbrowser.exe"
        ArrayIn := [CommonBrowserTextFile, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
        FileNew254 := Img_New254(ArrayIn)
        FileDel254 := Img_Del254(ArrayIn)
        ; -------------------------------------------
      } ; [UseCommonBrowser = 1][All Browsers Same Pum]
      else if (DataArray.290.2 == 2) ; [UseCommonBrowser = 2][Each Browser Different pum]
      {
        ; -------------------------------------------
        ArrayIn := [DataArray.367.5, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
        FileNew254 := Img_New254(ArrayIn)
        FileDel254 := Img_Del254(ArrayIn)
        ; -------------------------------------------
      } ; [UseCommonBrowser = 2][Each Browser Different pum]
      ; -------------------------------------------
      ;
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Stop/Hide (Nailing_Man)
      global s_522 := 0 ; Hide
      SetTimer, l_522, Off ; (522_1)(_Msg 4_)(_w480 x h270_)_Nailing_Man)
      global ShowAnimationChange := 0
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Stop/Hide (Nailing_Man)
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [RESTORE] Current Var Value, [SHOW] Vars
      if (Pre_134 == 1)
      {
        GuiControl, PopUpMenu:Show, g_134 ; (134_1)(Obj_ImageSelect1)
      }
      if (Pre_135 == 1)
      {
        GuiControl, PopUpMenu:Show, g_135 ; (135_1)(Obj_ImageSelect2)
      }
      if (Pre_136 == 1)
      {
        GuiControl, PopUpMenu:Show, g_136 ; (136_1)(Obj_ImageSelect3)
      }
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [RESTORE] Current Var Value, [SHOW] Vars
    } ; [End] if !FileExist(FileNew254)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [CHECK] Image Exist, [CREATE] Image, [ANIMATE] run
    ;
    ; -------------------------------------------
    DataArray := Image_GuiControl("137", 0, 0, DataArray) ; (137_1)(Obj_MsgImg480x270)
    ; -------------------------------------------
    GuiControl, PopUpMenu:, g_254, %FileNew254% ; (254_1)(Obj_MsgImg300x300)
    ; -------------------------------------------
  } ; (ThisType == "New") > Change Image (Obj_MsgImg300x300)
  else if (ThisType == "Del")
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ; (ThisType == "Del") > Change Image (Obj_MsgImg300x300)
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ;
    ; -------------------------------------------
    GuiControl, PopUpMenu:Hide, g_102 ; (102_1)(Obj_DisplayedIcon)
    ; -------------------------------------------
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [CHECK] Image Exist, [CREATE] Image, [ANIMATE] run
    if !FileExist(FileDel254)
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [GET] Current Var Value, [HIDE] Vars
      Pre_134 := DataArray.134.2 ; (134_2)(Obj_ImageSelect1_Sel [0,1,2,3])
      Pre_135 := DataArray.135.2 ; (135_2)(Obj_ImageSelect2_Sel [0,1,2,3])
      Pre_136 := DataArray.136.2 ; (136_2)(Obj_ImageSelect3_Sel [0,1,2,3])
      ; -------------------------------------------
      if (Pre_134 == "")
      {
        Pre_134 := 0
        DataArray.134.2 := Pre_134 ; (134_2)(Obj_ImageSelect1_Sel [0,1,2,3])
      }
      if (Pre_135 == "")
      {
        Pre_135 := 0
        DataArray.135.2 := Pre_135 ; (135_2)(Obj_ImageSelect2_Sel [0,1,2,3])
      }
      if (Pre_136 == "")
      {
        Pre_136 := 0
        DataArray.136.2 := Pre_136 ; (136_2)(Obj_ImageSelect3_Sel [0,1,2,3])
      }
      ; -------------------------------------------
      ; (134_1)(Obj_ImageSelect1)
      ; (135_1)(Obj_ImageSelect2)
      ; (136_1)(Obj_ImageSelect3)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [GET] Current Var Value, [HIDE] Vars
      ;
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Start/Show (Nailing_Man)
      global n_522 := 1 ; Start Frame Number
      global s_522 := 1 ; Show
      SetTimer, l_522, 100 ; (522_1)(_Msg 4_)(_w480 x h270_)_Nailing_Man)
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Start/Show (Nailing_Man)
      ;
      ; -------------------------------------------
      ArrayIn := [DataArray.367.5, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
      FileNew254 := Img_New254(ArrayIn)
      FileDel254 := Img_Del254(ArrayIn)
      ; -------------------------------------------
      ;
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Stop/Hide (Nailing_Man)
      global s_522 := 0 ; Hide
      SetTimer, l_522, Off ; (522_1)(_Msg 4_)(_w480 x h270_)_Nailing_Man)
      global ShowAnimationChange := 0
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Stop/Hide (Nailing_Man)
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [RESTORE] Current Var Value, [SHOW] Vars
      if (Pre_134 == 1)
      {
        GuiControl, PopUpMenu:Show, g_134 ; (134_1)(Obj_ImageSelect1)
      }
      if (Pre_135 == 1)
      {
        GuiControl, PopUpMenu:Show, g_135 ; (135_1)(Obj_ImageSelect2)
      }
      if (Pre_136 == 1)
      {
        GuiControl, PopUpMenu:Show, g_136 ; (136_1)(Obj_ImageSelect3)
      }
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [RESTORE] Current Var Value, [SHOW] Vars
    } ; [End] if !FileExist(FileDel254)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [CHECK] Image Exist, [CREATE] Image, [ANIMATE] run
    ;
    ; -------------------------------------------
    DataArray := Image_GuiControl("137", 0, 0, DataArray) ; (137_1)(Obj_MsgImg480x270)
    ; -------------------------------------------
    GuiControl, PopUpMenu:, g_254, %FileDel254% ; (254_1)(Obj_MsgImg300x300)
    ; -------------------------------------------
  } ; (ThisType == "Del") > Change Image (Obj_MsgImg300x300)
  ; -------------------------------------------
  GuiControl, PopUpMenu:Show, g_254 ; (254_1)(Obj_MsgImg300x300)
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
