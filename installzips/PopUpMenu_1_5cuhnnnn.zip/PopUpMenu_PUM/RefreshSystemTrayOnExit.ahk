﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
#NoTrayIcon
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\Script_Close.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Script_Running.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Tray_Refresh()
{
  ; -------------------------------------------
  WM_MOUSEMOVE := 0x200
  detectHiddenWin := A_DetectHiddenWindows
  DetectHiddenWindows, On
  ; -------------------------------------------
  allTitles := ["ahk_class Shell_TrayWnd", "ahk_class NotifyIconOverflowWindow"]
  allControls := ["ToolbarWindow321", "ToolbarWindow322", "ToolbarWindow323", "ToolbarWindow324"]
  allIconSizes := [24,32]
  ; -------------------------------------------
  for id, title in allTitles
  {
    ; -------------------------------------------
    for id, controlName in allControls
    {
      ; -------------------------------------------
      for id, iconSize in allIconSizes
      {
        ; -------------------------------------------
        ControlGetPos, xTray,yTray,wdTray,htTray,% controlName,% title
        y := htTray - 10
        ; -------------------------------------------
        While (y > 0)
        {
          ; -------------------------------------------
          x := wdTray - iconSize/2
          ; -------------------------------------------
          While (x > 0)
          {
            point := (y << 16) + x
            PostMessage,% WM_MOUSEMOVE, 0,% point,% controlName,% title
            x -= iconSize/2
          } ; [End] While (x > 0)
          ; -------------------------------------------
          y -= iconSize/2
          ; -------------------------------------------
        } ; [End] While (y > 0)
        ; -------------------------------------------
      } ; [End] for id, iconSize in allIconSizes
      ; -------------------------------------------
    } ; [End] for id, controlName in allControls
    ; -------------------------------------------
  } ; [End] for id, title in allTitles
  ; -------------------------------------------
  DetectHiddenWindows, %detectHiddenWin%
  ; -------------------------------------------
} ; [End] Tray_Refresh()
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
ScriptPath := A_ProgramFiles "\PopUpMenu_PUM\SysTray.ahk"
if (Script_Running(ScriptPath) > 0) ; (running)
{
  Script_Close(ScriptPath)
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Tray_Refresh()
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
