﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
#NoTrayIcon
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\Script_Running.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Splash_Script.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; this the Main Program Starter
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; PopUpMenu_1_DayStamp.zip
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Functions
; -------------------------------------------
CheckHasAdminRights()
{
  ; -------------------------------------------
  TOKEN_QUERY := 0x0008
  TokenElevationTypeDefault := 1
  TokenElevationTypeFull := 2
  TokenElevationTypeLimited := 3
  TokenType := 8
  TokenElevationType := 18
  ; -------------------------------------------
  TokenInformationClass := TokenElevationType
  DllCall("SetLastError", "UInt", 0)
  ret := DllCall("Advapi32.dll\OpenProcessToken", "UInt", DllCall("GetCurrentProcess"), "UInt", TOKEN_QUERY, "UIntP", hToken)
  ; -------------------------------------------
  DllCall("SetLastError", "UInt", 0)
  DllCall("Advapi32.dll\GetTokenInformation", "UInt", hToken, "UInt", TokenInformationClass, "Int", 0, "Int", 0, "UIntP", ReturnLength)
  ; -------------------------------------------
  sizeof_elevationType:=VarSetCapacity(elevationType, ReturnLength, 0)
  DllCall("SetLastError", "UInt", 0)
  DllCall("Advapi32.dll\GetTokenInformation", "UInt", hToken, "UInt", TokenInformationClass, "UIntP", elevationType, "Int", sizeof_elevationType, "UIntP", ReturnLength)
  ; -------------------------------------------
  if (elevationType=TokenElevationTypeDefault)
  {
    ThisUserHasAdminRights := 0
  }
  else if (elevationType=TokenElevationTypeFull)
  {
    ThisUserHasAdminRights := 1
  }
  else if (elevationType=TokenElevationTypeLimited)
  {
    ThisUserHasAdminRights := 1
  }
  else
  {
    ThisUserHasAdminRights := 0
  }
  if (hToken)
  {
    DllCall("CloseHandle", "UInt", hToken)
  }
  ; -------------------------------------------
  return ThisUserHasAdminRights
  ; -------------------------------------------
} ; [End] CheckHasAdminRights()
; -------------------------------------------
; Functions
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Script_SysTray   := A_ProgramFiles "\PopUpMenu_PUM\SysTray.ahk"
Script_SysConfig := A_ProgramFiles "\PopUpMenu_PUM\SysConfig.ahk"
Script_SysLoad   := A_ProgramFiles "\PopUpMenu_PUM\SysLoad.ahk"
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
if (Script_Running(Script_SysConfig) == 0 && Script_Running(Script_SysLoad) == 0) ; PopUpMenu is NOT Loading
{
  ; -------------------------------------------
  if (Script_Running(Script_SysTray) > 0) ; PopUpMenu is Running
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    Splash_Script("518", 0) ; (518_1)(Empty)
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ;
    ; -------------------------------------------
    return
    ; -------------------------------------------
  }
  else ; PopUpMenu is NOT Running
  {
    ; -------------------------------------------
    HasAdminRights := CheckHasAdminRights()
    ; -------------------------------------------
    if (HasAdminRights == 1) ; User is Admin
    {
      ; -------------------------------------------
      Run, *RunAs %A_ProgramFiles%\PopUpMenu_PUM\SysLoad.ahk,,, Priority_PopUpMenuStart
      ; -------------------------------------------
      Process, Priority, %Priority_PopUpMenuStart%, High
      ; -------------------------------------------
      return
      ; -------------------------------------------
    } ; [End] if (HasAdminRights == 1) ; User is Admin
    else ; User is NOT Admin
    {
      ; -------------------------------------------
      Run, %A_ProgramFiles%\PopUpMenu_PUM\SysLoad.ahk,,, Priority_PopUpMenuStart
      ; -------------------------------------------
      Process, Priority, %Priority_PopUpMenuStart%, High
      ; -------------------------------------------
      return
      ; -------------------------------------------
    } ; [End] else ; User is NOT Admin
  } ; [End] else ; PopUpMenu is NOT Running
} ; [End] ; PopUpMenu is NOT Loading
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; END OF FILE
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
