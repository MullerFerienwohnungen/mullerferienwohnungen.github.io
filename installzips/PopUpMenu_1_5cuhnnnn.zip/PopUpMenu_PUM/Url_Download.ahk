﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Url_Download(ThisUrl, ThisFile) ; ThisUrl, ThisFile > File Downloaded OK [0/1]
{
  ; -------------------------------------------
  FileOk := 1
  ; -------------------------------------------
	static Var1 := false
  ; -------------------------------------------
  try ; Test Code 1
  {
    ; -------------------------------------------
    global ReqVar := ComObjCreate("WinHttp.WinHttpRequest.5.1")
    ; -------------------------------------------
	  if(!Var1 || ReqVar.option(1) != ThisUrl)
    {
      ; -------------------------------------------
  		ReqVar.open("GET", ThisUrl)
      ; -------------------------------------------
    } ; [End] if(!Var1 || ReqVar.option(1) != ThisUrl)
    ; -------------------------------------------
    ReqVar.send()
    ; -------------------------------------------
  } ; [End] try ; Test Code 1
  catch e ; Had Error Next Try
  {
    ; -------------------------------------------
    try ; Test Code 2
    {
      ; -------------------------------------------
      global ReqVar := ComObjCreate("MSXML2.XMLHTTP.6.0")
      ; -------------------------------------------
	    if(!Var1 || ReqVar.option(1) != ThisUrl)
      {
    		ReqVar.open("GET", ThisUrl)
      } ; [End] if(!Var1 || ReqVar.option(1) != ThisUrl)
      ; -------------------------------------------
      ReqVar.send()
      ; -------------------------------------------
    } ; [End] try ; Test Code 2
    catch e ; [SET] FileOk := 0 (will return)
    {
      ; -------------------------------------------
      FileOk := 0
      ; -------------------------------------------
      try ; Test Code 3
      {
        FileEncoding, UTF-8
        URLDownloadToFile, %ThisUrl%, %ThisFile%
      } ; [End] try ; Test Code 3
    } ; [End] catch e ; Error 2
  } ; [End] catch e ; Had Error Next Try
  ; -------------------------------------------
  if (FileOk == 0)
  {
    return FileOk
  }
  ; -------------------------------------------
  LastChr := SubStr(ThisUrl, StrLen(ThisUrl))
  if (LastChr == "/")
  {
    Sleep, 500
  }
  ; -------------------------------------------
  ; (_18_Oct_2022_)(_13:56:44_)
  ; Remarked Out due to error
  ; See Image 
  ; D:\(_Installed_)\(_PopUpMenu_)\((_Errors_)\(Url_Download)_Error.png
  ;
	;~ if (ReqVar.ResponseText == "failed" || ReqVar.Status != 200 || ComObjType(ReqVar.ResponseStream) != 0xd)
	if (ReqVar.Status != 200 || ComObjType(ReqVar.ResponseStream) != 0xd)
  {
    FileOk := 0
		return FileOk
  }
  ; -------------------------------------------
	ReqStreamVar := ComObjQuery(ReqVar.ResponseStream, "{0000000c-0000-0000-C000-000000000046}")
  ; -------------------------------------------
	FileOpenVar := FileOpen(ThisFile, "w")
	Loop
  {
		VarSetCapacity(VarSetCap, 8192)
		Var1 := DllCall(NumGet(NumGet(ReqStreamVar + 0) + 3 * A_PtrSize), ptr, ReqStreamVar, ptr, &VarSetCap, uint, 8192, "ptr*", VarUntil)
		FileOpenVar.rawwrite(&VarSetCap, VarUntil)
	} until (VarUntil == 0)
	FileOpenVar.Close()
  ; -------------------------------------------
  ObjRelease(ReqStreamVar)
  ; -------------------------------------------
  global ReqVar := ""
  ; -------------------------------------------
	return FileOk
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
