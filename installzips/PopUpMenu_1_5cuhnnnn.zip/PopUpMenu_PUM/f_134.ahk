﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\f_087.ahk ; (087_1)(Obj_Mnu_Menu)
#Include %A_ProgramFiles%\PopUpMenu_PUM\f_081.ahk ; (081_1)(Obj_RunRwh_File)
#Include %A_ProgramFiles%\PopUpMenu_PUM\f_157.ahk ; (157_1)(Obj_Pum_Setting)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
f_134(DataArray) ; (134_1)(Obj_ImageSelect1)
{
  ; -------------------------------------------
  if (DataArray.366.5 == "mnu_cpl_key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
  {
    ; -------------------------------------------
    ; [ScriptError == 17] (Addon Not Installed)(Addon Not Available)(Addon Not Been Requested)
    ; -------------------------------------------
    if (DataArray.366.6 != 17)  ; (366_6)(ScriptError [Integer])
    {
      DataArray := f_087(DataArray) ; (087_1)(Obj_Mnu_Menu)
    }
  } ; End [ScriptError == 17]
  else if (DataArray.366.5 == "run_rwh_url_ofl" or DataArray.366.5 == "url") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
  {
    DataArray := f_081(DataArray) ; (081_1)(Obj_RunRwh_File)
  }
  else if (DataArray.366.5 == "pumtom" or DataArray.366.5 == "pumApplication") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
  {
    DataArray := f_157(DataArray) ; (157_1)(Obj_Pum_Setting)
  }
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
