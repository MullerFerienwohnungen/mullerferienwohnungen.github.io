﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Pum_Validate(Check_I, Check_C, Check_R, DataArray) ; > Result Array
{
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  Result := "Ok"
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  SysGet, WorkArea_, MonitorWorkArea
  Scr_W := WorkArea_Right - WorkArea_Left
  Scr_H := WorkArea_Bottom - WorkArea_Top
  ; -------------------------------------------
  XmlIconSize     := DataArray.362.14 ; (362_14)(XmlIconSize [Displaymode iconsize] [32,48,64])
  XmlColumnsX    := DataArray.362.4 ; (362_4)(XmlColumnsX [Pum (X) Columns])
  XmlRowsY       := DataArray.362.3 ; (362_3)(XmlRowsY [Pum (Y) Rows])
  ; -------------------------------------------
  Array_ShortcutGrid := DataArray.362.58 ; (362_58)(Array_ShortcutGrid [C##R##, C##R##, C##R##] of Existing Shortcuts)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (Check_I != "")
  {
    This_Check := "I"
  }
  else if (Check_I == "")
  {
    Check_I := XmlIconSize
  }
  ; -------------------------------------------
  if (Check_C != "")
  {
    This_Check := "C"
  }
  if (Check_C == "")
  {
    Check_C := XmlColumnsX
  }
  ; -------------------------------------------
  if (Check_R != "")
  {
    This_Check := "R"
  }
  if (Check_R == "")
  {
    Check_R := XmlRowsY
  }
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  Check_W := Check_C * Check_I
  Check_H := Check_R * Check_I
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (Check_W >= Scr_W or Check_H >= Scr_H) ; (X)
  {
    Result := "Screen"
  }
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  Max_C := 0
  Max_R := 0
  ;
  for Index, This_Grid in Array_ShortcutGrid
  {
    ; -------------------------------------------
    ; C##R##
    ; 123456
    ; -------------------------------------------
    This_C := SubStr(This_Grid, 2, 2)
    if (SubStr(This_C, 1, 1) == 0)
    {
      This_C := SubStr(This_C, 2, 1)
    }
    ; -------------------------------------------
    This_R := SubStr(This_Grid, 5, 2)
    if (SubStr(This_R, 1, 1) == 0)
    {
      This_R := SubStr(This_R, 2, 1)
    }
    ; -------------------------------------------
    if (This_C > Max_C)
    {
      Max_C := This_C
    }
    if (This_R > Max_R)
    {
      Max_R := This_R
    }
    ; -------------------------------------------
  } ; End for Index, This_Grid in Array_ShortcutGrid
  ;
  ; -------------------------------------------
  if (Check_C < Max_C or Check_R < Max_R) ; (X)
  {
    Result := "Exist"
  }
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; Update DataArray
  ;~ ; -------------------------------------------
  ;~ if (Result == "Ok")
  ;~ {
    ;~ Check_W := Check_C * Check_I
    ;~ Check_H := Check_R * Check_I
    ; (362_14)(XmlIconSize [Displaymode iconsize] [32,48,64])
    ; (362_4)(XmlColumnsX [Pum (X) Columns])
    ; (362_3)(XmlRowsY [Pum (Y) Rows])
  ;~ ; -------------------------------------------
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; -------------------------------------------
  return Result
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
