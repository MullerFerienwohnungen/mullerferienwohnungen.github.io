#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_ChangeDPI.ahk ; Image_ChangeDPI(NewDPI, ImageIn, ImageOut) ; > Image_Out
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_GetDPI.ahk ; Image_GetDPI(FilePath) ; > DPI
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Image_FileSize(MaxBiteSize, Image_Path) ; (25000000)(MaxBiteSize, FileSizeImage) > FileSizeImage
{
	; -------------------------------------------
	FileGetSize, Image_Size , %Image_Path%, B
	; -------------------------------------------
	while (Image_Size > MaxBiteSize)
	{
		; -------------------------------------------
		This_DPI := Image_GetDPI(Image_Path) ; > DPI
		; -------------------------------------------
		This_DPI := This_DPI - 50
		; -------------------------------------------
		Image_ChangeDPI(This_DPI, Image_Path, Image_Path) ; > Image_Out
		; -------------------------------------------
		FileGetSize, Image_Size , %Image_Path%, B
		; -------------------------------------------
	}
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; END OF FILE
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
