﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
#NoTrayIcon
#SingleInstance, Force
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; (600)
; Uninstall PopUpMenu
; Text Color 2e0e0e
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Functions
; -------------------------------------------
UninstallHasAdminRights()
{
  ; -------------------------------------------
  TOKEN_QUERY := 0x0008
  TokenElevationTypeDefault := 1
  TokenElevationTypeFull := 2
  TokenElevationTypeLimited := 3
  TokenType := 8
  TokenElevationType := 18
  ; -------------------------------------------
  TokenInformationClass := TokenElevationType
  DllCall("SetLastError", "UInt", 0)
  ret := DllCall("Advapi32.dll\OpenProcessToken", "UInt", DllCall("GetCurrentProcess"), "UInt", TOKEN_QUERY, "UIntP", hToken)
  ; -------------------------------------------
  DllCall("SetLastError", "UInt", 0)
  DllCall("Advapi32.dll\GetTokenInformation", "UInt", hToken, "UInt", TokenInformationClass, "Int", 0, "Int", 0, "UIntP", ReturnLength)
  ; -------------------------------------------
  sizeof_elevationType:=VarSetCapacity(elevationType, ReturnLength, 0)
  DllCall("SetLastError", "UInt", 0)
  DllCall("Advapi32.dll\GetTokenInformation", "UInt", hToken, "UInt", TokenInformationClass, "UIntP", elevationType, "Int", sizeof_elevationType, "UIntP", ReturnLength)
  ; -------------------------------------------
  if (elevationType=TokenElevationTypeDefault)
  {
    ThisUserHasAdminRights := 0
  }
  else if (elevationType=TokenElevationTypeFull)
  {
    ThisUserHasAdminRights := 1
  }
  else if (elevationType=TokenElevationTypeLimited)
  {
    ThisUserHasAdminRights := 1
  }
  else
  {
    ThisUserHasAdminRights := 0
  }
  if (hToken)
  {
    DllCall("CloseHandle", "UInt", hToken)
  }
  ; -------------------------------------------
  return ThisUserHasAdminRights
  ; -------------------------------------------
} ; [End] CheckHasAdminRights()
; -------------------------------------------
; Functions
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; User Language [GET] (UserLang)
; -------------------------------------------
File_UserLang := A_AppData "\PopUpMenu_PUM\system\File_UserLang.txt"
; -------------------------------------------
if FileExist(File_UserLang)
{
  FileReadLINE, UserLang, %File_UserLang%, 1
}
if (UserLang == "")
{
  ; -------------------------------------------
  if FileExist(File_UserLang)
  {
    FileDelete, %File_UserLang%
    Sleep, 100
  } ; [End] if FileExist(File_UserLang)
  ; -------------------------------------------
  if (A_Language == "0407" or A_Language == "0807" or A_Language == "0c07" or A_Language == "1007" or A_Language == "1407")
  {
    ; -------------------------------------------
    UserLang := "de"
    ; -------------------------------------------
  } ; [End] German (de)
  ; -------------------------------------------
  else if (A_Language == "0409" or A_Language == "0809" or A_Language == "0c09" or A_Language == "1009" or A_Language == "1409" or A_Language == "1809" or A_Language == "1c09" or A_Language == "2009" or A_Language == "2409" or A_Language == "2809" or A_Language == "2c09" or A_Language == "3009" or A_Language == "3409")
  {
    ; -------------------------------------------
    UserLang := "en"
    ; -------------------------------------------
  } ; [End] English (en)
  ; -------------------------------------------
  else if (A_Language == "040a" or A_Language == "080a" or A_Language == "0c0a" or A_Language == "100a" or A_Language == "140a" or A_Language == "180a" or A_Language == "1c0a" or A_Language == "200a" or A_Language == "240a" or A_Language == "280a" or A_Language == "2c0a" or A_Language == "300a" or A_Language == "340a" or A_Language == "380a" or A_Language == "3c0a" or A_Language == "400a" or A_Language == "440a" or A_Language == "480a" or A_Language == "4c0a" or A_Language == "500a")
  {
    ; -------------------------------------------
    UserLang := "es"
    ; -------------------------------------------
  } ; [End] Spanish (es)
  ; -------------------------------------------
  else if (A_Language == "040c" or A_Language == "080c" or A_Language == "0c0c" or A_Language == "100c" or A_Language == "140c" or A_Language == "180c")
  {
    ; -------------------------------------------
    UserLang := "fr"
    ; -------------------------------------------
  } ; [End] French (fr)
  ; -------------------------------------------
  else if (A_Language == "0410" or A_Language == "0810")
  {
    ; -------------------------------------------
    UserLang := "it"
    ; -------------------------------------------
  } ; [End] Italian (it)
  ; -------------------------------------------
  else if (A_Language == "0415")
  {
    ; -------------------------------------------
    UserLang := "pl"
    ; -------------------------------------------
  } ; [End] Polish (pl)
  ; -------------------------------------------
  else if (A_Language == "0416" or A_Language == "0816")
  {
    ; -------------------------------------------
    UserLang := "pt"
    ; -------------------------------------------
  } ; [End] Portuguese (pt)
  ; -------------------------------------------
  else if (A_Language == "0419")
  {
    ; -------------------------------------------
    UserLang := "ru"
    ; -------------------------------------------
  } ; [End] Russian (ru)
  ; -------------------------------------------
  else if (A_Language == "041d" or A_Language == "081d")
  {
    ; -------------------------------------------
    UserLang := "sv"
    ; -------------------------------------------
  } ; [End] Swedish (sv)
  ; -------------------------------------------
  else if (A_Language == "041f")
  {
    ; -------------------------------------------
    UserLang := "tr"
    ; -------------------------------------------
  } ; [End] Turkish (tr)
  ; -------------------------------------------
  else ; English (en)
  {
    ; -------------------------------------------
    UserLang := "en"
    ; -------------------------------------------
  } ; [End] else ; English (en)
  ; -------------------------------------------
  FileEncoding, UTF-8 ; UTF-8
  FileAppend, %UserLang%`n, %File_UserLang% ; UTF-8
  ; -------------------------------------------
} ; [End] if (UserLang == "")
; -------------------------------------------
; User Language [GET] (UserLang)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Vars
; -------------------------------------------
ColorTrans := "000000" ; Black
ImagePath  := A_ProgramFiles "\PopUpMenu_PUM\image\gui"
File_UserLang := A_AppData "\PopUpMenu_PUM\system\File_UserLang.txt"
GuiFont := "Arial"
; -------------------------------------------
; Vars
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Check if Current User has Admin Rights
; -------------------------------------------
HasAdminRights := UninstallHasAdminRights()
; -------------------------------------------
if (HasAdminRights == "")
{
  HasAdminRights := 0
}
; ; Check if Current User has Admin Rights
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Display Gui
; -------------------------------------------
if (HasAdminRights == 0)
{
  ; -------------------------------------------
  ThisUser := A_Username
  ; -------------------------------------------
  GuiFont := "Arial"
  ; -------------------------------------------
  Gui, Margin , 0, 0
  ; -------------------------------------------
  Gui, Add, Picture, x0   y0   w250 h250 vImgBg, %ImagePath%\UninstallError_%UserLang%.png
  ; -------------------------------------------
  Gui, Font, c087417 s14 w700, %GuiFont%
  Gui, Add, Text, Center                  x10  y82 w230 , %ThisUser% ; (100_1)(Obj_DisplayText_Top1)
  ; -------------------------------------------
  Gui, Color, %ColorTrans%
  Gui, +LastFound -Caption +AlwaysOnTop +ToolWindow -Border
  Winset, TransColor, %ColorTrans%,
  Gui, Show
  SetTimer, Splash_Error, %CountTime%
  return
  ; -------------------------------------------
  Splash_Error:
  {
    ; -------------------------------------------
    if (Error_Num == "")
    {
      Error_Num := 18
    }
    ; -------------------------------------------
    Error_Num := Error_Num - 1
    ; -------------------------------------------
    if (Error_Num == 0)
    {
      ExitApp
    }
    ; -------------------------------------------
  } ; [End] Splash_Animate:
  return
  ; -------------------------------------------
}
else if (HasAdminRights == 1)
{
  ; ------------------------------------------- 
  CountTime  := 750
  ; -------------------------------------------
  ;
  ; -------------------------------------------
  Gui, Margin , 0, 0
  ; -------------------------------------------
  Gui, Add, Picture, x0   y0   w250 h250 vImgBg,          %ImagePath%\Uninstall_%UserLang%.png
  ; -------------------------------------------
  Gui, Add, Picture, x17  y199 w87  h30  vObj_Yes gl_Yes,   %ImagePath%\Yes_%UserLang%.png
  Gui, Add, Picture, x146 y199 w87  h30  vObj_No gl_No,     %ImagePath%\No_%UserLang%.png
  Gui, Add, Picture, x109 y199 w32  h30  vSplash_Animate, %ImagePath%\Count_9.png
  Gui, Color, %ColorTrans%
  Gui, +LastFound -Caption +AlwaysOnTop +ToolWindow -Border
  Winset, TransColor, %ColorTrans%,
  Gui, Show
  SetTimer, Splash_Animate, %CountTime%
  return
  ; -------------------------------------------
  l_Yes:
  {
    ; -------------------------------------------
    SetTimer, Splash_Animate, Off
    ; -------------------------------------------
    GuiControl, Hide, Obj_Yes
    GuiControl, Hide, Obj_No
    GuiControl, Hide, Splash_Animate
    GuiControl, , ImgBg, %ImagePath%\UninstallWorking_%UserLang%.png
    GuiControl, Show, ImgBg
    Sleep, 500
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    CopyUninstallImage := A_ProgramFiles "\PopUpMenu_PUM\image\gui\UninstallWorking_" UserLang ".png"
    UninstallImage := A_Temp "\PopUpMenuTempFolder\UninstallPopUpMenu.png"
    FileCopy, %CopyUninstallImage%, %UninstallImage%, 1
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    Run, *RunAs %A_ProgramFiles%\PopUpMenu_PUM\Splash_601.ahk
    ; -------------------------------------------
    ExitApp
    ; -------------------------------------------
  }
  return
  ; -------------------------------------------
  l_No:
  {
    ExitApp
  }
  return
  ; -------------------------------------------
  Splash_Animate:
  {
    ; -------------------------------------------
    if (Image_Num == "")
    {
      Image_Num := 9
    }
    ; -------------------------------------------
    Image_Num := Image_Num - 1
    ; -------------------------------------------
    ThisImage := ImagePath "\Count_" Image_Num ".png"
    GuiControl, , Splash_Animate, %ThisImage%
    GuiControl, Show, Splash_Animate
    ; -------------------------------------------
    if (Image_Num == 0)
    {
      Sleep, 250
      ExitApp
    }
    ; -------------------------------------------
  } ; [End] Splash_Animate:
  return
  ; -------------------------------------------
} ; [End] else if (HasAdminRights == 1)
; -------------------------------------------
; Display Gui
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
