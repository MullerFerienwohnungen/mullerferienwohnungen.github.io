﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_Monitor.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Pum_Check.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Pum_WinInWinMaxSize.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_ResizePng.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_Combine.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Shortcut_Grid.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Array_ItemExist.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Array_Add.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Array_FromFile.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_GuiControl.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\l_544.ahk ; (544_1)(_Msg 8_)(_w300 x h300_)_Messure_Man)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Image_PumDim(DataArray) ; > Nothing
{
  ; -------------------------------------------
  global PressedCancel := 0
  ; -------------------------------------------
  ; This Creates
  ; ThisPumProcessFolder "\image\DisplayPumDim.png"
  ;
  ; a Display of all Existing and Empty Shortcut Grids
  ;
  ; this image is used for
  ; "pum_pumSetting_pumDimension"
  ; (254)(GUI Object: [pum] Message Image 8)
  ; -------------------------------------------
  ;
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Start (Animate) Messure_Man
  global n_544 := 1 ; Start Frame Number
  global s_544 := 1 ; Show
  SetTimer, l_544, 250 ; (544_1)(_Msg 8_)(_w300 x h300_)_Messure_Man)
  DataArray := Image_GuiControl("544_254", 1, 0, DataArray) ; (544_1)(_Msg 8_)(_w300 x h300_)_Messure_Man)
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Start (Animate) Messure_Man
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; Vars
  XmlIconSize := DataArray.362.14 ; (362_14)(XmlIconSize [Displaymode iconsize] [32,48,64])
  XmlColumnsX := DataArray.362.4 ; (362_4)(XmlColumnsX [Pum (X) Columns])
  XmlRowsY    := DataArray.362.3 ; (362_3)(XmlRowsY [Pum (Y) Rows])
  ThisPumProcessFolder := DataArray.361.8 ; (361)(8)(ThisPumProcessFolder [Pum Folder Path])
  Scr_W   := A_ScreenWidth
  Scr_H   := A_ScreenHeight
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; -------------------------------------------
  UserLang := DataArray.365.2 ; (365_2)(UserLang [Current User language])
  ; -------------------------------------------
  Percent_X := 4 + XmlColumnsX
  ThisPercent := Round(100 / Percent_X)
  PercentNum  := 0
  ; -------------------------------------------
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (PressedCancel == 0)
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Loop
    PercentImage := A_ProgramFiles "\PopUpMenu_PUM\image\gui\(277)_" PercentNum ".png"
    GuiControl, PopUpMenu:, g_277, %PercentImage% ; (277_1)(Obj_Pum_DisplayText_PercentGrid)
    GuiControl, PopUpMenu:Show, g_277 ; (277_1)(Obj_Pum_DisplayText_PercentGrid)
    ; -------------------------------------------
    PercentNum := PercentNum + ThisPercent
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Loop  
  } ; [End] if (PressedCancel == 0)
  else
  {
    DataArray := Image_GuiControl("277", 0, 0, DataArray) ; (277_1)(Obj_Pum_DisplayText_PercentGrid)
  }
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (PressedCancel == 0)
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    DataArray := Image_GuiControl("560_272", XmlColumnsX, 0, DataArray) ; (560_1)(ObjImg_pumDimensionNumberImage)
    DataArray := Image_GuiControl("560_266", XmlRowsY, 0, DataArray) ; (560_1)(ObjImg_pumDimensionNumberImage)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  } ; [End] if (PressedCancel == 0)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (PressedCancel == 0)
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    Image_Monitor(PercentNum, ThisPercent) ; > Nothing
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  } ; [End] if (PressedCancel == 0)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (PressedCancel == 0)
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Loop
    PercentImage := A_ProgramFiles "\PopUpMenu_PUM\image\gui\(277)_" PercentNum ".png"
    GuiControl, PopUpMenu:, g_277, %PercentImage% ; (277_1)(Obj_Pum_DisplayText_PercentGrid)
    GuiControl, PopUpMenu:Show, g_277 ; (277_1)(Obj_Pum_DisplayText_PercentGrid)
    ; -------------------------------------------
    PercentNum := PercentNum + ThisPercent
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Loop  
  } ; [End] if (PressedCancel == 0)
  else
  {
    DataArray := Image_GuiControl("277", 0, 0, DataArray) ; (277_1)(Obj_Pum_DisplayText_PercentGrid)
  }
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (PressedCancel == 0)
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [NEED] Scr_W, Scr_H, XmlIconSize
    ; [SET] (DisplayPum_[W,H]), Icon_Size
    ; -------------------------------------------
    WinInWin_Array := Pum_WinInWinMaxSize(280, 240, Scr_W, Scr_H) ; OuterWin_W, OuterWin_H, InterWin_W, InterWin_H > [Max_W, Max_H]
    Mon_W := Round(WinInWin_Array.1)
    Mon_H := Round(WinInWin_Array.2)
    ; -------------------------------------------
    Factor_MonX := Mon_W / Scr_W ; < 0
    Factor_MonY := Mon_H / Scr_H ; < 0
    ; -------------------------------------------
    Icon_Size := (XmlIconSize * Factor_MonX) ; Set New Icon Size\
    ;
    DisplayPum_W := Round(XmlColumnsX * Icon_Size)
    DisplayPum_H := Round(XmlRowsY * Icon_Size)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  } ; [End] if (PressedCancel == 0)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (PressedCancel == 0)
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; Resize Existing and Blank Icon Images
    ; -------------------------------------------
    Source_IcoE := A_ProgramFiles "\PopUpMenu_PUM\image\pum\Display_" XmlIconSize "_E.png" ; Existing
    ImagePath_IcoE := A_AppData "\PopUpMenu_PUM\temp\Display_" XmlIconSize "_E.png" ; Existing
    FileDelete, %ImagePath_IcoE%
    Sleep, 10
    ;
    FileCopy, %Source_IcoE%, %ImagePath_IcoE%
    Sleep, 10
    Image_ResizePng(Icon_Size, Icon_Size, ImagePath_IcoE, ImagePath_IcoE) ; Resize_W, Resize_H, ImageIn, ImageOut > 1 / 0
    ; -------------------------------------------
    Source_IcoB := A_ProgramFiles "\PopUpMenu_PUM\image\pum\Display_" XmlIconSize "_B.png" ; Blank
    ImagePath_IcoB := A_AppData "\PopUpMenu_PUM\temp\Display_" XmlIconSize "_B.png" ; Blank
    FileDelete, %ImagePath_IcoB%
    Sleep, 10
    ;
    FileCopy, %Source_IcoB%, %ImagePath_IcoB%
    Sleep, 10
    Image_ResizePng(Icon_Size, Icon_Size, ImagePath_IcoB, ImagePath_IcoB) ; Resize_W, Resize_H, ImageIn, ImageOut > 1 / 0
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  } ; [End] if (PressedCancel == 0)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (PressedCancel == 0)
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Loop
    PercentImage := A_ProgramFiles "\PopUpMenu_PUM\image\gui\(277)_" PercentNum ".png"
    GuiControl, PopUpMenu:, g_277, %PercentImage% ; (277_1)(Obj_Pum_DisplayText_PercentGrid)
    GuiControl, PopUpMenu:Show, g_277 ; (277_1)(Obj_Pum_DisplayText_PercentGrid)
    ; -------------------------------------------
    PercentNum := PercentNum + ThisPercent
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Loop
  } ; [End] if (PressedCancel == 0)
  else
  {
    DataArray := Image_GuiControl("277", 0, 0, DataArray) ; (277_1)(Obj_Pum_DisplayText_PercentGrid)
  }
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (PressedCancel == 0)
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [NEED] XmlColumnsX, XmlRowsY
    ; Array_PumAllGrid [C##R##, C##R##, C##R##]
    ; of every grid posible
    ; -------------------------------------------
    Num_R := 0
    Loop %XmlRowsY%
    {
      ; -------------------------------------------
      if (PressedCancel == 1)
      {
        break
      }
      ; -------------------------------------------
      ;
      Num_R := Num_R + 1
      Num_C := 0
      ; -------------------------------------------
      Loop %XmlColumnsX%
      {
        ; -------------------------------------------
        Num_C := Num_C + 1
        ; -------------------------------------------
        This_C := Num_C
        This_R := Num_R
        ; -------------------------------------------
        if (This_C < 10)
        {
          This_C := "0" This_C
        }
        if (This_R < 10)
        {
          This_R := "0" This_R
        }
        ; -------------------------------------------
        Grid_Num := "C" This_C "R" This_R
        Array_PumAllGrid := Array_Add(Array_PumAllGrid, Grid_Num, "End") ; ThisArray, AddThis, ThisPos > ThisArray
        ; -------------------------------------------
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  } ; [End] if (PressedCancel == 0)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ThisPumProcessArray := DataArray.361.10  ; (361)(10)(ThisPumProcessArray)
  ; -------------------------------------------
  Array_ShortcutGrid := Shortcut_Grid(ThisPumProcessArray) ; (361)(10)(ThisPumProcessArray)
  DataArray.362.58 := Array_ShortcutGrid ; (362_58)(Array_ShortcutGrid [C##R##, C##R##, C##R##] of Existing Shortcuts)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (PressedCancel == 0)
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [NEED] Array_PumAllGrid, ImagePath_IcoB, ImagePath_IcoE
    ; [SET] Array_IcoImagePath [ImagePath, Icon_X, Icon_Y, ImagePath, Icon_X, Icon_Y]
    ; 
    ; This Array is every Pum Grid (Existing and Blank)
    ; -------------------------------------------
    Array_IcoImagePath := []
    Array_GridImagePath := ""
    for Index, ThisGrid in Array_PumAllGrid
    {
      ; -------------------------------------------
      Num_C := SubStr(ThisGrid, 2, 2) - 1
      Num_R := SubStr(ThisGrid, 5, 2) - 1
      ; -------------------------------------------
      ShortcutExist := Array_ItemExist(Array_ShortcutGrid, ThisGrid) ; ThisArray, CheckThis > Number of times in Array
      ; -------------------------------------------
      if (ShortcutExist == 0)
      {
        Count_B := Count_B + 1  ; TEMP
        ImagePath := ImagePath_IcoB
      }
      else
      {
        Count_E := Count_E + 1  ; TEMP
        ImagePath := ImagePath_IcoE
      }
      ; -------------------------------------------
      Array_IcoImagePath.Push(ImagePath) ; Adds (AddThis) to End
      ; -------------------------------------------
      ; ThisGrid := "C" This_C "R" This_R
      AddThisGrid := [ImagePath, ThisGrid]
      Array_GridImagePath := Array_Add(Array_GridImagePath, AddThisGrid, "End") ; ThisArray, AddThis, ThisPos > ThisArray
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  } ; [End] if (PressedCancel == 0)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (PressedCancel == 0)
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [CREATE] A_AppData "\PopUpMenu_PUM\temp\Image_PumGrid.png"
    ; -------------------------------------------
    Array_ImageCombine := []
    Array_ImageCombine.Push(DisplayPum_W) ; Adds (AddThis) to End
    Array_ImageCombine.Push(DisplayPum_H) ; Adds (AddThis) to End
    Array_ImageCombine.Push(DisplayPumGrid) ; Adds (AddThis) to End
    ; -------------------------------------------
    ColumnX := 0
    ; -------------------------------------------
    Loop %XmlColumnsX%
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      if (PressedCancel == 1)
      {
        break
      }
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; -------------------------------------------
      ColumnX := ColumnX + 1
      ; -------------------------------------------
      ImageGridColumn := A_AppData "\PopUpMenu_PUM\temp\ImageGridColumn_" ColumnX ".png"
      FileDelete, %ImageGridColumn%
      ; -------------------------------------------
      Array_ImageCombine := []
      Array_ImageCombine.Push(DisplayPum_W) ; Adds (AddThis) to End
      Array_ImageCombine.Push(DisplayPum_H) ; Adds (AddThis) to End
      Array_ImageCombine.Push(ImageGridColumn) ; Adds (AddThis) to End
      ; -------------------------------------------
      if (ColumnX > 1)
      {
        ; -------------------------------------------
        LastColumnX := ColumnX - 1
        LastImageGridColumn := A_AppData "\PopUpMenu_PUM\temp\ImageGridColumn_" LastColumnX ".png"
        ; -------------------------------------------
        Array_ImageCombine.Push(LastImageGridColumn) ; Adds (AddThis) to End
        ; -------------------------------------------
        PosX := 0
        PosY := 0
        Array_ImageCombine.Push(PosX) ; Adds (AddThis) to End
        Array_ImageCombine.Push(PosY) ; Adds (AddThis) to End
        ; -------------------------------------------
      }
      ; -------------------------------------------
      for Index, ThisGridArray in Array_GridImagePath
      {
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        if (PressedCancel == 1)
        {
          break
        }
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ;
        ; -------------------------------------------
        ThisGridPos := ThisGridArray.2
        ; ThisGridPos := "C##R##"
        ; -------------------------------------------
        ThisColumnX := SubStr(ThisGridPos, 2, 2)
        ThisX       := (ThisColumnX - 1) * Icon_Size
        ; -------------------------------------------
        ThisRowY := SubStr(ThisGridPos, 5, 2)
        ThisY    := (ThisRowY - 1) * Icon_Size
        ; -------------------------------------------
        if (ThisColumnX == ColumnX)
        {
          ; -------------------------------------------
          ThisGridImage := ThisGridArray.1
          ; -------------------------------------------
          Array_ImageCombine.Push(ThisGridImage) ; Adds (AddThis) to End
          Array_ImageCombine.Push(ThisX) ; Adds (AddThis) to End
          Array_ImageCombine.Push(ThisY) ; Adds (AddThis) to End
          ; -------------------------------------------
        } ; [End] if (ThisColumnX == ColumnX)
      } ; [End] for Index, ThisGridArray in Array_GridImagePath
      ; -------------------------------------------
      ; This is your Time Killer
      Image_Combine(Array_ImageCombine) ; Image_Array := [Out_W, Out_H, Image_Out, (Image, Image_X, Image_Y,) etc]
      ; -------------------------------------------
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      if (PressedCancel == 0)
      {
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Loop
        PercentImage := A_ProgramFiles "\PopUpMenu_PUM\image\gui\(277)_" PercentNum ".png"
        GuiControl, PopUpMenu:, g_277, %PercentImage% ; (277_1)(Obj_Pum_DisplayText_PercentGrid)
        GuiControl, PopUpMenu:Show, g_277 ; (277_1)(Obj_Pum_DisplayText_PercentGrid)
        ; -------------------------------------------
        PercentNum := PercentNum + ThisPercent
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Loop
      }
      else
      {
        DataArray := Image_GuiControl("277", 0, 0, DataArray) ; (277_1)(Obj_Pum_DisplayText_PercentGrid)
      }
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    } ; [End] Loop %XmlColumnsX%
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  } ; [End] if (PressedCancel == 0)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (PressedCancel == 0)
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [CREATE] A_AppData "\PopUpMenu_PUM\temp\Image_PumGrid.png"
    ; -------------------------------------------
    if (ColumnX > 1)
    {
      ImageNum := 1
      while (ImageNum != ColumnX)
      {
        ThisImage := A_AppData "\PopUpMenu_PUM\temp\ImageGridColumn_" ImageNum ".png"
        FileDelete, %ThisImage%
        ImageNum := ImageNum + 1
      }
    } ; [End] if (ColumnX > 1)
    ; -------------------------------------------
    MoveThis      := A_AppData "\PopUpMenu_PUM\temp\ImageGridColumn_" ColumnX ".png"
    Image_PumGrid := A_AppData "\PopUpMenu_PUM\temp\Image_PumGrid.png"
    FileMove, %MoveThis%, %Image_PumGrid%
    ; -------------------------------------------
    ; Image_PumGrid.png Has Been Created No Longer Need Existing of Blank Icon Images
    FileDelete, %ImagePath_IcoE%
    FileDelete, %ImagePath_IcoB%
    ; -------------------------------------------
    ; [CREATE] A_AppData "\PopUpMenu_PUM\temp\Image_PumGrid.png"
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  } ; [End] if (PressedCancel == 0)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (PressedCancel == 0)
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; Center Pum in Display
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    ; Horizontal
    ; -------------------------------------------
    Num_1 := Mon_W - DisplayPum_W
    Num_1 := Floor(Num_1 / 2)
    Spacer_X := Num_1 + 10
    ; -------------------------------------------
    ;
    ; ------------------------------------------
    ; Vertical
    ; -------------------------------------------
    Factor := Mon_H / 240
    Factor := Factor * 10
    Num_1 := 250 - Mon_H
    Num_2 := (Mon_H - DisplayPum_H) / 2
    Spacer_Y := Num_1 + Num_2
    Spacer_Y := Spacer_Y + (Factor / 2)
    ; -------------------------------------------
    ; Center Pum in Display
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  } ; [End] if (PressedCancel == 0)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (PressedCancel == 0)
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; Combine 
    ; A_AppData "\PopUpMenu_PUM\system\DisplayMonitor.png"
    ; A_AppData "\PopUpMenu_PUM\temp\Image_PumGrid.png"
    ; -------------------------------------------
    DisplayMonitor := A_AppData "\PopUpMenu_PUM\system\DisplayMonitor.png"
    DisplayPumDim := ThisPumProcessFolder "\image\DisplayPumDim.png"
    ; -------------------------------------------
    Array_ImageCombine := []
    Array_ImageCombine.Push(300) ; Adds (AddThis) to End
    Array_ImageCombine.Push(300) ; Adds (AddThis) to End
    Array_ImageCombine.Push(DisplayPumDim) ; This is the Out Image
    ; -------------------------------------------
    Array_ImageCombine.Push(DisplayMonitor) ; Adds (AddThis) to End
    Array_ImageCombine.Push(0) ; Adds (AddThis) to End
    Array_ImageCombine.Push(0) ; Adds (AddThis) to End
    ; -------------------------------------------
    Array_ImageCombine.Push(Image_PumGrid) ; Adds (AddThis) to End
    Array_ImageCombine.Push(Spacer_X) ; Adds (AddThis) to End
    Array_ImageCombine.Push(Spacer_Y) ; Adds (AddThis) to End
    ; -------------------------------------------
    Image_Combine(Array_ImageCombine) ; Image_Array := [Out_W, Out_H, Image_Out, (Image, Image_X, Image_Y,) etc]
    ; -------------------------------------------
    FileDelete, %Image_PumGrid%
    FileDelete, %DisplayMonitor%
    ; -------------------------------------------
    ; Combine 
    ; A_AppData "\PopUpMenu_PUM\system\DisplayMonitor.png"
    ; A_AppData "\PopUpMenu_PUM\temp\Image_PumGrid.png"
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  } ; [End] if (PressedCancel == 0)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (PressedCancel == 0)
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    DataArray := Pum_Check(DataArray) ; > DataArray
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  } ; [End] if (PressedCancel == 0)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (PressedCancel == 0)
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Loop
    PercentImage := A_ProgramFiles "\PopUpMenu_PUM\image\gui\(277)_100.png"
    GuiControl, PopUpMenu:, g_277, %PercentImage% ; (277_1)(Obj_Pum_DisplayText_PercentGrid)
    GuiControl, PopUpMenu:Show, g_277 ; (277_1)(Obj_Pum_DisplayText_PercentGrid)
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Loop
  } ; [End] if (PressedCancel == 0)
  else
  {
    DataArray := Image_GuiControl("277", 0, 0, DataArray) ; (277_1)(Obj_Pum_DisplayText_PercentGrid)
  }
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  Sleep, 500
  ;
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Stop (Animate) Messure_Man
  global s_544 := 0 ; Hide
  SetTimer, l_544, Off ; (544_1)(_Msg 8_)(_w300 x h300_)_Messure_Man)
  global ShowAnimationChange := 0
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Stop (Animate) Messure_Man
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (PressedCancel == 0)
  {
    ; ------------------------------------------- ; Message Image (SelectImage)
    GuiControl, PopUpMenu:, g_254, %DisplayPumDim% ; (254_1)(Obj_MsgImg300x300)
    GuiControl, PopUpMenu:Show, g_254 ; (254_1)(Obj_MsgImg300x300)
    ; ------------------------------------------- ; Message Image (SelectImage)
  } ; [End] if (PressedCancel == 0)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; -------------------------------------------
  DataArray := Image_GuiControl("277", 0, 0, DataArray) ; (277_1)(Obj_Pum_DisplayText_PercentGrid)
  ; -------------------------------------------
  global PressedCancel := 0
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
