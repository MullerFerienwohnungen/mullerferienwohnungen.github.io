﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\Folder_WindowsUser.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_Combine.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_ImgToIco.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_ResizePng.ahk
; -------------------------------------------
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_PathFolderOrName.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Img_RunPng.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Img_RwhIco(ArrayIn) ; > FileRwhIco
{
/*
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
ArrayIn := [DataArray.367.5, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
FileRwhIco := Img_RwhIco(ArrayIn)
; -------------------------------------------
ArrayIn := [AppProcessPathNameExt, AppProcessName, UseCommonBrowser, UserLang, UserPictureFolder]
FileRwhIco := Img_RwhIco(ArrayIn)
; -------------------------------------------
ArrayIn := [run_OutTarget, "", "", UserLang, UserPictureFolder]
FileRwhIco := Img_RwhIco(ArrayIn)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
AppProcessPathNameExt := ArrayIn.1 ; (DataArray.367.5)(AppProcessPathNameExt [Path,Name,Ext])
AppProcessName        := ArrayIn.2 ; (DataArray.367.1)(AppProcessName [Name][LowerCase][NoSpace])
UseCommonBrowser      := ArrayIn.3 ; (DataArray.290.2 = 2 [UseCommonBrowser = 2][Each Browser Different pum])(DataArray.290.2 = 1 [UseCommonBrowser = 1][All Browsers Same Pum])
UserLang              := ArrayIn.4 ; (DataArray.365.2)(UserLang [Current User language])
UserPictureFolder     := ArrayIn.5 ; (UserPictureFolder)(ThisUserPictureFolder)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
return FileRwhIco
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
*/
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; StartUp Vars
  ; -------------------------------------------
  AppProcessPathNameExt := ArrayIn.1 ; (AppProcessPathNameExt)(AppProcessPathNameExt [Path,Name,Ext])
  AppProcessName        := ArrayIn.2 ; (AppProcessName)(AppProcessName [Name][LowerCase][NoSpace])
  UseCommonBrowser      := ArrayIn.3 ; (UseCommonBrowser = 1 [UseCommonBrowser = 2][Each Browser Different pum])(UseCommonBrowser = 0 [UseCommonBrowser = 1][All Browsers Same Pum])
  UserLang              := ArrayIn.4 ; (UserLang)(UserLang [Current User language])
  UserPictureFolder     := ArrayIn.5  ; (UserPictureFolder)(ThisUserPictureFolder)
  ; -------------------------------------------
  ; StartUp Vars
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; if This Value is Blank
  ; -------------------------------------------
  if (UseCommonBrowser == "")
  {
    UseCommonBrowser := 0
  }
  ; -------------------------------------------
  if (UserPictureFolder == "")
  {
    ; -------------------------------------------
    RegRead, UserPictureFolder, HKEY_CURRENT_USER, Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders, My Pictures
    ; -------------------------------------------
  }
  ; -------------------------------------------
  if (AppProcessName == "")
  {
    if (AppProcessPathNameExt != "")
    {
      SplitPath, AppProcessPathNameExt, , , , AppProcessName
    }
  }
  ; -------------------------------------------
  ; if This Value is Blank
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if FileExist(AppProcessPathNameExt) ; Does the App Exist
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ArrayIn    := [AppProcessPathNameExt, AppProcessName, UseCommonBrowser, "FileRunPng", UserLang, UserPictureFolder]
    ArrayOut   := Image_PathFolderOrName(ArrayIn)
    FileRunPng := ArrayOut.1
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ArrayIn    := [AppProcessPathNameExt, AppProcessName, UseCommonBrowser, "FileRwhIco", UserLang, UserPictureFolder]
    ArrayOut   := Image_PathFolderOrName(ArrayIn)
    FileRwhIco := ArrayOut.1
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [CHECK] [CREATE]
    ; [UserPictureFolder "\(_PopUpMenu_)\(_Application_)\Png\" AppProcessName "_(" AppProcessFolder ").png"]
    ; -------------------------------------------
    if !FileExist(FileRunPng)
    {
      ; -------------------------------------------
      ArrayIn := [AppProcessPathNameExt, AppProcessName, UseCommonBrowser, UserLang, UserPictureFolder]
      FileRunPng := Img_RunPng(ArrayIn)
      ; -------------------------------------------
    } ; [End] if !FileExist(FileRunPng)
    ; -------------------------------------------
    ; [CHECK] [CREATE]
    ; [UserPictureFolder "\(_PopUpMenu_)\(_Application_)\Png\" AppProcessName "_(" AppProcessFolder ").png"]
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [CHECK] [CREATE]
    ; [UserPictureFolder "\(_PopUpMenu_)\(_Application_)\(_Item_)\" AppProcessName "_(" AppProcessFolder ").ico"]
    ; -------------------------------------------
    if !FileExist(FileRwhIco)
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      TempFolder := A_AppData "\PopUpMenu_PUM\temp"
      ; -------------------------------------------
      if !FileExist(TempFolder)
      {
        FileCreateDir, %TempFolder%
        Sleep, 10
      } ; [End] if !FileExist(TempFolder)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; [RESIZE] [UserPictureFolder "\(_PopUpMenu_)\(_Application_)\Png\" AppProcessName "_(" AppProcessFolder ").png"]
      ; [TO]     [A_AppData "\PopUpMenu_PUM\temp\RwhIcoTemp1.png]
      ; -------------------------------------------
      RwhIcoTemp1 := A_AppData "\PopUpMenu_PUM\temp\RwhIcoTemp1.png" ; w53 h53
      ; -------------------------------------------
      if FileExist(RwhIcoTemp1)
      {
        FileDelete, %RwhIcoTemp1%
      } ; [End] if FileExist(RwhIcoTemp1)
      ; -------------------------------------------
      Image_ResizePng(53, 53, FileRunPng, RwhIcoTemp1) ; [RESIZE]_W, Resize_H, ImageIn, ImageOut > 1 / 0
      ; -------------------------------------------
      ; [RESIZE] [UserPictureFolder "\(_PopUpMenu_)\(_Application_)\Png\" AppProcessName "_(" AppProcessFolder ").png"]
      ; [TO]     [A_AppData "\PopUpMenu_PUM\temp\RwhIcoTemp1.png]
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; [CREATE]  [A_AppData "\PopUpMenu_PUM\temp\RwhIcoTemp2.png"]
      ; [COMBINE] [A_ProgramFiles "\PopUpMenu_PUM\image\ico\rwh.png"]
      ; [WITH]    [A_AppData "\PopUpMenu_PUM\temp\RwhIcoTemp1.png"]
      ; -------------------------------------------
      I1 := A_ProgramFiles "\PopUpMenu_PUM\image\ico\rwh.png" ; w80 h80
      X1 := 0
      Y1 := 0
      ;
      I2 := RwhIcoTemp1
      X2 := 14 ; X Position
      Y2 := 17 ; Y Postion
      ; -------------------------------------------
      RwhIcoTemp2 := A_AppData "\PopUpMenu_PUM\temp\RwhIcoTemp2.png" ; w80 h80
      Image_Array := [80, 80, RwhIcoTemp2, I1, X1, Y1, I2, X2, Y2]
      Image_Combine(Image_Array)
      ; -------------------------------------------
      ; [CREATE]  [A_AppData "\PopUpMenu_PUM\temp\RwhIcoTemp2.png"]
      ; [COMBINE] [A_ProgramFiles "\PopUpMenu_PUM\image\ico\rwh.png"]
      ; [WITH]    [A_AppData "\PopUpMenu_PUM\temp\RwhIcoTemp1.png"]
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; [CONVERT] [A_AppData "\PopUpMenu_PUM\temp\RwhIcoTemp2.png"]
      ; [TO ICO]  [UserPictureFolder "\(_PopUpMenu_)\(_Application_)\(_Item_)\" AppProcessName "_(" AppProcessFolder ").ico"]
      ; -------------------------------------------
      Image_ImgToIco(RwhIcoTemp2, FileRwhIco) ; > ImageOut
      ; -------------------------------------------
      ; [CONVERT] [A_AppData "\PopUpMenu_PUM\temp\RwhIcoTemp2.png"]
      ; [TO ICO]  [UserPictureFolder "\(_PopUpMenu_)\(_Application_)\(_Item_)\" AppProcessName "_(" AppProcessFolder ").ico"]
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; [DELETE] [A_AppData "\PopUpMenu_PUM\temp\RwhIcoTemp1.png"]
      ; [DELETE] [A_AppData "\PopUpMenu_PUM\temp\RwhIcoTemp2.png"]
      ; -------------------------------------------
      if FileExist(RwhIcoTemp1)
      {
        FileDelete, %RwhIcoTemp1%
      } ; [End] if FileExist(RwhIcoTemp1)
      ; -------------------------------------------
      if FileExist(RwhIcoTemp2)
      {
        FileDelete, %RwhIcoTemp2%
      } ; [End] if FileExist(RwhIcoTemp2)
      ; -------------------------------------------
      ; [DELETE] [A_AppData "\PopUpMenu_PUM\temp\RwhIcoTemp1.png"]
      ; [DELETE] [A_AppData "\PopUpMenu_PUM\temp\RwhIcoTemp2.png"]
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    } ; [End] if !FileExist(FileRwhIco)
    ; -------------------------------------------
    return FileRwhIco
    ; -------------------------------------------
  } ; [End] if FileExist(AppProcessPathNameExt) ; Does the App Exist
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
