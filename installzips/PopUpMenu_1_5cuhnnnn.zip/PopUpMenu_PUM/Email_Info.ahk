﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\IpLocator.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Email_Info() ; > ReturnArray := [(1)BoardID, (2)SystemName, (3)WindowsVersion, (4)IpPublic, (5)IpPrivate, (6)HasAdminRights, (7)ThisCity, (8)ThisRegion, (9)ThisPostal, (10)ThisCountry, (11)ThisTimeZone, (12)LangPopUpMenu, (13)LangSystem, (14)ContactName, (15)ContactEmail]
{
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; BoardID
  ; -------------------------------------------
  (ComObjGet("winmgmts:{impersonationLevel=impersonate}!\\" . A_ComputerName . "\root\cimv2").ExecQuery("Select * From Win32_BaseBoard")._NewEnum)[objMBInfo]
  BoardID := objMBInfo["SerialNumber"]
  ; -------------------------------------------
  ; BoardID
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; WindowsVersion
  ; -------------------------------------------
  RegRead, WindowsVersion, HKEY_LOCAL_MACHINE, Software\Microsoft\Windows NT\CurrentVersion, ProductName ; (360_2)(Windows Version)
  ; -------------------------------------------
  ; WindowsVersion
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; IpPublic, IpPrivate, ThisTimeZone, ThisRegion, ThisCity, ThisPostal, ThisCountry
  ; -------------------------------------------
  IpInfoArray := GetLocation() ; ReturnArray := ["IP", "TimeZone", "Region", "City", "ZipCode", "Country"]
  ; -------------------------------------------
  IpPrivate    := A_IPAddress1 ; (360_8)(Private IP)
  IpPublic     := IpInfoArray.1
  ThisTimeZone := IpInfoArray.2
  ThisRegion   := IpInfoArray.3
  ThisCity     := IpInfoArray.4
  ThisPostal   := IpInfoArray.5
  ThisCountry  := IpInfoArray.6
  ; -------------------------------------------
  ; IpPublic, IpPrivate, ThisTimeZone, ThisRegion, ThisCity, ThisPostal, ThisCountry
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; SystemName
  ; -------------------------------------------
  strComputer := "."
  objWMIService := ComObjGet("winmgmts:{impersonationLevel=impersonate}!\\" . strComputer . "\root\cimv2")
  ; -------------------------------------------
  colSettings := objWMIService.ExecQuery("Select * from Win32_ComputerSystem")._NewEnum
  while colSettings[strCSItem]
  {
    ComputerSystem := strCSItem.Caption
  } 
  ; -------------------------------------------
  colSettings := objWMIService.ExecQuery("Select * from Win32_OperatingSystem")._NewEnum
  while colSettings[objOSItem]
  {
    OperatingSystem := objOSItem.CSName
  }
  ; -------------------------------------------
  if (OperatingSystem == ComputerSystem)
  {
    SystemName := OperatingSystem
  }
  else
  {
    SystemName := ComputerSystem " / " OperatingSystem
  }
  ; -------------------------------------------
  ; SystemName
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; HasAdminRights
  ; -------------------------------------------
  HasAdminRights := EmailInfoHasAdminRights()
  ; -------------------------------------------
  ; HasAdminRights
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; LangPopUpMenu
  ; -------------------------------------------
  File_UserLang := A_AppData "\PopUpMenu_PUM\system\File_UserLang.txt"
  ; -------------------------------------------
  if FileExist(File_UserLang)
  {
    FileReadLINE, UserLang, %File_UserLang%, 1
    Sleep, 100
    if (UserLang == "de")
    {
      LangPopUpMenu := "(de) German"
    }
    else if (UserLang == "en")
    {
      LangPopUpMenu := "(en) English"
    }
    else if (UserLang == "es")
    {
      LangPopUpMenu := "(es) Spanish"
    }
    else if (UserLang == "fr")
    {
      LangPopUpMenu := "(fr) French"
    }
    else if (UserLang == "it")
    {
      LangPopUpMenu := "(it) Italian"
    }
    else if (UserLang == "pl")
    {
      LangPopUpMenu := "(pl) Polish"
    }
    else if (UserLang == "pt")
    {
      LangPopUpMenu := "(pt) Portuguese"
    }
    else if (UserLang == "ru")
    {
      LangPopUpMenu := "(ru) Russian"
    }
    else if (UserLang == "sv")
    {
      LangPopUpMenu := "(sv) Swedish"
    }
    else if (UserLang == "tr")
    {
      LangPopUpMenu := "(tr) Turkish"
    }
    else
    {
      LangPopUpMenu := "UNKNOWN"
    }
  } ; [End] if FileExist(File_UserLang)
  else
  {
    LangPopUpMenu := "UNKNOWN"
  }
  ; -------------------------------------------
  ; LangPopUpMenu
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;    
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  { ; LangSystem
    ; -------------------------------------------
    if (A_Language == "0436")
    {
      LangSystem := "Afrikaans"
    }
    else if (A_Language == "041c")
    {
      LangSystem := "Albanian"
    }
    else if (A_Language == "0401")
    {
      LangSystem := "Arabic_Saudi_Arabia"
    }
    else if (A_Language == "0801")
    {
      LangSystem := "Arabic_Iraq"
    }
    else if (A_Language == "0c01")
    {
      LangSystem := "Arabic_Egypt"
    }
    else if (A_Language == "1001")
    {
      LangSystem := "Arabic_Libya"
    }
    else if (A_Language == "1401")
    {
      LangSystem := "Arabic_Algeria"
    }
    else if (A_Language == "1801")
    {
      LangSystem := "Arabic_Morocco"
    }
    else if (A_Language == "1c01")
    {
      LangSystem := "Arabic_Tunisia"
    }
    else if (A_Language == "2001")
    {
      LangSystem := "Arabic_Oman"
    }
    else if (A_Language == "2401")
    {
      LangSystem := "Arabic_Yemen"
    }
    else if (A_Language == "2801")
    {
      LangSystem := "Arabic_Syria"
    }
    else if (A_Language == "2c01")
    {
      LangSystem := "Arabic_Jordan"
    }
    else if (A_Language == "3001")
    {
      LangSystem := "Arabic_Lebanon"
    }
    else if (A_Language == "3401")
    {
      LangSystem := "Arabic_Kuwait"
    }
    else if (A_Language == "3801")
    {
      LangSystem := "Arabic_UAE"
    }
    else if (A_Language == "3c01")
    {
      LangSystem := "Arabic_Bahrain"
    }
    else if (A_Language == "4001")
    {
      LangSystem := "Arabic_Qatar"
    }
    else if (A_Language == "042b")
    {
      LangSystem := "Armenian"
    }
    else if (A_Language == "042c")
    {
      LangSystem := "Azeri_Latin"
    }
    else if (A_Language == "082c")
    {
      LangSystem := "Azeri_Cyrillic"
    }
    else if (A_Language == "042d")
    {
      LangSystem := "Basque"
    }
    else if (A_Language == "0423")
    {
      LangSystem := "Belarusian"
    }
    else if (A_Language == "0402")
    {
      LangSystem := "Bulgarian"
    }
    else if (A_Language == "0403")
    {
      LangSystem := "Catalan"
    }
    else if (A_Language == "0404")
    {
      LangSystem := "Chinese_Taiwan"
    }
    else if (A_Language == "0804")
    {
      LangSystem := "Chinese_PRC"
    }
    else if (A_Language == "0c04")
    {
      LangSystem := "Chinese_Hong_Kong"
    }
    else if (A_Language == "1004")
    {
      LangSystem := "Chinese_Singapore"
    }
    else if (A_Language == "1404")
    {
      LangSystem := "Chinese_Macau"
    }
    else if (A_Language == "041a")
    {
      LangSystem := "Croatian"
    }
    else if (A_Language == "0405")
    {
      LangSystem := "Czech"
    }
    else if (A_Language == "0406")
    {
      LangSystem := "Danish"
    }
    else if (A_Language == "0413")
    {
      LangSystem := "Dutch_Standard"
    }
    else if (A_Language == "0813")
    {
      LangSystem := "Dutch_Belgian"
    }
    else if (A_Language == "0409")
    {
      LangSystem := "English_United_States"
    }
    else if (A_Language == "0809")
    {
      LangSystem := "English_United_Kingdom"
    }
    else if (A_Language == "0c09")
    {
      LangSystem := "English_Australian"
    }
    else if (A_Language == "1009")
    {
      LangSystem := "English_Canadian"
    }
    else if (A_Language == "1409")
    {
      LangSystem := "English_New_Zealand"
    }
    else if (A_Language == "1809")
    {
      LangSystem := "English_Irish"
    }
    else if (A_Language == "1c09")
    {
      LangSystem := "English_South_Africa"
    }
    else if (A_Language == "2009")
    {
      LangSystem := "English_Jamaica"
    }
    else if (A_Language == "2409")
    {
      LangSystem := "English_Caribbean"
    }
    else if (A_Language == "2809")
    {
      LangSystem := "English_Belize"
    }
    else if (A_Language == "2c09")
    {
      LangSystem := "English_Trinidad"
    }
    else if (A_Language == "3009")
    {
      LangSystem := "English_Zimbabwe"
    }
    else if (A_Language == "3409")
    {
      LangSystem := "English_Philippines"
    }
    else if (A_Language == "0425")
    {
      LangSystem := "Estonian"
    }
    else if (A_Language == "0438")
    {
      LangSystem := "Faeroese"
    }
    else if (A_Language == "0429")
    {
      LangSystem := "Farsi"
    }
    else if (A_Language == "040b")
    {
      LangSystem := "Finnish"
    }
    else if (A_Language == "040c")
    {
      LangSystem := "French_Standard"
    }
    else if (A_Language == "080c")
    {
      LangSystem := "French_Belgian"
    }
    else if (A_Language == "0c0c")
    {
      LangSystem := "French_Canadian"
    }
    else if (A_Language == "100c")
    {
      LangSystem := "French_Swiss"
    }
    else if (A_Language == "140c")
    {
      LangSystem := "French_Luxembourg"
    }
    else if (A_Language == "180c")
    {
      LangSystem := "French_Monaco"
    }
    else if (A_Language == "0437")
    {
      LangSystem := "Georgian"
    }
    else if (A_Language == "0407")
    {
      LangSystem := "German_Standard"
    }
    else if (A_Language == "0807")
    {
      LangSystem := "German_Swiss"
    }
    else if (A_Language == "0c07")
    {
      LangSystem := "German_Austrian"
    }
    else if (A_Language == "1007")
    {
      LangSystem := "German_Luxembourg"
    }
    else if (A_Language == "1407")
    {
      LangSystem := "German_Liechtenstein"
    }
    else if (A_Language == "0408")
    {
      LangSystem := "Greek"
    }
    else if (A_Language == "040d")
    {
      LangSystem := "Hebrew"
    }
    else if (A_Language == "0439")
    {
      LangSystem := "Hindi"
    }
    else if (A_Language == "040e")
    {
      LangSystem := "Hungarian"
    }
    else if (A_Language == "040f")
    {
      LangSystem := "Icelandic"
    }
    else if (A_Language == "0421")
    {
      LangSystem := "Indonesian"
    }
    else if (A_Language == "0410")
    {
      LangSystem := "Italian_Standard"
    }
    else if (A_Language == "0810")
    {
      LangSystem := "Italian_Swiss"
    }
    else if (A_Language == "0411")
    {
      LangSystem := "Japanese"
    }
    else if (A_Language == "043f")
    {
      LangSystem := "Kazakh"
    }
    else if (A_Language == "0457")
    {
      LangSystem := "Konkani"
    }
    else if (A_Language == "0412")
    {
      LangSystem := "Korean"
    }
    else if (A_Language == "0426")
    {
      LangSystem := "Latvian"
    }
    else if (A_Language == "0427")
    {
      LangSystem := "Lithuanian"
    }
    else if (A_Language == "042f")
    {
      LangSystem := "Macedonian"
    }
    else if (A_Language == "043e")
    {
      LangSystem := "Malay_Malaysia"
    }
    else if (A_Language == "083e")
    {
      LangSystem := "Malay_Brunei_Darussalam"
    }
    else if (A_Language == "044e")
    {
      LangSystem := "Marathi"
    }
    else if (A_Language == "0414")
    {
      LangSystem := "Norwegian_Bokmal"
    }
    else if (A_Language == "0814")
    {
      LangSystem := "Norwegian_Nynorsk"
    }
    else if (A_Language == "0415")
    {
      LangSystem := "Polish"
    }
    else if (A_Language == "0416")
    {
      LangSystem := "Portuguese_Brazilian"
    }
    else if (A_Language == "0816")
    {
      LangSystem := "Portuguese_Standard"
    }
    else if (A_Language == "0418")
    {
      LangSystem := "Romanian"
    }
    else if (A_Language == "0419")
    {
      LangSystem := "Russian"
    }
    else if (A_Language == "044f")
    {
      LangSystem := "Sanskrit"
    }
    else if (A_Language == "081a")
    {
      LangSystem := "Serbian_Latin"
    }
    else if (A_Language == "0c1a")
    {
      LangSystem := "Serbian_Cyrillic"
    }
    else if (A_Language == "041b")
    {
      LangSystem := "Slovak"
    }
    else if (A_Language == "0424")
    {
      LangSystem := "Slovenian"
    }
    else if (A_Language == "040a")
    {
      LangSystem := "Spanish_Traditional_Sort"
    }
    else if (A_Language == "080a")
    {
      LangSystem := "Spanish_Mexican"
    }
    else if (A_Language == "0c0a")
    {
      LangSystem := "Spanish_Modern_Sort"
    }
    else if (A_Language == "100a")
    {
      LangSystem := "Spanish_Guatemala"
    }
    else if (A_Language == "140a")
    {
      LangSystem := "Spanish_Costa_Rica"
    }
    else if (A_Language == "180a")
    {
      LangSystem := "Spanish_Panama"
    }
    else if (A_Language == "1c0a")
    {
      LangSystem := "Spanish_Dominican_Republic"
    }
    else if (A_Language == "200a")
    {
      LangSystem := "Spanish_Venezuela"
    }
    else if (A_Language == "240a")
    {
      LangSystem := "Spanish_Colombia"
    }
    else if (A_Language == "280a")
    {
      LangSystem := "Spanish_Peru"
    }
    else if (A_Language == "2c0a")
    {
      LangSystem := "Spanish_Argentina"
    }
    else if (A_Language == "300a")
    {
      LangSystem := "Spanish_Ecuador"
    }
    else if (A_Language == "340a")
    {
      LangSystem := "Spanish_Chile"
    }
    else if (A_Language == "380a")
    {
      LangSystem := "Spanish_Uruguay"
    }
    else if (A_Language == "3c0a")
    {
      LangSystem := "Spanish_Paraguay"
    }
    else if (A_Language == "400a")
    {
      LangSystem := "Spanish_Bolivia"
    }
    else if (A_Language == "440a")
    {
      LangSystem := "Spanish_El_Salvador"
    }
    else if (A_Language == "480a")
    {
      LangSystem := "Spanish_Honduras"
    }
    else if (A_Language == "4c0a")
    {
      LangSystem := "Spanish_Nicaragua"
    }
    else if (A_Language == "500a")
    {
      LangSystem := "Spanish_Puerto_Rico"
    }
    else if (A_Language == "0441")
    {
      LangSystem := "Swahili"
    }
    else if (A_Language == "041d")
    {
      LangSystem := "Swedish"
    }
    else if (A_Language == "081d")
    {
      LangSystem := "Swedish_Finland"
    }
    else if (A_Language == "0449")
    {
      LangSystem := "Tamil"
    }
    else if (A_Language == "0444")
    {
      LangSystem := "Tatar"
    }
    else if (A_Language == "041e")
    {
      LangSystem := "Thai"
    }
    else if (A_Language == "041f")
    {
      LangSystem := "Turkish"
    }
    else if (A_Language == "0422")
    {
      LangSystem := "Ukrainian"
    }
    else if (A_Language == "0420")
    {
      LangSystem := "Urdu"
    }
    else if (A_Language == "0443")
    {
      LangSystem := "Uzbek_Latin"
    }
    else if (A_Language == "0843")
    {
      LangSystem := "Uzbek_Cyrillic"
    }
    else if (A_Language == "042a")
    {
      LangSystem := "Vietnamese"
    }
    else
    {
      LangSystem := "UNKNOWN"
    }
    ; -------------------------------------------
  } ; LangSystem
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>                    
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; ContactName, ContactEmail
  ; -------------------------------------------
  File_ContactInfo := A_AppData "\PopUpMenu_PUM\system\Contact.txt"
  if FileExist(File_ContactInfo)
  {
    ; -------------------------------------------
    FileReadLine, ContactName, %File_ContactInfo%, 1
    FileReadLine, ContactEmail, %File_ContactInfo%, 2
    ; -------------------------------------------
    DataArray.359.1 := ContactName ; (359_1)(Pum_ContactName [Email Contact Name])
    DataArray.359.2 := ContactEmail ; (359_2)(Pum_ContactEmail [Contact Email Address])
    ; -------------------------------------------
    GuiControl, PopUpMenu:, g_188, %ContactEmail% ; (188_1)(Obj_Pum_EditFeild_EmailAddress)
    GuiControl, PopUpMenu:, g_189, %ContactName% ; (189_1)(Obj_Pum_EditFeild_ContactName)
    ; -------------------------------------------
  }
  else
  {
    ContactName := "Not Entered"
    ContactEmail := "Not Entered"
  }
  ; -------------------------------------------
  ; ContactName, ContactEmail
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  FileDelete, %A_Desktop%\iplocate
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ReturnArray := []
  ReturnArray[1]  := BoardID
  ReturnArray[2]  := SystemName
  ReturnArray[3]  := WindowsVersion
  ReturnArray[4]  := IpPublic
  ReturnArray[5]  := IpPrivate
  ReturnArray[6]  := HasAdminRights
  ReturnArray[7]  := ThisCity
  ReturnArray[8]  := ThisRegion
  ReturnArray[9]  := ThisPostal
  ReturnArray[10] := ThisCountry
  ReturnArray[11] := ThisTimeZone
  ReturnArray[12] := LangPopUpMenu
  ReturnArray[13] := LangSystem
  ReturnArray[14] := ContactName
  ReturnArray[15] := ContactEmail
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; > ReturnArray [(1)BoardID, (2)SystemName, (3)WindowsVersion, (4)IpPublic, (5)IpPrivate, (6)HasAdminRights, (7)ThisCity, (8)ThisRegion, (9)ThisPostal, (10)ThisCountry, (11)ThisTimeZone, (12)LangPopUpMenu, (13)LangSystem, (14)ContactName, (15)ContactEmail]
  ; [(1)BoardID, (2)SystemName, (3)WindowsVersion, (4)IpPublic, (5)IpPrivate, (6)HasAdminRights, (7)ThisCity, (8)ThisRegion, (9)ThisPostal, (10)ThisCountry, (11)ThisTimeZone, (12)LangPopUpMenu, (13)LangSystem, (14)ContactName, (15)ContactEmail]
  return ReturnArray
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  /*
    BoardID         := EmailInfoArray.1
    SystemName      := EmailInfoArray.2
    WindowsVersion  := EmailInfoArray.3
    IpPublic        := EmailInfoArray.4
    IpPrivate       := EmailInfoArray.5
    HasAdminRights  := EmailInfoArray.6
    ThisCity        := EmailInfoArray.7
    ThisRegion      := EmailInfoArray.8
    ThisPostal      := EmailInfoArray.9
    ThisCountry     := EmailInfoArray.10
    ThisTimeZone    := EmailInfoArray.11
    LangPopUpMenu   := EmailInfoArray.12
    LangSystem      := EmailInfoArray.13
    ContactName     := EmailInfoArray.14
    ContactEmail    := EmailInfoArray.15
  */
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
}
; -------------------------------------------
EmailInfoHasAdminRights()
{
  ; -------------------------------------------
  TOKEN_QUERY := 0x0008
  TokenElevationTypeDefault := 1
  TokenElevationTypeFull := 2
  TokenElevationTypeLimited := 3
  TokenType := 8
  TokenElevationType := 18
  ; -------------------------------------------
  TokenInformationClass := TokenElevationType
  DllCall("SetLastError", "UInt", 0)
  ret := DllCall("Advapi32.dll\OpenProcessToken", "UInt", DllCall("GetCurrentProcess"), "UInt", TOKEN_QUERY, "UIntP", hToken)
  ; -------------------------------------------
  DllCall("SetLastError", "UInt", 0)
  DllCall("Advapi32.dll\GetTokenInformation", "UInt", hToken, "UInt", TokenInformationClass, "Int", 0, "Int", 0, "UIntP", ReturnLength)
  ; -------------------------------------------
  sizeof_elevationType:=VarSetCapacity(elevationType, ReturnLength, 0)
  DllCall("SetLastError", "UInt", 0)
  DllCall("Advapi32.dll\GetTokenInformation", "UInt", hToken, "UInt", TokenInformationClass, "UIntP", elevationType, "Int", sizeof_elevationType, "UIntP", ReturnLength)
  ; -------------------------------------------
  if (elevationType=TokenElevationTypeDefault)
  {
    ThisUserHasAdminRights := 0
  }
  else if (elevationType=TokenElevationTypeFull)
  {
    ThisUserHasAdminRights := 1
  }
  else if (elevationType=TokenElevationTypeLimited)
  {
    ThisUserHasAdminRights := 1
  }
  else
  {
    ThisUserHasAdminRights := 0
  }
  if (hToken)
  {
    DllCall("CloseHandle", "UInt", hToken)
  }
  ; -------------------------------------------
  return ThisUserHasAdminRights
  ; -------------------------------------------
} ; [End] CheckHasAdminRights()
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
