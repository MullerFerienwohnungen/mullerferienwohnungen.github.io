﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\KeyArray_SelectKey.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\_S1_C.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\_S2_H.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\_S3_S.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
f_014(DataArray) ; (014_1)(Obj_Key_CtrlDown)
{
  ; -------------------------------------------
  DataArray := KeyArray_SelectKey("014", DataArray) ; (014_1)(GUI Object: [key] Ctrl Down)
  ; -------------------------------------------
  DataArray := _S1_C(DataArray)
  DataArray := _S2_H(DataArray)
  DataArray := _S3_S(DataArray)
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
