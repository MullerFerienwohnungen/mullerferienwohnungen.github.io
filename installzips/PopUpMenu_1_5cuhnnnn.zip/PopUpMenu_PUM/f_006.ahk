﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\Shortcut_Config.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Sys_ResetDataArray.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Shortcut_Default.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
f_006(DataArray) ; (006_1)(Obj_ShortcutToDefaultPum)
{
  ; -------------------------------------------
  if (DataArray.305.17 == 1) ; (305_17)(Run_DefaultPum [0,1][Selected Shortcut is to the Default pum])
  {
    ; -------------------------------------------
    ; Delete Default pum Shortcut
    ; -------------------------------------------
    DataArray.133.2 := 2 ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])
    ; -------------------------------------------
    GuiControlGet, Obj_EditFeild_StatusBar_Val, PopUpMenu:, g_122 ; (122_1)(Obj_EditFeild_StatusBar)
    DataArray.122.3 := Obj_EditFeild_StatusBar_Val ; (122_3)(Obj_EditFeild_StatusBar_Val [Text Value])
    ; -------------------------------------------
    DataArray := Shortcut_Config(DataArray) ; > DataArray
    ; -------------------------------------------
    DataArray := Sys_ResetDataArray(DataArray) ; > DataArray
    ; -------------------------------------------
    Sleep, 300
    ; -------------------------------------------
  } ; [End] Delete Default pum Shortcut
  else ; Create Default pum Shortcut
  {
    ; -------------------------------------------
    ; Create Default pum Shortcut
    ; -------------------------------------------
    UserLang := DataArray.365.2 ; (365_2)(UserLang [Current User language])
    ; -------------------------------------------
    DataArray.366.5 := "run" ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
    DataArray.133.2 := 0 ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])
    ; -------------------------------------------
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [SET] "run" Shortcut Vars
    ; -------------------------------------------
    ;
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (run)
    ; Script_Line_2 := 0/1/2                      (073_2)(Obj_Run_AsAdmin_Sel [0,1,2])
    ; Script_Line_3 := "x:\Executable.ext"        (305_11)(run_OutTarget [FullPath])
    ; Script_Line_4 := "Run_Arguments"            (305_12)(run_Arguments [Executable Arguments])
    ; Script_Line_5 := 0/1                        (305_13)(run_UseLink [Selected OutTarget File Is a LNK] [0/1])
    ; Script_Line_6 := ""                         (Empty)
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (run)
    ;
    DataArray.73.2   := 2 ; (073_2)(Obj_Run_AsAdmin_Sel [0,1,2])
    DataArray.305.11 := A_AppData "\PopUpMenu_PUM\pums\pumdefault\pum_pumdefault.exe" ; (305_11)(Run_OutTarget [PathExtName])
    DataArray.305.12 := "" ; (305_12)(Run_Arguments [Executable Arguments])
    DataArray.305.13 := 0 ; (305_13)(Run_UseLink [Selected OutTarget File Is a LNK] [0/1])
    ; -------------------------------------------
    ; [SET] "run" Shortcut Vars
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [SET] Shortcut Description
    ; -------------------------------------------
    if (UserLang == "de")
    {
      ; -------------------------------------------
      DataArray.122.3 := "Computer PUM" ; (122_3)(Obj_EditFeild_StatusBar_Val [Text Value])
      ; -------------------------------------------
    }
    else if (UserLang == "en")
    {
      ; -------------------------------------------
      DataArray.122.3 := "Computer PUM" ; (122_3)(Obj_EditFeild_StatusBar_Val [Text Value])
      ; -------------------------------------------
    }
    else if (UserLang == "es")
    {
      ; -------------------------------------------
      DataArray.122.3 := "Ordenador PUM" ; (122_3)(Obj_EditFeild_StatusBar_Val [Text Value])
      ; -------------------------------------------
    }
    else if (UserLang == "fr")
    {
      ; -------------------------------------------
      DataArray.122.3 := "Ordinateur PUM" ; (122_3)(Obj_EditFeild_StatusBar_Val [Text Value])
      ; -------------------------------------------
    }
    else if (UserLang == "it")
    {
      ; -------------------------------------------
      DataArray.122.3 := "Computer PUM" ; (122_3)(Obj_EditFeild_StatusBar_Val [Text Value])
      ; -------------------------------------------
    }
    else if (UserLang == "pl")
    {
      ; -------------------------------------------
      DataArray.122.3 := "Komputer PUM" ; (122_3)(Obj_EditFeild_StatusBar_Val [Text Value])
      ; -------------------------------------------
    }
    else if (UserLang == "pt")
    {
      ; -------------------------------------------
      DataArray.122.3 := "Computador PUM" ; (122_3)(Obj_EditFeild_StatusBar_Val [Text Value])
      ; -------------------------------------------
    }
    else if (UserLang == "ru")
    {
      ; -------------------------------------------
      DataArray.122.3 := "Компьютер PUM" ; (122_3)(Obj_EditFeild_StatusBar_Val [Text Value])
      ; -------------------------------------------
    }
    else if (UserLang == "sv")
    {
      ; -------------------------------------------
      DataArray.122.3 := "Dator PUM" ; (122_3)(Obj_EditFeild_StatusBar_Val [Text Value])
      ; -------------------------------------------
    }
    else if (UserLang == "tr")
    {
      ; -------------------------------------------
      DataArray.122.3 := "Bilgisayar PUM" ; (122_3)(Obj_EditFeild_StatusBar_Val [Text Value])
      ; -------------------------------------------
    }
    
    ; -------------------------------------------
    ; [SET] Shortcut Description
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; Copy (pumdefault.ico) to (TimeRightNow.ico)
    ; -------------------------------------------
    ThisIcon := A_ProgramFiles "\PopUpMenu_PUM\image\ico\pumdefault.ico"
    ; -------------------------------------------
    FormatTime, TimeRightNow , , yyyyMMddHHmmss
    ThisYear := SubStr(TimeRightNow, 1, 4)
    ThisMonth := SubStr(TimeRightNow, 5, 2)
    ThisDay := SubStr(TimeRightNow, 7, 2)
    ThisHour := SubStr(TimeRightNow, 9, 2)
    ThisMinute := SubStr(TimeRightNow, 11, 2)
    ThisSecond := SubStr(TimeRightNow, 13, 2)
    TimeRightNow := ThisYear ThisMonth ThisDay ThisHour ThisMinute ThisSecond
    ; -------------------------------------------
    TempIcon := A_AppData "\PopUpMenu_PUM\temp\" TimeRightNow ".ico" ; (386_2)(Temporary Icon [System Folder Path])
    ; -------------------------------------------
    FileCopy, %ThisIcon%, %TempIcon%, 1
    Sleep, 10
    DataArray.102.3 := TempIcon ; (102_3)(Obj_DisplayedIcon_Img [Image Path])
    ; -------------------------------------------
    ; Copy (pumdefault.ico) to (TimeRightNow.ico)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [CREATE] Shortcut Default pum
    ; -------------------------------------------
    DataArray := Shortcut_Default(DataArray) ; > DataArray
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [RESET] DataArray
    ; -------------------------------------------
    DataArray := Sys_ResetDataArray(DataArray) ; > DataArray
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  }
  ; -------------------------------------------
  Sleep, 300
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
