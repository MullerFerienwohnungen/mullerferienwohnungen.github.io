#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 163 [pumRestore]
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\Select_FileFolder.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Script_Close.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Pum_GetRestoreFile(UserLang) ; > File_PumRestore
{
	; -------------------------------------------
	SelectFileFolderType := "PumRestore"
	StartFolder := ""
	ThisPumPath := ""
	; -------------------------------------------
	OutArray := Select_FileFolder(UserLang, SelectFileFolderType, StartFolder, ThisPumPath) ; SelectFileFolderType(UserLang, ["Folder"or"AnyFile"or"AnyImage"or"Application"or"Browser"], StartFolder, ThisPumPath) > ; [OutTarget, Arguments, UseLink (0,1), Selected_File, SelectedItems_LinkIcon]
	; -------------------------------------------
	File_PumRestore := OutArray.1
	; -------------------------------------------
	SplitPath, File_PumRestore, , , SelectedItems_Ext, SelectedItems_Name
	; -------------------------------------------
	if ((SubStr(SelectedItems_Name, 1, 15) == "PopUpMenu_Pum_(") && (SelectedItems_Ext == "zip"))
	{
		; -------------------------------------------
		return File_PumRestore
		; -------------------------------------------
	}
	; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
