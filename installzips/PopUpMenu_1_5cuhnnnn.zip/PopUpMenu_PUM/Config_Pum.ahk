﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
#NoTrayIcon
#SingleInstance, Force
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
!Tab::return ; (Alt)(Tab)
; -------------------------------------------
^LButton::return ; (Ctrl)(LButton)
!LButton::return ; (Alt)(LButton)
#LButton::return ; (Win)(LButton)
+LButton::return ; (Shift)(LButton)
; -------------------------------------------
^#LButton::return ; (Ctrl)(Win)(LButton)
^+LButton::return ; (Ctrl)(Shift)(LButton)
^!LButton::return ; (Ctrl)(Alt)(LButton)
; -------------------------------------------
^#!LButton::return ; (Ctrl)(Win)(Alt)(LButton)
^#+LButton::return ; (Ctrl)(Win)(Shift)(LButton)
^!+LButton::return ; (Ctrl)(Alt)(Shift)(LButton)
; -------------------------------------------
^!+#LButton::return ; (Ctrl)(Alt)(Shift)(Win)(LButton)
; -------------------------------------------
; (Win)
#A::return 
#B::return
#C::return
#D::return
#E::return
#F::return
#G::return
#H::return
#I::return
#J::return
#K::return
#L::return
#M::return
#N::return
#O::return
#P::return
#Q::return
#R::return
#S::return
#T::return
#U::return
#V::return
#W::return
#X::return
#Y::return
#Z::return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
