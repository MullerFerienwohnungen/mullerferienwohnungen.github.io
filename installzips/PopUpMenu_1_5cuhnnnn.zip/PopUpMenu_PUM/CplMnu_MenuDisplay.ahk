﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\CplMnu_ListBox.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\f_102.ahk ; (102_1)(Obj_DisplayedIcon)
#Include %A_ProgramFiles%\PopUpMenu_PUM\Gui_AdjustTextWidth.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_GuiControl.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\MkbAdobeKeyStroke.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\UIS.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
CplMnu_MenuDisplay(DataArray) ; > DataArray
{
  ; -------------------------------------------
  cplmnu_IsDivider := DataArray.366.4 ; (366_4)(cplmnu_IsDivider [Selected List Item is a Divider] [0/1])
  ; -------------------------------------------
  if (cplmnu_IsDivider == "")
  {
    cplmnu_IsDivider := 0
    DataArray.366.4 := cplmnu_IsDivider ; (366_4)(cplmnu_IsDivider [Selected List Item is a Divider] [0/1])
  } ; [End] if (cplmnu_IsDivider == "")
  ; -------------------------------------------
  UserLang := DataArray.365.2 ; (365_2)(UserLang [Current User language])
  ; -------------------------------------------
  AppProcessName  := DataArray.367.1 ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
  ; -------------------------------------------
  Menu_Array := ""
  ; -------------------------------------------
  if (DataArray.366.5 == "cpl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
  {
    ; -------------------------------------------
    Menu_Type := "cpl"
    MenuSize := 8
    DataArray.300.6 := MenuSize ; (300_6)(Cpl_MenuSize [#])
    VarArrayNum := 341 ; [cpl] First of 10 Langage Menu Array DataAray Number
    ; -------------------------------------------
    MenuItem_1 := DataArray.300.2 ; (300_2)(Cpl_Number_x000 [#_X_X_X])
    MenuItem_2 := DataArray.300.3 ; (300_3)(Cpl_Number_0x00 [X_#_X_X])
    MenuItem_3 := DataArray.300.4 ; (300_4)(Cpl_Number_00x0 [X_X_#_X])
    MenuItem_Selected := DataArray.300.5 ; (300_5)(Cpl_Number_000x [X_X_X_#])
    ; -------------------------------------------
    ; <(341)> de_cpl - <(350)> tr_cpl
    ; [SET] CplMnu_MenuArray.ahk
    ; -------------------------------------------
    if (DataArray.365.2 == "de") ; (365_2)(UserLang [Current User language])
    {
      Menu_Array := DataArray.341.2 ; (341_2)([cpl] (cpl_AllMenuArray) de)
    } ; [End] (UserLang [Current User language])
    ; -------------------------------------------
    else if (DataArray.365.2 == "en") ; (365_2)(UserLang [Current User language])
    {
      Menu_Array := DataArray.342.2 ; (342_2)([cpl] (cpl_AllMenuArray) en)
    } ; [End] (UserLang [Current User language])
    ; -------------------------------------------
    else if (DataArray.365.2 == "es") ; (365_2)(UserLang [Current User language])
    {
      Menu_Array := DataArray.343.2 ; (343_2)([cpl] (cpl_AllMenuArray) es)
    } ; [End] (UserLang [Current User language])
    ; -------------------------------------------
    else if (DataArray.365.2 == "fr") ; (365_2)(UserLang [Current User language])
    {
      Menu_Array := DataArray.344.2 ; (344_2)([cpl] (cpl_AllMenuArray) fr)
    } ; [End] (UserLang [Current User language])
    ; -------------------------------------------
    else if (DataArray.365.2 == "it") ; (365_2)(UserLang [Current User language])
    {
      Menu_Array := DataArray.345.2 ; (345_2)([cpl] (cpl_AllMenuArray) it)
    } ; [End] (UserLang [Current User language])
    ; -------------------------------------------
    else if (DataArray.365.2 == "pl") ; (365_2)(UserLang [Current User language])
    {
      Menu_Array := DataArray.346.2 ; (346_2)([cpl] (cpl_AllMenuArray) pl)
    } ; [End] (UserLang [Current User language])
    ; -------------------------------------------
    else if (DataArray.365.2 == "pt") ; (365_2)(UserLang [Current User language])
    {
      Menu_Array := DataArray.347.2 ; (347_2)([cpl] (cpl_AllMenuArray) pt)
    } ; [End] (UserLang [Current User language])
    ; -------------------------------------------
    else if (DataArray.365.2 == "ru") ; (365_2)(UserLang [Current User language])
    {
      Menu_Array := DataArray.348.2 ; (348_2)([cpl] (cpl_AllMenuArray) ru)
    } ; [End] (UserLang [Current User language])
    ; -------------------------------------------
    else if (DataArray.365.2 == "sv") ; (365_2)(UserLang [Current User language])
    {
      Menu_Array := DataArray.349.2 ; (349_2)([cpl] (cpl_AllMenuArray) sv)
    } ; [End] (UserLang [Current User language])
    ; -------------------------------------------
    else if (DataArray.365.2 == "tr") ; (365_2)(UserLang [Current User language])
    {
      Menu_Array := DataArray.350.2 ; (350_2)([cpl] (cpl_AllMenuArray) tr)
    } ; [End] (UserLang [Current User language])
    ; -------------------------------------------
  } ; [End] (ScriptType [cpl])
  ; -------------------------------------------
  else if (DataArray.366.5 == "mnu") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
  {
    ; -------------------------------------------
    if ((DataArray.365.2 == "de" && DataArray.321.3 == 1) or (DataArray.365.2 == "en" && DataArray.322.3 == 1) or (DataArray.365.2 == "es" && DataArray.323.3 == 1) or (DataArray.365.2 == "fr" && DataArray.324.3 == 1) or (DataArray.365.2 == "it" && DataArray.325.3 == 1) or (DataArray.365.2 == "pl" && DataArray.326.3 == 1) or (DataArray.365.2 == "pt" && DataArray.327.3 == 1) or (DataArray.365.2 == "ru" && DataArray.328.3 == 1) or (DataArray.365.2 == "sv" && DataArray.329.3 == 1) or (DataArray.365.2 == "tr" && DataArray.330.3 == 1)) ; (321_3)([mnu] (mnu_MenuInstalled_de) [1/0])/(322_3)([mnu] (mnu_MenuInstalled_en) [1/0])/(323_3)([mnu] (mnu_MenuInstalled_es) [1/0])/(324_3)([mnu] (mnu_MenuInstalled_fr) [1/0])/(325_3)([mnu] (mnu_MenuInstalled_it) [1/0])/(326_3)([mnu] (mnu_MenuInstalled_pl) [1/0])/(327_3)([mnu] (mnu_MenuInstalled_pt) [1/0])/(328_3)([mnu] (mnu_MenuInstalled_ru) [1/0])/(329_3)([mnu] (mnu_MenuInstalled_sv) [1/0])/(365_2)(UserLang [Current User language])/(330_3)([mnu] (mnu_MenuInstalled_tr) [1/0])
    {
      ; -------------------------------------------
      Menu_Type := "MenuArray"
      MenuSize := DataArray.302.6 ; (302_6)(Mnu_MenuSize [#])
      ; -------------------------------------------
      VarArrayNum := 321 ; [mnu] First of 10 Langage Menu Array DataAray Number
      ; -------------------------------------------
      MenuItem_1 := DataArray.302.2 ; (302_2)(Mnu_Number_x000 [#_X_X_X])
      MenuItem_2 := DataArray.302.3 ; (302_3)(Mnu_Number_0x00 [X_#_X_X])
      MenuItem_3 := DataArray.302.4 ; (302_4)(Mnu_Number_00x0 [X_X_#_X])
      MenuItem_Selected := DataArray.302.5 ; (302_5)(Mnu_Number_000x [X_X_X_#])
      ; -------------------------------------------
      ; <(321)> de_MenuArray - <(330)> tr_MenuArray
      ; [SET] CplMnu_MenuArray.ahk
      ; -------------------------------------------
      if (DataArray.365.2 == "de") ; (365_2)(UserLang [Current User language])
      {
        Menu_Array := DataArray.321.2 ; (321_2)([mnu] (mnu_AllMenuArray) de)
      } ; [End] (UserLang [Current User language])
      ; -------------------------------------------
      else if (DataArray.365.2 == "en") ; (365_2)(UserLang [Current User language])
      {
        Menu_Array := DataArray.322.2 ; (322_2)([mnu] (mnu_AllMenuArray) en)
      } ; [End] (UserLang [Current User language])
      ; -------------------------------------------
      else if (DataArray.365.2 == "es") ; (365_2)(UserLang [Current User language])
      {
        Menu_Array := DataArray.323.2 ; (323_2)([mnu] (mnu_AllMenuArray) es)
      } ; [End] (UserLang [Current User language])
      ; -------------------------------------------
      else if (DataArray.365.2 == "fr") ; (365_2)(UserLang [Current User language])
      {
        Menu_Array := DataArray.324.2 ; (324_2)([mnu] (mnu_AllMenuArray) fr)
      } ; [End] (UserLang [Current User language])
      ; -------------------------------------------
      else if (DataArray.365.2 == "it") ; (365_2)(UserLang [Current User language])
      {
        Menu_Array := DataArray.325.2 ; (325_2)([mnu] (mnu_AllMenuArray) it)
      } ; [End] (UserLang [Current User language])
      ; -------------------------------------------
      else if (DataArray.365.2 == "pl") ; (365_2)(UserLang [Current User language])
      {
        Menu_Array := DataArray.326.2 ; (326_2)([mnu] (mnu_AllMenuArray) pl)
      } ; [End] (UserLang [Current User language])
      ; -------------------------------------------
      else if (DataArray.365.2 == "pt") ; (365_2)(UserLang [Current User language])
      {
        Menu_Array := DataArray.327.2 ; (327_2)([mnu] (mnu_AllMenuArray) pt)
      } ; [End] (UserLang [Current User language])
      ; -------------------------------------------
      else if (DataArray.365.2 == "ru") ; (365_2)(UserLang [Current User language])
      {
        Menu_Array := DataArray.328.2 ; (328_2)([mnu] (mnu_AllMenuArray) ru)
      } ; [End] (UserLang [Current User language])
      ; -------------------------------------------
      else if (DataArray.365.2 == "sv") ; (365_2)(UserLang [Current User language])
      {
        Menu_Array := DataArray.329.2 ; (329_2)([mnu] (mnu_AllMenuArray) sv)
      } ; [End] (UserLang [Current User language])
      ; -------------------------------------------
      else if (DataArray.365.2 == "tr") ; (365_2)(UserLang [Current User language])
      {
        Menu_Array := DataArray.330.2 ; (330_2)([mnu] (mnu_AllMenuArray) tr)
      } ; [End] (UserLang [Current User language])
      ; -------------------------------------------
    } ; Addon Array Avalible
    ; -------------------------------------------
  } ; [End] [else] [Script Type] "mnu"
  ; -------------------------------------------
  if (MenuSize > 0)
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [SET] Individual Menu Arrays
    ; -------------------------------------------
    for Index, ThisItem in Menu_Array
    {
      ArrayName := ThisItem.1
      ArrayItem := ThisItem.2
      %ArrayName% := ArrayItem ; %(String)% := (Array)
    } ; [End] for Index, ThisItem in Menu_Array
    ; -------------------------------------------
    { ; List Text / <Displayed Text> Top 2 / <Edit Feild> Status Bar Description
      ; -------------------------------------------
      Obj_CplMnu_DisplayText_ListLeft_Val := "" ; (110_3)(Obj_CplMnu_DisplayText_ListLeft_Val [Text Value])
      Obj_CplMnu_DisplayText_ListCenter_Val := "" ; (111_3)(Obj_CplMnu_DisplayText_ListCenter_Val [Text Value])
      Obj_CplMnu_DisplayText_ListRight_Val := "" ; (112_3)((Obj_CplMnu_DisplayText_ListRight_Val [Text Value])
      Obj_DisplayText_Top2_Val := "" ; (105_3)(Obj_DisplayText_Top2_Val [Text Value])
      Obj_EditFeild_StatusBar_Val := "" ; (122_3)(Obj_EditFeild_StatusBar_Val [Text Value])
      ComCheck :=  ""
      IsValid := 0
      ; -------------------------------------------
      ListArray0 := %UserLang%_%Menu_Type%_0
      ; -------------------------------------------
      ; Empty Var Values
      ListArray1 := ""
      ListArray2 := ""
      ListArray3 := ""
      ; -------------------------------------------
      if (MenuItem_1 > 0) ; MenuItem_1 (#_X_X_[X])
      {
        ; -------------------------------------------
        ListArray1 := %UserLang%_%Menu_Type%_%MenuItem_1%
        ; -------------------------------------------
        Obj_CplMnu_DisplayText_ListLeft_Val := ListArray0[MenuItem_1] ; (110_3)(Obj_CplMnu_DisplayText_ListLeft_Val [Text Value])
        ; -------------------------------------------
        if (cplmnu_IsDivider == 0) ; Is NOT a Divider
        {
          ; -------------------------------------------
          Obj_CplMnu_DisplayText_ListLeft_Val := StrReplace(Obj_CplMnu_DisplayText_ListLeft_Val, " >", "") ; (110_3)(Obj_CplMnu_DisplayText_ListLeft_Val [Text Value])
          Obj_CplMnu_DisplayText_ListLeft_Val := StrReplace(Obj_CplMnu_DisplayText_ListLeft_Val, "[", "") ; (110_3)(Obj_CplMnu_DisplayText_ListLeft_Val [Text Value])
          Obj_CplMnu_DisplayText_ListLeft_Val := StrReplace(Obj_CplMnu_DisplayText_ListLeft_Val, "]", "") ; (110_3)(Obj_CplMnu_DisplayText_ListLeft_Val [Text Value])
          ; -------------------------------------------
          ;
          ; -------------------------------------------
          Obj_CplMnu_DisplayText_ListLeft_Val := UIS(Obj_CplMnu_DisplayText_ListLeft_Val) ; (110_3)(Obj_CplMnu_DisplayText_ListLeft_Val [Text Value])
          DataArray.110.3 := Obj_CplMnu_DisplayText_ListLeft_Val ; (110_3)(Obj_CplMnu_DisplayText_ListLeft_Val [Text Value])
          FontColor := "921297"
          FontSize := 12
          MaxWidth := 158
          Gui_AdjustTextWidth("g_110", Obj_CplMnu_DisplayText_ListLeft_Val, GuiFont, FontSize, FontColor, MaxWidth) ; (110_1)(Obj_CplMnu_DisplayText_ListLeft)[cpl]
          ; -------------------------------------------
          DataArray.110.2 := 1 ; (110_2)(Obj_CplMnu_DisplayText_ListLeft_Sel [0,1,2,3])
          ; -------------------------------------------
        } ; [End] if (cplmnu_IsDivider == 0) ; Is NOT a Divider
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ;
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ; -------------------------------------------
        if (MenuItem_2 > 0) ; MenuItem_2 (X_#_X_[X])
        {
          ; -------------------------------------------
          ListArray2 := %UserLang%_%Menu_Type%_%MenuItem_1%_%MenuItem_2%
          ; -------------------------------------------
          Obj_CplMnu_DisplayText_ListCenter_Val := ListArray1[MenuItem_2][2] ; (111_3)(Obj_CplMnu_DisplayText_ListCenter_Val [Text Value])
          if (cplmnu_IsDivider == 0) ; Is NOT a Divider
          {
            ; -------------------------------------------
            Obj_CplMnu_DisplayText_ListCenter_Val := StrReplace(Obj_CplMnu_DisplayText_ListCenter_Val, " >", "") ; (111_3)(Obj_CplMnu_DisplayText_ListCenter_Val [Text Value])
            Obj_CplMnu_DisplayText_ListCenter_Val := StrReplace(Obj_CplMnu_DisplayText_ListCenter_Val, "[", "") ; (111_3)(Obj_CplMnu_DisplayText_ListCenter_Val [Text Value])
            Obj_CplMnu_DisplayText_ListCenter_Val := StrReplace(Obj_CplMnu_DisplayText_ListCenter_Val, "]", "") ; (111_3)(Obj_CplMnu_DisplayText_ListCenter_Val [Text Value])
            ; -------------------------------------------
            ;
            ; -------------------------------------------
            Obj_CplMnu_DisplayText_ListCenter_Val := UIS(Obj_CplMnu_DisplayText_ListCenter_Val) ; (111_3)(Obj_CplMnu_DisplayText_ListCenter_Val [Text Value])
            DataArray.111.3 := Obj_CplMnu_DisplayText_ListCenter_Val ; (111_3)(Obj_CplMnu_DisplayText_ListCenter_Val [Text Value])
            FontColor := "921297"
            FontSize := 12
            MaxWidth := 158
            Gui_AdjustTextWidth("g_111", Obj_CplMnu_DisplayText_ListCenter_Val, GuiFont, FontSize, FontColor, MaxWidth) ; (111_1)(Obj_CplMnu_DisplayText_ListCenter)
            ; -------------------------------------------
            DataArray.111.2 := 1 ; (111_2)(Obj_CplMnu_DisplayText_ListCenter_Sel [0,1,2,3])
            ; -------------------------------------------
          } ; [End] if (cplmnu_IsDivider == 0) ; Is NOT a Divider
          ; -------------------------------------------
          if (MenuItem_3 > 0) ; MenuItem_3 (X_X_#_[X])
          {
            ; -------------------------------------------
            ListArray3 := %UserLang%_%Menu_Type%_%MenuItem_1%_%MenuItem_2%_%MenuItem_3%
            ; -------------------------------------------
            Obj_CplMnu_DisplayText_ListRight_Val := ListArray2[MenuItem_3][2] ; (112_3)((Obj_CplMnu_DisplayText_ListRight_Val [Text Value])
            if (cplmnu_IsDivider == 0) ; Is NOT a Divider
            {
              ; -------------------------------------------
              Obj_CplMnu_DisplayText_ListRight_Val := StrReplace(Obj_CplMnu_DisplayText_ListRight_Val, " >", "") ; (112_3)((Obj_CplMnu_DisplayText_ListRight_Val [Text Value])
              Obj_CplMnu_DisplayText_ListRight_Val := StrReplace(Obj_CplMnu_DisplayText_ListRight_Val, "[", "") ; (112_3)((Obj_CplMnu_DisplayText_ListRight_Val [Text Value])
              Obj_CplMnu_DisplayText_ListRight_Val := StrReplace(Obj_CplMnu_DisplayText_ListRight_Val, "]", "") ; (112_3)((Obj_CplMnu_DisplayText_ListRight_Val [Text Value])
              ; -------------------------------------------
              ;
              ; -------------------------------------------
              Obj_CplMnu_DisplayText_ListRight_Val := UIS(Obj_CplMnu_DisplayText_ListRight_Val) ; (112_3)((Obj_CplMnu_DisplayText_ListRight_Val [Text Value])
              DataArray.112.3 := Obj_CplMnu_DisplayText_ListRight_Val ; (112_3)((Obj_CplMnu_DisplayText_ListRight_Val [Text Value])
              FontColor := "921297"
              FontSize := 12
              MaxWidth := 158
              Gui_AdjustTextWidth("g_112", Obj_CplMnu_DisplayText_ListRight_Val, GuiFont, FontSize, FontColor, MaxWidth) ; (112_1)(Obj_CplMnu_DisplayText_ListRight)
              ; -------------------------------------------
              DataArray.112.2 := 1 ; (112_2)(Obj_CplMnu_DisplayText_ListRightRight_Sel [0,1,2,3])
              ; -------------------------------------------
            } ; [End] if (cplmnu_IsDivider == 0) ; Is NOT a Divider
            ; -------------------------------------------
            if (MenuItem_Selected > 0) ; MenuItem_Selected (X_X_X_[#])
            {
              ; -------------------------------------------
              MenuItem_TextSelected := ListArray3[MenuItem_Selected][2] ; MenuItem_Selected (X_X_X_[#])
              if (cplmnu_IsDivider == 0) ; Is NOT a Divider
              {
                ; -------------------------------------------
                ComCheck := ListArray3[MenuItem_Selected][1] ; MenuItem_Selected (X_X_X_[#])
                ; -------------------------------------------
                if (DataArray.366.5 == "cpl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
                {
                  DataArray.300.8 := ComCheck ; (300_8)(Cpl_ComNum [Com_#### Used for Icon and Link/ahk Name])
                } ; [End] (ScriptType [cpl])
                else if (DataArray.366.5 == "mnu") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
                {
                  DataArray.302.8 := ComCheck ; (302_8)(Mnu_ComNum [Com_#### or Mkb_#### Used for Icon and Link/ahk Name])
                } ; [End] (ScriptType [mnu])
                ; -------------------------------------------
                ; [VALUE]
                Obj_DisplayText_Top2_Val := Obj_CplMnu_DisplayText_ListLeft_Val " > " Obj_CplMnu_DisplayText_ListCenter_Val " > " Obj_CplMnu_DisplayText_ListRight_Val " > " MenuItem_TextSelected
                Obj_DisplayText_Top2_Val := UIS(Obj_DisplayText_Top2_Val) ; (105_3)(Obj_DisplayText_Top2_Val [Text Value])
                DataArray.105.3 := Obj_DisplayText_Top2_Val ; (105_3)(Obj_DisplayText_Top2_Val [Text Value])
                ; -------------------------------------------
                FontColor := "199524"
                FontSize := 12
                MaxWidth := 480
                Gui_AdjustTextWidth("g_105", Obj_DisplayText_Top2_Val, GuiFont, FontSize, FontColor, MaxWidth) ; (105_1)(Obj_DisplayText_Top2)
                ; -------------------------------------------
                DataArray.105.2 := 1 ; (105_2)(Obj_DisplayText_Top2_Sel [0,1,2,3])
                ; -------------------------------------------
                ; [VALUE]
                Obj_EditFeild_StatusBar_Val := "(" MenuItem_TextSelected ")" ; (122_3)(Obj_EditFeild_StatusBar_Val [Text Value])
                Obj_EditFeild_StatusBar_Val := StrReplace(Obj_EditFeild_StatusBar_Val, "()_", "") ; (122_3)(Obj_EditFeild_StatusBar_Val [Text Value])
                ; -------------------------------------------
                ;
                Obj_EditFeild_StatusBar_Val := UIS(Obj_EditFeild_StatusBar_Val) ; (122_3)(Obj_EditFeild_StatusBar_Val [Text Value])
                DataArray.122.3 := Obj_EditFeild_StatusBar_Val ; (122_3)(Obj_EditFeild_StatusBar_Val [Text Value])
                GuiControl, PopUpMenu:, g_122, %Obj_EditFeild_StatusBar_Val% ; (122_1)(Obj_EditFeild_StatusBar)
                ; -------------------------------------------
                ; [SHOW]
                DataArray.122.2 := 1 ; (122_2)(Obj_EditFeild_StatusBar_Sel [0,1,2,3])
                GuiControl, PopUpMenu:Show, g_122 ; (122_1)(Obj_EditFeild_StatusBar)
                DataArray := Image_GuiControl("065", 1, 1, DataArray) ; (065_1)(Obj_ImageText_StatusBar)
                ; -------------------------------------------
                GuiControl, PopUpMenu:Focus, g_121 ; (121_1)(Obj_CplMnu_ListRight30)
                ; -------------------------------------------
              } ; [End] if (cplmnu_IsDivider == 0) ; Is NOT a Divider
              ; -------------------------------------------
            } ; [End] if (MenuItem_Selected > 0) ; MenuItem_Selected (X_X_X_[#])
            ; -------------------------------------------
            else if (MenuItem_Selected == 0) ; MenuItem_Selected (X_X_X_[#])
            {
              ; -------------------------------------------
              if (cplmnu_IsDivider == 0) ; Is NOT a Divider
              {
                ; -------------------------------------------
                Obj_DisplayText_Top2_Val := Obj_CplMnu_DisplayText_ListLeft_Val " > " Obj_CplMnu_DisplayText_ListCenter_Val " > " Obj_CplMnu_DisplayText_ListRight_Val " > "
                Obj_DisplayText_Top2_Val := UIS(Obj_DisplayText_Top2_Val) ; (105_3)(Obj_DisplayText_Top2_Val [Text Value])
                DataArray.105.3 := Obj_DisplayText_Top2_Val ; (105_3)(Obj_DisplayText_Top2_Val [Text Value])
                ; -------------------------------------------
                FontColor := "a30404" ; Red
                FontSize := 12
                MaxWidth := 480
                Gui_AdjustTextWidth("g_105", Obj_DisplayText_Top2_Val, GuiFont, FontSize, FontColor, MaxWidth) ; (105_1)(Obj_DisplayText_Top2)
                ; -------------------------------------------
                DataArray.105.2 := 1 ; (105_2)(Obj_DisplayText_Top2_Sel [0,1,2,3])
                ; -------------------------------------------
              } ; [End] if (cplmnu_IsDivider == 0) ; Is NOT a Divider
              ; -------------------------------------------
              ; [REMOVE VALUE]
              Obj_EditFeild_StatusBar_Val := "" ; (122_3)(Obj_EditFeild_StatusBar_Val [Text Value])
              DataArray.122.3 := Obj_EditFeild_StatusBar_Val ; (122_3)(Obj_EditFeild_StatusBar_Val [Text Value])
              GuiControl, PopUpMenu:, g_122, ; (122_1)(Obj_EditFeild_StatusBar)
              ; -------------------------------------------
              ; [SHOW]
              DataArray.122.2 := 1 ; (122_2)(Obj_EditFeild_StatusBar_Sel [0,1,2,3])
              GuiControl, PopUpMenu:Show, g_122 ; (122_1)(Obj_EditFeild_StatusBar)
              ; -------------------------------------------
              GuiControl, PopUpMenu:Focus, g_120 ; (120_1)(Obj_CplMnu_ListCenter30)
              ; -------------------------------------------
            } ; [End] else if (MenuItem_Selected == 0) ; MenuItem_Selected (X_X_X_[#])
            ; -------------------------------------------
          } ; [End] if (MenuItem_3 > 0) ; MenuItem_3 (X_X_#_[X])
          ; -------------------------------------------
          else if (MenuItem_3 == 0) ; MenuItem_3 (X_X_#_[X])
          {
            ; -------------------------------------------
            DataArray := Image_GuiControl("112", 0, 0, DataArray) ; (112_1)(Obj_CplMnu_DisplayText_ListRight)
            ; -------------------------------------------
            if (MenuItem_Selected > 0) ; MenuItem_Selected (X_X_X_[#])
            {
              ; -------------------------------------------
              MenuItem_TextSelected := ListArray2[MenuItem_Selected][2] ; MenuItem_Selected (X_X_X_[#])
              if (cplmnu_IsDivider == 0) ; Is NOT a Divider
              {
                ; -------------------------------------------
                ComCheck := ListArray2[MenuItem_Selected][1] ; MenuItem_Selected (X_X_X_[#])
                if (DataArray.366.5 == "cpl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
                {
                  DataArray.300.8 := ComCheck ; (300_8)(Cpl_ComNum [Com_#### Used for Icon and Link/ahk Name])
                } ; [End] (ScriptType [cpl])
                else if (DataArray.366.5 == "mnu") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
                {
                  DataArray.302.8 := ComCheck ; (302_8)(Mnu_ComNum [Com_#### or Mkb_#### Used for Icon and Link/ahk Name])
                } ; [End] (ScriptType [mnu])
                ; -------------------------------------------
                Obj_DisplayText_Top2_Val := Obj_CplMnu_DisplayText_ListLeft_Val " > " Obj_CplMnu_DisplayText_ListCenter_Val " > " MenuItem_TextSelected
                Obj_DisplayText_Top2_Val := UIS(Obj_DisplayText_Top2_Val) ; (105_3)(Obj_DisplayText_Top2_Val [Text Value])
                DataArray.105.3 := Obj_DisplayText_Top2_Val ; (105_3)(Obj_DisplayText_Top2_Val [Text Value])
                ; -------------------------------------------
                FontColor := "199524"
                FontSize := 12
                MaxWidth := 480
                Gui_AdjustTextWidth("g_105", Obj_DisplayText_Top2_Val, GuiFont, FontSize, FontColor, MaxWidth) ; (105_1)(Obj_DisplayText_Top2)
                ; -------------------------------------------
                DataArray.105.2 := 1 ; (105_2)(Obj_DisplayText_Top2_Sel [0,1,2,3])
                ; -------------------------------------------
                ; [VALUE]
                Obj_EditFeild_StatusBar_Val := "(" MenuItem_TextSelected ")" ; (122_3)(Obj_EditFeild_StatusBar_Val [Text Value])
                ; -------------------------------------------
                Obj_EditFeild_StatusBar_Val := StrReplace(Obj_EditFeild_StatusBar_Val, "()_", "") ; (122_3)(Obj_EditFeild_StatusBar_Val [Text Value])
                ; -------------------------------------------
                Obj_EditFeild_StatusBar_Val := UIS(Obj_EditFeild_StatusBar_Val) ; (122_3)(Obj_EditFeild_StatusBar_Val [Text Value])
                DataArray.122.3 := Obj_EditFeild_StatusBar_Val ; (122_3)(Obj_EditFeild_StatusBar_Val [Text Value])
                GuiControl, PopUpMenu:, g_122, %Obj_EditFeild_StatusBar_Val% ; (122_1)(Obj_EditFeild_StatusBar)
                ; -------------------------------------------
                ; [SHOW]
                DataArray.122.2 := 1 ; (122_2)(Obj_EditFeild_StatusBar_Sel [0,1,2,3])
                GuiControl, PopUpMenu:Show, g_122 ; (122_1)(Obj_EditFeild_StatusBar)
                DataArray := Image_GuiControl("065", 1, 1, DataArray) ; (065_1)(Obj_ImageText_StatusBar)
                ; -------------------------------------------
                GuiControl, PopUpMenu:Focus, g_117 ; (117_1)(Obj_CplMnu_ListRight60)
                ; -------------------------------------------
              } ; [End] if (cplmnu_IsDivider == 0) ; Is NOT a Divider
              ; -------------------------------------------
            } ; [End] if (MenuItem_Selected > 0) ; MenuItem_Selected (X_X_X_[#])
            ; -------------------------------------------
            else if (MenuItem_Selected == 0) ; MenuItem_Selected (X_X_X_[#])
            {
              ; -------------------------------------------
              if (cplmnu_IsDivider == 0) ; Is NOT a Divider
              {
                ; -------------------------------------------
                Obj_DisplayText_Top2_Val := Obj_CplMnu_DisplayText_ListLeft_Val " > " Obj_CplMnu_DisplayText_ListCenter_Val " > "
                Obj_DisplayText_Top2_Val := UIS(Obj_DisplayText_Top2_Val) ; (105_3)(Obj_DisplayText_Top2_Val [Text Value])
                DataArray.105.3 := Obj_DisplayText_Top2_Val ; (105_3)(Obj_DisplayText_Top2_Val [Text Value])
                ; -------------------------------------------
                FontColor := "a30404" ; Red
                FontSize := 12
                MaxWidth := 480
                Gui_AdjustTextWidth("g_105", Obj_DisplayText_Top2_Val, GuiFont, FontSize, FontColor, MaxWidth) ; (105_1)(Obj_DisplayText_Top2)
                ; -------------------------------------------
                DataArray.105.2 := 1 ; (105_2)(Obj_DisplayText_Top2_Sel [0,1,2,3])
                ; -------------------------------------------
                ; [REMOVE VALUE]
                Obj_EditFeild_StatusBar_Val := "" ; (122_3)(Obj_EditFeild_StatusBar_Val [Text Value])
                DataArray.122.3 := Obj_EditFeild_StatusBar_Val ; (122_3)(Obj_EditFeild_StatusBar_Val [Text Value])
                GuiControl, PopUpMenu:, g_122, ; (122_1)(Obj_EditFeild_StatusBar)
                ; -------------------------------------------
                DataArray.122.2 := 1 ; (122_2)(Obj_EditFeild_StatusBar_Sel [0,1,2,3])
                GuiControl, PopUpMenu:Show, g_122 ; (122_1)(Obj_EditFeild_StatusBar)
                DataArray := Image_GuiControl("065", 1, 1, DataArray) ; (065_1)(Obj_ImageText_StatusBar)
                ; -------------------------------------------
                GuiControl, PopUpMenu:Focus, g_118 ; (118_1)(Obj_CplMnu_ListLeft30)
                ; -------------------------------------------
              } ; [End] if (cplmnu_IsDivider == 0) ; Is NOT a Divider
              ; -------------------------------------------
            } ; [End] else if (MenuItem_Selected == 0) ; MenuItem_Selected (X_X_X_[#])
            ; -------------------------------------------
          } ; [End] else if (MenuItem_3 == 0) ; MenuItem_3 (X_X_#_[X])
          ; -------------------------------------------
        } ; [End] if (MenuItem_2 > 0) ; MenuItem_2 (X_#_X_[X])
        else if (MenuItem_2 == 0) ; MenuItem_2 (X_#_X_[X])
        {
          ; -------------------------------------------
          DataArray := Image_GuiControl("111", 0, 0, DataArray) ; (111_1)(Obj_CplMnu_DisplayText_ListCenter)
          ; -------------------------------------------
          if (MenuItem_Selected > 0) ; MenuItem_Selected (X_X_X_[#])
          {
            ; -------------------------------------------
            if (cplmnu_IsDivider == 0) ; Is NOT a Divider
            {
              ; -------------------------------------------
              MenuItem_TextSelected := ListArray1[MenuItem_Selected][2] ; MenuItem_Selected (X_X_X_[#])
              ComCheck := ListArray1[MenuItem_Selected][1] ; MenuItem_Selected (X_X_X_[#])
              ; -------------------------------------------
              if (DataArray.366.5 == "cpl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
              {
                DataArray.300.8 := ComCheck ; (300_8)(Cpl_ComNum [Com_#### Used for Icon and Link/ahk Name])
              } ; [End] (ScriptType [cpl])
              else if (DataArray.366.5 == "mnu") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
              {
                DataArray.302.8 := ComCheck ; (302_8)(Mnu_ComNum [Com_#### or Mkb_#### Used for Icon and Link/ahk Name])
              } ; [End] (ScriptType [mnu])
              ; -------------------------------------------
              ; [VALUE]
              if (Obj_CplMnu_DisplayText_ListLeft_Val != "")
              {
                Obj_DisplayText_Top2_Val := Obj_CplMnu_DisplayText_ListLeft_Val " > " MenuItem_TextSelected
              }
              else
              {
                Obj_DisplayText_Top2_Val := MenuItem_TextSelected
              }
              ; -------------------------------------------
              Obj_DisplayText_Top2_Val := UIS(Obj_DisplayText_Top2_Val) ; (105_3)(Obj_DisplayText_Top2_Val [Text Value])
              DataArray.105.3 := Obj_DisplayText_Top2_Val ; (105_3)(Obj_DisplayText_Top2_Val [Text Value])
              ; -------------------------------------------
              FontColor := "199524"
              FontSize := 12
              MaxWidth := 480
              Gui_AdjustTextWidth("g_105", Obj_DisplayText_Top2_Val, GuiFont, FontSize, FontColor, MaxWidth) ; (105_1)(Obj_DisplayText_Top2)
              ; -------------------------------------------
              DataArray.105.2 := 1 ; (105_2)(Obj_DisplayText_Top2_Sel [0,1,2,3])
              ; -------------------------------------------
              ; [VALUE]
              Obj_EditFeild_StatusBar_Val := "(" MenuItem_TextSelected ")" ; (122_3)(Obj_EditFeild_StatusBar_Val [Text Value])
              ; -------------------------------------------
              Obj_EditFeild_StatusBar_Val := StrReplace(Obj_EditFeild_StatusBar_Val, "()_", "") ; (122_3)(Obj_EditFeild_StatusBar_Val [Text Value])
              ; -------------------------------------------
              Obj_EditFeild_StatusBar_Val := UIS(Obj_EditFeild_StatusBar_Val) ; (122_3)(Obj_EditFeild_StatusBar_Val [Text Value])
              DataArray.122.3 := Obj_EditFeild_StatusBar_Val ; (122_3)(Obj_EditFeild_StatusBar_Val [Text Value])
              GuiControl, PopUpMenu:, g_122, %Obj_EditFeild_StatusBar_Val% ; (122_1)(Obj_EditFeild_StatusBar)
              ; -------------------------------------------
              ; [SHOW]
              DataArray.122.2 := 1 ; (122_2)(Obj_EditFeild_StatusBar_Sel [0,1,2,3])
              GuiControl, PopUpMenu:Show, g_122 ; (122_1)(Obj_EditFeild_StatusBar)
              DataArray := Image_GuiControl("065", 1, 1, DataArray) ; (065_1)(Obj_ImageText_StatusBar)
              ; -------------------------------------------
              GuiControl, PopUpMenu:Focus, g_116 ; (116_1)(Obj_CplMnu_List100)
              ; -------------------------------------------
            } ; [End] if (cplmnu_IsDivider == 0) ; Is NOT a Divider
            ; -------------------------------------------
          } ; [End] if (MenuItem_Selected > 0) ; MenuItem_Selected (X_X_X_[#])
          ; -------------------------------------------
          else if (MenuItem_Selected == 0) ; MenuItem_Selected (X_X_X_[#])
          {
            ; -------------------------------------------
            if (cplmnu_IsDivider == 0) ; Is NOT a Divider
            {
              ; -------------------------------------------
              ; [VALUE]
              if (Obj_CplMnu_DisplayText_ListLeft_Val != "")
              {
                ; -------------------------------------------
                Obj_DisplayText_Top2_Val := Obj_CplMnu_DisplayText_ListLeft_Val " > " ; (105_3)(Obj_DisplayText_Top2_Val [Text Value])/(110_3)(Obj_CplMnu_DisplayText_ListLeft_Val [Text Value])
                Obj_DisplayText_Top2_Val := UIS(Obj_DisplayText_Top2_Val) ; (105_3)(Obj_DisplayText_Top2_Val [Text Value])
                DataArray.105.3 := Obj_DisplayText_Top2_Val ; (105_3)(Obj_DisplayText_Top2_Val [Text Value])
                ; -------------------------------------------
                FontColor := "a30404" ; Red
                FontSize := 12
                MaxWidth := 480
                Gui_AdjustTextWidth("g_105", Obj_DisplayText_Top2_Val, GuiFont, FontSize, FontColor, MaxWidth) ; (105_1)(Obj_DisplayText_Top2)
                ; -------------------------------------------
                DataArray.105.2 := 1 ; (105_2)(Obj_DisplayText_Top2_Sel [0,1,2,3])
                ; -------------------------------------------
                ; [REMOVE VALUE]
                Obj_EditFeild_StatusBar_Val := "" ; (122_3)(Obj_EditFeild_StatusBar_Val [Text Value])
                DataArray.122.3 := Obj_EditFeild_StatusBar_Val ; (122_3)(Obj_EditFeild_StatusBar_Val [Text Value])
                GuiControl, PopUpMenu:, g_122, ; (122_1)(Obj_EditFeild_StatusBar)
                ; -------------------------------------------
                ; [SHOW]
                DataArray.122.2 := 1 ; (122_2)(Obj_EditFeild_StatusBar_Sel [0,1,2,3])
                GuiControl, PopUpMenu:Show, g_122 ; (122_1)(Obj_EditFeild_StatusBar)
                DataArray := Image_GuiControl("065", 1, 1, DataArray) ; (065_1)(Obj_ImageText_StatusBar)
                ; -------------------------------------------
                GuiControl, PopUpMenu:Focus, g_116 ; (116_1)(Obj_CplMnu_List100)
                ; -------------------------------------------
              } ; [End] if (Obj_CplMnu_DisplayText_ListLeft_Val != "")
              ; -------------------------------------------
            } ; [End] if (cplmnu_IsDivider == 0) ; Is NOT a Divider
            ; -------------------------------------------
          } ; [End] else if (MenuItem_Selected == 0) ; MenuItem_Selected (X_X_X_[#])
          ; -------------------------------------------
        } ; [End] else if (MenuItem_2 == 0) ; MenuItem_2 (X_#_X_[X])
        ; -------------------------------------------
      } ; [End] if (MenuItem_1 > 0) ; MenuItem_1 (#_X_X_[X])
      ; -------------------------------------------
      else if (MenuItem_1 == 0) ; MenuItem_1 (#_X_X_[X])
      {
        ; -------------------------------------------
        DataArray := Image_GuiControl("110", 0, 0, DataArray) ; (110_1)(Obj_CplMnu_DisplayText_ListLeft)[cpl]
        ; -------------------------------------------
        DataArray := Image_GuiControl("105", 0, 0, DataArray) ; (105_1)(Obj_DisplayText_Top2)
        ; -------------------------------------------
        ; [REMOVE VALUE]
        Obj_EditFeild_StatusBar_Val := "" ; (122_3)(Obj_EditFeild_StatusBar_Val [Text Value])
        DataArray.122.3 := Obj_EditFeild_StatusBar_Val ; (122_3)(Obj_EditFeild_StatusBar_Val [Text Value])
        GuiControl, PopUpMenu:, g_122, ; (122_1)(Obj_EditFeild_StatusBar)
        ; -------------------------------------------
      } ; [End] else if (MenuItem_1 == 0) ; MenuItem_1 (#_X_X_[X])
      ; -------------------------------------------
    } ; [End] List Text / <Displayed Text> Top 2 / <Edit Feild> Status Bar Description
    ; -------------------------------------------
    { ; [SET] ListBox#
      ; -------------------------------------------
      ; Empty Var Values
      ListBox1 := ""
      ListBox2 := ""
      ListBox3 := ""
      ; -------------------------------------------
      if ListArray1
      {
        ListBox1 := CplMnu_ListBox(ListArray1)
      } ; [End] if ListArray1
      ; -------------------------------------------
      if ListArray2
      {
        ListBox2 := CplMnu_ListBox(ListArray2)
      } ; [End] if ListArray2
      ; -------------------------------------------
      if ListArray3
      {
        ListBox3 := CplMnu_ListBox(ListArray3)
      } ; [End] if ListArray3
      ; -------------------------------------------
    } ; [End] [SET] ListBox#
    ; -------------------------------------------
    { ; Display List [HIDE][SHOW][CHOOSE][FOCUS]
      ; -------------------------------------------
      if (MenuItem_1 > 0)
      {
        ; -------------------------------------------
        if (MenuItem_2 > 0)
        {
          ; -------------------------------------------
          if (MenuItem_3 > 0)
          {
            ; -------------------------------------------
            ; [HIDE] List100, ListRight60
            ;
            DataArray := Image_GuiControl("116", 0, 0, DataArray) ; (116_1)(Obj_CplMnu_List100)
            DataArray := Image_GuiControl("117", 0, 0, DataArray) ; (117_1)(Obj_CplMnu_ListRight60)
            ; -------------------------------------------
            ;
            ; -------------------------------------------
            ; [Value] ListLeft30, ListCenter30, ListRight30
            ;
            CkListBox1 := DataArray.118.3 ; (118_3)(Obj_CplMnu_ListLeft30_Box [List Box])
            if (CkListBox1 != ListBox1)
            {
              DataArray.118.3 := ListBox1 ; (118_3)(Obj_CplMnu_ListLeft30_Box [List Box])
              GuiControl, PopUpMenu:, g_118, %ListBox1% ; (118_1)(Obj_CplMnu_ListLeft30)
            } ; [End] if (CkListBox1 != ListBox1)
            ; -------------------------------------------
            CkListBox2 := DataArray.120.3 ; (120_3)(Obj_CplMnu_ListCenter30_Box [List Box])
            if (CkListBox2 != ListBox2)
            {
              DataArray.120.3 := ListBox2 ; (120_3)(Obj_CplMnu_ListCenter30_Box [List Box])
              GuiControl, PopUpMenu:, g_120, %ListBox2% ; (120_1)(Obj_CplMnu_ListCenter30)
            } ; [End] if (CkListBox2 != ListBox2)
            ; -------------------------------------------
            CkListBox3 := DataArray.121.3 ; (121_3)(Obj_CplMnu_ListRight30_Box [List Box])
            if (CkListBox3 != ListBox3)
            {
              DataArray.121.3 := ListBox3 ; (121_3)(Obj_CplMnu_ListRight30_Box [List Box])
              GuiControl, PopUpMenu:, g_121, %ListBox3% ; (121_1)(Obj_CplMnu_ListRight30)
            } ; [End] if (CkListBox3 != ListBox3)
            ; -------------------------------------------
            ;
            ; -------------------------------------------
            ; [CHOOSE][FOCUS] ListLeft30, ListCenter30
            ;
            if (cplmnu_IsDivider == 0) ; Is NOT a Divider
            {
              GuiControl, PopUpMenu:Choose, g_118, %MenuItem_2% ; (118_1)(Obj_CplMnu_ListLeft30)
              GuiControl, PopUpMenu:Choose, g_120, %MenuItem_3% ; (120_1)(Obj_CplMnu_ListCenter30)
            } ; [End] if (cplmnu_IsDivider == 0) ; Is NOT a Divider
            ; -------------------------------------------
            if (MenuItem_Selected > 0)
            {
              if (cplmnu_IsDivider == 0) ; Is NOT a Divider
              {
                GuiControl, PopUpMenu:Choose, g_121, %MenuItem_Selected% ; (121_1)(Obj_CplMnu_ListRight30)
              } ; [End] if (cplmnu_IsDivider == 0) ; Is NOT a Divider
            } ; [End] if (MenuItem_Selected > 0)
            ; -------------------------------------------
            else if (MenuItem_Selected == 0)
            {
              if (cplmnu_IsDivider == 0) ; Is NOT a Divider
              {
                GuiControl, PopUpMenu:Choose, g_121, 0 ; (121_1)(Obj_CplMnu_ListRight30)
              } ; [End] if (cplmnu_IsDivider == 0) ; Is NOT a Divider
            } ; [End] else if (MenuItem_Selected == 0)
            ; -------------------------------------------
            ;
            ; -------------------------------------------
            ; [SHOW] ListLeft30, ListCenter30, ListRight30
            ; -------------------------------------------
            DataArray.118.2 := 1 ; (118_2)(Obj_CplMnu_ListLeft30_Sel [0,1,2,3])
            GuiControl, PopUpMenu:Show, g_118 ; (118_1)(Obj_CplMnu_ListLeft30)
            ; -------------------------------------------
            DataArray.120.2 := 1 ; (120_2)(Obj_CplMnu_ListCenter30_Sel [0,1,2,3])
            GuiControl, PopUpMenu:Show, g_120 ; (120_1)(Obj_CplMnu_ListCenter30)
            ; -------------------------------------------
            DataArray.121.2 := 1 ; (121_2)(Obj_CplMnu_ListRight30_Sel [0,1,2,3])
            GuiControl, PopUpMenu:Show, g_121 ; (121_1)(Obj_CplMnu_ListRight30)
            ; -------------------------------------------
          } ; [End] if (MenuItem_3 > 0)
          ; -------------------------------------------
          else if (MenuItem_3 == 0)
          {
            ; -------------------------------------------
            ; [HIDE] List100, ListCenter30, ListRight30
            ;
            DataArray := Image_GuiControl("116", 0, 0, DataArray) ; (116_1)(Obj_CplMnu_List100)
            DataArray := Image_GuiControl("120", 0, 0, DataArray) ; (120_1)(Obj_CplMnu_ListCenter30)
            DataArray := Image_GuiControl("121", 0, 0, DataArray) ; (121_1)(Obj_CplMnu_ListRight30)
            ; -------------------------------------------
            ;
            ; -------------------------------------------
            ; [Value] ListLeft30, ListRight60
            ;
            CkListBox1 := DataArray.118.3 ; (118_3)(Obj_CplMnu_ListLeft30_Box [List Box])
            if (CkListBox1 != ListBox1)
            {
              DataArray.118.3 := ListBox1 ; (118_3)(Obj_CplMnu_ListLeft30_Box [List Box])
              GuiControl, PopUpMenu:, g_118, %ListBox1% ; (118_1)(Obj_CplMnu_ListLeft30)
            } ; [End] if (CkListBox1 != ListBox1)
            ; -------------------------------------------
            CkListBox2 := DataArray.117.3 ; (117_3)(Obj_CplMnu_ListRight60_Box [List Box])
            if (CkListBox2 != ListBox2)
            {
              DataArray.117.3 := ListBox2 ; (117_3)(Obj_CplMnu_ListRight60_Box [List Box])
              GuiControl, PopUpMenu:, g_117, %ListBox2% ; (117_1)(Obj_CplMnu_ListRight60)
            } ; [End] if (CkListBox2 != ListBox2)
            ; -------------------------------------------
            ;
            ; -------------------------------------------
            ; [CHOOSE] ListLeft30
            ;
            if (cplmnu_IsDivider == 0) ; Is NOT a Divider 
            {
              GuiControl, PopUpMenu:Choose, g_118, %MenuItem_2% ; (118_1)(Obj_CplMnu_ListLeft30)
            } ; [End] if (cplmnu_IsDivider == 0) ; Is NOT a Divider 
            ; -------------------------------------------
            ;
            ; -------------------------------------------
            ; [CHOOSE] [FOCUS] ListRight60
            ;
            if (MenuItem_Selected > 0) ; MenuItem_Selected (X_X_X_[#])
            {
              if (cplmnu_IsDivider == 0) ; Is NOT a Divider
              {
                GuiControl, PopUpMenu:Choose, g_117, %MenuItem_Selected% ; (117_1)(Obj_CplMnu_ListRight60)
              } ; [End] if (cplmnu_IsDivider == 0) ; Is NOT a Divider
            } ; [End] if (MenuItem_Selected > 0) ; MenuItem_Selected (X_X_X_[#])
            else if (MenuItem_Selected == 0) ; MenuItem_Selected (X_X_X_[#])
            {
              if (cplmnu_IsDivider == 0) ; Is NOT a Divider
              {
                GuiControl, PopUpMenu:Choose, g_117, 0 ; (117_1)(Obj_CplMnu_ListRight60)
              } ; [End] if (cplmnu_IsDivider == 0) ; Is NOT a Divider
            } ; [End] else if (MenuItem_Selected == 0) ; MenuItem_Selected (X_X_X_[#])
            ; -------------------------------------------
            ;
            ; -------------------------------------------
            ; [SHOW] ListLeft30, ListRight60
            ;
            DataArray.118.2 := 1 ; (118_2)(Obj_CplMnu_ListLeft30_Sel [0,1,2,3])
            GuiControl, PopUpMenu:Show, g_118 ; (118_1)(Obj_CplMnu_ListLeft30)
            ; -------------------------------------------
            DataArray.117.2 := 1 ; (117_2)(Obj_CplMnu_ListRight60_Sel [0,1,2,3])
            GuiControl, PopUpMenu:Show, g_117 ; (117_1)(Obj_CplMnu_ListRight60)
            ; -------------------------------------------
          } ; [End] else if (MenuItem_3 == 0)
          ; -------------------------------------------
        } ; [End] if (MenuItem_2 > 0)
        ; -------------------------------------------
        else if (MenuItem_2 == 0)
        {
          ; -------------------------------------------
          ; [HIDE] ListLeft30, ListCenter30, ListRight30, ListRight60
          ;
          DataArray := Image_GuiControl("117", 0, 0, DataArray) ; (117_1)(Obj_CplMnu_ListRight60)
          DataArray := Image_GuiControl("118", 0, 0, DataArray) ; (118_1)(Obj_CplMnu_ListLeft30)
          DataArray := Image_GuiControl("120", 0, 0, DataArray) ; (120_1)(Obj_CplMnu_ListCenter30)
          DataArray := Image_GuiControl("121", 0, 0, DataArray) ; (121_1)(Obj_CplMnu_ListRight30)
          ; -------------------------------------------
          ;
          ; -------------------------------------------
          ; [Value] List100
          ;
          CkListBox1 := DataArray.116.3 ; (116_3)(Obj_CplMnu_List100_Box [List Box])
          if (CkListBox1 != ListBox1)
          {
            DataArray.116.3 := ListBox1 ; (116_3)(Obj_CplMnu_List100_Box [List Box])
            GuiControl, PopUpMenu:, g_116, %ListBox1% ; (116_1)(Obj_CplMnu_List100)
          } ; [End] if (CkListBox1 != ListBox1)
          ; -------------------------------------------
          ;
          ; -------------------------------------------
          ; [CHOOSE] [FOCUS] List100
          ;
          if (MenuItem_Selected > 0)
          {
            if (cplmnu_IsDivider == 0) ; Is NOT a Divider
            {
              GuiControl, PopUpMenu:Choose, g_116, %MenuItem_Selected% ; (116_1)(Obj_CplMnu_List100)
            } ; [End] if (cplmnu_IsDivider == 0) ; Is NOT a Divider
          } ; [End] if (MenuItem_Selected > 0)
          ; -------------------------------------------
          DataArray.116.2 := 1 ; (116_2)(Obj_CplMnu_List100_Sel [0,1,2,3])
          GuiControl, PopUpMenu:Show, g_116 ; (116_1)(Obj_CplMnu_List100)
          ; -------------------------------------------
        } ; [End] else if (MenuItem_2 == 0)
        ; -------------------------------------------
      } ; [End] if (MenuItem_1 > 0)
      ; -------------------------------------------
      else if (MenuItem_1 == 0)
      { ; [HIDE] List MenuItem_1 = 0
        ; -------------------------------------------
        DataArray := Image_GuiControl("110", 0, 0, DataArray) ; (110_1)(Obj_CplMnu_DisplayText_ListLeft)[cpl]
        DataArray := Image_GuiControl("111", 0, 0, DataArray) ; (111_1)(Obj_CplMnu_DisplayText_ListCenter)
        DataArray := Image_GuiControl("112", 0, 0, DataArray) ; (112_1)(Obj_CplMnu_DisplayText_ListRight)
        DataArray := Image_GuiControl("116", 0, 0, DataArray) ; (116_1)(Obj_CplMnu_List100)
        DataArray := Image_GuiControl("117", 0, 0, DataArray) ; (117_1)(Obj_CplMnu_ListRight60)
        DataArray := Image_GuiControl("118", 0, 0, DataArray) ; (118_1)(Obj_CplMnu_ListLeft30)
        DataArray := Image_GuiControl("120", 0, 0, DataArray) ; (120_1)(Obj_CplMnu_ListCenter30)
        DataArray := Image_GuiControl("121", 0, 0, DataArray) ; (121_1)(Obj_CplMnu_ListRight30)
        ; -------------------------------------------
      } ; [End] else if (MenuItem_1 == 0)
      ; -------------------------------------------
    } ; [End] Display List [HIDE][SHOW][CHOOSE][FOCUS]
    ; -------------------------------------------
    { ; [Temp_Icon][Ok Button]
      ; -------------------------------------------
      if (cplmnu_IsDivider == 0) ; Is NOT a Divider
      {
        ; -------------------------------------------
        Temp_Icon := ""
        ; -------------------------------------------
        DataArray.102.2 := 1 ; (102_2)(Obj_DisplayedIcon_Sel [0,1,2,3])
        ; -------------------------------------------
        if (MenuItem_1 > 0 && MenuItem_Selected > 0)
        {
          ; -------------------------------------------
          if (MenuItem_2 > 0)
          {
            ; -------------------------------------------
            if (MenuItem_3 > 0)
            {
              if (DataArray.366.5 == "cpl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
              {
                Temp_Icon := A_ProgramFiles "\PopUpMenu_PUM\menu\cpl\ico\" ComCheck ".ico"
              } ; [End] (ScriptType [cpl])
              ; -------------------------------------------
              else if (DataArray.366.5 == "mnu") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
              {
                Temp_Icon := A_ProgramFiles "\PopUpMenu_PUM\menu\mnu\" AppProcessName "\" DataArray.365.2 "\ico\" ComCheck ".ico" ; (365_2)(UserLang [Current User language])
              } ; [End] (ScriptType [mnu])
              ; -------------------------------------------
              MissingIconNum := MenuItem_1 "_" MenuItem_2 "_" MenuItem_3 "_(" MenuItem_Selected ")" ; MenuItem_1 (#_X_X_[X])/MenuItem_2 (X_#_X_[X])/MenuItem_3 (X_X_#_[X])/MenuItem_Selected (X_X_X_[#])
              ; -------------------------------------------
              if (InStr(ComCheck, "Mkb_") > 0)
              {
                ; -------------------------------------------
                ThisMkbKeystroke := MkbAdobeKeyStroke(MenuItem_TextSelected, AppProcessName, DataArray.365.2) ; (365_2)(UserLang [Current User language])
                ; -------------------------------------------
                if (ThisMkbKeystroke == "")
                {
                  ; -------------------------------------------
                  DataArray.119.1 := "" ; (119_1)(Mkb_KeyStroke)
                  IsValid := 0
                  ; -------------------------------------------
                } ; [End] if (ThisMkbKeystroke == "")
                else if (ThisMkbKeystroke != "")
                {
                  ; -------------------------------------------
                  DataArray.119.1 := ThisMkbKeystroke ; (119_1)(Mkb_KeyStroke)
                  IsValid := 1
                  ; -------------------------------------------
                } ; [End] else if (ThisMkbKeystroke != "")
                ; -------------------------------------------
              } ; [End] if (InStr(ComCheck, "Mkb_") > 0)
              ; -------------------------------------------
              else if (InStr(ComCheck, "Mkb_") == 0)
              {
                ; -------------------------------------------
                if FileExist(Temp_Icon)
                {
                  IsValid := 1
                } ; [End] if FileExist(Temp_Icon)
                ; -------------------------------------------
                else ; !FileExist(Temp_Icon)
                {
                  Temp_Icon := A_ProgramFiles "\PopUpMenu_PUM\image\ico\Missing.png"
                  IsValid := 0
                } ; [End] !FileExist(Temp_Icon)
                ; -------------------------------------------
              } ; [End] else if (InStr(ComCheck, "Mkb_") == 0)
              ; -------------------------------------------
            } ; [End] if (MenuItem_3 > 0)
            ; -------------------------------------------
            else if (MenuItem_3 == 0)
            {
              ; -------------------------------------------
              if (DataArray.366.5 == "cpl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
              {
                Temp_Icon := A_ProgramFiles "\PopUpMenu_PUM\menu\cpl\ico\" ComCheck ".ico"
              } ; [End] (ScriptType [cpl])
              ; -------------------------------------------
              else if (DataArray.366.5 == "mnu") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
              {
                Temp_Icon := A_ProgramFiles "\PopUpMenu_PUM\menu\mnu\" AppProcessName "\" DataArray.365.2 "\ico\" ComCheck ".ico" ; (365_2)(UserLang [Current User language])
              } ; [End] (ScriptType [mnu])
              ; -------------------------------------------
              MissingIconNum := MenuItem_1 "_" MenuItem_2 "_(" MenuItem_Selected ")" ; MenuItem_1 (#_X_X_[X])/MenuItem_2 (X_#_X_[X])/MenuItem_Selected (X_X_X_[#])
              ; -------------------------------------------
              if (InStr(ComCheck, "Mkb_") > 0)
              {
                ; -------------------------------------------
                ThisMkbKeystroke := MkbAdobeKeyStroke(MenuItem_TextSelected, AppProcessName, DataArray.365.2) ; (365_2)(UserLang [Current User language])
                if (ThisMkbKeystroke == "")
                {
                  ; -------------------------------------------
                  DataArray.119.1 := "" ; (119_1)(Mkb_KeyStroke)
                  IsValid := 0
                  ; -------------------------------------------
                } ; [End] if (ThisMkbKeystroke == "")
                ; -------------------------------------------
                else if (ThisMkbKeystroke != "")
                {
                  ; -------------------------------------------
                  DataArray.119.1 := ThisMkbKeystroke ; (119_1)(Mkb_KeyStroke)
                  IsValid := 1
                  ; -------------------------------------------
                } ; [End] else if (ThisMkbKeystroke != "")
                ; -------------------------------------------
              } ; [End] if (InStr(ComCheck, "Mkb_") > 0)
              else ; else if (InStr(ComCheck, "Mkb_") == 0)
              {
                if FileExist(Temp_Icon)
                {
                  IsValid := 1
                } ; [End] if FileExist(Temp_Icon)
                else ; !FileExist(Temp_Icon)
                {
                  Temp_Icon := A_ProgramFiles "\PopUpMenu_PUM\image\ico\Missing.png"
                  IsValid := 0
                } ; [End] !FileExist(Temp_Icon)
              } ; [End] else if (InStr(ComCheck, "Mkb_") == 0)
              ; -------------------------------------------
            } ; [End] else if (MenuItem_3 == 0)
            ; -------------------------------------------
          } ; [End] if (MenuItem_2 > 0)
          ; -------------------------------------------
          else if (MenuItem_2 == 0)
          {
            ; -------------------------------------------
            if (DataArray.366.5 == "cpl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
            {
              Temp_Icon := A_ProgramFiles "\PopUpMenu_PUM\menu\cpl\ico\" ComCheck ".ico"
            } ; [End] (ScriptType [cpl])
            ; -------------------------------------------
            else if (DataArray.366.5 == "mnu") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
            {
              Temp_Icon := A_ProgramFiles "\PopUpMenu_PUM\menu\mnu\" AppProcessName "\" DataArray.365.2 "\ico\" ComCheck ".ico" ; (365_2)(UserLang [Current User language])
            } ; [End] (ScriptType [mnu])
            ; -------------------------------------------
            MissingIconNum := MenuItem_1 "_(" MenuItem_Selected ")" ; MenuItem_1 (#_X_X_[X])/MenuItem_Selected (X_X_X_[#])
            ; -------------------------------------------
            if (InStr(ComCheck, "Mkb_") > 0)
            {
              ; -------------------------------------------
              ThisMkbKeystroke := MkbAdobeKeyStroke(MenuItem_TextSelected, AppProcessName, DataArray.365.2) ; (365_2)(UserLang [Current User language])
              if (ThisMkbKeystroke == "")
              {
                ; -------------------------------------------
                DataArray.119.1 := "" ; (119_1)(Mkb_KeyStroke)
                IsValid := 0
                ; -------------------------------------------
              } ; [End] if (ThisMkbKeystroke == "")
              ; -------------------------------------------
              else if (ThisMkbKeystroke != "")
              {
                ; -------------------------------------------
                DataArray.119.1 := ThisMkbKeystroke ; (119_1)(Mkb_KeyStroke)
                IsValid := 1
                ; -------------------------------------------
              } ; [End] else if (ThisMkbKeystroke != "")
              ; -------------------------------------------
            } ; [End] if (InStr(ComCheck, "Mkb_") > 0)
            else ; else if (InStr(ComCheck, "Mkb_") == 0)
            {
              ; -------------------------------------------
              if FileExist(Temp_Icon)
              {
                IsValid := 1
              } ; [End] if FileExist(Temp_Icon)
              ; -------------------------------------------
              else if !FileExist(Temp_Icon)
              {
                Temp_Icon := A_ProgramFiles "\PopUpMenu_PUM\image\ico\Missing.png"
                IsValid := 0
              } ; [End] else if !FileExist(Temp_Icon)
              ; -------------------------------------------
            } ; [End] else if (InStr(ComCheck, "Mkb_") == 0)
            ; -------------------------------------------
          } ; [End] else if (MenuItem_2 == 0)
          ; -------------------------------------------
        } ; [End] if (MenuItem_1 > 0 && MenuItem_Selected > 0)
        ; -------------------------------------------
        else if (MenuItem_Selected == 0 or MenuItem_1 == 0)
        {
          ; -------------------------------------------
          GuiControl, PopUpMenu:Hide, g_102 ; (102_1)(Obj_DisplayedIcon)
          IsValid := 0
          ; -------------------------------------------
        } ; [End] else if (MenuItem_Selected == 0 or MenuItem_1 == 0)
        ; -------------------------------------------
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ;
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        if (Temp_Icon != "")
        {
          DataArray := f_102(Temp_Icon, DataArray) ; (102_1)(Obj_DisplayedIcon)
        } ; [End] if (Temp_Icon != "")
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ;
        ; -------------------------------------------
        if (IsValid == 1)
        {
          if (InStr(ComCheck, "Mkb_") > 0)
          {
            ; -------------------------------------------
            Obj_DisplayText_Top1_Val := DataArray.119.1 ; (119_1)(Mkb_KeyStroke)
            ; -------------------------------------------
            DataArray.100.2 := 1 ; (100_2)(Obj_DisplayText_Top1_Sel [0,1,2,3])
            DataArray.100.3 := Obj_DisplayText_Top1_Val ; (100_3)(Obj_DisplayText_Top1_Val [Text Value])
            ; -------------------------------------------
            /*
            ; -------------------------------------------
            FontColor := "199524" ; Green
            FontColor := "a30404" ; Red
            FontColor := "000000" ; Black
            FontColor := "921297" ; Purple
            FontColor := "040e47" ; Blue
            ; -------------------------------------------
            */
            FontColor := "199524" ; Green
            FontSize := 12
            MaxWidth := 480
            Gui_AdjustTextWidth("g_100", Obj_DisplayText_Top1_Val, GuiFont, FontSize, FontColor, MaxWidth) ; (100_1)(Obj_DisplayText_Top1)
            ; -------------------------------------------
          } ; [End] if (InStr(ComCheck, "Mkb_") > 0)
          ; -------------------------------------------
          if (DataArray.133.2 != 2) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])
          {
            DataArray := Image_GuiControl("004", 1, 0, DataArray) ; (004_1)(Obj_ok)
          }
          DataArray := Image_GuiControl("104", 0, 0, DataArray) ; (104_1)(Obj_DisplayText_Bottom1)
          DataArray := Image_GuiControl("107", 0, 0, DataArray) ; (107_1)(Obj_DisplayText_Bottom2)
          ; -------------------------------------------
        } ; [End] if (IsValid == 1)
        ; -------------------------------------------
        else if (IsValid == 0)
        {
          ; -------------------------------------------
          if (InStr(ComCheck, "Mkb_") > 0)
          {
            ; -------------------------------------------
            if (DataArray.365.2 == "de") ; (365_2)(UserLang [Current User language])
            {
              Obj_DisplayText_Top1_Val    := "Diesem Befehl ist kein Schlüssel zugewiesen"
              Obj_DisplayText_Bottom1_Val := "Überprüfen der " AppProcessName " Tastenkombinationseigenschaften"
            } ; [End] (UserLang [Current User language])
            ; ------------------------------------------- 
            else if (DataArray.365.2 == "en") ; (365_2)(UserLang [Current User language])
            {
              Obj_DisplayText_Top1_Val    := "There is no key assigned to this command"
              Obj_DisplayText_Bottom1_Val := "Check " AppProcessName " Keystroke Customization Properties"
            } ; [End] (UserLang [Current User language])
            ; ------------------------------------------- 
            else if (DataArray.365.2 == "es") ; (365_2)(UserLang [Current User language])
            {
              Obj_DisplayText_Top1_Val    := "No hay ninguna clave asignada a este comando"
              Obj_DisplayText_Bottom1_Val := "Comprobar Propiedades de acceso directo del teclado de " AppProcessName
            } ; [End] (UserLang [Current User language])
            ; ------------------------------------------- 
            else if (DataArray.365.2 == "fr") ; (365_2)(UserLang [Current User language])
            {
              Obj_DisplayText_Top1_Val    := "Aucune clé n’est affectée à cette commande"
              Obj_DisplayText_Bottom1_Val := "Vérifier Les propriétés du raccourci Clavier " AppProcessName
            } ; [End] (UserLang [Current User language])
            ; ------------------------------------------- 
            else if (DataArray.365.2 == "it") ; (365_2)(UserLang [Current User language])
            {
              Obj_DisplayText_Top1_Val    := "A questo comando non è assegnata alcuna chiave"
              Obj_DisplayText_Bottom1_Val := "Controllare le proprietà delle scelte rapide da tastiera di " AppProcessName
            } ; [End] (UserLang [Current User language])
            ; ------------------------------------------- 
            else if (DataArray.365.2 == "pl") ; (365_2)(UserLang [Current User language])
            {
              Obj_DisplayText_Top1_Val    := "Do tego polecenia nie przypisano klucza"
              Obj_DisplayText_Bottom1_Val := "Sprawdzanie właściwości skrótu klawiaturowego programu " AppProcessName
            } ; [End] (UserLang [Current User language])
            ; ------------------------------------------- 
            else if (DataArray.365.2 == "pt") ; (365_2)(UserLang [Current User language])
            {
              Obj_DisplayText_Top1_Val    := "Não há nenhuma chave atribuída a este comando"
              Obj_DisplayText_Bottom1_Val := "Verifique as propriedades do atalho do teclado do " AppProcessName
            } ; [End] (UserLang [Current User language])
            ; ------------------------------------------- 
            else if (DataArray.365.2 == "ru") ; (365_2)(UserLang [Current User language])
            {
              Obj_DisplayText_Top1_Val    := "Этой команде не назначен ключ"
              Obj_DisplayText_Bottom1_Val := "Проверьте " AppProcessName " Клавиатура ярлык Свойства"
            } ; [End] (UserLang [Current User language])
            ; ------------------------------------------- 
            else if (DataArray.365.2 == "sv") ; (365_2)(UserLang [Current User language])
            {
              Obj_DisplayText_Top1_Val    := "Det finns ingen nyckel tilldelad det här kommandot"
              Obj_DisplayText_Bottom1_Val := "Kontrollera egenskaper för kortkommandon i " AppProcessName
            } ; [End] (UserLang [Current User language])
            ; ------------------------------------------- 
            else if (DataArray.365.2 == "tr") ; (365_2)(UserLang [Current User language])
            {
              Obj_DisplayText_Top1_Val    := "Bu komuta atanmış anahtar yok"
              Obj_DisplayText_Bottom1_Val := AppProcessName " Klavye kısayol özelliklerini kontrol et"
            } ; [End] (UserLang [Current User language])
            ; -------------------------------------------
            DataArray.100.2 := 1 ; (100_2)(Obj_DisplayText_Top1_Sel [0,1,2,3])
            Obj_DisplayText_Top1_Val := UIS(Obj_DisplayText_Top1_Val) ; (100_3)(Obj_DisplayText_Top1_Val [Text Value])
            DataArray.100.3 := Obj_DisplayText_Top1_Val ; (100_3)(Obj_DisplayText_Top1_Val [Text Value])
            ;
            DataArray.104.2 := 1 ; (104_2)(Obj_DisplayText_Bottom1_Sel [0,1,2,3])
            Obj_DisplayText_Bottom1_Val := UIS(Obj_DisplayText_Bottom1_Val) ; (104_3)(Obj_DisplayText_Bottom1_Val [Text Value])
            DataArray.104.3 := Obj_DisplayText_Bottom1_Val ; (104_3)(Obj_DisplayText_Bottom1_Val [Text Value])
            ;
            ; -------------------------------------------
            FontColor := "a30404" ; Red
            FontSize := 12
            MaxWidth := 480
            Gui_AdjustTextWidth("g_100", Obj_DisplayText_Top1_Val, GuiFont, FontSize, FontColor, MaxWidth) ; (100_1)(Obj_DisplayText_Top1)
            Gui_AdjustTextWidth("g_104", Obj_DisplayText_Bottom1_Val, GuiFont, FontSize, FontColor, MaxWidth) ; (104_1)(Obj_DisplayText_Bottom1)
            DataArray := Image_GuiControl("107", 0, 0, DataArray) ; (107_1)(Obj_DisplayText_Bottom2)
            ; -------------------------------------------
            if (DataArray.133.2 != 2) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])
            {
              DataArray := Image_GuiControl("004", 3, 0, DataArray) ; (004_1)(Obj_ok)
            } ; [End] (133_2)(Obj_DeleteShortcut_Sel [0,1,2])
            ; -------------------------------------------
          } ; [End] if (InStr(ComCheck, "Mkb_") > 0)
          else ; else (InStr(ComCheck, "Mkb_") == 0)
          {
            ; -------------------------------------------
            if (DataArray.133.2 != 2) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])
            {
              DataArray := Image_GuiControl("004", 3, 0, DataArray) ; (004_1)(Obj_ok)
            }
            DataArray := Image_GuiControl("100", 0, 0, DataArray) ; (100_1)(Obj_DisplayText_Top1)
            DataArray := Image_GuiControl("104", 0, 0, DataArray) ; (104_1)(Obj_DisplayText_Bottom1)
            DataArray := Image_GuiControl("107", 0, 0, DataArray) ; (107_1)(Obj_DisplayText_Bottom2)
            ; -------------------------------------------
          } ; [End] else (InStr(ComCheck, "Mkb_") == 0)
          ; -------------------------------------------
        } ; [End] else if (IsValid == 0)
        ; -------------------------------------------
      } ; [End] if (cplmnu_IsDivider == 0) ; Is NOT a Divider
      ; -------------------------------------------
    } ; [End] [Temp_Icon][Ok Button]
    ; -------------------------------------------
  } ; [End] if (MenuSize > 0)
  ; -------------------------------------------
  if (cplmnu_IsDivider == 1)
  {
    ; -------------------------------------------
    Obj_EditFeild_StatusBar_Val := "" ; (122_3)(Obj_EditFeild_StatusBar_Val [Text Value])
    GuiControl, PopUpMenu:, g_122, %Obj_EditFeild_StatusBar_Val% ; (122_1)(Obj_EditFeild_StatusBar)
    ; -------------------------------------------
    DataArray := Image_GuiControl("100", 0, 0, DataArray) ; (100_1)(Obj_DisplayText_Top1)
    DataArray := Image_GuiControl("104", 0, 0, DataArray) ; (104_1)(Obj_DisplayText_Bottom1)
    DataArray := Image_GuiControl("105", 0, 0, DataArray) ; (105_1)(Obj_DisplayText_Top2)
    DataArray := Image_GuiControl("107", 0, 0, DataArray) ; (107_1)(Obj_DisplayText_Bottom2)
    ; -------------------------------------------
    GuiControl, PopUpMenu:Hide, g_102 ; (102_1)(Obj_DisplayedIcon)
    ; -------------------------------------------
    if (DataArray.133.2 != 2) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])
    {
      DataArray := Image_GuiControl("004", 3, 0, DataArray) ; (004_1)(Obj_ok)
    }
    ; -------------------------------------------
  }
  ; -------------------------------------------
  ;
  return DataArray
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
