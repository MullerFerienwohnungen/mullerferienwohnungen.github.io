﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Wait_FileFolder(WaitType, ThisFileFolder) ; (WaitType["Exist","NotExist"], ThisFileFolder > Nothing
{
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (WaitType == "Exist")
  {
    ; -------------------------------------------
    BreakTime := A_TickCount + 2000
    while !FileExist(ThisFileFolder)
    {
      if (A_TickCount > BreakTime)
      {
        break
      } ; [End] if (A_TickCount > BreakTime)
    } ; [End] while FileExist(ThisFileFolder)
    ; -------------------------------------------
  }
  ; -------------------------------------------
  else if (WaitType == "NotExist")
  {
    ; -------------------------------------------
    BreakTime := A_TickCount + 2000
    while FileExist(ThisFileFolder)
    {
      if (A_TickCount > BreakTime)
      {
        break
      } ; [End] if (A_TickCount > BreakTime)
    } ; [End] while FileExist(ThisFileFolder)
    ; -------------------------------------------
  }
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
