#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\Array_FromFile.ahk
;
#Include %A_ProgramFiles%\PopUpMenu_PUM\Array_Add.ahk ; Array_Add(ThisArray, AddThis, ThisPos) ; > ThisArray
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
XmlValidate(File_ThisXml) ; > 1 = Ok , 0 Xml Has Error
{
  ; -------------------------------------------
  Array_ThisXml := Array_FromFile(File_ThisXml)
  ; -------------------------------------------
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; Check if Xml Structure is Correct
  ; -------------------------------------------
  XmlValidate_1 := 1
  ; -------------------------------------------
  for Index, ThisLine in Array_ThisXml
  {
    ; -------------------------------------------
    if (Index == 3)
    {
      ; -------------------------------------------
      if (InStr(ThisLine, "<toolbox") == 0)
      {
        XmlValidate_1 := 0
      }
      if (InStr(ThisLine, ">") == 0)
      {
        XmlValidate_1 := 0
      }
      ; -------------------------------------------
    } ; if (Index == 2)
    ; -------------------------------------------
    if (Index == 5)
    {
      ; -------------------------------------------
      if (InStr(ThisLine, "<titlebar") == 0)
      {
        XmlValidate_1 := 0
      }
      if (InStr(ThisLine, "/>") == 0)
      {
        XmlValidate_1 := 0
      }
      ; -------------------------------------------
    }
    ; -------------------------------------------
    if (Index == 7)
    {
      ; -------------------------------------------
      if (InStr(ThisLine, "<statusbar") == 0)
      {
        XmlValidate_1 := 0
      }
      if (InStr(ThisLine, "/>") == 0)
      {
        XmlValidate_1 := 0
      }
      ; -------------------------------------------
    }
    ; -------------------------------------------
    if (Index == 9)
    {
      ; -------------------------------------------
      if (InStr(ThisLine, "<displaymode") == 0)
      {
        XmlValidate_1 := 0
      }
      if (InStr(ThisLine, "/>") == 0)
      {
        XmlValidate_1 := 0
      }
      ; -------------------------------------------
    }
    ; -------------------------------------------
    if (Index == 11)
    {
      ; -------------------------------------------
      if (InStr(ThisLine, "<tile") == 0)
      {
        XmlValidate_1 := 0
      }
      if (InStr(ThisLine, "/>") == 0)
      {
        XmlValidate_1 := 0
      }
      ; -------------------------------------------
    }
    ; -------------------------------------------
    if (Index == 13)
    {
      ; -------------------------------------------
      if (InStr(ThisLine, "<border") == 0)
      {
        XmlValidate_1 := 0
      }
      if (InStr(ThisLine, "/>") == 0)
      {
        XmlValidate_1 := 0
      }
      ; -------------------------------------------
    }
    ; -------------------------------------------
    if (Index == 15)
    {
      ; -------------------------------------------
      if (InStr(ThisLine, "<font") == 0)
      {
        XmlValidate_1 := 0
      }
      if (InStr(ThisLine, "/>") == 0)
      {
        XmlValidate_1 := 0
      }
      ; -------------------------------------------
    }
    ; -------------------------------------------
    if (Index == 17)
    {
      ; -------------------------------------------
      if (InStr(ThisLine, "<hint") == 0)
      {
        XmlValidate_1 := 0
      }
      if (InStr(ThisLine, "/>") == 0)
      {
        XmlValidate_1 := 0
      }
      ; -------------------------------------------
    }
    ; -------------------------------------------
    if (Index == 19)
    {
      ; -------------------------------------------
      if (InStr(ThisLine, "<background") == 0)
      {
        XmlValidate_1 := 0
      }
      if (InStr(ThisLine, ">") == 0)
      {
        XmlValidate_1 := 0
      }
      ; -------------------------------------------
    }
    ; -------------------------------------------
    if (Index == 20)
    {
      ; -------------------------------------------
      if (InStr(ThisLine, "<filename>") == 0)
      {
        XmlValidate_1 := 0
      }
      if (InStr(ThisLine, "</filename>") == 0)
      {
        XmlValidate_1 := 0
      }
      ; -------------------------------------------
    }
    ; -------------------------------------------
    if (Index == 21)
    {
      ; -------------------------------------------
      if (InStr(ThisLine, "</background>") == 0)
      {
        XmlValidate_1 := 0
      }
      ; -------------------------------------------
    }
    ; -------------------------------------------
    if (Index == 23)
    {
      ; -------------------------------------------
      if (InStr(ThisLine, "<shortcuts>") == 0)
      {
        XmlValidate_1 := 0
      }
      ; -------------------------------------------
    }
    ; -------------------------------------------
    if (Index > 23) ; Break After Line 23
    {
      break
    }
    ; -------------------------------------------
  } ; for Index, ThisLine in Array_ThisXml
  ; -------------------------------------------
  ; Check if Xml Structure is Correct
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; Check if "</shortcuts>" and "</toolbox>" exist
  ; -------------------------------------------
  if (XmlValidate_1 == 1) ; Structure Was CORRECT
  {
    ; -------------------------------------------
    XmlValidate_2 := 0
    ; -------------------------------------------
    for Index, ThisLine in Array_ThisXml
    {
      ; -------------------------------------------
      if (InStr(ThisLine, "</shortcuts>") > 0)
      {
        XmlValidate_2 := XmlValidate_2 + 1
      }
      ; -------------------------------------------
      if (InStr(ThisLine, "</toolbox>") > 0)
      {
        XmlValidate_2 := XmlValidate_2 + 1
      }
      ; -------------------------------------------
      ;
      ; -------------------------------------------
      if (XmlValidate_2 == 2) ; (File OK)(Both Items Exist) (Break out of Loop)
      {
        break
      }
      ; -------------------------------------------
    } ; for Index, ThisLine in Array_ThisXml
    ; -------------------------------------------
  } ; if (XmlValidate_1 == 1) ; Structure Was CORRECT
  ; Check if "</shortcuts>" and "</toolbox>" exist
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; -------------------------------------------
  if (XmlValidate_1 == 1 && XmlValidate_2 == 2)
  {
    return 1
  }
  else
  {
    return 0
  }
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>