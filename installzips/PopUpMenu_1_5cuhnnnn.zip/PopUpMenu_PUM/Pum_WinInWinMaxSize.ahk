﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
/*
    OuterWin_W := 300
    OuterWin_H := 126.923077
    InnerWin_W := 1216
    InnerWin_H := 896
*/
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Pum_WinInWinMaxSize(OuterWin_W, OuterWin_H, InnerWin_W, InnerWin_H) ; OuterWin_W, OuterWin_H, InnerWin_W, InnerWin_H > [Max_W, Max_H]
{
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (OuterWin_W > OuterWin_H)
  {
    ; -------------------------------------------
    if (InnerWin_W > InnerWin_H)
    {
      ; -------------------------------------------
      Max_W := OuterWin_W
      Max_H := (InnerWin_H / InnerWin_W) * OuterWin_W
      ; -------------------------------------------
      if (Max_H > OuterWin_H)
      {
        ; -------------------------------------------
        Max_W := (InnerWin_W / InnerWin_H) * OuterWin_H
        Max_H := OuterWin_H
        ; -------------------------------------------
      }
      ; -------------------------------------------
    }
    if (InnerWin_W < InnerWin_H)
    {
      ; -------------------------------------------
      Max_W := (InnerWin_W / InnerWin_H) * OuterWin_H
      Max_H := OuterWin_H
      ; -------------------------------------------
      if (Max_W > OuterWin_W)
      {
        ; -------------------------------------------
        Max_W := OuterWin_W
        Max_H := (InnerWin_H / InnerWin_W) * OuterWin_W
        ; -------------------------------------------
      } 
      ; -------------------------------------------
    }
    if (InnerWin_W == InnerWin_H)
    {
      Max_W := OuterWin_H
      Max_H := OuterWin_H
    }
    ; -------------------------------------------
  }
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (OuterWin_W < OuterWin_H)
  {
    ; -------------------------------------------
    if (InnerWin_W > InnerWin_H)
    {
      ; -------------------------------------------
      Max_W := OuterWin_W
      Max_H := (InnerWin_H / InnerWin_W) * OuterWin_W
      ; -------------------------------------------
      if (Max_H > OuterWin_H)
      {
        ; -------------------------------------------
        Max_W := (InnerWin_W / InnerWin_H) * OuterWin_H
        Max_H := OuterWin_H
        ; -------------------------------------------
      }
      ; -------------------------------------------
    }
    if (InnerWin_W < InnerWin_H)
    {
      ; -------------------------------------------
      Max_W := (InnerWin_W / InnerWin_H) * OuterWin_H
      Max_H := OuterWin_H
      ; -------------------------------------------
      if (Max_W > OuterWin_W)
      {
        ; -------------------------------------------
        Max_W := OuterWin_W
        Max_H := (InnerWin_H / InnerWin_W) * OuterWin_W
        ; -------------------------------------------
      }
      ; -------------------------------------------
    }
    if (InnerWin_W == InnerWin_H)
    {
      Max_W := OuterWin_H
      Max_H := OuterWin_H
    }
    ; -------------------------------------------
  }
  else if (OuterWin_W == OuterWin_H)
  {
    ; -------------------------------------------
    if (InnerWin_W > InnerWin_H)
    {
      Max_W := OuterWin_W
      Max_H := (InnerWin_H / InnerWin_W) * OuterWin_W
    }
    if (InnerWin_W < InnerWin_H)
    {
      Max_W := (InnerWin_W / InnerWin_H) * OuterWin_H
      Max_H := OuterWin_H
    }
    if (InnerWin_W == InnerWin_H)
    {
      Max_W := OuterWin_H
      Max_H := OuterWin_H
    }
    ; -------------------------------------------
  }
  ; -------------------------------------------
  ReturnArray := [Max_W, Max_H]
  return ReturnArray
  ; -------------------------------------------
} ; End WinInWinMaxSize
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
