﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\Sys_EnableDisable.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_GuiControl.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Pum_ColorVarConvert.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Folder_WindowsUser.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Select_FileFolder.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_Convert.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Pum_WinInWinMaxSize.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_ResizePng.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_Combine.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\l_543.ahk ; (543_1)(_Msg 8_)(_w300 x h300_)_Sanding_Man)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
f_165(DataArray) ; (165_1)(Obj_Pum_BgImageSelect)
{
  ; -------------------------------------------
  Obj_Pum_BgImageSelect_Sel := DataArray.165.2 ; (165_2)(Obj_Pum_BgImageSelect_Sel [0,1,2])
  UserLang := DataArray.365.2 ; (365_2)(UserLang [Current User language])
  ; -------------------------------------------
  ;
  ; -------------------------------------------
  Pre_Msg8 := DataArray.254.3 ; (254_3)(Obj_MsgImg300x300_Img [Image Path])
  ; -------------------------------------------
  ;
  if (Obj_Pum_BgImageSelect_Sel == "")
  {
    Obj_Pum_BgImageSelect_Sel := 1
  }
  ; -------------------------------------------
  global PumLock
  ; -------------------------------------------
  if (PumLock == "")
  {
    ; -------------------------------------------
    global PumLock := 0
    ; -------------------------------------------
  }
  ; -------------------------------------------
  if (PumLock == 0)
  {
    ; -------------------------------------------
    global PumLock := 1
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    if (Obj_Pum_BgImageSelect_Sel == 1)
    {
      ; -------------------------------------------
      Sys_EnableDisable("Disable") ; "Enable" or "Disable"
      ; -------------------------------------------
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      DataArray := Image_GuiControl("004", 3, 0, DataArray) ; (004_1)(Obj_ok)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      { ; [START UP]  Vars
        ; -------------------------------------------
        { ; [GET] Vars
          ; -------------------------------------------
          UserLang := DataArray.365.2 ; (365_2)(UserLang [Current User language])
          ThisPumProcessFolder := DataArray.361.8 ; (361)(8)(ThisPumProcessFolder [Pum Folder Path])
          ; -------------------------------------------
          XmlIconSize    := DataArray.362.14 ; (362_14)(XmlIconSize [Displaymode iconsize] [32,48,64])
          XmlColumnsX    := DataArray.362.4 ; (362_4)(XmlColumnsX [Pum (X) Columns])
          XmlRowsY       := DataArray.362.3 ; (362_3)(XmlRowsY [Pum (Y) Rows])
          ; -------------------------------------------
          Img_W          := DataArray.362.34 ; (362_34)(Img_W)
          Img_H          := DataArray.362.35 ; (362_35)(Img_H)
          Pum_W          := DataArray.362.36 ; (362_36)(Pum_W)
          Pum_H          := DataArray.362.37 ; (362_37)(Pum_H)
          bg_Image_Type  := DataArray.362.38 ; (362_38)(Bg_Image_Type [C=Crop,F=Fit])
          Img_Gui_W      := DataArray.362.39 ; (362_39)(Img_Gui_W)
          Img_Gui_H      := DataArray.362.40 ; (362_40)(Img_Gui_H)
          Img_Gui_X      := DataArray.362.41 ; (362_41)(Img_Gui_X)
          Img_Gui_Y      := DataArray.362.42 ; (362_42)(Img_Gui_Y)
          Pum_Gui_W      := DataArray.362.44 ; (362_44)(Pum_Gui_W)
          Pum_Gui_H      := DataArray.362.45 ; (362_45)(Pum_Gui_H)
          Pum_Gui_X      := DataArray.362.46 ; (362_46)(Pum_Gui_X)
          Pum_Gui_Y      := DataArray.362.47 ; (362_47)(Pum_Gui_Y)
          Pum_Gui_Max_W  := DataArray.362.48 ; (362_48)(Pum_Gui_Max_W)
          Pum_Gui_Max_H  := DataArray.362.49 ; (362_49)(Pum_Gui_Max_H)
          Pum_Gui_Min_W  := DataArray.362.50 ; (362_50)(Pum_Gui_Min_W)
          Pum_Gui_Min_H  := DataArray.362.51 ; (362_51)(Pum_Gui_Min_H)
          bg_Selected_Rotate := DataArray.362.54 ; (362_54)(bg_Selected_Rotate)
          ; -------------------------------------------
          XmlBgColor := DataArray.362.27 ; (362_27)(XmlBgColor [Background color])
          XmlBgType  := DataArray.362.28 ; (362_28)(XmlBgType [BG Image 1 / BG Trans 2])
          ; -------------------------------------------
          ; VarType = ("VarNum"(123),"ColorGrid"(A1),"HexColor"(FFFFFF),"MsColor"(1234546)) > [VarNum, ColorGrid, HexColor, MsColor]
          Color_Array := Pum_ColorVarConvert("MsColor", XmlBgColor, DataArray)
          Pum_BgColor_GridNum      := Color_Array.2
          ; -------------------------------------------
        } ; End [GET] Vars
        ; -------------------------------------------
        File_PumFrame := A_ProgramFiles "\PopUpMenu_PUM\image\pum\PumFrame.png"
        ; -------------------------------------------
        Temp_Selected_Img   := DataArray.362.33 ; (362_33)(Temp_Selected_Img [FilePath])
        Temp_Selected_Gui   := ThisPumProcessFolder "\image\Temp_Selected_Gui.png"
        Temp_Selected_Fit   := ThisPumProcessFolder "\image\Temp_Selected_Fit.png"
        ; -------------------------------------------
        Temp_Display_Img     := ThisPumProcessFolder "\image\Temp_Display_Img.png"
        ; -------------------------------------------
        File_Pum_Gui         := ThisPumProcessFolder "\image\File_Pum_Gui.png"
        ; -------------------------------------------
      } ; End [START UP] Vars
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Quick Hide
      GuiControl, PopUpMenu:Hide, g_102 ; (102_1)(Obj_DisplayedIcon)
      ; -------------------------------------------
      DataArray := Image_GuiControl("165", 2, 1, DataArray) ; (165_1)(Obj_Pum_BgImageSelect)
      DataArray := Image_GuiControl("167", 0, 1, DataArray) ; (167_1)(Obj_Pum_BgFitImage)
      DataArray := Image_GuiControl("182", 0, 0, DataArray) ; (182_1)(Obj_Pum_BgRotateLeft)
      DataArray := Image_GuiControl("183", 0, 0, DataArray) ; (183_1)(Obj_Pum_BgRotateRight)
      DataArray := Image_GuiControl("241", 0, 0, DataArray) ; (241_1)(Obj_Pum_CropLeft)
      DataArray := Image_GuiControl("242", 0, 0, DataArray) ; (242_1)(Obj_Pum_CropRight)
      DataArray := Image_GuiControl("243", 0, 0, DataArray) ; (243_1)(Obj_Pum_CropUp)
      DataArray := Image_GuiControl("244", 0, 0, DataArray) ; (244_1)(Obj_Pum_CropDown)
      DataArray := Image_GuiControl("245", 0, 0, DataArray) ; (245_1)(Obj_Pum_CropCenter)
      DataArray := Image_GuiControl("246", 0, 0, DataArray) ; (246_1)(Obj_Pum_ZoomIn)
      DataArray := Image_GuiControl("247", 0, 0, DataArray) ; (247_1)(Obj_Pum_ZoomOut)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Quick Hide
      ;
      ; -------------------------------------------
      RegRead, StartFolder, HKEY_CURRENT_USER, Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders, My Pictures
      ; -------------------------------------------
      ;
      ; -------------------------------------------
      ; [OutTarget, Arguments, UseLink (0,1), Selected_File, LinkIcon]
      Selected_Array := Select_FileFolder(DataArray.365.2, "AnyImage", StartFolder, ThisPumProcessFolder) ; (365_2)(UserLang [Current User language])
      ; -------------------------------------------
      ;
      ; -------------------------------------------
      File_SelectedImage := Selected_Array.1
      ; -------------------------------------------
      if File_SelectedImage
      {
        ; -------------------------------------------
        ; SplitPath, InputVar, OutFileName, OutDir, OutExtension, OutNameNoExt, OutDrive
        SplitPath, File_SelectedImage, SelectedImage_FileNameExt, SelectedImage_Folder, SelectedImage_Ext, SelectedImage_FileName
        ; -------------------------------------------
        if (SelectedImage_Ext == "apng" or SelectedImage_Ext == "avif" or SelectedImage_Ext == "bmp" or SelectedImage_Ext == "gif" or SelectedImage_Ext == "ico" or SelectedImage_Ext == "jfif" or SelectedImage_Ext == "jpeg" or SelectedImage_Ext == "jpg" or SelectedImage_Ext == "png" or SelectedImage_Ext == "svg" or SelectedImage_Ext == "tif" or SelectedImage_Ext == "tiff" or SelectedImage_Ext == "webp")
        {
          ; -------------------------------------------
          if (SelectedImage_Ext == "jfif")
          {
            Temp_jpg := A_AppData "\PopUpMenu_PUM\temp\" SelectedImage_Name ".jpg"
            FileCopy, %File_SelectedImage%, %Temp_jpg%, 1
            Sleep, 10
          }
          ; -------------------------------------------
          ;
          ; -------------------------------------------
          bg_Image_Type := "C"
          ; -------------------------------------------
          XmlBgType := 1
          DataArray.362.28 := 1 ; (New Image Selected) (362_28)(XmlBgType [BG Image 1 / BG Trans 2])
          ; -------------------------------------------
          ;
          ; -------------------------------------------
          ;
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ 
          ; (543_1)(_Msg 8_)(_w300 x h300_)_Sanding_Man)
          global n_543 := 1 ; Start Frame Number
          global s_543 := 1 ; Show
          SetTimer, l_543, 100 ; (543_1)(_Msg 8_)(_w300 x h300_)_Sanding_Man)
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ;
          Test_Selected_Img := ThisPumProcessFolder "\image\Test_Selected_Img." SelectedImage_Ext
          FileDelete, %Test_Selected_Img%
          Test_Selected_Img := Image_Convert(File_SelectedImage, Test_Selected_Img) ; Image_In, Image_Out > Image_Out
          ; -------------------------------------------
          if FileExist(Test_Selected_Img)
          {
            ; -------------------------------------------
            Temp_Display_Txt_Img := ThisPumProcessFolder "\image\Temp_Display_Txt_Img.png"
            FileDelete, %Temp_Display_Txt_Img%
            ; -------------------------------------------
            ;
            ; -------------------------------------------
            DataArray.362.33 := File_SelectedImage ; (362_33)(Temp_Selected_Img [FilePath])
            ; -------------------------------------------
            ;
            ; -------------------------------------------
            FileDelete, %Temp_Selected_Gui%
            FileDelete, %Temp_Selected_Fit%
            FileDelete, %Temp_Display_Img%
            ; -------------------------------------------
            Delete_1 := ThisPumProcessFolder "\image\Temp_Selected_Img.*"
            FileDelete, %Delete_1%
            ; -------------------------------------------
            Temp_Selected_Img := ThisPumProcessFolder "\image\Temp_Selected_Img." SelectedImage_Ext
            FileMove, %Test_Selected_Img%, %Temp_Selected_Img%, 1
            DataArray.362.33 := Temp_Selected_Img ; (362_33)(Temp_Selected_Img [FilePath])
            ; -------------------------------------------
            ; [SET] (Img_Gui_[W,H]) | Width and Height of Resized Image to fit 300x300 Square
            Gui, ImageSize:Add, Picture, hwndJustForSize, %Temp_Selected_Img%
            ControlGetPos, , , Img_W, Img_H, , ahk_id %JustForSize%
            ; -------------------------------------------
            ; [SET] (Img_Gui_[W,H]) | Width and Height of Resized Image to fit 300x300 Square
            WinInWin_Array := Pum_WinInWinMaxSize(300, 300, Img_W, Img_H) ; OuterWin_W, OuterWin_H, InterWin_W, InterWin_H > [Max_W, Max_H]
            Img_Gui_W := WinInWin_Array.1
            Img_Gui_H := WinInWin_Array.2
            ; -------------------------------------------
            ;  [NEED] (Img_Gui_[W,H]) (Temp_Selected_Img) | [CREATE] (Temp_Selected_Gui.png)
            ;  [Resized Image to fit 300x300 Square for Display Image]
            FileDelete, %Temp_Selected_Gui%
            Image_ResizePng(Img_Gui_W, Img_Gui_H, Temp_Selected_Img, Temp_Selected_Gui) ; Resize_W, Resize_H, ImageIn, ImageOut > 1 / 0
            PreventFunctionError := 1
            ; -------------------------------------------
            ;
            ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            { ; [COMMON] [NEED] (XmlColumnsX)(XmlRowsY)(XmlIconSize) | [SET] (Pum_[W,H])
              ; -------------------------------------------
              ;
              Pum_W := XmlColumnsX * XmlIconSize
              Pum_H := XmlRowsY * XmlIconSize
              ;
              ; -------------------------------------------
            } ; End [COMMON] [NEED] (XmlColumnsX)(XmlRowsY)(XmlIconSize) | [SET] (Pum_[W,H])
            ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            ;
            ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            { ; [NEED] (Img_Gui_[W,H]) (Pum_[W,H]) | [SET] (Pum_Gui_[W,H]) (Pum_Gui_Max_[W,H])
              ; -------------------------------------------
              WinInWin_Array := Pum_WinInWinMaxSize(Img_Gui_W, Img_Gui_H, Pum_W, Pum_H) ; OuterWin_W, OuterWin_H, InterWin_W, InterWin_H > [Max_W, Max_H]
              ; -------------------------------------------
              Pum_Gui_W := WinInWin_Array.1
              Pum_Gui_H := WinInWin_Array.2
              ; -------------------------------------------
              Pum_Gui_Max_W := WinInWin_Array.1
              Pum_Gui_Max_H := WinInWin_Array.2
              ; -------------------------------------------
            } ; End [NEED] (Img_Gui_[W,H]) (Pum_[W,H] | [SET] (Pum_Gui_[W,H]) (Pum_Gui_Max_[W,H])
            ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            ;
            ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            { ; [NEED] (Img_Gui_Fit_[W,H]) (Temp_Selected_Gui.png) | [CREATE] (Temp_Selected_Fit.png)
              ; -------------------------------------------
              FileDelete, %Temp_Selected_Fit%
              Image_ResizePng(Pum_Gui_Max_W, Pum_Gui_Max_H, Temp_Selected_Gui, Temp_Selected_Fit) ; New_W, New_H, Image_In, Image_Out > 1 / 0
              ; -------------------------------------------
            } ; End [NEED] (Img_Gui_Fit_[W,H]) (Temp_Selected_Gui.png) | [CREATE] (Temp_Selected_Fit.png)
            ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            ;
            ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            { ; [NEED] (Img_Gui_[W,H]) (Temp_Selected_Gui.png) | [RESIZE] (Temp_Selected_Gui.png) | [SET] (Img_Gui_[X,Y]) (Pum_Gui_Min_[W,H])
              ; -------------------------------------------
              if (Img_Gui_W > Img_Gui_H)
              {
                ; -------------------------------------------
                Img_Gui_X := 0
                Img_Gui_Y := (300 - Img_Gui_H) / 2
                ; -------------------------------------------
                Pum_Gui_Min_W := 300 / 5
                Pum_Gui_Min_H := Img_Gui_H / 5
                ; -------------------------------------------
              } ; End (Img_Gui_W > Img_Gui_H)
              else if (Img_Gui_W < Img_Gui_H)
              {
                ; -------------------------------------------
                Img_Gui_X := (300 - Img_Gui_W) / 2
                Img_Gui_Y := 0
                ; -------------------------------------------
                Pum_Gui_Min_W := Img_Gui_W / 5
                Pum_Gui_Min_H := 300 / 5
                ; -------------------------------------------
              } ; End (Img_Gui_W < Img_Gui_H)
              else if (Img_Gui_W == Img_Gui_H)
              {
                ; -------------------------------------------
                Img_Gui_X := 0
                Img_Gui_Y := 0
                ; -------------------------------------------
                Pum_Gui_Min_W := 300 / 5
                Pum_Gui_Min_H := 300 / 5
                ; -------------------------------------------
              } ; End (Img_Gui_W == Img_Gui_H)
              ; -------------------------------------------
            } ; End [NEED] (Img_Gui_[W,H]) | [SET] (Img_Gui_[X,Y]) (Pum_Gui_Min_[W,H])
            ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            ;
            ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            { ; [NEED] (Img_Gui_[W,H]) (Pum_Gui_Max_[W,H]) | [SET] (Pum_Gui_[X,Y])
              ; -------------------------------------------
              Pum_Gui_X := (Img_Gui_W - Pum_Gui_Max_W) / 2
              Pum_Gui_Y := (Img_Gui_H - Pum_Gui_Max_H) / 2
              ; -------------------------------------------
            } ; End [NEED] (Img_Gui_[W,H]) (Pum_Gui_Max_[W,H]) | [SET] (Pum_Gui_[X,Y])
            ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            ;
            ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            { ; [NEED] (Pum_Gui_Max_[W,H]) (File_PumFrame) | [CREATE] (File_Pum_Gui.png)
              ; -------------------------------------------
              FileDelete, %File_Pum_Gui%
              ; -------------------------------------------
              Image_ResizePng(Pum_Gui_Max_W, Pum_Gui_Max_H, File_PumFrame, File_Pum_Gui) ; New_W, New_H, ImageIn, ImageOut > 1 / 0
              ; -------------------------------------------
            } ; End [NEED] (Pum_Gui_Max_[W,H]) (File_PumFrame) | [CREATE] (File_Pum_Gui.png)
            ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            ;
            ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            { ; [NEED] (Img_Gui_[W,H]) (Pum_Gui_[X,Y]) | [SET] (Spacer_Img_[X,Y]) | [SET] (Spacer_Pum_[X,Y])
              ; -------------------------------------------
              Spacer_Img_X := (300 - Img_Gui_W) / 2
              Spacer_Img_Y := (300 - Img_Gui_H) / 2
              ; -------------------------------------------
              Spacer_Pum_X := (Pum_Gui_X + Spacer_Img_X)
              Spacer_Pum_Y := (Pum_Gui_Y + Spacer_Img_Y)
              ; -------------------------------------------
            } ; End [NEED] (Img_Gui_[W,H]) (Pum_Gui_[X,Y]) | [SET] (Spacer_Img_[X,Y]) | [SET] (Spacer_Pum_[X,Y])
            ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            ;
            ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            { ; [NEED] (Temp_Selected_Gui.png) (File_Pum_Gui.png) (Spacer_[X,Y])) | [Create] (Temp_Display_Img.png)
              ; -------------------------------------------            
              Temp_Resize := A_ProgramFiles "\PopUpMenu_PUM\image\pum\pum_" Pum_BgColor_GridNum "_100.png"
              ; -------------------------------------------
              TxT_Gui_C := ThisPumProcessFolder "\image\File_TxT_Gui_C.png"
              FileDelete, %TxT_Gui_C%
              ; -------------------------------------------
              Image_ResizePng(Img_Gui_W , Img_Gui_H, Temp_Resize, TxT_Gui_C) ; Resize_W, Resize_H, ImageIn, ImageOut > 1 / 0
              ; -------------------------------------------
              FileDelete, %Temp_Display_Img%
              Image_Array := [300, 300, Temp_Display_Img, TxT_Gui_C, Spacer_Img_X, Spacer_Img_Y, Temp_Selected_Gui, Spacer_Img_X, Spacer_Img_Y, File_Pum_Gui, Spacer_Pum_X, Spacer_Pum_Y]
              Image_Combine(Image_Array)
              FileDelete, %TxT_Gui_C%
              ; -------------------------------------------
            } ; End [NEED] (Temp_Selected_Fit.png) (File_Pum_Gui.png) (Spacer_[X,Y])) | [Create] (Temp_Display_Img.png)
            ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            ;
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ 
            ; (543_1)(_Msg 8_)(_w300 x h300_)_Sanding_Man)
            global s_543 := 0 ; Hide
            SetTimer, l_543, Off ; (543_1)(_Msg 8_)(_w300 x h300_)_Sanding_Man)
            global ShowAnimationChange := 0
            Sleep, 110
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ;
            ; -------------------------------------------
            GuiControl, PopUpMenu:, g_254, %Temp_Display_Img% ; (254_1)(Obj_MsgImg300x300)
            GuiControl, PopUpMenu:Show, g_254 ; (254_1)(Obj_MsgImg300x300)
            DataArray.254.3 := Temp_Display_Img ; (254_3)(Obj_MsgImg300x300_Img [Image Path])
            ; -------------------------------------------
            ;
            ; (New Image)
            ;
            ; -------------------------------------------
            if (DataArray.362.52 == "" or DataArray.362.52 == 0 or DataArray.362.52 == 1) ; (362_52)(bg_Selected_Change)
            {
              DataArray.362.52 := 2 ; (362_52)(bg_Selected_Change. [1=,2=New Image)
            }
            ; -------------------------------------------
            DataArray.362.54 := 0 ; (362_54)(bg_Selected_Rotate)
            ; -------------------------------------------
            Pum_Factor := DataArray.362.34 / DataArray.362.39 ; (362_34)(Img_W)/(362_39)(Img_Gui_W)
            DataArray.362.55 := Pum_Factor * DataArray.362.46 ; (362_55)(Pum_X)/(362_46)(Pum_Gui_X)
            DataArray.362.56 := Pum_Factor * DataArray.362.47 ; (362_56)(Pum_Y)/(362_47)(Pum_Gui_Y)
            ; -------------------------------------------
            DataArray := Image_GuiControl("004", 1, 0, DataArray) ; (004_1)(Obj_ok)
            ; -------------------------------------------
            ;
            ; -------------------------------------------
            ;
            ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            { ; [SHOW-HIDE] Controls
              ; -------------------------------------------
              DataArray := Image_GuiControl("182", 1, 0, DataArray) ; (182_1)(Obj_Pum_BgRotateLeft)
              DataArray := Image_GuiControl("183", 1, 0, DataArray) ; (183_1)(Obj_Pum_BgRotateRight)
              ; -------------------------------------------
              if (bg_Image_Type == "C") ; Image is a Crop
              {
                ; -------------------------------------------
                DataArray.241.3 := "" ; (241_3)(Obj_Pum_CropLeft_Img [Image Path])
                DataArray.242.3 := "" ; (242_3)(Obj_Pum_CropRight_Img [Image Path])
                DataArray.243.3 := "" ; (243_3)(Obj_Pum_CropUp_Img [Image Path])
                DataArray.244.3 := "" ; (244_3)(Obj_Pum_CropDown_Img [Image Path])
                DataArray.245.3 := "" ; (245_3)(Obj_Pum_CropCenter_Img [Image Path])
                DataArray.246.3 := "" ; (246_3)(Obj_Pum_ZoomIn_Img [Image Path])
                DataArray.247.3 := "" ; (247_3)(Obj_Pum_ZoomOut_Img [Image Path])
                ; -------------------------------------------
                DataArray := Image_GuiControl("167", 1, 1, DataArray) ; (167_1)(Obj_Pum_BgFitImage)
                ; -------------------------------------------
                if (Pum_Gui_X <= 0.9999999999999999999999999999999999999999)
                {
                  Pum_Gui_X := 0
                }
                if (Pum_Gui_Y <= 0.9999999999999999999999999999999999999999)
                {
                  Pum_Gui_Y := 0
                }
                ; -------------------------------------------
                if (Pum_Gui_X == 0)
                {
                  DataArray := Image_GuiControl("241", 0, 0, DataArray) ; (241_1)(Obj_Pum_CropLeft)
                }
                else
                {
                  DataArray := Image_GuiControl("241", 1, 0, DataArray) ; (241_1)(Obj_Pum_CropLeft)
                }
                ; -------------------------------------------
                if ((Pum_Gui_X + Pum_Gui_W) >= Img_Gui_W)
                {
                  DataArray := Image_GuiControl("242", 0, 0, DataArray) ; (242_1)(Obj_Pum_CropRight)
                }
                else
                {
                  DataArray := Image_GuiControl("242", 1, 0, DataArray) ; (242_1)(Obj_Pum_CropRight)
                }
                ; -------------------------------------------
                if (Pum_Gui_Y == 0)
                {
                  DataArray := Image_GuiControl("243", 0, 0, DataArray) ; (243_1)(Obj_Pum_CropUp)
                }
                else
                {
                  DataArray := Image_GuiControl("243", 1, 0, DataArray) ; (243_1)(Obj_Pum_CropUp)
                }
                ; -------------------------------------------
                if ((Pum_Gui_Y + Pum_Gui_H) >= Img_Gui_H)
                {
                  DataArray := Image_GuiControl("244", 0, 0, DataArray) ; (244_1)(Obj_Pum_CropDown)
                }
                else
                {
                  DataArray := Image_GuiControl("244", 1, 0, DataArray) ; (244_1)(Obj_Pum_CropDown)
                }
                ; -------------------------------------------
                DataArray := Image_GuiControl("245", 1, 0, DataArray) ; (245_1)(Obj_Pum_CropCenter)
                ; -------------------------------------------
                if ((Pum_Gui_W > Pum_Gui_Min_W && Pum_Gui_W < Pum_Gui_Max_W) && (Pum_Gui_H > Pum_Gui_Min_H && Pum_Gui_H < Pum_Gui_Max_H))
                {
                  DataArray := Image_GuiControl("246", 1, 0, DataArray) ; (246_1)(Obj_Pum_ZoomIn)
                  DataArray := Image_GuiControl("247", 1, 0, DataArray) ; (247_1)(Obj_Pum_ZoomOut)
                }
                else if ((Pum_Gui_W > Pum_Gui_Min_W) && (Pum_Gui_H > Pum_Gui_Min_H))
                {
                  DataArray := Image_GuiControl("246", 1, 0, DataArray) ; (246_1)(Obj_Pum_ZoomIn)
                  DataArray := Image_GuiControl("247", 0, 0, DataArray) ; (247_1)(Obj_Pum_ZoomOut)
                }
                else if ((Pum_Gui_W < Pum_Gui_Max_W) && (Pum_Gui_H < Pum_Gui_Max_H))
                {
                  DataArray := Image_GuiControl("246", 0, 0, DataArray) ; (246_1)(Obj_Pum_ZoomIn)
                  DataArray := Image_GuiControl("247", 1, 0, DataArray) ; (247_1)(Obj_Pum_ZoomOut)
                }
                ; -------------------------------------------
              } ; End (bg_Image_Type == "C")
              ; -------------------------------------------
              else if (bg_Image_Type == "F") ; Image is a Crop
              {
                ; -------------------------------------------
                DataArray := Image_GuiControl("167", 2, 1, DataArray) ; (167_1)(Obj_Pum_BgFitImage)
                ; -------------------------------------------
                DataArray := Image_GuiControl("241", 0, 0, DataArray) ; (241_1)(Obj_Pum_CropLeft)
                DataArray := Image_GuiControl("242", 0, 0, DataArray) ; (242_1)(Obj_Pum_CropRight)
                DataArray := Image_GuiControl("243", 0, 0, DataArray) ; (243_1)(Obj_Pum_CropUp)
                DataArray := Image_GuiControl("244", 0, 0, DataArray) ; (244_1)(Obj_Pum_CropDown)
                DataArray := Image_GuiControl("245", 0, 0, DataArray) ; (245_1)(Obj_Pum_CropCenter)
                DataArray := Image_GuiControl("246", 0, 0, DataArray) ; (246_1)(Obj_Pum_ZoomIn)
                DataArray := Image_GuiControl("247", 0, 0, DataArray) ; (247_1)(Obj_Pum_ZoomOut)
              } ; End (bg_Image_Type == "F")
              ; -------------------------------------------
            } ; End [SHOW-HIDE] Controls
            ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            ;
            ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            { ; [UPDATE] Vars
              ; -------------------------------------------
              DataArray.365.2  := UserLang ; (365_2)(UserLang [Current User language])
              DataArray.361.8  := ThisPumProcessFolder ; (361)(8)(ThisPumProcessFolder [Pum Folder Path])
              ; -------------------------------------------
              DataArray.362.14 := XmlIconSize ; (362_14)(XmlIconSize [Displaymode iconsize] [32,48,64])
              DataArray.362.4  := XmlColumnsX ; (362_4)(XmlColumnsX [Pum (X) Columns])
              DataArray.362.3  := XmlRowsY ; (362_3)(XmlRowsY [Pum (Y) Rows])
              ; -------------------------------------------
              DataArray.362.34 := Img_W ; (362_34)(Img_W)
              DataArray.362.35 := Img_H ; (362_35)(Img_H)
              DataArray.362.36 := Pum_W ; (362_36)(Pum_W)
              DataArray.362.37 := Pum_H ; (362_37)(Pum_H)
              DataArray.362.38 := bg_Image_Type ; (362_38)(Bg_Image_Type [C=Crop,F=Fit])
              DataArray.362.39 := Img_Gui_W ; (362_39)(Img_Gui_W)
              DataArray.362.40 := Img_Gui_H ; (362_40)(Img_Gui_H)
              DataArray.362.41 := Img_Gui_X ; (362_41)(Img_Gui_X)
              DataArray.362.42 := Img_Gui_Y ; (362_42)(Img_Gui_Y)
              DataArray.362.44 := Pum_Gui_W ; (362_44)(Pum_Gui_W)
              DataArray.362.45 := Pum_Gui_H ; (362_45)(Pum_Gui_H)
              DataArray.362.46 := Pum_Gui_X ; (362_46)(Pum_Gui_X)
              DataArray.362.47 := Pum_Gui_Y ; (362_47)(Pum_Gui_Y)
              DataArray.362.48 := Pum_Gui_Max_W ; (362_48)(Pum_Gui_Max_W)
              DataArray.362.49 := Pum_Gui_Max_H ; (362_49)(Pum_Gui_Max_H)
              DataArray.362.50 := Pum_Gui_Min_W ; (362_50)(Pum_Gui_Min_W)
              DataArray.362.51 := Pum_Gui_Min_H ; (362_51)(Pum_Gui_Min_H)
              ; -------------------------------------------
              DataArray.362.27 := XmlBgColor ; (362_27)(XmlBgColor [Background color])
              ; -------------------------------------------
            } ; End [UPDATE] Vars
            ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            ;
          } ; if FileExist(Test_Selected_Img)
          else ; Image Can Not Be Converted
          {
            ; -------------------------------------------
            DataArray := Image_GuiControl("165", 1, 1, DataArray) ; (165_1)(Obj_Pum_BgImageSelect)
            ; -------------------------------------------
            ;
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ 
            ; (543_1)(_Msg 8_)(_w300 x h300_)_Sanding_Man)
            global s_543 := 0 ; Hide
            SetTimer, l_543, Off ; (543_1)(_Msg 8_)(_w300 x h300_)_Sanding_Man)
            global ShowAnimationChange := 0
            Sleep, 110
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            Error_438 := A_ProgramFiles "\PopUpMenu_PUM\image\pum\438_" UserLang ".png"
            GuiControl, PopUpMenu:, g_254, %Error_438% ; (254_1)(Obj_MsgImg300x300)
            GuiControl, PopUpMenu:Show, g_254 ; (254_1)(Obj_MsgImg300x300)
            Sleep, 1500
            GuiControl, PopUpMenu:, g_254, %Pre_Msg8% ; (254_1)(Obj_MsgImg300x300)
            GuiControl, PopUpMenu:Show, g_254 ; (254_1)(Obj_MsgImg300x300)
          }
        } ; End Selected Is a Image
        else
        {
          DataArray := Image_GuiControl("004", 1, 0, DataArray) ; (004_1)(Obj_ok)
        }
      } ; End A File was Selected
      ; -------------------------------------------
      
      ; -------------------------------------------
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      DataArray := Image_GuiControl("004", 1, 0, DataArray) ; (004_1)(Obj_ok)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; -------------------------------------------
      Sys_EnableDisable("Enable") ; "Enable" or "Disable"
      ; -------------------------------------------
    } ; End All Image Controls Buttons are in Normal State
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    global PumLock := 0
    ; -------------------------------------------
  } ; End (PumLock == 0)
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
