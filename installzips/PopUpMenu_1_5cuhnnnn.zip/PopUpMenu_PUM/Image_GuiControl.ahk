﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\Gui_ObjectSize.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Image_GuiControl(GuiVarNum, SelectImgNum, HasLanguage, DataArray) ; Image_GuiControl(GuiVarNum, SelectImgNum, HasLanguage, DataArray) ; > DataArray
{
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (GuiVarNum != "" or SelectImgNum != "" or HasLanguage != "") ; Pass Check
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [STARTUP] [SET] Vars
    ScriptType     := DataArray.366.5 ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
    UserLang       := DataArray.365.2 ; (365_2)(UserLang [Current User language])
    AppProcessName := DataArray.367.1 ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
    ; -------------------------------------------
    if (ScriptType == "mnu")
    {
      ; -------------------------------------------
      MenuSize := DataArray.302.6 ; (302_6)(Mnu_MenuSize [#])
      ; -------------------------------------------
    } ; [End] if (ScriptType == "mnu")
    else if (ScriptType == "cpl")
    {
      ; -------------------------------------------
      MenuSize := DataArray.300.6 ; (300_6)(Cpl_MenuSize [#])
      ; -------------------------------------------
    } ; [End] else if (ScriptType == "cpl")
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [STARTUP] [SET] Vars
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [CHECK] [GET] ImgVarNum
    if (InStr(GuiVarNum, "_") > 0)
    {
      ; -------------------------------------------
      ; ###_### -or- Menu_###
      ; ImgVarNum = XXX_###
      ; GuiVarNum = ###_XXX
      ; -------------------------------------------
      GetNum := GuiVarNum
      UnderScorePos := InStr(GetNum, "_")
      ImgVarNum := SubStr(GetNum, 1, UnderScorePos - 1)
      GuiVarNum := SubStr(GetNum, UnderScorePos + 1)
      ; -------------------------------------------
      if (ImgVarNum == "Menu")
      {
        ImageType := ImgVarNum
        ImgVarNum := GuiVarNum
      }
      ; -------------------------------------------
      else if (ImgVarNum == "Image")
      {
        ImageType := ImgVarNum
        ThisImage := SelectImgNum
      }
      ; -------------------------------------------
    } ; [End] if (InStrInStr(GuiVarNum, "_") > 0)
    else
    {
      ImgVarNum := GuiVarNum
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [CHECK] [GET] ImgVarNum
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [SET] DataArrayNum [REMOVE] 0 from GuiVarNum
    DataArrayNum := GuiVarNum
    ; -------------------------------------------
    if (SubStr(DataArrayNum, 1, 1) == "0") ; 00# Remove 0's
    {
      DataArrayNum := SubStr(DataArrayNum, 2)
    }
    if (SubStr(DataArrayNum, 1, 1) == "0") ; 0# Remove 0's
    {
      DataArrayNum := SubStr(DataArrayNum, 2)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [SET] DataArrayNum [REMOVE] 0 from GuiVarNum
    ;
    if (SelectImgNum == 0)
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [HIDE] GuiVarNum, [SET] DataArray.DataArrayNum.3 := ""
      DataArray[DataArrayNum][3] := ""
      GuiControl, PopUpMenu:Hide, g_%GuiVarNum%
      GuiControl, PopUpMenu:, g_%GuiVarNum%
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [HIDE] GuiVarNum, [SET] DataArray.DataArrayNum.3 := ""
    }
    else if (SelectImgNum != 0)
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [SET] DataArray.DataArrayNum.2 := SelectImgNum
      if (SelectImgNum == 1 or SelectImgNum == 2 or SelectImgNum == 3)
      {
        ; -------------------------------------------
        DataArray[DataArrayNum][2] := SelectImgNum ; [SET] DataArray to SelectImgNum
        ; -------------------------------------------
      }
      else
      {
        ; -------------------------------------------
        DataArray[DataArrayNum][2] := 1 ; [SET] DataArray to SelectImgNum
        ; -------------------------------------------
      }
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [SET] DataArray.DataArrayNum.2 := SelectImgNum
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [SET] ThisImage
      if (ImageType != "Image")
      {
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [SET] ImagePath
        if (ImageType == "Menu")
        {
          ; -------------------------------------------
          if (ScriptType == "mnu")
          {
            if (HasLanguage == 0)
            {
              ; -------------------------------------------
              ImagePath := A_ProgramFiles "\PopUpMenu_PUM\menu\" ScriptType "\" AppProcessName "\image"
              ; -------------------------------------------
            } ; [End] if (HasLanguage == 0)
            else if (HasLanguage == 1)
            {
              ; -------------------------------------------
              ImagePath := A_ProgramFiles "\PopUpMenu_PUM\menu\" ScriptType "\" AppProcessName "\" UserLang "\image"
              ; -------------------------------------------
            } ; [End] else if (HasLanguage == 1)
          } ; [End] if (ScriptType == "mnu")
          else if (ScriptType == "cpl")
          {
            if (HasLanguage == 0)
            {
              ; -------------------------------------------
              ImagePath := A_ProgramFiles "\PopUpMenu_PUM\menu\" ScriptType "\image"
              ; -------------------------------------------
            } ; [End] if (HasLanguage == 0)
            else if (HasLanguage == 1)
            {
              ; -------------------------------------------
              ImagePath := A_ProgramFiles "\PopUpMenu_PUM\menu\" ScriptType "\image\" UserLang
              ; -------------------------------------------
            } ; [End] else if (HasLanguage == 1)
          } ; [End] else if (ScriptType == "cpl")
        } ; [End] if (ImgVarNum == "Menu")
        else
        {
          ; -------------------------------------------
          ImagePath := A_ProgramFiles "\PopUpMenu_PUM\image\gui"
          ; -------------------------------------------
        }
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [SET] ImagePath
        ;
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [SET] ThisImage
        if (HasLanguage == 0)
        {
          ; -------------------------------------------
          ThisImage := ImagePath "\(" ImgVarNum ")_" SelectImgNum ".png" ; (302_6)(MenuSize [#])/(365_2)(UserLang [Current User language])
          ; -------------------------------------------
        } ; [End] if (HasLanguage == 0)
        else if (HasLanguage == 1)
        {
          ; -------------------------------------------
          ThisImage := ImagePath "\(" ImgVarNum ")_" SelectImgNum "_" UserLang ".png" ; (302_6)(MenuSize [#])/(365_2)(UserLang [Current User language])
          ; -------------------------------------------
        } ; [End] else if (HasLanguage == 1)
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [SET] ThisImage
      } ; [End] if (ImageType != "Image")
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [SET] ThisImage
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [SET] DataArray.DataArrayNum.3 := ThisImage, [GuiControl] g_%GuiVarNum%, %ThisImage%
      CurrentImage := DataArray[DataArrayNum][3]
      ; -------------------------------------------
      if (CurrentImage != ThisImage)
      {
        if FileExist(ThisImage)
        {
          ; -------------------------------------------
          DataArray[DataArrayNum][3] := ThisImage
          GuiControl, PopUpMenu:, g_%GuiVarNum%, %ThisImage%
          ; -------------------------------------------
          Gui_ObjectSize(GuiVarNum, DataArray) ; > Nothing
          ; -------------------------------------------
        } ; [End] if FileExist(ThisImage)
        ; -------------------------------------------
      } ; [End] if (CurrentImage != ThisImage)
      ; -------------------------------------------
      if (SelectImgNum != 0)
      {
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [GuiControl] PopUpMenu:Show, g_%GuiVarNum%
        GuiControl, PopUpMenu:Show, g_%GuiVarNum%
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [GuiControl] PopUpMenu:Show, g_%GuiVarNum%
      }
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [SET] DataArray.DataArrayNum.3 := ThisImage, [GuiControl] g_%GuiVarNum%, %ThisImage%
    } ; [End] else if (SelectImgNum != 0)
    ; -------------------------------------------
  } ; [End] if (GuiVarNum != "" or SelectImgNum != "" or HasLanguage != "") ; Pass Check
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  return DataArray
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
