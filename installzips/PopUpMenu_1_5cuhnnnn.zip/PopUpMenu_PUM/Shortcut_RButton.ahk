﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\Array_FromFile.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\XmlVal.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\String_Reverse.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Shortcut_RButton(DataArray) ; > DataArray
{
  ; -------------------------------------------
  KeyWait, RButton, L
  ; -------------------------------------------
  Pum_MousePosArray := ""
  ; -------------------------------------------
  WinGet, ThisPumProcessExe, ProcessName, ahk_class TfrmToolbox
  ; -------------------------------------------
  if (InStr(ThisPumProcessExe, "pum_") > 0) ; pum Exist
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; Get Current Mouse Position
    ; -------------------------------------------
    CoordMode, Mouse, Window
    ; -------------------------------------------
    MouseGetPos , Pum_MousePosX, Pum_MousePosY, , , 1
    ; -------------------------------------------
    ; Get Current Mouse Position
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; Current (ThisPumProcessArray) from Pum_Run(DataArray)
    ; Set (ThisPumProcessName)(ThisPumProcessFolder) from SplitPath, ThisPumProcessExe
    ; -------------------------------------------
    SplitPath, ThisPumProcessExe, , , , ThisPumProcessName
    ThisPumProcessName := StrReplace(ThisPumProcessName, "pum_", "")
    ThisPumProcessFolder := A_AppData "\PopUpMenu_PUM\pums\" ThisPumProcessName
    ; -------------------------------------------
    ThisPumProcessArray := DataArray.361.10
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    Check_Len := ThisPumProcessArray.MaxIndex() ; Highest Length
    if (Check_Len < 38 or Check_Len == "")
    {
      ; -------------------------------------------
      ThisPumProcessXml := A_AppData "\PopUpMenu_PUM\pums\" ThisPumProcessName "\settings\toolbox0.xml"
      ThisPumProcessArray := Array_FromFile(ThisPumProcessXml)
      DataArray.361.10 := ThisPumProcessArray
      ; -------------------------------------------
    } ; if (Check_Len < 38 or Check_Len == "")
    ; -------------------------------------------
    ; Current (ThisPumProcessArray) from Pum_Run(DataArray)
    ; Set (ThisPumProcessName)(ThisPumProcessFolder) from SplitPath, ThisPumProcessExe
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; XML Line Strings from (ThisPumProcessArray)
    ; -------------------------------------------
    XmlLine3  := ThisPumProcessArray.3
    XmlLine9  := ThisPumProcessArray.9
    XmlLine19 := ThisPumProcessArray.19
    XmlLine20 := ThisPumProcessArray.20
    ; -------------------------------------------
    ; XML Line Strings from (ThisPumProcessArray)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; (XmlRowsY)
    ; -------------------------------------------
    FindItem := "rows"
    XmlString := XmlLine3 ; <toolbox name="" rows="19" columns="25" left="38" top="36" stayontop="-1" >
    ; -------------------------------------------
    ItemPos := InStr(XmlString, FindItem)
    ValStringTemp := SubStr(XmlString, ItemPos)
    ValStartPos := InStr(ValStringTemp, """",,, 1)
    ValStartPos := ValStartPos + 1
    ValEndPos := InStr(ValStringTemp, """",,, 2)
    ValLen := ValEndPos - ValStartPos
    ThisVar  := SubStr(ValStringTemp, ValStartPos, ValLen)
    ; -------------------------------------------
    XmlRowsY := ThisVar
    ; -------------------------------------------
    ; (XmlRowsY)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; (XmlColumnsX)
    ; -------------------------------------------
    FindItem := "columns"
    XmlString := XmlLine3 ; <toolbox name="" rows="19" columns="25" left="38" top="36" stayontop="-1" >
    ; -------------------------------------------
    ItemPos := InStr(XmlString, FindItem)
    ValStringTemp := SubStr(XmlString, ItemPos)
    ValStartPos := InStr(ValStringTemp, """",,, 1)
    ValStartPos := ValStartPos + 1
    ValEndPos := InStr(ValStringTemp, """",,, 2)
    ValLen := ValEndPos - ValStartPos
    ThisVar  := SubStr(ValStringTemp, ValStartPos, ValLen)
    ; -------------------------------------------
    XmlColumnsX := ThisVar
    ; -------------------------------------------
    ; (XmlColumnsX)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; (XmlWinPosX)
    ; -------------------------------------------
    FindItem := "left"
    XmlString := XmlLine3 ; <toolbox name="" rows="19" columns="25" left="38" top="36" stayontop="-1" >
    ; -------------------------------------------
    ItemPos := InStr(XmlString, FindItem)
    ValStringTemp := SubStr(XmlString, ItemPos)
    ValStartPos := InStr(ValStringTemp, """",,, 1)
    ValStartPos := ValStartPos + 1
    ValEndPos := InStr(ValStringTemp, """",,, 2)
    ValLen := ValEndPos - ValStartPos
    ThisVar  := SubStr(ValStringTemp, ValStartPos, ValLen)
    ; -------------------------------------------
    XmlWinPosX := ThisVar
    ; -------------------------------------------
    ; (XmlWinPosX)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; (XmlWinPosY)
    ; -------------------------------------------
    FindItem := "top"
    XmlString := XmlLine3 ; <toolbox name="" rows="19" columns="25" left="38" top="36" stayontop="-1" >
    ; -------------------------------------------
    ItemPos := InStr(XmlString, FindItem)
    ValStringTemp := SubStr(XmlString, ItemPos)
    ValStartPos := InStr(ValStringTemp, """",,, 1)
    ValStartPos := ValStartPos + 1
    ValEndPos := InStr(ValStringTemp, """",,, 2)
    ValLen := ValEndPos - ValStartPos
    ThisVar  := SubStr(ValStringTemp, ValStartPos, ValLen)
    ; -------------------------------------------
    XmlWinPosY := ThisVar
    ; -------------------------------------------
    ; (XmlWinPosY)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; (XmlIconSize)
    ; -------------------------------------------
    FindItem := "iconsize"
    XmlString := XmlLine9 ; <displaymode type="0" iconsize="48" />
    ; -------------------------------------------
    ItemPos := InStr(XmlString, FindItem)
    ValStringTemp := SubStr(XmlString, ItemPos)
    ValStartPos := InStr(ValStringTemp, """",,, 1)
    ValStartPos := ValStartPos + 1
    ValEndPos := InStr(ValStringTemp, """",,, 2)
    ValLen := ValEndPos - ValStartPos
    ThisVar  := SubStr(ValStringTemp, ValStartPos, ValLen)
    ; -------------------------------------------
    XmlIconSize := ThisVar
    ; -------------------------------------------
    ; (XmlIconSize)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; (XmlBgColor)
    ; -------------------------------------------
    FindItem := "color"
    XmlString := XmlLine19 ; <background color="12632256" type="1" effect="0" opacity="50" >
    ; -------------------------------------------
    ItemPos := InStr(XmlString, FindItem)
    ValStringTemp := SubStr(XmlString, ItemPos)
    ValStartPos := InStr(ValStringTemp, """",,, 1)
    ValStartPos := ValStartPos + 1
    ValEndPos := InStr(ValStringTemp, """",,, 2)
    ValLen := ValEndPos - ValStartPos
    ThisVar  := SubStr(ValStringTemp, ValStartPos, ValLen)
    ; -------------------------------------------
    XmlBgColor := ThisVar
    ; -------------------------------------------
    ; (XmlBgColor)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; (XmlBgType)
    ; -------------------------------------------
    FindItem := "type"
    XmlString := XmlLine19 ; <background color="12632256" type="1" effect="0" opacity="50" >
    ; -------------------------------------------
    ItemPos := InStr(XmlString, FindItem)
    ValStringTemp := SubStr(XmlString, ItemPos)
    ValStartPos := InStr(ValStringTemp, """",,, 1)
    ValStartPos := ValStartPos + 1
    ValEndPos := InStr(ValStringTemp, """",,, 2)
    ValLen := ValEndPos - ValStartPos
    ThisVar  := SubStr(ValStringTemp, ValStartPos, ValLen)
    ; -------------------------------------------
    XmlBgType := ThisVar
    ; -------------------------------------------
    ; (XmlBgType)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; (XmlBgOpacity)
    ; -------------------------------------------
    FindItem := "opacity"
    XmlString := XmlLine19 ; <background color="12632256" type="1" effect="0" opacity="50" >
    ; -------------------------------------------
    ItemPos := InStr(XmlString, FindItem)
    ValStringTemp := SubStr(XmlString, ItemPos)
    ValStartPos := InStr(ValStringTemp, """",,, 1)
    ValStartPos := ValStartPos + 1
    ValEndPos := InStr(ValStringTemp, """",,, 2)
    ValLen := ValEndPos - ValStartPos
    ThisVar  := SubStr(ValStringTemp, ValStartPos, ValLen)
    ; -------------------------------------------
    XmlBgOpacity := ThisVar
    ; -------------------------------------------
    ; (XmlBgOpacity)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; (XmlBgBmp)
    ; -------------------------------------------
    XmlBgBmp := XmlLine20 ; <filename>C:\Users\CaveMan\AppData\Roaming\PopUpMenu_PUM\pums\pumdefault\image\bg_Selected_Bmp.bmp</filename>
    ; -------------------------------------------
    XmlBgBmp := StrReplace(XmlBgBmp, "       <filename>", "")
    XmlBgBmp := StrReplace(XmlBgBmp, "      <filename>", "")
    XmlBgBmp := StrReplace(XmlBgBmp, "     <filename>", "")
    XmlBgBmp := StrReplace(XmlBgBmp, "    <filename>", "")
    XmlBgBmp := StrReplace(XmlBgBmp, "   <filename>", "")
    XmlBgBmp := StrReplace(XmlBgBmp, "  <filename>", "")
    XmlBgBmp := StrReplace(XmlBgBmp, " <filename>", "")
    XmlBgBmp := StrReplace(XmlBgBmp, "<filename>", "")
    XmlBgBmp := StrReplace(XmlBgBmp, "</filename>", "")
    ; -------------------------------------------
    ; (XmlBgBmp)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [Set Vars] from (mobiletext.txt)
    ; (Pum_MobileTextOnOff)
    ; (Pum_MobileTextColor)
    ; (Pum_MobileBgColor)
    ; (Pum_MobileTextSize)
    ; -------------------------------------------
    File_MobileText := ThisPumProcessFolder "\ahk\mobiletext.txt"
    if FileExist(File_MobileText)
    {
      ; -------------------------------------------
      MobileTextArray := Array_FromFile(File_MobileText)
      ; -------------------------------------------
      Pum_MobileTextOnOff := MobileTextArray.1
      Pum_MobileTextColor := MobileTextArray.2
      Pum_MobileBgColor   := MobileTextArray.3
      Pum_MobileTextSize  := MobileTextArray.4
      ; -------------------------------------------
    }
    else
    {
      ; -------------------------------------------
      Pum_MobileTextSize := "12"
      Pum_MobileTextOnOff := "1"
      Pum_MobileTextColor := "0x000000"
      Pum_MobileBgColor := "0xffffff"
      ; -------------------------------------------
      FileEncoding, UTF-8 ; UTF-8
      FileAppend, %Pum_MobileTextOnOff%`n, %File_MobileText% ; UTF-8
      FileAppend, %Pum_MobileTextColor%`n, %File_MobileText% ; UTF-8
      FileAppend, %Pum_MobileBgColor%`n, %File_MobileText% ; UTF-8
      FileAppend, %Pum_MobileTextSize%`n, %File_MobileText% ; UTF-8
      ; -------------------------------------------
    }
    ; -------------------------------------------
    Sleep, 1
    ; -------------------------------------------
    DataArray.362.23 := Pum_MobileTextSize ; (362_23)(Pum_MobileTextSize [Font Size, 10, 12, 14])
    DataArray.362.24 := Pum_MobileTextOnOff ; (362_24)(Pum_MobileTextOnOff [1 = On, 0 Off])
    DataArray.362.25 := Pum_MobileTextColor ; (362_25)(Pum_MobileTextColor [Text Color (Hex)])
    DataArray.362.26 := Pum_MobileBgColor ; (362_26)(Pum_MobileBgColor [Background Color (Hex)])
    ; -------------------------------------------
    ; [Set Vars] from (mobiletext.txt)
    ; (Pum_MobileTextOnOff)
    ; (Pum_MobileTextColor)
    ; (Pum_MobileBgColor)
    ; (Pum_MobileTextSize)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; Set (XmlShortcutPosX)(XmlShortcutPosY)
    ; -------------------------------------------
    XmlShortcutPosX := Pum_MousePosX / XmlIconSize
    XmlShortcutPosY := Pum_MousePosY / XmlIconSize
    ; -------------------------------------------
    XmlShortcutPosX := XmlShortcutPosX + 1
    XmlShortcutPosY := XmlShortcutPosY + 1
    ; -------------------------------------------
    XmlShortcutPosX := Floor(XmlShortcutPosX)
    XmlShortcutPosY := Floor(XmlShortcutPosY)
    ; -------------------------------------------
    ; Set (XmlShortcutPosX)(XmlShortcutPosY)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    if (XmlShortcutPosX > XmlColumnsX) ; Mouse is Outside Pum (Right)
    {
      XmlShortcutPosX := 0
    }
    else if (XmlShortcutPosX < 0) ; Mouse is Outside Pum (Left)
    {
      XmlShortcutPosX := 0
    }
    ; -------------------------------------------
    if (XmlShortcutPosY > XmlRowsY) ; Mouse is Outside Pum (Bottom)
    {
      XmlShortcutPosY := 0
    }
    else if (XmlShortcutPosY < 0) ; Mouse is Outside Pum (Top)
    {
      XmlShortcutPosY := 0
    }
    ; -------------------------------------------
    if (XmlShortcutPosX == 0 or XmlShortcutPosY == 0)
    {
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ; -1 Means a Not in Pum
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      XmlShortcutLineNum := "-1" ; (370_1)(XmlShortcutLineNum [XML Line Number])
      DataArray.370.1 := XmlShortcutLineNum ; (370_1)(XmlShortcutLineNum [XML Line Number])
    }
    else ; Check for Empty Grid [SET] (370_1)(XML_SC Line Number [-1 = Not in Pum] [0 = Empty Grid] [# = XML Line Number])
    {
      ; -------------------------------------------
      CheckFor := "<shortcut row=""" XmlShortcutPosY """ column=""" XmlShortcutPosX """"
      XmlShortcutLineNum := 0
      ; -------------------------------------------
      for Index, ThisLine in ThisPumProcessArray
      {
        if (InStr(ThisLine, CheckFor) > 0)
        {
          ; -------------------------------------------
          XmlShortcutLineNum := Index
          ; -------------------------------------------
          ;
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          ; (Line 2) <filename>key-20191128111115.ahk</filename>
          ; -------------------------------------------
          ScriptNameExt := ThisPumProcessArray[XmlShortcutLineNum + 1]
          ;
          ScriptNameExt := StrReplace(ScriptNameExt, "<filename>ahk\","")
          ScriptNameExt := StrReplace(ScriptNameExt, "<filename>","")
          ScriptNameExt := StrReplace(ScriptNameExt, "</filename>","")
          ScriptNameExt := StrReplace(ScriptNameExt, A_Space ,"")
          ScriptType := SubStr(ScriptNameExt, 1, 3)
          XmlScriptPath := A_AppData "\PopUpMenu_PUM\pums\" ThisPumProcessName "\ahk\" ScriptNameExt
          XmlOldScriptPath := XmlScriptPath
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          ;
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          ; (Line 8) <icon name="pumiconcache\20220227082859.ico" index="0" />
          ; -------------------------------------------
          ; Var 363_4 = X:\Folder\PopUpMenu_PUM\cache\20191128111115.ico
          ; -------------------------------------------
          Xml_IconNameExt := ThisPumProcessArray[XmlShortcutLineNum + 7]
          Xml_IconNameExt := StrReplace(Xml_IconNameExt, "<icon name=""pumiconcache\", "")
          Xml_IconNameExt := StrReplace(Xml_IconNameExt, "<icon name=""", "")
          Xml_IconNameExt := StrReplace(Xml_IconNameExt, """ index=""0"" />", "")
          Xml_IconNameExt := StrReplace(Xml_IconNameExt, A_Space, "")
          Xml_IconPath := A_AppData "\PopUpMenu_PUM\pums\" ThisPumProcessName "\pumiconcache\"  Xml_IconNameExt
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          ; If Icon is Missing, Copy Bakup Icon from (A_AppData "\PopUpMenu_PUM\pums\" ThisPumProcessName "\iconcache")
          ; -------------------------------------------
          if !FileExist(Xml_IconPath) ; (A_AppData "\PopUpMenu_PUM\pums\" ThisPumProcessName "\pumiconcache\"  Xml_IconNameExt)
          {
            ; -------------------------------------------
            ;
            Bak_CatchPath := A_AppData "\PopUpMenu_PUM\pums\" ThisPumProcessName "\iconcache"
            Loop, Files, %Bak_CatchPath%\*.ico
            {
              ; -------------------------------------------
              Bak_IconPath := A_LoopFileFullPath
              ; -------------------------------------------
              SplitPath, Bak_IconPath, Bak_IconNameExt ; C__ProgramData_PopUpMenu_PUM_cache_20191128111115.ico,0_(64).ico
              ; -------------------------------------------
              if (InStr(Bak_IconNameExt, Xml_IconNameExt) > 0)
              {
                FileCopy, %Bak_IconPath%, %Xml_IconPath%, 1
                Sleep, 10
              } ; [End] if (InStr(Bak_IconNameExt, Xml_IconNameExt) > 0)
            } ; [End] Loop, Files, %Bak_CatchPath%\*.ico
          } ; [End] if !FileExist(Xml_IconPath)
          ; -------------------------------------------
          ; If Icon is Missing, Copy Bakup Icon from (A_AppData "\PopUpMenu_PUM\pums\" ThisPumProcessName "\iconcache")
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          ;
          ; -------------------------------------------
          break
          ; -------------------------------------------                                                
        } ; End if (InStr(ThisLine, CheckFor) > 0)
        ; -------------------------------------------
      } ; [End] for Index, ThisLine in ThisPumProcessArray
      ; -------------------------------------------
      ;
      ; -------------------------------------------
      if (XmlShortcutLineNum == 0)
      {
        ScriptType := "xxx"
      }
      ; -------------------------------------------
      ;
      ; -------------------------------------------
      FileReadLine, ShortcutDescription, %XmlOldScriptPath%, 10
      ShortcutDescription := SubStr(ShortcutDescription, 2)
      ; -------------------------------------------
      if (ShortcutDescription == "")
      {
        if (ScriptType == "ofl")
        {
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (ofl)
          ; Script_Line_2 := ""                         *** EMPTY ***
          ; Script_Line_3 := "x:\Folder"                (303_2)(ofl_FolderPathName [Folder Name With Path])
          ; Script_Line_4 := ""                         *** EMPTY ***
          ; Script_Line_5 := ""                         *** EMPTY ***
          ; Script_Line_6 := ""                         *** EMPTY ***
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (ofl)
          ;
          ; -------------------------------------------
          FileReadLine, ScriptLine3, %XmlOldScriptPath%, 3
          ScriptLine3 := StrReplace(ScriptLine3, """", "")
          ScriptLine3 := StrReplace(ScriptLine3, ".lnk", "")
          ; -------------------------------------------
          DataArray.303.2 := ScriptLine3 ; (303_2)(ofl_FolderPathName [Folder Name With Path])
          ; -------------------------------------------
          ScriptLine3 := String_Reverse(ScriptLine3) ; > StringReversed
          SlashPos := InStr(ScriptLine3, "\")
          ScriptLine3 := SubStr(ScriptLine3, 1, SlashPos - 1)
          ScriptLine3 := String_Reverse(ScriptLine3) ; > StringReversed
          ; -------------------------------------------
          DataArray.303.3 := ScriptLine3 ; (303_3)(ofl_FolderName [Folder Name NO Path])
          ; -------------------------------------------
          Obj_EditFeild_StatusBar_Val := ScriptLine3
          ; -------------------------------------------
        } ; [End] if (ScriptType == "ofl")
        else if (ScriptType == "run")
        {
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (run)
          ; Script_Line_2 := 0/1/2                      (073_2)(Obj_Run_AsAdmin_Sel [0,1,2])
          ; Script_Line_3 := "x:\Executable.ext"        (305_11)(run_OutTarget [FullPath])
          ; Script_Line_4 := "Run_Arguments"            (305_12)(run_Arguments [Executable Arguments])
          ; Script_Line_5 := 0/1                        (305_13)(run_UseLink [Selected OutTarget File Is a LNK] [0/1])
          ; Script_Line_6 := ""                         (Empty)
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (run)
          ;
          ; -------------------------------------------
          FileReadLine, ScriptLine3, %XmlOldScriptPath%, 3
          ScriptLine3 := StrReplace(ScriptLine3, """", "")
          DataArray.305.11 := ScriptLine3 ; (305_11)(Run_OutTarget [PathExtName])
          ; -------------------------------------------
          ;
          ; -------------------------------------------
          ;(_15_Apr_2023_)(_21_18_50_)
          ; I think this is here just for infromation reasons
          ; Searching for error in the icon image for a "run" Script Type exe 
          ;
          ;~ ; ArrayIn := [AppProcessPathNameExt, AppProcessName, UseCommonBrowser, UserLang, UserPictureFolder]
          ;~ ArrayIn := [DataArray.305.11, "", "", DataArray.365.2, DataArray.363.12]
          ;~ ; -------------------------------------------
          ;~ FileDel135   := Img_Del135(ArrayIn)
          ;~ FileDel254   := Img_Del254(ArrayIn)
          ;~ FileError440 := Img_Error440(ArrayIn)
          ;~ FileError450 := Img_Error450(ArrayIn)
          ;~ FileError460 := Img_Error460(ArrayIn)
          ;~ FileError470 := Img_Error470(ArrayIn)
          ;~ FileMnu134   := Img_Mnu134(ArrayIn)
          ;~ FileMnu137   := Img_Mnu137(ArrayIn)
          ;~ FileNew135   := Img_New135(ArrayIn)
          ;~ FileNew254   := Img_New254(ArrayIn)
          ;~ FileOflIco   := Img_OflIco(ArrayIn)
          ;~ FileRunIco   := Img_RunIco(ArrayIn)
          ;~ FileRwhIco   := Img_RwhIco(ArrayIn)
          ; -------------------------------------------
          ;
          ; -------------------------------------------
          SplitPath, ScriptLine3, , , , ScriptLine3_Name
          Obj_EditFeild_StatusBar_Val := ScriptLine3_Name
          ; -------------------------------------------
        } ; [End] else if (ScriptType == "run")
        else if (ScriptType == "rwh")
        {
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (rwh)
          ; Script_Line_2 := 1/2                        (073_2)(Obj_Run_AsAdmin_Sel [0,1,2])
          ; Script_Line_3 := "x:\File.ext"              (305_4)(run_FilePathNameExt [Selected File] [Path,Name,Ext])
          ; Script_Line_4 := "x:\Executable.ext"        (305_5)(Rwh_OpeningApp [Full File Path])
          ; Script_Line_5 := ""                         *** EMPTY ***
          ; Script_Line_6 := ""                         *** EMPTY ***
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (rwh)
          ;
          ; -------------------------------------------
          FileReadLine, ScriptLine3, %XmlOldScriptPath%, 3
          FileReadLine, ScriptLine4, %XmlOldScriptPath%, 4
          ScriptLine3 := StrReplace(ScriptLine3, """", "")
          ScriptLine4 := StrReplace(ScriptLine4, """", "")
          ; -------------------------------------------
          DataArray.305.4 := ScriptLine3 ; (305_4)(Run_FilePathNameExt [Selected File] [Path,Name,Ext])
          DataArray.305.5 := ScriptLine4 ; (305_5)(Rwh_OpeningApp [Full File Path])
          ; -------------------------------------------
          ;
          ; -------------------------------------------
          ; ArrayIn := [AppProcessPathNameExt, AppProcessName, UseCommonBrowser, UserLang, UserPictureFolder]
          ;~ ArrayIn := [DataArray.305.5, "", "", DataArray.365.2, DataArray.363.12]
          ; -------------------------------------------
          ;~ FileDel135   := Img_Del135(ArrayIn)
          ;~ FileDel254   := Img_Del254(ArrayIn)
          ;~ FileError440 := Img_Error440(ArrayIn)
          ;~ FileError450 := Img_Error450(ArrayIn)
          ;~ FileError460 := Img_Error460(ArrayIn)
          ;~ FileError470 := Img_Error470(ArrayIn)
          ;~ FileMnu134   := Img_Mnu134(ArrayIn)
          ;~ FileMnu137   := Img_Mnu137(ArrayIn)
          ;~ FileNew135   := Img_New135(ArrayIn)
          ;~ FileNew254   := Img_New254(ArrayIn)
          ;~ FileOflIco   := Img_OflIco(ArrayIn)
          ;~ FileRunIco   := Img_RunIco(ArrayIn)
          ;~ FileRwhIco   := Img_RwhIco(ArrayIn)
          ; -------------------------------------------
          ;
          ; -------------------------------------------
          SplitPath, ScriptLine3, , , , ScriptLine3_Name
          SplitPath, ScriptLine4, , , , ScriptLine4_Name
          ; -------------------------------------------
          Obj_EditFeild_StatusBar_Val := ScriptLine3_Name " > " ScriptLine4_Name
          ; -------------------------------------------
        } ; [End] else if (ScriptType == "rwh")
      }
      else
      {
        Obj_EditFeild_StatusBar_Val := ShortcutDescription
      }
      ; -------------------------------------------
      DataArray.122.3 := Obj_EditFeild_StatusBar_Val ; (122_3)(Obj_EditFeild_StatusBar_Val [Text Value])
      ; -------------------------------------------
      DataArray.361.2  := Pum_MousePosArray ; (361)(2)(Pum_MousePosArray [(X_Pos), (Y_Pos) / [0, 0])
      DataArray.361.8  := ThisPumProcessFolder ; (361)(8)(ThisPumProcessFolder [Pum Folder Path])
      ; -------------------------------------------
      Check_Len := ThisPumProcessArray.MaxIndex() ; Highest Length
      if (Check_Len > 30)
      {
        DataArray.361.10 := ThisPumProcessArray
      }
      ; -------------------------------------------
      DataArray.361.11 := Pum_MousePosX ; (361)(11)(Pum_MousePosX [Integer])
      DataArray.361.12 := Pum_MousePosY ; (361)(12)(Pum_MousePosY [Integer])
      DataArray.361.15 := ThisPumProcessName ; (361)(15)(ThisPumProcessName [NO pum_,Path,Ext])
      ; -------------------------------------------
      DataArray.362.3  := XmlRowsY ; (362_3)(XmlRowsY [Pum (Y) Rows])
      DataArray.362.4  := XmlColumnsX ; (362_4)(XmlColumnsX [Pum (X) Columns])
      DataArray.362.5  := XmlWinPosX ; (362_5)(XmlWinPosX [Pum Window Position (X) Left])
      DataArray.362.6  := XmlWinPosY ; (362_6)(XmlWinPosY [Pum Window Position (Y) Top])
      DataArray.362.14 := XmlIconSize ; (362_14)(XmlIconSize [Displaymode iconsize] [32,48,64])
      DataArray.362.27 := XmlBgColor ; (362_27)(XmlBgColor [Background color])
      DataArray.362.28 := XmlBgType ; (362_28)(XmlBgType [BG Image 1 / BG Trans 2])
      DataArray.362.30 := XmlBgOpacity ; (362_30)(XmlBgOpacity [Background opacity] [0 - 100])
      DataArray.362.31 := XmlBgBmp ; (362_31)(XmlBgBmp [BMP Image [Full Path])
      ; -------------------------------------------
      DataArray.366.5 := ScriptType ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      ; -------------------------------------------
      DataArray.370.1  := XmlShortcutLineNum ; (370_1)(XmlShortcutLineNum [XML Line Number])
      DataArray.370.2  := XmlShortcutPosX ; (370_2)(XmlShortcutPosX)
      DataArray.370.3  := XmlShortcutPosY ; (370_3)(XmlShortcutPosY)
      DataArray.370.8  := XmlScriptPath ; (370_8)(XmlScriptPath [Full File Path])
      DataArray.370.9  := XmlOldScriptPath ; (370_9)(XmlOldScriptPath [Full File Path])
      DataArray.370.10 := Xml_IconPath ; (370_10)(TbXml_ShortcutLine8_IconPath [Full File Path])
      ; -------------------------------------------
      ;
      ; -------------------------------------------
      FormatTime, TimeRightNow , , yyyyMMddHHmmss
      ThisYear := SubStr(TimeRightNow, 1, 4)
      ThisMonth := SubStr(TimeRightNow, 5, 2)
      ThisDay := SubStr(TimeRightNow, 7, 2)
      ThisHour := SubStr(TimeRightNow, 9, 2)
      ThisMinute := SubStr(TimeRightNow, 11, 2)
      ThisSecond := SubStr(TimeRightNow, 13, 2)
      TimeRightNow := ThisYear ThisMonth ThisDay ThisHour ThisMinute ThisSecond
      ; -------------------------------------------
      TempIcon := A_AppData "\PopUpMenu_PUM\temp\" TimeRightNow ".ico" ; (386_2)(Temporary Icon [System Folder Path])
      ; -------------------------------------------
      FileCopy, %Xml_IconPath%, %TempIcon%, 1
      Sleep, 10
      ; -------------------------------------------
      DataArray.102.3 := TempIcon ; (102_3)(Obj_DisplayedIcon_Img [Image Path])
      ; -------------------------------------------
    } ; [End] Check for Empty Grid [SET] (370_1)(XML_SC Line Number [-1 = Not in Pum] [0 = Empty Grid] [# = XML Line Number])
    ; -------------------------------------------
  }
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
} ; [End] Shortcut_RButton(DataArray) ; > DataArray
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
