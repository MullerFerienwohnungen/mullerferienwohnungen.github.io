﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
#NoTrayIcon
#SingleInstance, Force
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; (500)(Splash Anamated: PopUpMenu Loading)(No Text)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
if WinExist("PopUpMenuUpdate501" . "ahk_class AutoHotkeyGUI") ; (Update Splash is Running)
{
	ExitApp
}
else
{
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; [StartUp] Vars / PreLoad Image
  ; -------------------------------------------
  ; *Note* Splash_Script("Off", 0) is Ran (SysTray.ahk)
  ; Max 90 Seconds to ExitApp
  ; -------------------------------------------
  Breaktime := A_TickCount + 90000
  ImagePath := A_ProgramFiles "\PopUpMenu_PUM\image\gui"
  ; -------------------------------------------
  GuiLoadNum := 0
  ; -------------------------------------------
  Loop 23
  {
  	; -------------------------------------------
  	GuiLoadNum := GuiLoadNum + 1
  	ThisImage := ImagePath "\(500)_" GuiLoadNum ".png"
  	LoadPicture(ThisImage)
  	; -------------------------------------------
  }
  ; -------------------------------------------
  GuiLoadNum := 0
  ; -------------------------------------------
  ; [StartUp] Vars / PreLoad Image
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; Gui
  ; -------------------------------------------
  Gui, PopUpMenu500:Add, Picture, x0  y0   w200 h250 vG_GuiLoad, 
  ; -------------------------------------------
  Gui, PopUpMenu500:+LastFound -Caption +AlwaysOnTop +ToolWindow -Border ; Gui Start (AlwaysOnTop)
  Gui, PopUpMenu500:Color, 562958 ; Good Color For Pum Guy 
  WinSet, TransColor, 562958
  ; -------------------------------------------
  Gui, PopUpMenu500:Show, , PopUpMenu500
  ; -------------------------------------------
  SetTimer, PopUpMenuLabel500, 50
  ; -------------------------------------------
  return
  ; -------------------------------------------
  ; Gui
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; Labels
  ; -------------------------------------------
  PopUpMenuLabel500:
  {
  	; -------------------------------------------
    if (A_TickCount > BreakTime)
    {
			; -------------------------------------------
      SetTimer, PopUpMenuLabel500, Off
      ExitApp
			; -------------------------------------------
    }
    ; -------------------------------------------
	  ;
	  ; -------------------------------------------
	  if (GuiLoadNum < 23)
    {
    	GuiLoadNum := GuiLoadNum + 1
  	  ThisImage := ImagePath "\(500)_" GuiLoadNum ".png"
  	  GuiControl, PopUpMenu500:, G_GuiLoad, %ThisImage%
		  if (GuiLoadNum > 13)
		  {
  			; -------------------------------------------
			  SetTimer, PopUpMenuLabel500, 100
			  if (GuiLoadNum == 23)
			  {
  				SetTimer, PopUpMenuLabel500, 500
			  }
			  ; -------------------------------------------
		  } ; if (GuiLoadNum > 13)
    } ; Loop 23
	  ; -------------------------------------------
  } ; PopUpMenuLabel500:
  return
  ; -------------------------------------------
  ; Labels
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
} ; if !WinExist("PopUpMenu501" . "ahk_exe AutoHotkey.exe") ; (There was a Update)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
