﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
#NoTrayIcon
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
;
; This is the Update Script
; This Script is only ran is User Has Admin Rights
;
; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\Array_Add.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Array_FromFile.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Email_Send.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Folder_SetIcon.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Url_ConnectCheck.ahk
; -------------------------------------------
#Include %A_ProgramFiles%\PopUpMenu_PUM\File_UnZip.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Folder_WindowsUser.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Splash_Script.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Functions
; -------------------------------------------
CheckForUpdate(domain_update, TypeArray, ReturnEmailArray) ; > ReturnEmailArray
{
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  ; TypeArray.1 =  ("pum" or "addon")
  ; TypeArray.2 =  ("AddonProcess")
  ; TypeArray.3 =  ("AddonLang")
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  ;
  ; -------------------------------------------
  if (ReturnEmailArray == "")
  {
    ReturnEmailArray := []
  }
  ; -------------------------------------------
  NewUpdate := 0
  ; -------------------------------------------
  UpdateType := TypeArray.1
  ; -------------------------------------------
  if (UpdateType == "addon")
  {
    ; -------------------------------------------
    AddonProcess := TypeArray.2
    AddonLang    := TypeArray.3
    ; -------------------------------------------
    UpdateZipType := AddonProcess "_" AddonLang
  }
  else
  {
    UpdateZipType := UpdateType
  }
  ; -------------------------------------------
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; StartUp Vars
  ; -------------------------------------------
  StringLower, UpdateType, UpdateType
  ; -------------------------------------------
  ; StartUp Vars
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; Folder Check (\update\downloadedzip) (\update\link) (\update\unzippedzip)
  ; -------------------------------------------
  CheckFolder_1 := A_ProgramFiles "\PopUpMenu_PUM\update\downloadedzip"
  if !FileExist(CheckFolder_1)
  {
    FileCreateDir, %CheckFolder_1%
    Sleep, 10
  }
  CheckFolder_2 := A_ProgramFiles "\PopUpMenu_PUM\update\link"
  if !FileExist(CheckFolder_2)
  {
    FileCreateDir, %CheckFolder_2%
    Sleep, 10
  }
  CheckFolder_3 := A_ProgramFiles "\PopUpMenu_PUM\update\unzippedzip"
  if !FileExist(CheckFolder_3)
  {
    FileCreateDir, %CheckFolder_3%
    Sleep, 10
  }
  ; -------------------------------------------
  ; Folder Check (\update\downloadedzip) (\update\link) (\update\unzippedzip)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; SET (Url_FileUpdateCurrentTxt) and (Pc_FileUpdateLastTxt)
  ; -------------------------------------------
  if (UpdateType == "addon")
  {
    ; -------------------------------------------
    Url_FileUpdateCurrentTxt := domain_update "/update/current_" AddonProcess "_" AddonLang ".txt"
    Pc_FileUpdateCurrentTxt  := A_ProgramFiles "\PopUpMenu_PUM\menu\mnu\" AddonProcess "\" AddonLang "\update\current_" AddonProcess "_" AddonLang ".txt"
    ; -------------------------------------------
  } ; [End] if (UpdateType == "addon")
  else ; UpdateType Would = ("pum" or "icons")
  {
    ; -------------------------------------------
    Url_FileUpdateCurrentTxt := domain_update "/update/current_" UpdateType ".txt"
    Pc_FileUpdateCurrentTxt  := A_ProgramFiles "\PopUpMenu_PUM\update\current_" UpdateType ".txt"
    ; -------------------------------------------
  } ; [End] else ; UpdateType Would = ("pum" or "icons")
  ; -------------------------------------------
  ; SET (Url_FileUpdateCurrentTxt) and (Pc_FileUpdateLastTxt)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; Download Current Update (Pc_FileUpdateCurrentTxt)
  ; -------------------------------------------
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (_12_Nov_2022_)(_21:38:38_)
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  ; -------------------------------------------
  ; OLD
  ; Downloaded_OK := DownloadFile(Url_FileUpdateCurrentTxt, Pc_FileUpdateCurrentTxt) ; ThisUrl, ThisFile > Downloaded_OK [0/1]
  ; -------------------------------------------
  ; New
  Downloaded_OK := Url_Download(Url_FileUpdateCurrentTxt, Pc_FileUpdateCurrentTxt) ; ThisUrl, ThisFile > Downloaded_OK [0/1]
  ; -------------------------------------------
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (_12_Nov_2022_)(_21:38:38_)
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  ; -------------------------------------------
  ; Download Current Update (Pc_FileUpdateCurrentTxt)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; Check if the file was Download was Ok
  ; -------------------------------------------
  if (Downloaded_OK == 1) ; (Pc_FileUpdateCurrentTxt) [Downloaded OK]
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; Set (Pc_FileUpdateLastTxt)
    ; -------------------------------------------
    if (UpdateType == "addon")
    {
      ; -------------------------------------------
      Pc_FileUpdateLastTxt := A_ProgramFiles "\PopUpMenu_PUM\menu\mnu\" AddonProcess "\" AddonLang "\update\last_" AddonProcess "_" AddonLang ".txt"
      ; -------------------------------------------
    } ; [End] if (UpdateType == "addon")
    else ; UpdateType Would = ("pum" or "icons")
    {
      ; -------------------------------------------
      Pc_FileUpdateLastTxt := A_ProgramFiles "\PopUpMenu_PUM\update\last_" UpdateType ".txt"
      ; -------------------------------------------
    } ; [End] else ; UpdateType Would = ("pum" or "icons")
    ; -------------------------------------------
    ; Set (Pc_FileUpdateLastTxt)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; if (Pc_FileUpdateLastTxt) Does Not exist,
    ; Create one Starting at (Update 0)
    ; -------------------------------------------
    if !FileExist(Pc_FileUpdateLastTxt)
    {
      FileAppend, 0`n, %Pc_FileUpdateLastTxt%, UTF-8
    } ; End !FileExist(Pc_TxtFile_LastUpdate)
    ; -------------------------------------------
    ; if (Pc_FileUpdateLastTxt) Does Not exist,
    ; Create one Starting at (Update 0)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; SET ABOVE (Pc_FileUpdateCurrentTxt)
    ; Read (Pc_FileUpdateCurrentTxt) Set (CurrentUpdate)
    ; Read (Pc_FileUpdateLastTxt) Set (LastUpdate)
    ; -------------------------------------------
    CurrentUpdate := ""
    LastUpdate := ""
    ; -------------------------------------------
    FileReadLine, CurrentUpdate, %Pc_FileUpdateCurrentTxt%, 1
    FileReadLine, LastUpdate, %Pc_FileUpdateLastTxt%, 1
    ; -------------------------------------------
    OrgUpdate := LastUpdate
    ; -------------------------------------------
    ;
    ;
    ; -------------------------------------------
    ; SET ABOVE (Pc_FileUpdateCurrentTxt)
    ; Read (Pc_FileUpdateCurrentTxt) Set (CurrentUpdate)
    ; Read (Pc_FileUpdateLastTxt) Set (LastUpdate)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; Check if (CurrentUpdate) is Greater tham (LastUpdate)
    ; This would mean Program is Not Up To Date
    ; Display (501_1)(Splash Anamated: PopUpMenu Updating)
    ; -------------------------------------------
    if (CurrentUpdate > LastUpdate) ; Splash Image
    {
      
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      Splash_Script("501", 0) ; (501)(Splash Anamated: PopUpMenu Updating)
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    } ; (CurrentUpdate > LastUpdate) ; Splash Image
    ; -------------------------------------------
    ; Check if (CurrentUpdate) is Greater tham (LastUpdate)
    ; This would mean Program is Not Up To Date
    ; Display (501_1)(Splash Anamated: PopUpMenu Updating)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; WHILE LOOP (CurrentUpdate) is Greater tham (LastUpdate)
    ; -------------------------------------------
    while (CurrentUpdate > LastUpdate) ; while there is a Update
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; ThisUpdate is a (Temp Value) Until Zip is Downloaded Ok and Unzipped
      ; -------------------------------------------
      ThisUpdate := LastUpdate + 1
      ; -------------------------------------------
      ; ThisUpdate is a (Temp Value) Until Zip is Downloaded Ok and Unzipped
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; ThisUpdate Link to Zip file
      ; (update_1_pum.zip)
      ; 
      UpdateDownloadLink  := domain_update "/files/update_" ThisUpdate "_" UpdateZipType ".zip"
      UpdateDownloadedZip := A_ProgramFiles "\PopUpMenu_PUM\update\downloadedzip\update.zip"
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;  Download (UpdateDownloadLink) to (UpdateDownloadedZip)
      ; -------------------------------------------
      Downloaded_OK := DownloadFile(UpdateDownloadLink, UpdateDownloadedZip) ; ThisUrl, ThisFile > File Downloaded OK [0/1]
      ; -------------------------------------------
      ;  Download (UpdateDownloadLink) to (UpdateDownloadedZip)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      if (Downloaded_OK == 1) ; (UpdateDownloadedZip) [Downloaded OK] > [UnZip] / (Update Zip File)
      {
        ; -------------------------------------------
        ; SET ABOVE
        ; UpdateDownloadedZip := A_ProgramFiles "\PopUpMenu_PUM\update\downloadedzip\update.zip"
        ; -------------------------------------------
        Pc_FolderUnzipped  := A_ProgramFiles "\PopUpMenu_PUM\update\unzippedzip"
        ; -------------------------------------------
        File_UnZip(UpdateDownloadedZip, Pc_FolderUnzipped) ; ZipFile, UnZipDir
        ; -------------------------------------------
        Sleep, 500
        ; -------------------------------------------
        ;
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [Move] Unziped "\Icons" Folder
        if (UpdateType == "icons")
        {
          ; -------------------------------------------
          Pc_FolderUnzipped_Pictures := A_ProgramFiles "\PopUpMenu_PUM\update\unzippedzip\Icons"
          ; -------------------------------------------
          if FileExist(Pc_FolderUnzipped_Pictures) ; Unzipped Folder Exist
          {
            ; -------------------------------------------
            MoveThis := Pc_FolderUnzipped_Pictures
            RegRead, MoveHere, HKEY_CURRENT_USER, Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders, My Pictures
            ; -------------------------------------------
            if FileExist(MoveHere) ; Program Folder Exist
            {
              ; -------------------------------------------
              FileMoveDir, %MoveThis%, %MoveHere% , 2 ; Move and Overwrite
              ; -------------------------------------------
              ; For Slow Machines
              ; -------------------------------------------
              MoveThisAnyFile := MoveThis "\*.*"
              BreakTime := A_TickCount + 7000
              while FileExist(MoveThisAnyFile)
              {
                if (A_TickCount > BreakTime)
                {
                  break
                }
              }
              ; -------------------------------------------
              Sleep, 500
              ; -------------------------------------------
            } ; End FileExist(MoveHere)
            ; -------------------------------------------
          } ; End Check if Folder Exist
          ; -------------------------------------------
        } ; [End] if (UpdateType == "icons")
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [Move] Unziped "\Icons" Folder
        ;
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [Move] Unziped "\Addon\PopUpMenu_PUM\menu"
        if (UpdateType == "addon")
        {
          ; -------------------------------------------
          Pc_FolderUnzipped_Addon := A_ProgramFiles "\PopUpMenu_PUM\update\unzippedzip\Addon"
          ; -------------------------------------------
          if FileExist(Pc_FolderUnzipped_Addon) ; Unzipped Folder Exist
          {
            ; -------------------------------------------
            MoveThis := Pc_FolderUnzipped_Addon
            MoveHere := A_ProgramFiles
            ; -------------------------------------------
            if FileExist(MoveHere) ; Program Folder Exist
            {
              ; -------------------------------------------
              FileMoveDir, %MoveThis%, %MoveHere% , 2 ; Move and Overwrite
              ; -------------------------------------------
              ; For Slow Machines
              ; -------------------------------------------
              MoveThisAnyFile := MoveThis "\*.*"
              BreakTime := A_TickCount + 7000
              while FileExist(MoveThisAnyFile)
              {
                if (A_TickCount > BreakTime)
                {
                  break
                }
              }
              ; -------------------------------------------
              Sleep, 500
              ; -------------------------------------------
            } ; End FileExist(MoveHere)
            ; -------------------------------------------
          } ; End Check if Folder Exist
          ; -------------------------------------------
        } ; [End] if (UpdateType == "addon")
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [Move] Unziped "\Addon\PopUpMenu_PUM\menu"
        ;
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [Move] Unziped "Program\PopUpMenu_PUM"
        if (UpdateType == "pum")
        {
          ; -------------------------------------------
          Pc_FolderUnzipped_Pum := A_ProgramFiles "\PopUpMenu_PUM\update\unzippedzip\Program"
          ; -------------------------------------------
          if FileExist(Pc_FolderUnzipped_Pum) ; Unzipped Folder Exist
          {
            ; -------------------------------------------
            MoveThis := Pc_FolderUnzipped_Pum
            MoveHere := A_ProgramFiles
            ; -------------------------------------------
            if FileExist(MoveHere) ; Program Folder Exist
            {
              ; -------------------------------------------
              FileMoveDir, %MoveThis%, %MoveHere% , 2 ; Move and Overwrite
              ; -------------------------------------------
              ; For Slow Machines
              ; -------------------------------------------
              MoveThisAnyFile := MoveThis "\*.*"
              BreakTime := A_TickCount + 7000
              while FileExist(MoveThisAnyFile)
              {
                if (A_TickCount > BreakTime)
                {
                  break
                }
              }
              ; -------------------------------------------
              Sleep, 500
              ; -------------------------------------------
            } ; End FileExist(MoveHere_1)
            ; -------------------------------------------
          } ; End Check if Folder Exist
          ; -------------------------------------------
        } ; [End] if (UpdateType == "pum")
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [Move] Unziped "Program\PopUpMenu_PUM"
        ;
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ; Update was Download OK and Unzipped
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ;
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ; Add One Number to (LastUpdate)
        ; -------------------------------------------
        LastUpdate := LastUpdate + 1
        ; -------------------------------------------
        ; Add One Number to (LastUpdate)
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ;
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ; Delete Old (Pc_FileUpdateLastTxt)
        ; -------------------------------------------
        ; Set ABOVE (Pc_FileUpdateLastTxt)
        if FileExist(Pc_FileUpdateLastTxt)
        {
          FileDelete, %Pc_FileUpdateLastTxt%
          Sleep, 100
        }
        ; -------------------------------------------
        ; Delete Old (Pc_FileUpdateLastTxt)
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ;
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ; Delete Old (UpdateDownloadedZip)
        ; -------------------------------------------
        ; SET ABOVE (UpdateDownloadedZip)
        if FileExist(UpdateDownloadedZip)
        {
          FileDelete, %UpdateDownloadedZip%
          Sleep, 100
        }
        ; -------------------------------------------
        ; Delete Old (UpdateDownloadedZip)
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ;
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ; Recreate (Pc_FileUpdateLastTxt) with new (LastUpdate)
        ; -------------------------------------------
        ; Set ABOVE (Pc_FileUpdateLastTxt)
        FileAppend, %LastUpdate%, %Pc_FileUpdateLastTxt%, UTF-8
        ; -------------------------------------------
        ; Recreate (Pc_FileUpdateLastTxt) with new (LastUpdate)
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ;
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ; Set (ThisEmailUpdate)
        ; Add (ThisEmailUpdate) to (ReturnEmailArray)
        ; (ReturnEmailArray) is returned at end of this function
        ; -------------------------------------------
        if (UpdateType == "addon")
        {
          ; -------------------------------------------
          AddonUpdateType := AddonProcess "_" AddonLang
          ThisEmailUpdate := [AddonUpdateType, OrgUpdate, ThisUpdate]
          ; -------------------------------------------
        } ; [End] if (UpdateType == "addon")
        else ; UpdateType Would = ("pum" or "icons")
        {
          ; -------------------------------------------
          ThisEmailUpdate := [UpdateType, OrgUpdate, ThisUpdate]
          ; -------------------------------------------
        } ; [End] else ; UpdateType Would = ("pum" or "icons")
        ; -------------------------------------------
        NewUpdate := 1
        ; -------------------------------------------
        ReturnEmailArray.Push(ThisEmailUpdate)
        ; -------------------------------------------
        ; Set (ThisEmailUpdate)
        ; Add (ThisEmailUpdate) to (ReturnEmailArray)
        ; (ReturnEmailArray) is returned at end of this function
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      } ; [End] if (Downloaded_OK == 1) ; (Update Zip File) [Downloaded OK] > [UnZip] / (Update Zip File)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      else ; (Downloaded_OK DOES NOT = 1) (UpdateDownloadedZip) [Downloaded FAILED]
      {
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ; Delete Old (UpdateDownloadedZip)
        ; -------------------------------------------
        ; SET ABOVE (UpdateDownloadedZip)
        if FileExist(UpdateDownloadedZip)
        {
          ; -------------------------------------------
          ; SET ABOVE (UpdateDownloadedZip)
          if FileExist(UpdateDownloadedZip)
          {
            FileDelete, %UpdateDownloadedZip%
            Sleep, 100
          }
          ; -------------------------------------------
        } ; [End] if FileExist(UpdateDownloadedZip)
        ; -------------------------------------------
        ; Delete Old (UpdateDownloadedZip)
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ;
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ; Break out of (while (CurrentUpdate > LastUpdate)) Loop
        ; -------------------------------------------
        break
        ; -------------------------------------------
        ; Break out of (while (CurrentUpdate > LastUpdate)) Loop
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      } ; [End] else ; (Downloaded_OK DOES NOT = 1) (UpdateDownloadedZip) [Downloaded FAILED]
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    } ; [End] while (CurrentUpdate > LastUpdate) ; while there is a Update
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; All Updates have finished
    ; Delete (Pc_FileUpdateCurrentTxt)
    ; -------------------------------------------
    if FileExist(Pc_FileUpdateCurrentTxt)
    {
      FileDelete, %Pc_FileUpdateCurrentTxt%
      Sleep, 100
    }
    ; -------------------------------------------
    ; All Updates have finished
    ; Delete (Pc_FileUpdateCurrentTxt)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  } ; End  ; (Current Update File) [Downloaded OK] > [Read] (Last Update File)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  else ; (Pc_FileUpdateCurrentTxt) [Downloaded FAILED]
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; Delete Old (Pc_FileUpdateCurrentTxt)
    ; -------------------------------------------
    if FileExist(Pc_FileUpdateCurrentTxt)
    {
      ; -------------------------------------------
      ; SET ABOVE (Pc_FileUpdateCurrentTxt)
      if FileExist(Pc_FileUpdateCurrentTxt)
      {
        FileDelete, %Pc_FileUpdateCurrentTxt%
        Sleep, 100
      }
      ; -------------------------------------------
    }
    ; -------------------------------------------
    ; Delete Old (Pc_FileUpdateCurrentTxt)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  } ; End (Current Update File) [Downloaded FAILED] > [Delete] (Current Update File)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (NewUpdate == 0)
  {
    ReturnEmailArray := 0
  }
  ; -------------------------------------------
  return ReturnEmailArray
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
} ; End CheckForUpdate (TypeArray, ReturnEmailArray) ; > ReturnEmailArray
; -------------------------------------------
DownloadFile(ThisUrl, ThisFile) ; > (0 = NOT Downloaded, 1 = Download OK)
{
  ; -------------------------------------------
  FileOK := 1
  ; -------------------------------------------
  UrlDownloadToFile, %ThisUrl%, %ThisFile%
  ; -------------------------------------------
  if ErrorLevel
  {
    FileOK := 0
  }
  ; -------------------------------------------
  if (FileOK == 1)
  {
    if FileExist(ThisFile)
    {
      ; -------------------------------------------
      ThisFileArray := Array_FromFile(ThisFile) ; > Array
      ; -------------------------------------------
      for Index, ThisLine in ThisFileArray
      {
        ; -------------------------------------------
        StringLower, ThisLine, ThisLine
        ; -------------------------------------------
        if (InStr(ThisLine, "html>") > 0) ; (Line 1 Github 404 page) <!DOCTYPE html>
        {
          ; -------------------------------------------
          FileOK := 0
          if FileExist(ThisFile)
          {
            FileDelete, %ThisFile%
            Sleep, 100
          }
          ; -------------------------------------------
          break
          ; -------------------------------------------
        } ; [End] if (InStr(ThisLine, "doctype") > 0 && InStr(ThisLine, "html>") > 0) ; (Line 1 Github 404 page) <!DOCTYPE html>
        ; -------------------------------------------
      } ; [End] for Index, ThisLine in ThisFileArray
    } ; [End] if FileExist(ThisFile)
    else
    {
      ; -------------------------------------------
      FileOK := 0
      ; -------------------------------------------
    }
  }
  ; -------------------------------------------
	return FileOK
  ; -------------------------------------------
} ; [End] Url_Download(ThisUrl, ThisFile)
; -------------------------------------------
Url_Download(ThisUrl, ThisFile) ; ThisUrl, ThisFile > File Downloaded OK [0/1]
{
  ; -------------------------------------------
  FileOk := 1
  ; -------------------------------------------
	static Var1 := false
  ; -------------------------------------------
  try ; Test Code 1
  {
    ; -------------------------------------------
    global ReqVar := ComObjCreate("WinHttp.WinHttpRequest.5.1")
    ; -------------------------------------------
	  if(!Var1 || ReqVar.option(1) != ThisUrl)
    {
      ; -------------------------------------------
  		ReqVar.open("GET", ThisUrl)
      ; -------------------------------------------
    } ; [End] if(!Var1 || ReqVar.option(1) != ThisUrl)
    ; -------------------------------------------
    ReqVar.send()
    ; -------------------------------------------
  } ; [End] try ; Test Code 1
  catch e ; Had Error Next Try
  {
    ; -------------------------------------------
    try ; Test Code 2
    {
      ; -------------------------------------------
      global ReqVar := ComObjCreate("MSXML2.XMLHTTP.6.0")
      ; -------------------------------------------
	    if(!Var1 || ReqVar.option(1) != ThisUrl)
      {
    		ReqVar.open("GET", ThisUrl)
      } ; [End] if(!Var1 || ReqVar.option(1) != ThisUrl)
      ; -------------------------------------------
      ReqVar.send()
      ; -------------------------------------------
    } ; [End] try ; Test Code 2
    catch e ; [SET] FileOk := 0 (will return)
    {
      ; -------------------------------------------
      FileOk := 0
      ; -------------------------------------------
      try ; Test Code 3
      {
        FileEncoding, UTF-8
        URLDownloadToFile, %ThisUrl%, %ThisFile%
      } ; [End] try ; Test Code 3
    } ; [End] catch e ; Error 2
  } ; [End] catch e ; Had Error Next Try
  ; -------------------------------------------
  if (FileOk == 0)
  {
    return FileOk
  }
  ; -------------------------------------------
  LastChr := SubStr(ThisUrl, StrLen(ThisUrl))
  if (LastChr == "/")
  {
    Sleep, 500
  }
  ; -------------------------------------------
  ; (_18_Oct_2022_)(_13:56:44_)
  ; Remarked Out due to error
  ; See Image 
  ; D:\(_Installed_)\(_PopUpMenu_)\((_Errors_)\(Url_Download)_Error.png
  ;
	;~ if (ReqVar.ResponseText == "failed" || ReqVar.Status != 200 || ComObjType(ReqVar.ResponseStream) != 0xd)
	if (ReqVar.Status != 200 || ComObjType(ReqVar.ResponseStream) != 0xd)
  {
    FileOk := 0
		return FileOk
  }
  ; -------------------------------------------
	ReqStreamVar := ComObjQuery(ReqVar.ResponseStream, "{0000000c-0000-0000-C000-000000000046}")
  ; -------------------------------------------
	FileOpenVar := FileOpen(ThisFile, "w")
	Loop
  {
		VarSetCapacity(VarSetCap, 8192)
		Var1 := DllCall(NumGet(NumGet(ReqStreamVar + 0) + 3 * A_PtrSize), ptr, ReqStreamVar, ptr, &VarSetCap, uint, 8192, "ptr*", VarUntil)
		FileOpenVar.rawwrite(&VarSetCap, VarUntil)
	} until (VarUntil == 0)
	FileOpenVar.Close()
  ; -------------------------------------------
  ObjRelease(ReqStreamVar)
  ; -------------------------------------------
  global ReqVar := ""
  ; -------------------------------------------
	return FileOk
  ; -------------------------------------------
}
; -------------------------------------------
; Functions
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; [PopUpMenu FOLDER] [UNINSTALL LINK CHECK] AdMin Reqired
; -------------------------------------------
if (UserLang == "de") ; Link Description (PopUpMenuDesc) (UninstallDesc)
{
  UninstallDesc := "Deinstallieren Sie Popupmenu"
}
; -------------------------------------------
if (UserLang == "en") ; Link Description (PopUpMenuDesc) (UninstallDesc)
{
  UninstallDesc := "Uninstall PopUpMenu"
}
; -------------------------------------------
if (UserLang == "es") ; Link Description (PopUpMenuDesc) (UninstallDesc)
{
  UninstallDesc := "Desinstalar PopUpMenu"
}
; -------------------------------------------
if (UserLang == "fr") ; Link Description (PopUpMenuDesc) (UninstallDesc)
{
  UninstallDesc := "Désinstallez PopUpMenu"
}
; -------------------------------------------
if (UserLang == "it") ; Link Description (PopUpMenuDesc) (UninstallDesc)
{
  UninstallDesc := "Disinstallare PopUpMenu"
}
; -------------------------------------------
if (UserLang == "pl") ; Link Description (PopUpMenuDesc) (UninstallDesc)
{
  UninstallDesc := "Odinstaluj PopUpMenu"
}
; -------------------------------------------
if (UserLang == "pt") ; Link Description (PopUpMenuDesc) (UninstallDesc)
{
  UninstallDesc := "Desinstalar PopUpMenu"
}
; -------------------------------------------
if (UserLang == "ru") ; Link Description (PopUpMenuDesc) (UninstallDesc)
{
  UninstallDesc := "Удалите PopUpMenu"
}
; -------------------------------------------
if (UserLang == "sv") ; Link Description (PopUpMenuDesc) (UninstallDesc)
{
  UninstallDesc := "Avinstallera PopUpMenu"
}
; -------------------------------------------
if (UserLang == "tr") ; Link Description (PopUpMenuDesc) (UninstallDesc)
{
  UninstallDesc := "PopUpMenu'yu kaldir"
}
; -------------------------------------------
UninstallLink   := A_ProgramFiles "\PopUpMenu_PUM\Uninstall.lnk"
if !FileExist(UninstallLink)
{
  UninstallTarget := A_ProgramFiles "\PopUpMenu_PUM\Splash_600.ahk"
  UninstallIcon   := A_ProgramFiles "\PopUpMenu_PUM\image\ico\uninstall.ico"
  FileCreateShortcut, %UninstallTarget%, %UninstallLink%, , , %UninstallDesc%, %UninstallIcon%
}
; -------------------------------------------
; [PopUpMenu FOLDER] [UNINSTALL LINK CHECK] AdMin Reqired
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Get All Working Pums (PumsArray) File Name Only, No Folder or Ext
; -------------------------------------------
PumsArray := ""
; -------------------------------------------
Folder_PumsCommon := A_AppData "\PopUpMenu_PUM\pums"
Loop, Files, %Folder_PumsCommon%\*.exe, R
{
  ; -------------------------------------------
  PumPath := A_LoopFileFullPath
  ; -------------------------------------------
  SplitPath, PumPath, Pum_ExtName, Pum_Folder, Pum_Ext, Pum_Name
  ; -------------------------------------------
  PumsArray := Array_Add(PumsArray, Pum_Name, "End") ; ThisArray, AddThis, ThisPos > ThisArray
  ; -------------------------------------------
} ; [End] Loop, Files, %Folder_PumsCommon%\*.exe, R
; -------------------------------------------
; Get All Working Pums (PumsArray) File Name Only, No Folder or Ext
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Delete Unwanted Files, (Extra Xml)(*.icl)(*.dwl)(*.dwl2)(*.dwl3)
for Index, ThisPum in PumsArray ; Delete Extra Xml files
{
  ; -------------------------------------------
  Folder_PumSpecific := Folder_PumsCommon "\" ThisPum
  Folder_PumSystem := Folder_PumSpecific "\system"
  ; -------------------------------------------
  Icl_Files := Folder_PumSpecific "\*.icl" ; (361_8)(Folder_PumSpecific [Pum Folder Path])
  if FileExist(Icl_Files)
  {
    FileDelete, %Icl_Files%
    Sleep, 100
  }
  ; -------------------------------------------
  Dwl_Files := Folder_PumSpecific "\*.dwl" ; (361_8)(Folder_PumSpecific [Pum Folder Path])
  if FileExist(Dwl_Files)
  {
    FileDelete, %Dwl_Files%
    Sleep, 100
  }
  ; -------------------------------------------
  Dwl_Files2 := Folder_PumSpecific "\*.dwl2" ; (361_8)(Folder_PumSpecific [Pum Folder Path])
  if FileExist(Dwl_Files2)
  {
    FileDelete, %Dwl_Files2%
    Sleep, 100
  }
  ; -------------------------------------------
  Dwl_Files3 := Folder_PumSpecific "\*.dwl3" ; (361_8)(Folder_PumSpecific [Pum Folder Path])
  if FileExist(Dwl_Files3)
  {
    FileDelete, %Dwl_Files3%
    Sleep, 100
  }
  ; -------------------------------------------
  Num := 1
  Loop 9
  {
    ErrorXml :=  Folder_PumSystem "\toolbox" Num "*.xml"
    if FileExist(ErrorXml)
    {
      FileDelete, %ErrorXml%
      Sleep, 100
    }
    Num := Num + 1
  } ; [End] Loop 9
  ; -------------------------------------------
} ; [End] for Index, This_Pum in PumsArray ; Delete Extra Xml files
; -------------------------------------------
; Delete Unwanted Files, (Extra Xml)(*.icl)(*.dwl)(*.dwl2)(*.dwl3)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Check if There ia a Internet Connection
; -------------------------------------------
flag=0x40
HasConnection := DllCall("Wininet.dll\InternetGetConnectedState", "Str", flag,"Int",0)
; -------------------------------------------
; Check if There ia a Internet Connection
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
if (HasConnection == 1) ; Internet Connection OK
{
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; Get List of Current Addons
  ; currentaddons.txt
  ; -------------------------------------------
  Url_CurrentAddons  := "https://midnightitsalmost.github.io/system/currentaddons.txt"
  File_CurrentAddons := A_ProgramFiles "\PopUpMenu_PUM\update\currentaddons.txt"
  ; -------------------------------------------
  ;
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (_12_Nov_2022_)(_21:39:56_)
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  ; Old
  ; DownloadFile(Url_CurrentAddons, File_CurrentAddons) ; ThisUrl, ThisFile > Downloaded_OK [0/1]
  ; -------------------------------------------
  ; New
  Url_Download(Url_CurrentAddons, File_CurrentAddons) ; ThisUrl, ThisFile > Downloaded_OK [0/1]
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (_12_Nov_2022_)(_21:39:56_)
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  ;
  ; -------------------------------------------
  ; Get List of Current Addons
  ; currentaddons.txt
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; Get Current PopUpMenu Web Site Domain
  ; domain_popupmenusite.txt
  ; -------------------------------------------
  Url_PopupmenuSiteDomain  := "https://midnightitsalmost.github.io/system/domain_popupmenusite.txt"
  File_PopupmenuSiteDomain := A_ProgramFiles "\PopUpMenu_PUM\update\domain_popupmenusite.txt"
  ; -------------------------------------------
  ;
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (_12_Nov_2022_)(_21:39:56_)
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  ; Old
  ; DownloadFile(Url_PopupmenuSiteDomain, File_PopupmenuSiteDomain) ; ThisUrl, ThisFile > Downloaded_OK [0/1]
  ; -------------------------------------------
  ; New
  Url_Download(Url_PopupmenuSiteDomain, File_PopupmenuSiteDomain) ; ThisUrl, ThisFile > Downloaded_OK [0/1]
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (_12_Nov_2022_)(_21:39:56_)
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  ;
  ; -------------------------------------------
  ; Get List of Current Addons
  ; currentaddons.txt
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; -------------------------------------------
  ; Get Current PopUpMenu Web Site Domain
  ; domain_popupmenusite.txt
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; Download domain_update.txt
  ; -------------------------------------------
  Url_domain_update  := "https://midnightitsalmost.github.io/system/domain_update.txt"
  File_domain_update := A_ProgramFiles "\PopUpMenu_PUM\update\domain_update.txt"
  ; -------------------------------------------
  ;
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (_12_Nov_2022_)(_21:39:56_)
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  ; Old
  ; Downloaded_OK := DownloadFile(Url_domain_update, File_domain_update) ; ThisUrl, ThisFile > Downloaded_OK [0/1]
  ; -------------------------------------------
  ; New
  Downloaded_OK := Url_Download(Url_domain_update, File_domain_update) ; ThisUrl, ThisFile > Downloaded_OK [0/1]
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (_12_Nov_2022_)(_21:39:56_)
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  ;
  ; -------------------------------------------
  ; Download domain_update.txt
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (Downloaded_OK == 1) ; domain_update.txt
  {
    ; -------------------------------------------
    if FileExist(File_domain_update)
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; Get (DomainUpdate) from domain_update.txt
      ; -------------------------------------------
      FileReadLine, DomainUpdate, %File_domain_update%, 1
      ;
      FileDelete, %File_domain_update%
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; Check for updates (PopUpMenu Main Program)
      ; -------------------------------------------
      TypeArray := ["pum", "", ""]
      CheckEmailUpdateArray := CheckForUpdate(DomainUpdate, TypeArray, "")
      if (CheckEmailUpdateArray != 0)
      {
        EmailUpdateArray := CheckEmailUpdateArray
      }
      ; -------------------------------------------
      ; Check for updates (PopUpMenu Main Program)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; Check for updates (PopUpMenu Pictures)
      ; -------------------------------------------
      TypeArray := ["icons", "", ""]
      CheckEmailUpdateArray := CheckForUpdate(DomainUpdate, TypeArray, EmailUpdateArray)
      if (CheckEmailUpdateArray != 0)
      {
        EmailUpdateArray := CheckEmailUpdateArray
        CheckEmailUpdateArray := ""
      }
      ; -------------------------------------------
      ; Check for updates (PopUpMenu Pictures)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; Check for updates (Installed Addons)
      ; -------------------------------------------
      Path_Addons  := A_ProgramFiles "\PopUpMenu_PUM\menu\mnu"
      ; -------------------------------------------
      Loop, Files, %Path_Addons%\*, D ; [Get] AddonProcess
      {
        ; TypeArray := ["addon", AddonProcess, AddonLang]
        ; -------------------------------------------
        AddonProcess := A_LoopFileName
        ; -------------------------------------------
        Path_AddonProcess := Path_Addons "\" AddonProcess
        Loop, Files, %Path_AddonProcess%\*, D ; AddonProcess "\" [Get] AddonLang
        {
          ; -------------------------------------------
          AddonLang := A_LoopFileName
          ; -------------------------------------------
          ;
          ; -------------------------------------------
          TypeArray := ["addon", AddonProcess, AddonLang]
          CheckEmailUpdateArray := CheckForUpdate(DomainUpdate, TypeArray, EmailUpdateArray)
          ; -------------------------------------------
          if (CheckEmailUpdateArray != 0)
          {
            EmailUpdateArray := CheckEmailUpdateArray
            CheckEmailUpdateArray := ""
          }
          ; -------------------------------------------
        } ; [End] Loop, Files, %Path_AddonProcess%\*, D
        ; -------------------------------------------
      } ; [End] Loop, Files, %Path_Addons%\*, D
      ; -------------------------------------------
      ; Check for updates (Installed Addons)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; (EmailUpdateArray)
      ; if there was a Update
      ; to either Main Program, New Icons, or to a Installed Addon
      ; Then send a Email about each Update
      ; -------------------------------------------
      EmailUpdateArrayLen := EmailUpdateArray.MaxIndex()
      ; -------------------------------------------
      if (EmailUpdateArrayLen == "")
      {
        EmailUpdateArrayLen := 0
      }
      ; -------------------------------------------
      if (EmailUpdateArrayLen > 0) ; There was at least 1 update
      {
        ;
        ; -------------------------------------------
        Email_Subject := "(Update)"
        ; -------------------------------------------
        for Index, ThisUpdate in EmailUpdateArray
        {
          ; -------------------------------------------
          ; ThisUpdate = [UpdateType, LastUpdate, ThisUpdate]
          ; -------------------------------------------
          ProductName      := ThisUpdate.1
          Email_OrgUpdate := ThisUpdate.2
          Email_ThisUpdate := ThisUpdate.3
          ; -------------------------------------------
          Email_Body := ""
          Email_Body := Email_Body "----------------------------------`n"
          Email_Body := Email_Body "Product Name : " ProductName "`n"
          Email_Body := Email_Body "Old Version : " Email_OrgUpdate "`n"
          Email_Body := Email_Body "New Version : " Email_ThisUpdate "`n"
        } ; End for Index, This_Update in Array_SendEmailUpdated
        ; -------------------------------------------
        Email_Body := Email_Body "----------------------------------`n"
        ; -------------------------------------------
        Email_Send(Email_Subject, Email_Body)
        ; -------------------------------------------
      } ; End if IsObject(Array_SendEmailUpdated)
      ; -------------------------------------------
    } ; [End] if FileExist(File_domain_update)
    ; -------------------------------------------
  } ; [End] if (Downloaded_OK == 1) ; domain_update.txt
  ; -------------------------------------------
} ; End if (Url_ConnectCheck(flag=0x40) == 1)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; END OF FILE
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
