﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\Folder_WindowsUser.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_ImgToIco.ahk
; -------------------------------------------
#Include %A_ProgramFiles%\PopUpMenu_PUM\Img_RunPng.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_PathFolderOrName.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Img_RunIco(ArrayIn) ; > FileRunIco
{
/*
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
ArrayIn := [DataArray.367.5, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
FileRunIco := Img_RunIco(ArrayIn)
; -------------------------------------------
ArrayIn := [AppProcessPathNameExt, AppProcessName, UseCommonBrowser, UserLang, UserPictureFolder]
FileRunIco := Img_RunIco(ArrayIn)
; -------------------------------------------
ArrayIn := [run_OutTarget, "", "", UserLang, UserPictureFolder]
FileRunIco := Img_RunIco(ArrayIn)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
AppProcessPathNameExt := ArrayIn.1 ; (DataArray.367.5)(AppProcessPathNameExt [Path,Name,Ext])
AppProcessName        := ArrayIn.2 ; (DataArray.367.1)(AppProcessName [Name][LowerCase][NoSpace])
UseCommonBrowser      := ArrayIn.3 ; (DataArray.290.2 = 2 [UseCommonBrowser = 2][Each Browser Different pum])(DataArray.290.2 = 1 [UseCommonBrowser = 1][All Browsers Same Pum])
UserLang              := ArrayIn.4 ; (DataArray.365.2)(UserLang [Current User language])
UserPictureFolder     := ArrayIn.5 ; (UserPictureFolder)(ThisUserPictureFolder)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
return FileRunIco
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
*/
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; StartUp Vars
  ; -------------------------------------------
  AppProcessPathNameExt := ArrayIn.1 ; (AppProcessPathNameExt)(AppProcessPathNameExt [Path,Name,Ext])
  AppProcessName        := ArrayIn.2 ; (AppProcessName)(AppProcessName [Name][LowerCase][NoSpace])
  UseCommonBrowser      := ArrayIn.3 ; (UseCommonBrowser = 1 [UseCommonBrowser = 2][Each Browser Different pum])(UseCommonBrowser = 0 [UseCommonBrowser = 1][All Browsers Same Pum])
  UserLang              := ArrayIn.4 ; (UserLang)(UserLang [Current User language])
  UserPictureFolder     := ArrayIn.5  ; (UserPictureFolder)(ThisUserPictureFolder)
  ; -------------------------------------------
  ; StartUp Vars
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; if This Value is Blank
  ; -------------------------------------------
  if (UseCommonBrowser == "")
  {
    UseCommonBrowser := 0
  }
  ; -------------------------------------------
  if (UserPictureFolder == "")
  {
    ; -------------------------------------------
    RegRead, UserPictureFolder, HKEY_CURRENT_USER, Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders, My Pictures
    ; -------------------------------------------
  }
  ; -------------------------------------------
  if (AppProcessName == "")
  {
    if (AppProcessPathNameExt != "")
    {
      SplitPath, AppProcessPathNameExt, , , , AppProcessName
    }
  }
  ; -------------------------------------------
  ; if This Value is Blank
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if FileExist(AppProcessPathNameExt) ; Does the App Exist
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ArrayIn    := [AppProcessPathNameExt, AppProcessName, UseCommonBrowser, "FileRunPng", UserLang, UserPictureFolder]
    ArrayOut   := Image_PathFolderOrName(ArrayIn)
    FileRunPng := ArrayOut.1
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ArrayIn      := [AppProcessPathNameExt, AppProcessName, UseCommonBrowser, "FileRunIco", UserLang, UserPictureFolder]
    ArrayOut     := Image_PathFolderOrName(ArrayIn)
    FileRunIco := ArrayOut.1
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [CHECK] [CREATE]
    ; [UserPictureFolder "\(_PopUpMenu_)\(_Application_)\Png\" AppProcessName "_(" AppProcessFolder ").png"]
    ; -------------------------------------------
    if !FileExist(FileRunPng)
    {
      ; -------------------------------------------
      ArrayIn := [AppProcessPathNameExt, AppProcessName, UseCommonBrowser, UserLang, UserPictureFolder]
      FileRunPng := Img_RunPng(ArrayIn)
      ; -------------------------------------------
    } ; [End] if !FileExist(FileRunPng)
    ; -------------------------------------------
    ; [CHECK] [CREATE]
    ; [UserPictureFolder "\(_PopUpMenu_)\(_Application_)\Png\" AppProcessName "_(" AppProcessFolder ").png"]
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [CHECK] [CREATE]
    ; [UserPictureFolder "\(_PopUpMenu_)\(_Application_)\Ico\" AppProcessName "_(" AppProcessFolder ").ico"]
    ; -------------------------------------------
    if !FileExist(FileRunIco)
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; [CONVERT] [UserPictureFolder "\(_PopUpMenu_)\(_Application_)\Png\" AppProcessName "_(" AppProcessFolder ").png"]
      ; [TO ICO]  [UserPictureFolder "\(_PopUpMenu_)\(_Application_)\Ico\" AppProcessName "_(" AppProcessFolder ").ico"]
      ; -------------------------------------------
      Image_ImgToIco(FileRunPng, FileRunIco) ; > ImageOut
      ; -------------------------------------------
      ; [CONVERT] [UserPictureFolder "\(_PopUpMenu_)\(_Application_)\Png\" AppProcessName "_(" AppProcessFolder ").png"]
      ; [TO ICO]  [UserPictureFolder "\(_PopUpMenu_)\(_Application_)\Ico\" AppProcessName "_(" AppProcessFolder ").ico"]
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    } ; [End] if !FileExist(FileRunIco)
    ; -------------------------------------------
    ; [CHECK] [CREATE]
    ; [UserPictureFolder "\(_PopUpMenu_)\(_Application_)\Ico\" AppProcessName "_(" AppProcessFolder ").ico"]
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    return FileRunIco
    ; -------------------------------------------
  } ; [End] if FileExist(AppProcessPathNameExt) ; Does the App Exist
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
