﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\Array_ItemExist.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_GuiControl.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Email_Validate(DataArray) ; > DataArray
{
  ; -------------------------------------------
  if (InStr(DataArray.366.5, "pumContact") > 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
  {
    ; -------------------------------------------
    ImageContent :=  A_ProgramFiles "\PopUpMenu_PUM\image\gui\(187)_Content.png"
    ImageNoContent :=  A_ProgramFiles "\PopUpMenu_PUM\image\gui\(187)_NoContent.png"
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    IsValid := 1
    ; -------------------------------------------
    GuiControlGet, ThisEmail, PopUpMenu:, g_188 ; (188_1)(Obj_Pum_EditFeild_EmailAddress)
    ; -------------------------------------------
    StringLower, Lower_ThisEmail, ThisEmail
    ; -------------------------------------------
    ThisEmailLen := StrLen(Lower_ThisEmail)
    ; -------------------------------------------
    if (ThisEmailLen == 0 or ThisEmailLen == "") ; No Email Address
    {
      IsValid := 0
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (IsValid == 1) ; (ThisEmailLen is NOT 0) or (ThisEmailLen is NOT Blank)
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; Check (First) and (Last) Character
      ; is a Letter or Number
      ; -------------------------------------------
      Array_LetterNumber := ["a", "b", "c", "d", "e", "f", "g", "h","i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0"]
      ; -------------------------------------------
      FirstChr := SubStr(Lower_ThisEmail, 1, 1)
      FirstIsInArray := Array_ItemExist(Array_LetterNumber, FirstChr) ; ThisArray, CheckThis > Number of times in Array
      ; -------------------------------------------
      LastChr := SubStr(Lower_ThisEmail, ThisEmailLen, 1)
      LastIsInArray := Array_ItemExist(Array_LetterNumber, LastChr) ; ThisArray, CheckThis > Number of times in Array
      ; -------------------------------------------
      if (FirstIsInArray == 0 or LastIsInArray == 0) ; Not a Valid Character (First) and (Last) Character
      {
        IsValid := 0
      }
      ; -------------------------------------------
      ; Check (First) and (Last) Character
      ; is a Letter or Number
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    } ; [End] if (IsValid == 1)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (IsValid == 1) ; (First) and (Last) Characters (Are a Number or a Letter)
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; Check All Characters in (Lower_ThisEmail)
      ; are a Letter or Number
      ; -------------------------------------------
      Array_EmailChr := ["a", "b", "c", "d", "e", "f", "g", "h","i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "@", ".", "_", "-"]
      Num := 1
      Loop %ThisEmailLen%
      {
        Chk_This := SubStr(Lower_ThisEmail, Num, 1)
        IsInArray := Array_ItemExist(Array_EmailChr, Chk_This) ; ThisArray, CheckThis > Number of times in Array
        if (IsInArray == 0) ; Not a Valid Character
        {
          IsValid := 0
        }
        Num := Num + 1
      } ; End Loop %ThisEmailLen%
      ; -------------------------------------------
      ; Check All Characters in (Lower_ThisEmail)
      ; are a Letter or Number
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      if (IsValid == 1) ; All Characters in (Lower_ThisEmail) are (Valid)
      {
        ; -------------------------------------------
        Pos_At := InStr(Lower_ThisEmail, "@",,, 1)
        ; -------------------------------------------
        if (Pos_At > 0) ; At Least 1 @ Exist (Valid)
        {
          ; -------------------------------------------
          Pos_Period := InStr(Lower_ThisEmail, ".",,, 1)
          ; -------------------------------------------
          if (Pos_Period > 0) ; At Least 1 . Exist (Valid)
          {
            ; -------------------------------------------
            Pos_At_Extra := InStr(Lower_ThisEmail, "@",,, 2)
            ; -------------------------------------------
            if (Pos_At_Extra == 0) ; Only 1 @ Exist (Valid)
            {
              ; -------------------------------------------
              Pos_Underscore := InStr(Lower_ThisEmail, "_",,, 1)
              ; -------------------------------------------
              if (Pos_Underscore < Pos_At) ; _ is Before @ (Valid)
              {
                ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                if (IsValid == 1)
                {
                  ; -------------------------------------------
                  Pos_Check := InStr(Lower_ThisEmail, "@",,, 1)
                  ; -------------------------------------------
                  if (Pos_Check > 0) ; Has AtLeast one @ (Valid)
                  {
                    ; -------------------------------------------
                    Chk_This := Substr(Lower_ThisEmail, Pos_Check + 1, 1)
                    ; -------------------------------------------
                    IsInArray := Array_ItemExist(Array_LetterNumber, Chk_This) ; ThisArray, CheckThis > Number of times in Array
                    if (IsInArray == 0) ; Chr After (InValid)
                    {
                      IsValid := 0
                    } ; End Chr After (InValid)
                  } ; End Has AtLeast one @ (Valid)
                } ; End (IsValid == 1)
                ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                if (IsValid == 1)
                {
                  ; -------------------------------------------
                  Num := 1
                  Pos_Check := InStr(Lower_ThisEmail, "_",,, Num)
                  ; -------------------------------------------
                  if (Pos_Check > 0)
                  {
                    Loop %ThisEmailLen%
                    {
                      if (Pos_Check > 0)
                      {
                        ; -------------------------------------------
                        Chk_This := Substr(Lower_ThisEmail, Pos_Check + 1, 1)
                        ; -------------------------------------------
                        IsInArray := Array_ItemExist(Array_LetterNumber, Chk_This) ; ThisArray, CheckThis > Number of times in Array
                        if (IsInArray == 0) ; Chr After (InValid)
                        {
                          Pos_Check := 0
                          IsValid := 0
                        } ; End Chr After (InValid)
                        else ; Check Next (Valid)
                        {
                          Num := 1
                          Pos_Check := InStr(Lower_ThisEmail, "-",,, Num)
                        } ; End Check Next (Valid)
                        ; -------------------------------------------
                      } ; End (Pos_Check > 0)
                    } ; End Loop %ThisEmailLen%
                  } ; End (Pos_Check > 0)
                } ; End (IsValid == 1)
                ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                if (IsValid == 1)
                {
                  ; -------------------------------------------
                  Num := 1
                  Pos_Check := InStr(Lower_ThisEmail, "-",,, Num)
                  ; -------------------------------------------
                  if (Pos_Check > 0)
                  {
                    Loop %ThisEmailLen%
                    {
                      if (Pos_Check > 0)
                      {
                        ; -------------------------------------------
                        Chk_This := Substr(Lower_ThisEmail, Pos_Check + 1, 1)
                        ; -------------------------------------------
                        IsInArray := Array_ItemExist(Array_LetterNumber, Chk_This) ; ThisArray, CheckThis > Number of times in Array
                        if (IsInArray == 0) ; Chr After (InValid)
                        {
                          Pos_Check := 0
                          IsValid := 0
                        } ; End Chr After (InValid)
                        else ; Check Next (Valid)
                        {
                          Num := 1
                          Pos_Check := InStr(Lower_ThisEmail, "-",,, Num)
                        } ; End Check Next (Valid)
                        ; -------------------------------------------
                      } ; End (Pos_Check > 0)
                    } ; End Loop %ThisEmailLen%
                  } ; End (Pos_Check > 0)
                } ; End (IsValid == 1)
                ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                if (IsValid == 1)
                {
                  ; -------------------------------------------
                  Num := 1
                  Pos_Check := InStr(Lower_ThisEmail, ".",,, Num)
                  ; -------------------------------------------
                  if (Pos_Check > 0)
                  {
                    Loop %ThisEmailLen%
                    {
                      if (Pos_Check > 0)
                      {
                        ; -------------------------------------------
                        Chk_This := Substr(Lower_ThisEmail, Pos_Check + 1, 1)
                        ; -------------------------------------------
                        IsInArray := Array_ItemExist(Array_LetterNumber, Chk_This) ; ThisArray, CheckThis > Number of times in Array
                        if (IsInArray == 0) ; Chr After (InValid)
                        {
                          Pos_Check := 0
                          IsValid := 0
                        } ; End Chr After (InValid)
                        else ; Check Next (Valid)
                        {
                          Num := 1
                          Pos_Check := InStr(Lower_ThisEmail, "-",,, Num)
                        } ; End Check Next (Valid)
                        ; -------------------------------------------
                      } ; End (Pos_Check > 0)
                    } ; End Loop %ThisEmailLen%
                  } ; End (Pos_Check > 0)
                } ; End (IsValid == 1)
                ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                if (IsValid == 1) ; Domain Check
                {
                  ; -------------------------------------------
                  DomainName := SubStr(Lower_ThisEmail, Pos_At + 1)
                  ; -------------------------------------------
                  Pos_Period := InStr(DomainName, ".",,, 1)
                  Pos_Period_2 := InStr(DomainName, ".",,, 2)
                  ; -------------------------------------------
                  if (Pos_Period == 0) ; Only 1 . (Valid)
                  {
                    IsValid := 0
                  }
                  else if (Pos_Period_2 == 0) ; Only 1 . (Valid)
                  {
                    if (Pos_Period > 0) ; Has a . in Domain Name (Valid)
                    {
                      Check_DomainLen := SubStr(DomainName, Pos_Period + 1)
                      if (StrLen(Check_DomainLen) < 2) ; Domain Less than 2 two Chr long (InValid)
                      {
                        IsValid := 0
                      } ; End Domain Less than 2 two Chr long (InValid)
                    } ; End Has a . in Domain Name (Valid)
                  } ; End Only 1 . (Valid)
                  else ; More than 1 . (InValid)
                  {
                    IsValid := 0
                  }
                } ; End (IsValid == 1)
                ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
              } ; End _ is Before @ (Valid)
              else ; _ is After @ (InValid)
              {
                IsValid := 0
              } ; End is After @ (InValid)
              ; -------------------------------------------
            } ; End Only 1 @ Exist (Valid)
            else ; More that 1 @ Exist (InValid)
            {
              IsValid := 0
            } ; End More that 1 @ Exist (InValid)
          } ; End At Least 1 . Exist (Valid)
          else ; NO . Exist (InValid)
          {
            IsValid := 0
          } ; End NO . Exist (InValid)
          ; -------------------------------------------
        } ; End At Least 1 @ Exist (Valid)
        else ; NO @ Exist (InValid)
        {
          IsValid := 0
        } ; End NO @ Exist (InValid)
        ; -------------------------------------------
      } ; End Character Check (Valid)
      ; -------------------------------------------
      if (IsValid == 1) ; Email address is Valid
      {
        GuiControlGet, ContactName, PopUpMenu:, g_189 ; (189_1)(Obj_Pum_EditFeild_ContactName)
        if (StrLen(ContactName) > 0) ; ContactName has name
        {
          GuiControlGet, ContactBody, PopUpMenu:, g_190 ; (190_1)(Obj_Pum_EditFeild_EmailBody)
          if (StrLen(ContactBody) > 0) ; Body has Content
          {
            ; -------------------------------------------
            DataArray.187.2 := 1 ; (187_2)(Obj_Pum_SendEmailAnimate_Sel [0,1,2])
            DataArray.187.3 := ImageContent ; (187_3)(Obj_Pum_SendEmailAnimate_Img [Image Path])
            GuiControl, PopUpMenu:, g_187, %ImageContent% ; (187_1)(Obj_Pum_SendEmailAnimate)
            GuiControl, PopUpMenu:Show, g_187 ; (187_1)(Obj_Pum_SendEmailAnimate)
            Sleep, 10
            ; -------------------------------------------
            DataArray := Image_GuiControl("004", 1, 0, DataArray) ; (004_1)(Obj_ok)
            ; -------------------------------------------
          }  ; End Body has Content
          else ; Body has NO Content
          {
            ; -------------------------------------------
            DataArray.187.2 := 1 ; (187_2)(Obj_Pum_SendEmailAnimate_Sel [0,1,2])
            DataArray.187.3 := ImageNoContent ; (187_3)(Obj_Pum_SendEmailAnimate_Img [Image Path])
            GuiControl, PopUpMenu:, g_187, %ImageNoContent% ; (187_1)(Obj_Pum_SendEmailAnimate)
            GuiControl, PopUpMenu:Show, g_187 ; (187_1)(Obj_Pum_SendEmailAnimate)
            Sleep, 10
            ; -------------------------------------------
            DataArray := Image_GuiControl("004", 3, 0, DataArray) ; (004_1)(Obj_ok)
            ; -------------------------------------------
            IsValid := 0
            ; -------------------------------------------
          } ; End Body has NO Content
        } ; End ContactName has name
        else ; ContactName has NO name
        {
          ; -------------------------------------------
          DataArray.187.2 := 1 ; (187_2)(Obj_Pum_SendEmailAnimate_Sel [0,1,2])
          DataArray.187.3 := ImageNoContent ; (187_3)(Obj_Pum_SendEmailAnimate_Img [Image Path])
          GuiControl, PopUpMenu:, g_187, %ImageNoContent% ; (187_1)(Obj_Pum_SendEmailAnimate)
          GuiControl, PopUpMenu:Show, g_187 ; (187_1)(Obj_Pum_SendEmailAnimate)
          Sleep, 10
          ; -------------------------------------------
          DataArray := Image_GuiControl("004", 3, 0, DataArray) ; (004_1)(Obj_ok)
          ; -------------------------------------------
          IsValid := 0
          ; -------------------------------------------
        } ; End ContactName has NO name
      } ; End Email address is Valid
      else ; Email address is NOT Valid
      {
        ; -------------------------------------------
        DataArray := Image_GuiControl("004", 3, 0, DataArray) ; (004_1)(Obj_ok)
        ; -------------------------------------------
        DataArray.187.2 := 1 ; (187_2)(Obj_Pum_SendEmailAnimate_Sel [0,1,2])
        DataArray.187.3 := ImageNoContent ; (187_3)(Obj_Pum_SendEmailAnimate_Img [Image Path])
        GuiControl, PopUpMenu:, g_187, %ImageNoContent% ; (187_1)(Obj_Pum_SendEmailAnimate)
        GuiControl, PopUpMenu:Show, g_187 ; (187_1)(Obj_Pum_SendEmailAnimate)
        Sleep, 10
        ; -------------------------------------------
        IsValid := 0
        ; -------------------------------------------
      } ; End Email address is NOT Valid
      ; -------------------------------------------
    } ; End First Character (Vaild)
    ; -------------------------------------------
    else ; All Characters in (Lower_ThisEmail) are (Valid) or No Email Address
    {
      ; -------------------------------------------
      DataArray.187.2 := 1 ; (187_2)(Obj_Pum_SendEmailAnimate_Sel [0,1,2])
      DataArray.187.3 := ImageNoContent ; (187_3)(Obj_Pum_SendEmailAnimate_Img [Image Path])
      GuiControl, PopUpMenu:, g_187, %ImageNoContent% ; (187_1)(Obj_Pum_SendEmailAnimate)
      GuiControl, PopUpMenu:Show, g_187 ; (187_1)(Obj_Pum_SendEmailAnimate)
      Sleep, 10
      ; -------------------------------------------
      DataArray := Image_GuiControl("004", 3, 0, DataArray) ; (004_1)(Obj_ok)
      ; -------------------------------------------
      IsValid := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  } ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
