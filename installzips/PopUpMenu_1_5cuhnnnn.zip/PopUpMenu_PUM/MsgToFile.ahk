﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;#Include D:\(_Installed_)\(_PopUpMenu_)\(_Construct_)\Scripts\MsgToFile.ahk ; MsgToFile("Delete")
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
MsgToFile(ThisMsg)
{
  ; -------------------------------------------
  MsgToFile_File := A_Desktop "\MsgToFile.txt"
  ; -------------------------------------------
  if (ThisMsg == "Delete")
  {
    FileDelete, %MsgToFile_File%
    Sleep, 500
  }
  else
  {
    ; -------------------------------------------
    FileAppend, %ThisMsg%`n, %MsgToFile_File%
    ; -------------------------------------------
  }
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
