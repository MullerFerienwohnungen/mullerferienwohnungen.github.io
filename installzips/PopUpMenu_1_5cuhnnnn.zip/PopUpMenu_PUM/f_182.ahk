﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\Sys_EnableDisable.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_GuiControl.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Pum_ColorVarConvert.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_Rotate.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Pum_WinInWinMaxSize.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_ResizePng.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_Combine.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\l_541.ahk ; (541_1)(_Msg 8_)(_w300 x h300_)_Rotate_Left)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
f_182(DataArray) ; (182_1)(Obj_Pum_BgRotateLeft)
{
  ; -------------------------------------------
  global PumLock
  if (PumLock == "" or !PumLock)
  {
    ; -------------------------------------------
    global PumLock := 0
    ; -------------------------------------------
  }
  ; -------------------------------------------
  if (PumLock == 0)
  {
    ; -------------------------------------------
    global PumLock := 1
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    Sys_EnableDisable("Disable") ; "Enable" or "Disable"
    ; -------------------------------------------
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    DataArray := Image_GuiControl("004", 3, 0, DataArray) ; (004_1)(Obj_ok)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    { ; [START UP]  Vars
      ; -------------------------------------------
      { ; [GET] Vars
        ; -------------------------------------------
        ThisPumProcessFolder := DataArray.361.8 ; (361)(8)(ThisPumProcessFolder [Pum Folder Path])
        ; -------------------------------------------
        XmlIconSize    := DataArray.362.14 ; (362_14)(XmlIconSize [Displaymode iconsize] [32,48,64])
        XmlColumnsX   := DataArray.362.4 ; (362_4)(XmlColumnsX [Pum (X) Columns])
        XmlRowsY      := DataArray.362.3 ; (362_3)(XmlRowsY [Pum (Y) Rows])
        ; -------------------------------------------
        Img_W          := DataArray.362.34 ; (362_34)(Img_W)
        Pum_W          := DataArray.362.36 ; (362_36)(Pum_W)
        Pum_H          := DataArray.362.37 ; (362_37)(Pum_H)
        bg_Image_Type  := DataArray.362.38 ; (362_38)(Bg_Image_Type [C=Crop,F=Fit])
        Img_Gui_W      := DataArray.362.39 ; (362_39)(Img_Gui_W)
        Img_Gui_H      := DataArray.362.40 ; (362_40)(Img_Gui_H)
        Img_Gui_X      := DataArray.362.41 ; (362_41)(Img_Gui_X)
        Img_Gui_Y      := DataArray.362.42 ; (362_42)(Img_Gui_Y)
        Pum_Gui_W      := DataArray.362.44 ; (362_44)(Pum_Gui_W)
        Pum_Gui_H      := DataArray.362.45 ; (362_45)(Pum_Gui_H)
        Pum_Gui_X      := DataArray.362.46 ; (362_46)(Pum_Gui_X)
        Pum_Gui_Y      := DataArray.362.47 ; (362_47)(Pum_Gui_Y)
        Pum_Gui_Max_W  := DataArray.362.48 ; (362_48)(Pum_Gui_Max_W)
        Pum_Gui_Max_H  := DataArray.362.49 ; (362_49)(Pum_Gui_Max_H)
        Pum_Gui_Min_W  := DataArray.362.50 ; (362_50)(Pum_Gui_Min_W)
        Pum_Gui_Min_H  := DataArray.362.51 ; (362_51)(Pum_Gui_Min_H)
        bg_Selected_Rotate := DataArray.362.54 ; (362_54)(bg_Selected_Rotate)
        ; -------------------------------------------
        XmlBgColor := DataArray.362.27 ; (362_27)(XmlBgColor [Background color])
        ; -------------------------------------------
        ; VarType = ("VarNum"(123),"ColorGrid"(A1),"HexColor"(FFFFFF),"MsColor"(1234546)) > [VarNum, ColorGrid, HexColor, MsColor]
        Color_Array := Pum_ColorVarConvert("MsColor", XmlBgColor, DataArray)
        Pum_BgColor_GridNum      := Color_Array.2
        ; -------------------------------------------
      } ; End [GET] Vars
      ; -------------------------------------------
      File_PumFrame := A_ProgramFiles "\PopUpMenu_PUM\image\pum\PumFrame.png" ; (365_2)(Current User language)
      ; -------------------------------------------
      bg_Selected_Gui     := ThisPumProcessFolder "\image\bg_Selected_Gui.png" ; (361)(8)(Pum [Specific Folder Path])
      bg_Selected_Fit     := ThisPumProcessFolder "\image\bg_Selected_Fit.png" ; (361)(8)(Pum [Specific Folder Path])
      ; -------------------------------------------
      Temp_Selected_Gui   := ThisPumProcessFolder "\image\Temp_Selected_Gui.png" ; (361)(8)(Pum [Specific Folder Path])
      Temp_Selected_Fit   := ThisPumProcessFolder "\image\Temp_Selected_Fit.png" ; (361)(8)(Pum [Specific Folder Path])
      ; -------------------------------------------
      Temp_Display_Img     := ThisPumProcessFolder "\image\Temp_Display_Img.png" ; (361)(8)(Pum [Specific Folder Path])
      ; -------------------------------------------
      File_Pum_Gui       := ThisPumProcessFolder "\image\File_Pum_Gui.png" ; (361)(8)(Pum [Specific Folder Path])
      ; -------------------------------------------
    } ; End [START UP] Vars
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; -------------------------------------------
    GuiControl, PopUpMenu:Hide, g_102 ; (102_1)(Obj_DisplayedIcon)
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    FileDelete, %bg_Temp_Txt%
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    Temp_Display_Txt_Img := ThisPumProcessFolder "\image\Temp_Display_Txt_Img.png" ; (361)(8)(Pum [Specific Folder Path])
    FileDelete, %Temp_Display_Txt_Img%
    ; -------------------------------------------
    ;
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ; (008_1)(GUI Object: [key] Alt)
    global n_541 := 0 ; Start Frame Number
    global s_541 := 1 ; Show
    SetTimer, l_541, 300 ; (541_1)(_Msg 8_)(_w300 x h300_)_Rotate_Left)
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ;
    ; -------------------------------------------
    DataArray := Image_GuiControl("182", 2, 0, DataArray) ; (182_1)(Obj_Pum_BgRotateLeft)
    ; -------------------------------------------
    { ; [COMMON] [NEED] (XmlColumnsX)(XmlRowsY)(XmlIconSize) | [SET] (Pum_[W,H])
      ; -------------------------------------------
      ;
      Pum_W := XmlColumnsX * XmlIconSize
      Pum_H := XmlRowsY * XmlIconSize
      ;
      ; -------------------------------------------
    } ; End [COMMON] [NEED] (XmlColumnsX)(XmlRowsY)(XmlIconSize) | [SET] (Pum_[W,H])
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if !FileExist(Temp_Selected_Gui)
    {
      FileCopy, %bg_Selected_Gui%, %Temp_Selected_Gui%, 1
      Sleep, 10
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; (Rotate Arrow Left)
    Image_Rotate(-90, Temp_Selected_Gui, Temp_Selected_Gui)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if !FileExist(Temp_Selected_Fit)
    {
      FileCopy, %bg_Selected_Fit%, %Temp_Selected_Fit%, 1
      Sleep, 10
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    Image_Rotate(-90, Temp_Selected_Fit, Temp_Selected_Fit)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    Gui, ImageSize:Add, Picture, hwndJustForSize, %Temp_Selected_Gui% ; (368_5)(Selected Pum Background [Full Path])
    ControlGetPos, , , Rotate_Gui_W, Rotate_Gui_H, , ahk_id %JustForSize% ; (368_6)(Pum Background Image X_Width)/(368_7)(Pum Background Image Y_Height)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    { ; [NEED] (Rotate_Gui_[W,H]) | [SET] (Img_Gui_[W,H])
      ; -------------------------------------------
      WinInWin_Array := Pum_WinInWinMaxSize(300, 300, Rotate_Gui_W, Rotate_Gui_H) ; OuterWin_W, OuterWin_H, InterWin_W, InterWin_H > [Max_W, Max_H]
      ; -------------------------------------------
      Img_Gui_W := WinInWin_Array.1
      Img_Gui_H := WinInWin_Array.2
      ; -------------------------------------------
    } ; End [NEED] (Rotate_Gui_[W,H]) | [SET] (Img_Gui_[W,H])
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    { ; [NEED] (Img_Gui_[W,H]) (Temp_Selected_Gui.png) | [RESIZE] (Temp_Selected_Gui.png) | [SET] (Img_Gui_[X,Y]) (Pum_Gui_Min_[W,H])
      ; -------------------------------------------
      if (Img_Gui_W > Img_Gui_H)
      {
        ; -------------------------------------------
        Img_Gui_X := 0
        Img_Gui_Y := (300 - Img_Gui_H) / 2
        ; -------------------------------------------
        Pum_Gui_Min_W := 300 / 5
        Pum_Gui_Min_H := Img_Gui_H / 5
        ; -------------------------------------------
      } ; End (Img_Gui_W > Img_Gui_H)
      else if (Img_Gui_W < Img_Gui_H)
      {
        ; -------------------------------------------
        Img_Gui_X := (300 - Img_Gui_W) / 2
        Img_Gui_Y := 0
        ; -------------------------------------------
        Pum_Gui_Min_W := Img_Gui_W / 5
        Pum_Gui_Min_H := 300 / 5
        ; -------------------------------------------
      } ; End (Img_Gui_W < Img_Gui_H)
      else if (Img_Gui_W == Img_Gui_H)
      {
        ; -------------------------------------------
        Img_Gui_X := 0
        Img_Gui_Y := 0
        ; -------------------------------------------
        Pum_Gui_Min_W := 300 / 5
        Pum_Gui_Min_H := 300 / 5
        ; -------------------------------------------
      } ; End (Img_Gui_W == Img_Gui_H)
      ; -------------------------------------------
      Image_ResizePng(Img_Gui_W, Img_Gui_H, Temp_Selected_Gui, Temp_Selected_Gui) ; New_W, New_H, ImageIn, ImageOut > 1 / 0
      ; -------------------------------------------
    } ; End [NEED] (Img_Gui_[W,H]) (Temp_Selected_Gui.png) | [RESIZE] (Temp_Selected_Gui.png) | [SET] (Img_Gui_[X,Y]) (Pum_Gui_Min_[W,H])
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; -------------------------------------------
    FileDelete, %Temp_Display_Img%
    ; -------------------------------------------
    if !FileExist(Temp_Selected_Gui)
    {
      FileCopy, %bg_Selected_Gui%, %Temp_Selected_Gui%, 1
      Sleep, 10
    }
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    if (bg_Image_Type == "C")
    {
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      { ; [NEED] (Img_Gui_[W,H]) (Pum_[W,H] | [SET] (Pum_Gui_[W,H]) | [SET] (Pum_Gui_Max_[W,H])
        ; -------------------------------------------
        WinInWin_Array := Pum_WinInWinMaxSize(Img_Gui_W, Img_Gui_H, Pum_W, Pum_H) ; OuterWin_W, OuterWin_H, InterWin_W, InterWin_H > [Max_W, Max_H]
        ; -------------------------------------------
        Pum_Gui_W := WinInWin_Array.1
        Pum_Gui_H := WinInWin_Array.2
        ; -------------------------------------------
        Pum_Gui_Max_W := WinInWin_Array.1
        Pum_Gui_Max_H := WinInWin_Array.2
        ; -------------------------------------------
      } ; End [NEED] (Img_Gui_[W,H]) (Pum_[W,H] | [SET] (Pum_Gui_[W,H]) | [SET] (Pum_Gui_Max_[W,H])
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      { ; [NEED] (Pum_Gui_Max_[W,H]) (File_PumFrame) | [CREATE] (File_Pum_Gui.png)
        ; -------------------------------------------
        FileDelete, %File_Pum_Gui%
        ; -------------------------------------------
        Image_ResizePng(Pum_Gui_Max_W, Pum_Gui_Max_H, File_PumFrame, File_Pum_Gui) ; New_W, New_H, ImageIn, ImageOut > 1 / 0
        ; -------------------------------------------
      } ; End [NEED] (Pum_Gui_Max_[W,H]) (File_PumFrame) | [CREATE] (File_Pum_Gui.png)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      { ; [NEED] (Img_Gui_[W,H]) (Pum_Gui_[W,H]) | [SET] (Pum_Gui_[X,Y])
        ; -------------------------------------------
        Pum_Gui_X := (Img_Gui_W - Pum_Gui_W) / 2
        Pum_Gui_Y := (Img_Gui_H - Pum_Gui_H) / 2
        ; -------------------------------------------
      } ; End [NEED] (Img_Gui_[W,H]) (Pum_Gui_[W,H]) | [SET] (Pum_Gui_[X,Y])
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      { ; [NEED] (Img_Gui_[W,H]) (Pum_Gui_[X,Y]) | [SET] (Spacer_Img_[X,Y]) | [SET] (Spacer_Pum_[X,Y])
        ; -------------------------------------------
        Spacer_Img_X := (300 - Img_Gui_W) / 2
        Spacer_Img_Y := (300 - Img_Gui_H) / 2
        ; -------------------------------------------
        Spacer_Pum_X := (Pum_Gui_X + Spacer_Img_X)
        Spacer_Pum_Y := (Pum_Gui_Y + Spacer_Img_Y)
        ; -------------------------------------------
      } ; End [NEED] (Img_Gui_[W,H]) (Pum_Gui_[X,Y]) | [SET] (Spacer_Img_[X,Y]) | [SET] (Spacer_Pum_[X,Y])
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      { ; [NEED] (Temp_Selected_Gui.png) (File_Pum_Gui.png) (Spacer_[X,Y])) | [Create] (Temp_Display_Img.png)
        ; -------------------------------------------
        Temp_Resize := A_ProgramFiles "\PopUpMenu_PUM\image\pum\pum_" Pum_BgColor_GridNum "_100.png"
        ; -------------------------------------------
        TxT_Gui_C := ThisPumProcessFolder "\image\File_TxT_Gui_C.png"
        FileDelete, %TxT_Gui_C%
        ; -------------------------------------------
        Image_ResizePng(Img_Gui_W , Img_Gui_H, Temp_Resize, TxT_Gui_C) ; Resize_W, Resize_H, ImageIn, ImageOut > 1 / 0
        ; -------------------------------------------
        Image_Array := [300, 300, Temp_Display_Img, TxT_Gui_C, Spacer_Img_X, Spacer_Img_Y, Temp_Selected_Gui, Spacer_Img_X, Spacer_Img_Y, File_Pum_Gui, Spacer_Pum_X, Spacer_Pum_Y]
        Image_Combine(Image_Array)
        ; -------------------------------------------
      } ; End [NEED] (Temp_Selected_Fit.png) (File_Pum_Gui.png) (Spacer_[X,Y])) | [Create] (Temp_Display_Img.png)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
    } ; End (bg_Image_Type == "C")
    else if (bg_Image_Type == "F")
    {
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      { ; [NEED] (Pum_[W,H]) | [SET] (Pum_Gui_Max_[W,H])
        ; -------------------------------------------
        WinInWin_Array := Pum_WinInWinMaxSize(300, 300, Pum_W, Pum_H) ; OuterWin_W, OuterWin_H, InterWin_W, InterWin_H > [Max_W, Max_H]
        ; -------------------------------------------
        Pum_Gui_Max_W := WinInWin_Array.1
        Pum_Gui_Max_H := WinInWin_Array.2
        ; -------------------------------------------
      } ; End [NEED] (Pum_[W,H]) | [SET] (Pum_Gui_Max_[W,H])
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      { ; [NEED] (Pum_Gui_Max_[W,H]) (Temp_Selected_Gui.png) | [CREATE] (Temp_Selected_Fit.png)
        ; -------------------------------------------
        FileDelete, %Temp_Selected_Fit%
        ; -------------------------------------------
        Image_ResizePng(Pum_Gui_Max_W, Pum_Gui_Max_H, Temp_Selected_Gui, Temp_Selected_Fit) ; New_W, New_H, ImageIn, ImageOut > 1 / 0
        ; -------------------------------------------
      } ; End [NEED] (Pum_Gui_Max_[W,H]) (Temp_Selected_Gui.png) | [CREATE] (Temp_Selected_Fit.png)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      { ; [NEED] (Pum_Gui_Max_[W,H]) (File_PumFrame) | [CREATE] (File_Pum_Gui.png)
        ; -------------------------------------------
        FileDelete, %File_Pum_Gui%
        ; -------------------------------------------
        Image_ResizePng(Pum_Gui_Max_W, Pum_Gui_Max_H, File_PumFrame, File_Pum_Gui) ; New_W, New_H, ImageIn, ImageOut > 1 / 0
        ; -------------------------------------------
      } ; End [NEED] (Pum_Gui_Max_[W,H]) (File_PumFrame) | [CREATE] (File_Pum_Gui.png)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      { ; [NEED] (Pum_Gui_Max_[W,H]) | [SET] (Spacer_[X,Y])
        ; -------------------------------------------
        Spacer_X := (300 - Pum_Gui_Max_W) / 2
        Spacer_Y := (300 - Pum_Gui_Max_H) / 2
        ; -------------------------------------------
      } ; End [NEED] (Pum_Gui_Max_[W,H]) | [SET] (Spacer_[X,Y])
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      { ; [NEED] (Temp_Selected_Fit.png) (File_Pum_Gui.png) (Spacer_[X,Y])) | [Create] (Temp_Display_Img.png)
        ; -------------------------------------------
        Temp_Resize := A_ProgramFiles "\PopUpMenu_PUM\image\pum\pum_" Pum_BgColor_GridNum "_100.png"
        ; -------------------------------------------
        TxT_Gui_C := ThisPumProcessFolder "\image\File_TxT_Gui_C.png"
        FileDelete, %TxT_Gui_C%
        ; -------------------------------------------
        Image_ResizePng(Pum_Gui_Max_W , Pum_Gui_Max_H, Temp_Resize, TxT_Gui_C) ; Resize_W, Resize_H, ImageIn, ImageOut > 1 / 0
        ; -------------------------------------------
        Image_Array := [300, 300, Temp_Display_Img, TxT_Gui_C, Spacer_X, Spacer_Y, Temp_Selected_Fit, Spacer_X, Spacer_Y, File_Pum_Gui, Spacer_X, Spacer_Y]
        Image_Combine(Image_Array)
        FileDelete, %TxT_Gui_C%
        ; -------------------------------------------
      } ; End [NEED] (Temp_Selected_Fit.png) (File_Pum_Gui.png) (Spacer_[X,Y])) | [Create] (Temp_Display_Img.png)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
    } ; End (bg_Image_Type == "F")
    ; -------------------------------------------
    ;
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ; (008_1)(GUI Object: [key] Alt)
    global s_541 := 0 ; Hide
    SetTimer, l_541, Off ; (541_1)(_Msg 8_)(_w300 x h300_)_Rotate_Left)
    global ShowAnimationChange := 0
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ;
    ; -------------------------------------------
    GuiControl, PopUpMenu:, g_254, %Temp_Display_Img% ; (254_1)(Obj_MsgImg300x300)
    GuiControl, PopUpMenu:Show, g_254 ; (254_1)(Obj_MsgImg300x300)
    DataArray.254.3 := Temp_Display_Img ; (254_3)(Obj_MsgImg300x300_Img [Image Path])
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    ; (Rotate Arrow Left)
    if (DataArray.362.54 == "" or DataArray.362.54 == "0") ; (362_54)(bg_Selected_Rotate)
    {
      DataArray.362.54 := "-90" ; (362_54)(bg_Selected_Rotate)
    }
    else if (DataArray.362.54 == "-90") ; (362_54)(bg_Selected_Rotate)
    {
      DataArray.362.54 := "180" ; (362_54)(bg_Selected_Rotate)
    }
    else if (DataArray.362.54 == "180") ; (362_54)(bg_Selected_Rotate)
    {
      DataArray.362.54 := "90" ; (362_54)(bg_Selected_Rotate)
    }
    else if (DataArray.362.54 == "90") ; (362_54)(bg_Selected_Rotate)
    {
      DataArray.362.54 := "0" ; (362_54)(bg_Selected_Rotate)
    }
    ; -------------------------------------------
    if (DataArray.362.52 == "" or DataArray.362.52 == 0 or DataArray.362.52 == 1) ; (362_52)(bg_Selected_Change)
    {
      DataArray.362.52 := 2 ; (362_52)(bg_Selected_Change)
    }
    Pum_Factor := DataArray.362.34 / DataArray.362.39 ; (362_34)(Img_W)/(362_39)(Img_Gui_W)
    DataArray.362.55 := Pum_Factor * DataArray.362.46 ; (362_55)(Pum_X)/(362_46)(Pum_Gui_X)
    DataArray.362.56 := Pum_Factor * DataArray.362.47 ; (362_56)(Pum_Y)/(362_47)(Pum_Gui_Y)
    ; -------------------------------------------
    DataArray := Image_GuiControl("004", 1, 0, DataArray) ; (004_1)(Obj_ok)
    ; -------------------------------------------
    ;
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ;                  
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    { ; [SHOW-HIDE] Controls
      ; -------------------------------------------
      DataArray := Image_GuiControl("182", 1, 0, DataArray) ; (182_1)(Obj_Pum_BgRotateLeft)
      DataArray := Image_GuiControl("183", 1, 0, DataArray) ; (183_1)(Obj_Pum_BgRotateRight)
      ; -------------------------------------------
      if (bg_Image_Type == "C") ; Image is a Crop
      {
        ; -------------------------------------------
        DataArray.241.3 := "" ; (241_3)(Obj_Pum_CropLeft_Img [Image Path])
        DataArray.242.3 := "" ; (242_3)(Obj_Pum_CropRight_Img [Image Path])
        DataArray.243.3 := "" ; (243_3)(Obj_Pum_CropUp_Img [Image Path])
        DataArray.244.3 := "" ; (244_3)(Obj_Pum_CropDown_Img [Image Path])
        DataArray.245.3 := "" ; (245_3)(Obj_Pum_CropCenter_Img [Image Path])
        DataArray.246.3 := "" ; (246_3)(Obj_Pum_ZoomIn_Img [Image Path])
        DataArray.247.3 := "" ; (247_3)(Obj_Pum_ZoomOut_Img [Image Path])
        ; -------------------------------------------
        DataArray := Image_GuiControl("167", 1, 1, DataArray) ; (167_1)(Obj_Pum_BgFitImage)
        ; -------------------------------------------
        if (Pum_Gui_X <= 0.9999999999999999999999999999999999999999)
        {
          Pum_Gui_X := 0
        }
        if (Pum_Gui_Y <= 0.9999999999999999999999999999999999999999)
        {
          Pum_Gui_Y := 0
        }
        ; -------------------------------------------
        if (Pum_Gui_X == 0)
        {
          DataArray := Image_GuiControl("241", 0, 0, DataArray) ; (241_1)(Obj_Pum_CropLeft)
        }
        else
        {
          DataArray := Image_GuiControl("241", 1, 0, DataArray) ; (241_1)(Obj_Pum_CropLeft)
        }
        ; -------------------------------------------
        if ((Pum_Gui_X + Pum_Gui_W) >= Img_Gui_W)
        {
          DataArray := Image_GuiControl("242", 0, 0, DataArray) ; (242_1)(Obj_Pum_CropRight)
        }
        else
        {
          DataArray := Image_GuiControl("242", 1, 0, DataArray) ; (242_1)(Obj_Pum_CropRight)
        }
        ; -------------------------------------------
        if (Pum_Gui_Y == 0)
        {
          DataArray := Image_GuiControl("243", 0, 0, DataArray) ; (243_1)(Obj_Pum_CropUp)
        }
        else
        {
          DataArray := Image_GuiControl("243", 1, 0, DataArray) ; (243_1)(Obj_Pum_CropUp)
        }
        ; -------------------------------------------
        if ((Pum_Gui_Y + Pum_Gui_H) >= Img_Gui_H)
        {
          DataArray := Image_GuiControl("244", 0, 0, DataArray) ; (244_1)(Obj_Pum_CropDown)
        }
        else
        {
          DataArray := Image_GuiControl("244", 1, 0, DataArray) ; (244_1)(Obj_Pum_CropDown)
        }
        ; -------------------------------------------
        DataArray := Image_GuiControl("245", 1, 0, DataArray) ; (245_1)(Obj_Pum_CropCenter)
        ; -------------------------------------------
        if ((Pum_Gui_W > Pum_Gui_Min_W && Pum_Gui_W < Pum_Gui_Max_W) && (Pum_Gui_H > Pum_Gui_Min_H && Pum_Gui_H < Pum_Gui_Max_H))
        {
          DataArray := Image_GuiControl("246", 1, 0, DataArray) ; (246_1)(Obj_Pum_ZoomIn)
          DataArray := Image_GuiControl("247", 1, 0, DataArray) ; (247_1)(Obj_Pum_ZoomOut)
        }
        else if ((Pum_Gui_W > Pum_Gui_Min_W) && (Pum_Gui_H > Pum_Gui_Min_H))
        {
          DataArray := Image_GuiControl("246", 1, 0, DataArray) ; (246_1)(Obj_Pum_ZoomIn)
          DataArray := Image_GuiControl("247", 0, 0, DataArray) ; (247_1)(Obj_Pum_ZoomOut)
        }
        else if ((Pum_Gui_W < Pum_Gui_Max_W) && (Pum_Gui_H < Pum_Gui_Max_H))
        {
          DataArray := Image_GuiControl("246", 0, 0, DataArray) ; (246_1)(Obj_Pum_ZoomIn)
          DataArray := Image_GuiControl("247", 1, 0, DataArray) ; (247_1)(Obj_Pum_ZoomOut)
        }
        ; -------------------------------------------
      } ; End (bg_Image_Type == "C")
      ; -------------------------------------------
      else if (bg_Image_Type == "F") ; Image is a Fit
      {
        ; -------------------------------------------
        DataArray := Image_GuiControl("167", 2, 1, DataArray) ; (167_1)(Obj_Pum_BgFitImage)
        ; -------------------------------------------
        DataArray := Image_GuiControl("241", 0, 0, DataArray) ; (241_1)(Obj_Pum_CropLeft)
        DataArray := Image_GuiControl("242", 0, 0, DataArray) ; (242_1)(Obj_Pum_CropRight)
        DataArray := Image_GuiControl("243", 0, 0, DataArray) ; (243_1)(Obj_Pum_CropUp)
        DataArray := Image_GuiControl("244", 0, 0, DataArray) ; (244_1)(Obj_Pum_CropDown)
        DataArray := Image_GuiControl("245", 0, 0, DataArray) ; (245_1)(Obj_Pum_CropCenter)
        DataArray := Image_GuiControl("246", 0, 0, DataArray) ; (246_1)(Obj_Pum_ZoomIn)
        DataArray := Image_GuiControl("247", 0, 0, DataArray) ; (247_1)(Obj_Pum_ZoomOut)
      } ; End (bg_Image_Type == "F")
      ; -------------------------------------------
    } ; End [SHOW-HIDE] Controls
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    { ; [UPDATE] Vars
      ; -------------------------------------------
      DataArray.361.8  := ThisPumProcessFolder ; (361)(8)(ThisPumProcessFolder [Pum Folder Path])
      ; -------------------------------------------
      DataArray.362.14 := XmlIconSize ; (362_14)(XmlIconSize [Displaymode iconsize] [32,48,64])
      DataArray.362.4  := XmlColumnsX ; (362_4)(XmlColumnsX [Pum (X) Columns])
      DataArray.362.3  := XmlRowsY ; (362_3)(XmlRowsY [Pum (Y) Rows])
      ; -------------------------------------------
      DataArray.362.34 := Img_W ; (362_34)(Img_W)
      DataArray.362.36 := Pum_W ; (362_36)(Pum_W)
      DataArray.362.37 := Pum_H ; (362_37)(Pum_H)
      DataArray.362.38 := bg_Image_Type ; (362_38)(Bg_Image_Type [C=Crop,F=Fit])
      DataArray.362.39 := Img_Gui_W ; (362_39)(Img_Gui_W)
      DataArray.362.40 := Img_Gui_H ; (362_40)(Img_Gui_H)
      DataArray.362.41 := Img_Gui_X ; (362_41)(Img_Gui_X)
      DataArray.362.42 := Img_Gui_Y ; (362_42)(Img_Gui_Y)
      DataArray.362.44 := Pum_Gui_W ; (362_44)(Pum_Gui_W)
      DataArray.362.45 := Pum_Gui_H ; (362_45)(Pum_Gui_H)
      DataArray.362.46 := Pum_Gui_X ; (362_46)(Pum_Gui_X)
      DataArray.362.47 := Pum_Gui_Y ; (362_47)(Pum_Gui_Y)
      DataArray.362.48 := Pum_Gui_Max_W ; (362_48)(Pum_Gui_Max_W)
      DataArray.362.49 := Pum_Gui_Max_H ; (362_49)(Pum_Gui_Max_H)
      DataArray.362.50 := Pum_Gui_Min_W ; (362_50)(Pum_Gui_Min_W)
      DataArray.362.51 := Pum_Gui_Min_H ; (362_51)(Pum_Gui_Min_H)
      ; -------------------------------------------
      DataArray.362.27 := XmlBgColor ; (362_27)(XmlBgColor [Background color])
      ; -------------------------------------------
    } ; End [UPDATE] Vars
    ; -------------------------------------------
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    DataArray := Image_GuiControl("004", 1, 0, DataArray) ; (004_1)(Obj_ok)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; -------------------------------------------
    Sys_EnableDisable("Enable") ; "Enable" or "Disable"
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    global PumLock := 0
    ; -------------------------------------------
  } ; End (PumLock == 0)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  return DataArray
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
