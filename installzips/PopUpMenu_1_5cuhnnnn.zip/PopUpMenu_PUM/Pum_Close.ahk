﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\Sys_ResetDataArray.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Array_FromFile.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Pum_FileDelete.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Pum_Close(DataArray) ; > DataArray
{
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; Get ActiveProcessName
  ; -------------------------------------------
  WinGet, Active_ID, ID, A
  WinGet, ActiveProcessName, ProcessName, ahk_id %Active_ID%
  ; Get ActiveProcessName
  ; -------------------------------------------
  ; Get ActiveProcessName
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; Existing pum Process
  ; -------------------------------------------
  WinGet, ThisPumProcessExe, ProcessName, ahk_class TfrmToolbox
  if (InStr(ThisPumProcessExe, "pum_") == 0) ; pum Exist
  {
    ThisPumProcessExe := ""
  }
  ; -------------------------------------------
  ; Existing pum Process
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  SetTitleMatchMode, 2
  ; -------------------------------------------
  if WinExist("Shortcut_Pop_Up_Menu" . "ahk_class AutoHotkeyGUI") ; Shortcut Gui Exist
  {
    ; -------------------------------------------
    WinGet, Gui_Id, ID , Shortcut_Pop_Up_Menu ahk_class AutoHotkeyGUI
    WinSet, AlwaysOnTop, Off, ahk_id %Gui_Id%
    ; -------------------------------------------
    Gui, PopUpMenu:Destroy
    ; -------------------------------------------
    Sleep, 10
    ; -------------------------------------------
    WinSet, AlwaysOnTop, On, ahk_exe %ThisPumProcessExe%
    ; -------------------------------------------
    DataArray := Sys_ResetDataArray(DataArray) ; > DataArray
    ; -------------------------------------------
  } ; [End] if WinExist("Shortcut_Pop_Up_Menu" . "ahk_class AutoHotkeyGUI") ; Shortcut Gui Exist
  ; -------------------------------------------
  else ; Close pum
  {
    ; -------------------------------------------
    Process, Close, %ThisPumProcessExe%
    ; -------------------------------------------
    Pum_FileDelete(ThisPumProcessExe)
    ; -------------------------------------------
  } ; [End] else if (PumActive == 1) ; Close Any PUM
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
} ; End Pum_Close`
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
