﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
#SingleInstance, force
#NoTrayIcon
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\Script_Running.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Pum_Run.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
ScriptPath := A_ProgramFiles "\PopUpMenu_PUM\SysTray.ahk"
; -------------------------------------------
if (Script_Running(ScriptPath) == 0) ; (NOT Running)
{
  ; -------------------------------------------
  RunWait, %A_ProgramFiles%\PopUpMenu_PUM\SysLoad.ahk
  Sleep, 500
  ; -------------------------------------------
  DataArray := Pum_Run(DataArray) ; > DataArray
  ; -------------------------------------------
}
else
{
  ; -------------------------------------------
  DataArray := Pum_Run(DataArray) ; > DataArray
  ; -------------------------------------------
}
; -------------------------------------------
ExitApp
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
