﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\Sys_EnableDisable.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_GuiControl.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_PumDim.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Pum_Check.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
f_156(DataArray) ; (156_1)(Obj_Pum_BgDim)
{
  global PumLock
  if (PumLock == "")
  {
    ; -------------------------------------------
    global PumLock := 0
    ; -------------------------------------------
  }
  ; -------------------------------------------
  if (PumLock == 0)
  {
    ; -------------------------------------------
    global PumLock := 1
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    if (DataArray.156.2 == "" or DataArray.156.2 == 1) ; (156_2)(Obj_Pum_BgDim_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      bg_Display_Img := DataArray.361.8 "\image\bg_Display_Img.png" ; (361)(8)(ThisPumProcessFolder [Pum Folder Path])
      FileDelete, %bg_Display_Img%
      ; -------------------------------------------
      Sys_EnableDisable("Disable") ; "Enable" or "Disable"
      ; -------------------------------------------
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      DataArray := Image_GuiControl("004", 3, 0, DataArray) ; (004_1)(Obj_ok)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; -------------------------------------------
      DataArray.366.5 := "pum_pumSetting_pumDimension" ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      DataArray.362.52 := 0 ; (362_52)(bg_Selected_Change)
      ; -------------------------------------------
      ;
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Hide/Stop (Animate) Pum_Building_Construct
      global s_521 := 0 ; Hide
      SetTimer, l_521, Off ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
      global ShowAnimationChange := 0
      ;
      DataArray := Image_GuiControl("137", 0, 0, DataArray) ; (137_1)(Obj_MsgImg480x270)
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Hide/Stop (Animate) Pum_Building_Construct
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      { ; Hide
        ; -------------------------------------------
        ; Hide [pumBgImage]
        DataArray := Image_GuiControl("165", 0, 1, DataArray) ; (165_1)(Obj_Pum_BgImageSelect)
        DataArray := Image_GuiControl("167", 0, 1, DataArray) ; (167_1)(Obj_Pum_BgFitImage)
        DataArray := Image_GuiControl("182", 0, 0, DataArray) ; (182_1)(Obj_Pum_BgRotateLeft)
        DataArray := Image_GuiControl("183", 0, 0, DataArray) ; (183_1)(Obj_Pum_BgRotateRight)
        DataArray := Image_GuiControl("241", 0, 0, DataArray) ; (241_1)(Obj_Pum_CropLeft)
        DataArray := Image_GuiControl("242", 0, 0, DataArray) ; (242_1)(Obj_Pum_CropRight)
        DataArray := Image_GuiControl("243", 0, 0, DataArray) ; (243_1)(Obj_Pum_CropUp)
        DataArray := Image_GuiControl("244", 0, 0, DataArray) ; (244_1)(Obj_Pum_CropDown)
        DataArray := Image_GuiControl("245", 0, 0, DataArray) ; (245_1)(Obj_Pum_CropCenter)
        DataArray := Image_GuiControl("246", 0, 0, DataArray) ; (246_1)(Obj_Pum_ZoomIn)
        DataArray := Image_GuiControl("247", 0, 0, DataArray) ; (247_1)(Obj_Pum_ZoomOut)
        ; -------------------------------------------
        ; Hide [pumBgText]
        GuiControl, PopUpMenu:Hide, g_164 ; (164_1)(Obj_Pum_BgTxtImg)
        DataArray := Image_GuiControl("166", 0, 1, DataArray) ; (166_1)(Obj_Pum_BgColor)
        DataArray := Image_GuiControl("172", 0, 1, DataArray) ; (172_1)(Obj_Pum_MobileText)
        DataArray := Image_GuiControl("173", 0, 1, DataArray) ; (173_1)(Obj_Pum_MobileTxtColor)
        DataArray := Image_GuiControl("174", 0, 1, DataArray) ; (174_1)(Obj_Pum_MobileBgColor)
        ; -------------------------------------------
        ; Hide [pumBgText] Tranparency (177)-(181)
        DataArray := Image_GuiControl("177", 0, 1, DataArray) ; (177_1)(Obj_Pum_BgTrans)
        DataArray := Image_GuiControl("178", 0, 0, DataArray) ; (178_1)(Obj_Pum_BgOpacityUp)
        DataArray := Image_GuiControl("179", 0, 0, DataArray) ; (179_1)(Obj_Pum_BgOpacityDown)
        DataArray := Image_GuiControl("180", 0, 0, DataArray) ; (180_1)(Obj_Pum_DisplayText_Opacity)
        DataArray := Image_GuiControl("181", 0, 0, DataArray) ; (181_1)(Obj_Pum_Opacity)
        ;
        ; Hide [pumBgText] Color Picker (291) - (238)
        Num_Hide := 190
        Loop 48
        {
          Num_Hide := Num_Hide + 1
          DataArray := Image_GuiControl(Num_Hide, 0, 0, DataArray) ; (166_1)(GUI Object: [pum] [pumBgColor])
        }
        ; -------------------------------------------
        ; Hide (Message Image 8)
        DataArray := Image_GuiControl("254", 0, 1, DataArray) ; (254_1)(Obj_MsgImg300x300)
        ; -------------------------------------------
      } ; End Hide
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; Show[pumDimension]
      ; -------------------------------------------
      DataArray := Image_GuiControl("154", 1, 1, DataArray) ; (154_1)(Obj_Pum_BgImage)
      DataArray := Image_GuiControl("155", 1, 1, DataArray) ; (155_1)(Obj_Pum_BgText)
      DataArray := Image_GuiControl("156", 2, 1, DataArray) ; (156_1)(Obj_Pum_BgDim)
      ; -------------------------------------------
      ; <Display Text>
      DataArray := Image_GuiControl("263", 1, 1, DataArray) ; (263_1)(Obj_Pum_ImageText_IconSize)
      DataArray := Image_GuiControl("269", 1, 1, DataArray) ; (269_1)(Obj_Pum_DisplayText_Vertical)
      DataArray := Image_GuiControl("275", 1, 1, DataArray) ; (275_1)(Obj_Pum_DisplayText_Horizontal)
      ; -------------------------------------------
      ; [End] Show [pumDimension]
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; All with DoNotEnter Sign until Pum_Check
      ; Determines if Pum Size is beyond the bounds of possibility
      ; -------------------------------------------
      Icon_Image := A_ProgramFiles "\PopUpMenu_PUM\image\gui\(260)_" DataArray.362.14 ".png" ; (362_14)(XmlIconSize [Displaymode iconsize] [32,48,64])
      GuiControl, PopUpMenu:, g_260, %Icon_Image% ; (260_1)(Obj_Pum_IconSize)
      GuiControl, PopUpMenu:Show, g_260 ; (260_1)(Obj_Pum_IconSize)
      ; -------------------------------------------
      DataArray := Image_GuiControl("261", 3, 0, DataArray) ; (261_1)(Obj_Pum_IconUp)
      DataArray := Image_GuiControl("262", 3, 0, DataArray) ; (262_1)(Obj_Pum_IconDown)
      DataArray := Image_GuiControl("267", 3, 0, DataArray) ; (267_1)(Obj_Pum_PumRowUp)
      DataArray := Image_GuiControl("268", 3, 0, DataArray) ; (268_1)(Obj_Pum_PumRowDown)
      DataArray := Image_GuiControl("273", 3, 0, DataArray) ; (273_1)(Obj_Pum_PumColumnUp)
      DataArray := Image_GuiControl("274", 3, 0, DataArray) ; (274_1)(Obj_Pum_PumColumnDown)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ThisPumProcessFolder := DataArray.361.8  ; (361)(8)(ThisPumProcessFolder [Pum Folder Path])
      DisplayPumDim := ThisPumProcessFolder "\image\DisplayPumDim.png" ; (361)(8)(ThisPumProcessFolder [Pum Folder Path])
      ; -------------------------------------------
      if FileExist(DisplayPumDim)
      {
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ ; Message Image (SelectImage)
        GuiControl, PopUpMenu:, g_254, %DisplayPumDim% ; (254_1)(Obj_MsgImg300x300)
        GuiControl, PopUpMenu:Show, g_254 ; (254_1)(Obj_MsgImg300x300)
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ ; Message Image (SelectImage)
      }
      else
      {
        GuiControl, PopUpMenu:Hide, g_254 ; (254_1)(Obj_MsgImg300x300)
        Image_PumDim(DataArray) ; > Nothing
      }
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      DataArray := Pum_Check(DataArray) ; > DataArray
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      DataArray := Image_GuiControl("004", 1, 0, DataArray) ; (004_1)(Obj_ok)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; -------------------------------------------
      Sys_EnableDisable("Enable") ; "Enable" or "Disable"
      ; -------------------------------------------
    } ; End Button in Normal State
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    global PumLock := 0
    ; -------------------------------------------
  } ; End (PumLock == 0)
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
} ; End (156_1)(GUI Object: [pumDimension])
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
