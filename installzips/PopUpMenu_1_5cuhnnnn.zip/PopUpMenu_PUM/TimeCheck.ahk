﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; -------------------------------------------
; To Use
; First Varible == "Start"
; Last  Varible == "End"
; 
;~ #Include %A_ProgramFiles%\PopUpMenu_PUM\TimeCheck.ahk
;~ global ArrayTime := TimeCheck("Start", ArrayTime) ; "Start" "End" > ArrayTime
;~ global ArrayTime := TimeCheck("This Time Description", ArrayTime) ; "Start" "End" > ArrayTime
;~ global ArrayTime := TimeCheck("End", ArrayTime) ; "Start" "End" > ArrayTime
; -------------------------------------------
TimeCheck(StartEnd, ArrayTime) ; "Start" "End" > ArrayTime
{
  ; -------------------------------------------
  if (StartEnd == "Start")
  {
    ArrayTime := ""
    AddTooArray := ["Start", A_TickCount]
    ArrayTime := TimeCheck_ArrayAdd(ArrayTime, AddTooArray, "End") ; ThisArray, AddThis, ThisPos > ThisArray
  } ; End (StartEnd == "Start")
  else if (StartEnd == "End")
  {
    ; -------------------------------------------
    AddTooArray := ["End", A_TickCount]
    ArrayTime := TimeCheck_ArrayAdd(ArrayTime, AddTooArray, "End") ; ThisArray, AddThis, ThisPos > ThisArray
    ; ------------------------------------------
    Msg := ""
    ; -------------------------------------------
    for Index, ThisTimeArray in ArrayTime
    {
      if (Index == 1)
      {
        StartTime := ThisTimeArray[2]
      }
      else if (Index == 2)
      {
        ; -------------------------------------------
        ThisDesc := ThisTimeArray[1]
        ThisTime := ThisTimeArray[2]
        ; -------------------------------------------
        LapTime := ThisTime - StartTime
        LapTime := LapTime / 1000
        LapTime := Round(LapTime , 3)
        ; -------------------------------------------
        Msg := Msg "========================`n"
        Msg := Msg LapTime " = " ThisDesc "`n"
        ; -------------------------------------------
        OldTime := ThisTime
        ; -------------------------------------------
      }
      else ; (Index > 2)
      {
        ; -------------------------------------------
        ThisDesc := ThisTimeArray[1]
        ThisTime := ThisTimeArray[2]
        ; -------------------------------------------
        if (ThisDesc == "End")
        {
          LapTime := ThisTime - StartTime
          LapTime := LapTime / 1000
          LapTime := Round(LapTime , 3)
          ; -------------------------------------------
          Msg := Msg "========================`n"
          Msg := Msg LapTime " = Total Time`n"
          Msg := Msg "========================`n"
          ; -------------------------------------------
        }
        else
        {
          LapTime := ThisTime - OldTime
          LapTime := LapTime / 1000
          LapTime := Round(LapTime , 3)
          ; -------------------------------------------
          Msg := Msg LapTime " = " ThisDesc "`n"
          ; -------------------------------------------
          OldTime := ThisTime
        }
        ; -------------------------------------------
      } ; End (Index > 2)
      ; -------------------------------------------
    } ; End for Index, ThisTimeArray in ThisTimeCheck
    ; -------------------------------------------
    Clipboard := Msg
    ; -------------------------------------------
    Tooltip, %Msg%, -300, -100
    Msg := ""
    ; -------------------------------------------
  } ; End (StartEnd == "End")
  else ; All other time points
  {
    ; -------------------------------------------
    AddTooArray := [StartEnd, A_TickCount]
    ArrayTime := TimeCheck_ArrayAdd(ArrayTime, AddTooArray, "End") ; ThisArray, AddThis, ThisPos > ThisArray
    ; -------------------------------------------
  } ; End All other time points
  ; -------------------------------------------
  return ArrayTime
  ; -------------------------------------------
}
; -------------------------------------------
TimeCheck_ArrayAdd(ThisArray, AddThis, ThisPos) ; ThisArray, AddThis, ThisPos > ThisArray
{
  ; -------------------------------------------
  if !ThisPos
  {
    ThisPos := "End"
  }
  ; -------------------------------------------
  if AddThis
  {
    CheckThis := ThisArray[1]
    if CheckThis
    {
      if (ThisPos == "End")
      {
        ThisArray.Push(AddThis) ; Adds (AddThis) to End
      }
      else
      {
        if (ThisPos == 0)
        {
          ThisPos := 1
        }
        ThisArray.InsertAt(ThisPos, AddThis) ; Adds (AddThis) at (ThisPos)
      }
    } ; End if CheckThis
    else
    {
      ThisArray := []
      ThisArray[1] := AddThis
    } ; End else
  } ; End if AddThis
  return ThisArray
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; END OF FILE
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
