﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\Sys_EnableDisable.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_GuiControl.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Pum_SelectedColorDisplay.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
f_166(DataArray) ; (166_1)(Obj_Pum_BgColor)
{
  ; -------------------------------------------
  global PumLock
  if (PumLock == "")
  {
    ; -------------------------------------------
    global PumLock := 0
    ; -------------------------------------------
  }
  ; -------------------------------------------
  if (PumLock == 0)
  {
    ; -------------------------------------------
    global PumLock := 1
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    Sys_EnableDisable("Disable") ; "Enable" or "Disable"
    ; -------------------------------------------
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    DataArray := Image_GuiControl("004", 3, 0, DataArray) ; (004_1)(Obj_ok)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; -------------------------------------------
    GuiControl, PopUpMenu:Hide, g_102 ; (102_1)(Obj_DisplayedIcon)
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    if (DataArray.166.2 == "" or DataArray.166.2 == 1) ; (166_2)(Obj_Pum_BgColor_Sel [0,1,2])
    {
      ; -------------------------------------------
      DataArray.366.5 := "pum_pumSetting_pumBgText_pumBgColor" ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      ; -------------------------------------------
      DataArray := Image_GuiControl("254", 0, 0, DataArray) ; (254_1)(Obj_MsgImg300x300)
      ; -------------------------------------------
      DataArray := Image_GuiControl("166", 2, 1, DataArray) ; (166_1)(Obj_Pum_BgColor)
      DataArray := Image_GuiControl("173", 0, 1, DataArray) ; (173_1)(Obj_Pum_MobileTxtColor)
      DataArray := Image_GuiControl("174", 0, 1, DataArray) ; (174_1)(Obj_Pum_MobileBgColor)
      ; -------------------------------------------
      DataArray := Image_GuiControl("177", 1, 1, DataArray) ; (177_1)(Obj_Pum_BgTrans)
      DataArray := Image_GuiControl("178", 1, 0, DataArray) ; (178_1)(Obj_Pum_BgOpacityUp)
      DataArray := Image_GuiControl("179", 1, 0, DataArray) ; (179_1)(Obj_Pum_BgOpacityDown)
      DataArray := Image_GuiControl("180", 1, 1, DataArray) ; (180_1)(Obj_Pum_DisplayText_Opacity)
      ; -------------------------------------------
      BgColor_Opicity := DataArray.362.30 ; (362_30)(XmlBgOpacity [Background opacity] [0 - 100])
      GuiControl, PopUpMenu:, g_180, %BgColor_Opicity% ; (180_1)(Obj_Pum_DisplayText_Opacity)
      GuiControl, PopUpMenu:Show, g_180 ; (180_1)(Obj_Pum_DisplayText_Opacity)
      ; -------------------------------------------
    } ; End Selected
    ; -------------------------------------------
    else ; Not Selected
    {
      ; -------------------------------------------
      DataArray.366.5 := "pum_pumSetting_pumBgText" ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      ; -------------------------------------------
      DataArray := Image_GuiControl("177", 0, 1, DataArray) ; (177_1)(Obj_Pum_BgTrans)
      DataArray := Image_GuiControl("178", 0, 0, DataArray) ; (178_1)(Obj_Pum_BgOpacityUp)
      DataArray := Image_GuiControl("179", 0, 0, DataArray) ; (179_1)(Obj_Pum_BgOpacityDown)
      DataArray := Image_GuiControl("180", 0, 1, DataArray) ; (180_1)(Obj_Pum_DisplayText_Opacity)
      ; -------------------------------------------
      if (DataArray.362.24 == "1") ; (362_24)(Pum_MobileTextOnOff [1 = On, 0 Off])
      {
        DataArray := Image_GuiControl("173", 1, 1, DataArray) ; (173_1)(Obj_Pum_MobileTxtColor)
        DataArray := Image_GuiControl("174", 1, 1, DataArray) ; (174_1)(Obj_Pum_MobileBgColor)
      }
      ; -------------------------------------------
      DataArray := Image_GuiControl("166", 1, 1, DataArray) ; (166_1)(Obj_Pum_BgColor)
      ; -------------------------------------------
    } ; End Not Selected
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; -------------------------------------------
    DataArray := Pum_SelectedColorDisplay(DataArray)
    ; -------------------------------------------
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    DataArray := Image_GuiControl("004", 1, 0, DataArray) ; (004_1)(Obj_ok)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; -------------------------------------------
    Sys_EnableDisable("Enable") ; "Enable" or "Disable"
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    global PumLock := 0
    ; -------------------------------------------
  } ; End (PumLock == 0)
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
} ; End (166_1)(GUI Object: [pum] [pumBgColor])
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
