﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\Sys_EnableDisable.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_GuiControl.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Pum_ColorVarConvert.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_ResizeImg.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_ResizePng.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_Combine.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
f_246(DataArray) ; (246_1)(Obj_Pum_ZoomIn)
{
  ; -------------------------------------------
  global PumLock
  if (PumLock == "")
  {
    ; -------------------------------------------
    global PumLock := 0
    ; -------------------------------------------
  }
  ; -------------------------------------------
  if (PumLock == 0)
  {
    ; -------------------------------------------
    global PumLock := 1
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    Sys_EnableDisable("Disable") ; "Enable" or "Disable"
    ; -------------------------------------------
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    DataArray := Image_GuiControl("004", 3, 0, DataArray) ; (004_1)(Obj_ok)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    { ; [START UP]  Vars
      ; -------------------------------------------
      { ; [GET] Vars
        ; -------------------------------------------
        ThisPumProcessFolder := DataArray.361.8 ; (361)(8)(ThisPumProcessFolder [Pum Folder Path])
        ; -------------------------------------------
        Img_W          := DataArray.362.34 ; (362_34)(Img_W)
        bg_Image_Type  := DataArray.362.38 ; (362_38)(Bg_Image_Type [C=Crop,F=Fit])
        Img_Gui_W      := DataArray.362.39 ; (362_39)(Img_Gui_W)
        Img_Gui_H      := DataArray.362.40 ; (362_40)(Img_Gui_H)
        Pum_Gui_W      := DataArray.362.44 ; (362_44)(Pum_Gui_W)
        Pum_Gui_H      := DataArray.362.45 ; (362_45)(Pum_Gui_H)
        Pum_Gui_X      := DataArray.362.46 ; (362_46)(Pum_Gui_X)
        Pum_Gui_Y      := DataArray.362.47 ; (362_47)(Pum_Gui_Y)
        Pum_Gui_Max_W  := DataArray.362.48 ; (362_48)(Pum_Gui_Max_W)
        Pum_Gui_Max_H  := DataArray.362.49 ; (362_49)(Pum_Gui_Max_H)
        Pum_Gui_Min_W  := DataArray.362.50 ; (362_50)(Pum_Gui_Min_W)
        Pum_Gui_Min_H  := DataArray.362.51 ; (362_51)(Pum_Gui_Min_H)
        bg_Selected_Rotate    := DataArray.362.54 ; (362_54)(bg_Selected_Rotate)
        ; -------------------------------------------
        XmlBgColor := DataArray.362.27 ; (362_27)(XmlBgColor [Background color])
        ; -------------------------------------------
        ; VarType = ("VarNum"(123),"ColorGrid"(A1),"HexColor"(FFFFFF),"MsColor"(1234546)) > [VarNum, ColorGrid, HexColor, MsColor]
        Color_Array := Pum_ColorVarConvert("MsColor", XmlBgColor, DataArray)
        Pum_BgColor_GridNum      := Color_Array.2
        ; -------------------------------------------
      } ; End [GET] Vars
      ; -------------------------------------------
      File_PumFrame := A_ProgramFiles "\PopUpMenu_PUM\image\pum\PumFrame.png" ; (365_2)(Current User language)
      ; -------------------------------------------
      bg_Selected_Gui     := ThisPumProcessFolder "\image\bg_Selected_Gui.png" ; (361)(8)(Pum [Specific Folder Path])
      ; -------------------------------------------
      Temp_Selected_Gui   := ThisPumProcessFolder "\image\Temp_Selected_Gui.png" ; (361)(8)(Pum [Specific Folder Path])
      ; -------------------------------------------
      Temp_Display_Img     := ThisPumProcessFolder "\image\Temp_Display_Img.png" ; (361)(8)(Pum [Specific Folder Path])
      ; -------------------------------------------
      File_Pum_Gui       := ThisPumProcessFolder "\image\File_Pum_Gui.png" ; (361)(8)(Pum [Specific Folder Path])
      ; -------------------------------------------
    } ; End [START UP] Vars
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; -------------------------------------------
    GuiControl, PopUpMenu:Hide, g_102 ; (102_1)(Obj_DisplayedIcon)
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    FileDelete, %bg_Temp_Txt%
    ; -------------------------------------------
    ;
    if (Pum_Gui_X <= 0.9999999999999999999999999999999999999999)
    {
      Pum_Gui_X := 0
    }
    if (Pum_Gui_Y <= 0.9999999999999999999999999999999999999999)
    {
      Pum_Gui_Y := 0
    }
    ; -------------------------------------------
    if (Pum_Gui_W > Pum_Gui_Min_W && Pum_Gui_H > Pum_Gui_Min_H)
    {
      ; -------------------------------------------
      Temp_Display_Txt_Img := ThisPumProcessFolder "\image\Temp_Display_Txt_Img.png" ; (361)(8)(Pum [Specific Folder Path])
      FileDelete, %Temp_Display_Txt_Img%
      ; -------------------------------------------
      ;
      ; -------------------------------------------
      DataArray := Image_GuiControl("246", 2, 0, DataArray) ; (246_1)(Obj_Pum_ZoomIn)
      ; -------------------------------------------
      Factor := Pum_Gui_H / Pum_Gui_W
      Pum_Gui_W := Pum_Gui_W - 20
      Pum_Gui_H := Factor * Pum_Gui_W
      ; ------------------------------------------
      if (Pum_Gui_X <= 0.9999999999999999999999999999999999999999)
      {
        Pum_Gui_X := 0
      }
      if (Pum_Gui_Y <= 0.9999999999999999999999999999999999999999)
      {
        Pum_Gui_Y := 0
      }
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> (Zoom In)
      { ; [NEED] (Pum_Gui_[W,H]) (File_PumFrame) | [CREATE] (File_Pum_Gui.png)
        ; -------------------------------------------
        FileDelete, %File_Pum_Gui%
        ; -------------------------------------------
        Image_ResizeImg(Pum_Gui_W, Pum_Gui_H, File_PumFrame, File_Pum_Gui) ; New_W, New_H, ImageIn, ImageOut > 1 / 0
        ; -------------------------------------------
      } ; End [NEED] (Pum_Gui_[W,H]) (File_PumFrame) | [CREATE] (File_Pum_Gui.png)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> (Zoom In)
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> (Zoom In)
      { ; [NEED] (Img_Gui_[W,H]) (Pum_Gui_[X,Y]) | [SET] (Spacer_Img_[X,Y]) | [SET] (Spacer_Pum_[X,Y])
        ; -------------------------------------------
        Spacer_Img_X := (300 - Img_Gui_W) / 2
        Spacer_Img_Y := (300 - Img_Gui_H) / 2
        ; -------------------------------------------
        Spacer_Pum_X := (Pum_Gui_X + Spacer_Img_X)
        Spacer_Pum_Y := (Pum_Gui_Y + Spacer_Img_Y)
        ; -------------------------------------------
      } ; End [NEED] (Img_Gui_[W,H]) (Pum_Gui_[X,Y]) | [SET] (Spacer_Img_[X,Y]) | [SET] (Spacer_Pum_[X,Y])
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> (Zoom In)
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> (Zoom In)
      { ; [NEED] (Temp_Selected_Gui.png) (File_Pum_Gui.png) (Spacer_[X,Y])) | [Create] (Temp_Display_Img.png)
        ; -------------------------------------------
        Temp_Resize := A_ProgramFiles "\PopUpMenu_PUM\image\pum\pum_" Pum_BgColor_GridNum "_100.png"
        ; -------------------------------------------
        TxT_Gui_C := ThisPumProcessFolder "\image\File_TxT_Gui_C.png"
        FileDelete, %TxT_Gui_C%
        ; -------------------------------------------
        Image_ResizePng(Img_Gui_W , Img_Gui_H, Temp_Resize, TxT_Gui_C) ; Resize_W, Resize_H, ImageIn, ImageOut > 1 / 0
        ; -------------------------------------------
        FileDelete, %Temp_Display_Img%
        if !FileExist(Temp_Selected_Gui)
        {
          FileCopy, %bg_Selected_Gui%, %Temp_Selected_Gui%, 1
          Sleep, 10
        }
        ; -------------------------------------------
        Image_Array := [300, 300, Temp_Display_Img, TxT_Gui_C, Spacer_Img_X, Spacer_Img_Y, Temp_Selected_Gui, Spacer_Img_X, Spacer_Img_Y, File_Pum_Gui, Spacer_Pum_X, Spacer_Pum_Y]
        Image_Combine(Image_Array)
        FileDelete, %TxT_Gui_C%
        ; -------------------------------------------
      } ; End [NEED] (Temp_Selected_Gui.png) (File_Pum_Gui.png) (Spacer_[X,Y])) | [Create] (Temp_Display_Img.png)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; (246_1)(GUI Object: Crop Zoom In)
      ;
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      GuiControl, PopUpMenu:, g_254, %Temp_Display_Img% ; (254_1)(Obj_MsgImg300x300)
      GuiControl, PopUpMenu:Show, g_254 ; (254_1)(Obj_MsgImg300x300)
      DataArray.254.3 := Temp_Display_Img ; (254_3)(Obj_MsgImg300x300_Img [Image Path])
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ;
      ; (Crop Zoom In)
      ;
      if (DataArray.362.54 == "") ; (362_54)(bg_Selected_Rotate)
      {
        DataArray.362.54 := 0 ; (362_54)(bg_Selected_Rotate)
      }
      ; -------------------------------------------
      if (DataArray.362.52 == "" or DataArray.362.52 == 0 or DataArray.362.52 == 1) ; (362_52)(bg_Selected_Change)
      {
        DataArray.362.52 := 2 ; (362_52)(bg_Selected_Change)
      }
      Pum_Factor := DataArray.362.34 / DataArray.362.39 ; (362_34)(Img_W)/(362_39)(Img_Gui_W)
      DataArray.362.55 := Pum_Factor * DataArray.362.46 ; (362_55)(Pum_X)/(362_46)(Pum_Gui_X)
      DataArray.362.56 := Pum_Factor * DataArray.362.47 ; (362_56)(Pum_Y)/(362_47)(Pum_Gui_Y)
      ; -------------------------------------------
      DataArray := Image_GuiControl("004", 1, 0, DataArray) ; (004_1)(Obj_ok)
      ; -------------------------------------------
      ;
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      { ; [UPDATE] Vars
        ; -------------------------------------------
        DataArray.361.8  := ThisPumProcessFolder ; (361)(8)(ThisPumProcessFolder [Pum Folder Path])
        ; -------------------------------------------
        DataArray.362.34 := Img_W ; (362_34)(Img_W)
        DataArray.362.38 := bg_Image_Type ; (362_38)(Bg_Image_Type [C=Crop,F=Fit])
        DataArray.362.39 := Img_Gui_W ; (362_39)(Img_Gui_W)
        DataArray.362.40 := Img_Gui_H ; (362_40)(Img_Gui_H)
        DataArray.362.44 := Pum_Gui_W ; (362_44)(Pum_Gui_W)
        DataArray.362.45 := Pum_Gui_H ; (362_45)(Pum_Gui_H)
        DataArray.362.46 := Pum_Gui_X ; (362_46)(Pum_Gui_X)
        DataArray.362.47 := Pum_Gui_Y ; (362_47)(Pum_Gui_Y)
        DataArray.362.48 := Pum_Gui_Max_W ; (362_48)(Pum_Gui_Max_W)
        DataArray.362.49 := Pum_Gui_Max_H ; (362_49)(Pum_Gui_Max_H)
        DataArray.362.50 := Pum_Gui_Min_W ; (362_50)(Pum_Gui_Min_W)
        DataArray.362.51 := Pum_Gui_Min_H ; (362_51)(Pum_Gui_Min_H)
        ; -------------------------------------------
        DataArray.362.27 := XmlBgColor ; (362_27)(XmlBgColor [Background color])
        ; -------------------------------------------
      } ; End [UPDATE] Vars
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
    } ; End (Pum_Gui_W > Pum_Gui_Min_W && Pum_Gui_H > Pum_Gui_Min_H)
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    { ; [SHOW-HIDE] Controls
      ; -------------------------------------------
      DataArray := Image_GuiControl("182", 1, 0, DataArray) ; (182_1)(Obj_Pum_BgRotateLeft)
      DataArray := Image_GuiControl("183", 1, 0, DataArray) ; (183_1)(Obj_Pum_BgRotateRight)
      ; -------------------------------------------
      if (bg_Image_Type == "C") ; Image is a Crop
      {
        ; -------------------------------------------
        DataArray.241.3 := "" ; (241_3)(Obj_Pum_CropLeft_Img [Image Path])
        DataArray.242.3 := "" ; (242_3)(Obj_Pum_CropRight_Img [Image Path])
        DataArray.243.3 := "" ; (243_3)(Obj_Pum_CropUp_Img [Image Path])
        DataArray.244.3 := "" ; (244_3)(Obj_Pum_CropDown_Img [Image Path])
        DataArray.245.3 := "" ; (245_3)(Obj_Pum_CropCenter_Img [Image Path])
        DataArray.246.3 := "" ; (246_3)(Obj_Pum_ZoomIn_Img [Image Path])
        DataArray.247.3 := "" ; (247_3)(Obj_Pum_ZoomOut_Img [Image Path])
        ; -------------------------------------------
        DataArray := Image_GuiControl("167", 1, 1, DataArray) ; (167_1)(Obj_Pum_BgFitImage)
        ; -------------------------------------------
        if (Pum_Gui_X <= 0.9999999999999999999999999999999999999999)
        {
          Pum_Gui_X := 0
        }
        if (Pum_Gui_Y <= 0.9999999999999999999999999999999999999999)
        {
          Pum_Gui_Y := 0
        }
        ; -------------------------------------------
        if (Pum_Gui_X == 0)
        {
          DataArray := Image_GuiControl("241", 0, 0, DataArray) ; (241_1)(Obj_Pum_CropLeft)
        }
        else
        {
          DataArray := Image_GuiControl("241", 1, 0, DataArray) ; (241_1)(Obj_Pum_CropLeft)
        }
        ; -------------------------------------------
        if ((Pum_Gui_X + Pum_Gui_W) >= Img_Gui_W)
        {
          DataArray := Image_GuiControl("242", 0, 0, DataArray) ; (242_1)(Obj_Pum_CropRight)
        }
        else
        {
          DataArray := Image_GuiControl("242", 1, 0, DataArray) ; (242_1)(Obj_Pum_CropRight)
        }
        ; -------------------------------------------
        if (Pum_Gui_Y == 0)
        {
          DataArray := Image_GuiControl("243", 0, 0, DataArray) ; (243_1)(Obj_Pum_CropUp)
        }
        else
        {
          DataArray := Image_GuiControl("243", 1, 0, DataArray) ; (243_1)(Obj_Pum_CropUp)
        }
        ; -------------------------------------------
        if ((Pum_Gui_Y + Pum_Gui_H) >= Img_Gui_H)
        {
          DataArray := Image_GuiControl("244", 0, 0, DataArray) ; (244_1)(Obj_Pum_CropDown)
        }
        else
        {
          DataArray := Image_GuiControl("244", 1, 0, DataArray) ; (244_1)(Obj_Pum_CropDown)
        }
        ; -------------------------------------------
        DataArray := Image_GuiControl("245", 1, 0, DataArray) ; (245_1)(Obj_Pum_CropCenter)
        ; -------------------------------------------
        if ((Pum_Gui_W > Pum_Gui_Min_W && Pum_Gui_W < Pum_Gui_Max_W) && (Pum_Gui_H > Pum_Gui_Min_H && Pum_Gui_H < Pum_Gui_Max_H))
        {
          DataArray := Image_GuiControl("246", 1, 0, DataArray) ; (246_1)(Obj_Pum_ZoomIn)
          DataArray := Image_GuiControl("247", 1, 0, DataArray) ; (247_1)(Obj_Pum_ZoomOut)
        }
        else if ((Pum_Gui_W > Pum_Gui_Min_W) && (Pum_Gui_H > Pum_Gui_Min_H))
        {
          DataArray := Image_GuiControl("246", 1, 0, DataArray) ; (246_1)(Obj_Pum_ZoomIn)
          DataArray := Image_GuiControl("247", 0, 0, DataArray) ; (247_1)(Obj_Pum_ZoomOut)
        }
        else if ((Pum_Gui_W < Pum_Gui_Max_W) && (Pum_Gui_H < Pum_Gui_Max_H))
        {
          DataArray := Image_GuiControl("246", 0, 0, DataArray) ; (246_1)(Obj_Pum_ZoomIn)
          DataArray := Image_GuiControl("247", 1, 0, DataArray) ; (247_1)(Obj_Pum_ZoomOut)
        }
        ; -------------------------------------------
      } ; End (bg_Image_Type == "C")
      ; -------------------------------------------
      else if (bg_Image_Type == "F") ; Image is a Crop
      {
        ; -------------------------------------------
        DataArray := Image_GuiControl("167", 2, 1, DataArray) ; (167_1)(Obj_Pum_BgFitImage)
        ; -------------------------------------------
        DataArray := Image_GuiControl("241", 0, 0, DataArray) ; (241_1)(Obj_Pum_CropLeft)
        DataArray := Image_GuiControl("242", 0, 0, DataArray) ; (242_1)(Obj_Pum_CropRight)
        DataArray := Image_GuiControl("243", 0, 0, DataArray) ; (243_1)(Obj_Pum_CropUp)
        DataArray := Image_GuiControl("244", 0, 0, DataArray) ; (244_1)(Obj_Pum_CropDown)
        DataArray := Image_GuiControl("245", 0, 0, DataArray) ; (245_1)(Obj_Pum_CropCenter)
        DataArray := Image_GuiControl("246", 0, 0, DataArray) ; (246_1)(Obj_Pum_ZoomIn)
        DataArray := Image_GuiControl("247", 0, 0, DataArray) ; (247_1)(Obj_Pum_ZoomOut)
      } ; End (bg_Image_Type == "F")
      ; -------------------------------------------
    } ; End [SHOW-HIDE] Controls
    ; -------------------------------------------
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    DataArray := Image_GuiControl("004", 1, 0, DataArray) ; (004_1)(Obj_ok)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; -------------------------------------------
    Sys_EnableDisable("Enable") ; "Enable" or "Disable"
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    global PumLock := 0
    ; -------------------------------------------
  } ; End (PumLock == 0)
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
} ; (246_1)(GUI Object: Crop Zoom In)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
