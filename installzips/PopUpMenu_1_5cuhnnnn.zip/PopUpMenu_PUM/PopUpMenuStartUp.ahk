﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
#NoTrayIcon
#SingleInstance, Force
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; (Current User) StartLoad (PopUpMenuStartUp.txt)
; is the Load PopUpMenu at Windows Login
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
PumSystemFolder := A_AppData "\PopUpMenu_PUM\system"
if !FileExist(PumSystemFolder)
{
  FileCreateDir, %PumSystemFolder%
} ; [End] if !FileExist(PumSystemFolder)
; -------------------------------------------
PopUpMenuStartUp := PumSystemFolder "\PopUpMenuStartUp.txt"
; -------------------------------------------
if !FileExist(PopUpMenuStartUp) ; (PopUpMenuStartUp.txt) (DOES NOT Exist)
{
  ; -------------------------------------------
  StartLoad := 1 ; DO NOT Load at Windows Startup
  ; -------------------------------------------
  FileEncoding, UTF-8
  FileAppend, %StartLoad%, %PopUpMenuStartUp% ; 20127 us-ascii US-ASCII (7-bit)
  ; -------------------------------------------
} ; [End] if !FileExist(PopUpMenuStartUp) ; (PopUpMenuStartUp.txt) (DOES NOT Exist)
else ; (PopUpMenuStartUp.txt) (Exist)
{
  ; -------------------------------------------
  FileReadLine, StartLoad, %PopUpMenuStartUp%, 1 ; FileReadLine, OutputVar, Filename, LineNum
  ; -------------------------------------------
  if (StartLoad != 1 && StartLoad != 2)
  {
    ; -------------------------------------------
    FileDelete, %PopUpMenuStartUp%
    Sleep, 10
    ; -------------------------------------------
    StartLoad := 1 ; DO NOT Load at Windows Startup
    ; -------------------------------------------
    FileEncoding, UTF-8
    FileAppend, %StartLoad%, %PopUpMenuStartUp% ; 20127 us-ascii US-ASCII (7-bit)
    ; -------------------------------------------
  }
} ; [End] else ; (PopUpMenuStartUp.txt) (Exist)
; -------------------------------------------
; (Current User) StartLoad (PopUpMenu.lnk)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; -------------------------------------------
if (StartLoad == 2) ; Load at Windows Startup
{
  ; -------------------------------------------
  StartMenuCommonPopUpMenuLink := A_StartMenuCommon "\Programs\PopUpMenu\PopUpMenu.lnk"
  if FileExist(StartMenuCommonPopUpMenuLink)
  {
    Run, %StartMenuCommonPopUpMenuLink%
  }
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
