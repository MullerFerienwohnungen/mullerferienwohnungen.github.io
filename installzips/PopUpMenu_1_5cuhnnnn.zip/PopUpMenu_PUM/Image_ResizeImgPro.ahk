#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_ResizeImg.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_Combine.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; Resize Image Keeping the Image Proportions 
;
Image_ResizeImgPro(Target_W, Target_H, ImageToResizePro) ; Target_W, Target_H, ImageToResizePro > ImageToResizePro
{
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; [RESIZE IMAGE]
  ; -------------------------------------------
  SplitPath, ImageToResizePro, Image_ExtName, Image_Folder, Image_Extension, Image_Name
  ; -------------------------------------------
  ;
  ; -------------------------------------------
  Gui, ImageSize:Add, Picture, hwndJustForSize, %ImageToResizePro% ; (368_5)(Selected Pum Background [Full Path])
  ControlGetPos, , , Image_W, Image_H, , ahk_id %JustForSize% ; (368_6)(Pum Background Image X_Width)/(368_7)(Pum Background Image Y_Height)
  ; -------------------------------------------
  ;
	; -------------------------------------------
  if (Image_W != Target_W or Image_H != Target_H)
  {
  	; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  	; [RESIZE Blank Trans] to Target_W x Target_H
  	; -------------------------------------------
  	Image_SquareBlank      := A_ProgramFiles "\PopUpMenu_PUM\image\ico\SquareBlank.png"
  	ImageToResizePro_BG   := A_Temp "\ImageToResizePro_BG.png"
		if FileExist(ImageToResizePro_BG)
		{
			FileDelete, %ImageToResizePro_BG%
		}
		; -------------------------------------------
		;
  	; -------------------------------------------
  	Image_ResizeImg(Target_W, Target_H, Image_SquareBlank, ImageToResizePro_BG)
  	; -------------------------------------------
  	; [RESIZE Blank Trans] to Target_W x Target_H
  	; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  	;
  	; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  	; [RESIZE] (ImageToResizePro) Proportionally to Target_W/Target_H
  	; -------------------------------------------
  	if (Target_W == Target_H)
  	{
		  if (Image_W > Image_H)
		  {
  			; -------------------------------------------
			  New_Image_W := Target_W
			  New_Image_H := Round((Image_H / Image_W) * Target_W)
			  ; -------------------------------------------
			  Position_X := 0
			  Position_Y := (Target_H - New_Image_H) * 0.5
			  ; -------------------------------------------
		  }
		  else if (Image_H > Image_W)
		  {
  			; -------------------------------------------
			  New_Image_W := Round((Image_W / Image_H) * Target_W)
			  New_Image_H := Target_H
			  ; -------------------------------------------
			  Position_X := (Target_W - New_Image_W) * 0.5
			  Position_Y := 0
			  ; -------------------------------------------
		  }
		  else if (Image_H == Image_W)
		  {
  			; -------------------------------------------
			  New_Image_W := Target_W
			  New_Image_H := Target_H
			  ; -------------------------------------------
			  Position_X := 0
			  Position_Y := 0
			  ; -------------------------------------------
		  }
	  } ; if (Target_W == Target_H)
	  ; -------------------------------------------
	  else if (Target_W > Target_H)
	  {
  		if (Image_W > Image_H)
		  {
  			; -------------------------------------------
			  New_Image_W := Target_W
			  New_Image_H := Round((Image_H / Image_W) * Target_W)
			  ; -------------------------------------------
			  Position_X := 0
			  Position_Y := (Target_H - New_Image_H) * 0.5
			  ; -------------------------------------------
		  }
		  else if (Image_H > Image_W)
		  {
  			; -------------------------------------------
			  New_Image_W := Round((Image_W / Image_H) * Target_H)
			  New_Image_H := Target_H
			  ; -------------------------------------------
			  Position_X := (Target_W - New_Image_W) * 0.5
			  Position_Y := 0
			  ; -------------------------------------------
		  }
		  else if (Image_W == Image_H)
		  {
  			; -------------------------------------------
			  New_Image_W := Target_H
			  New_Image_H := Target_H
			  ; -------------------------------------------
			  Position_X := (Target_W - New_Image_W) * 0.5
			  Position_Y := 0
			  ; -------------------------------------------
		  }
	  } ; if (Target_W == Target_H)
	  ; -------------------------------------------
	  else if (Target_H > Target_W)
	  {
  		if (Image_W > Image_H)
		  {
  			; -------------------------------------------
			  New_Image_W := Target_W
			  New_Image_H := Round((Image_H / Image_W) * Target_W)
			  ; -------------------------------------------
			  Position_X := 0
				Position_Y := Target_H - New_Image_W
			  ; -------------------------------------------
		  }
		  else if (Image_H > Image_W)
		  {
  			; -------------------------------------------
			  New_Image_W := Round((Image_W / Image_H) * Target_H)
			  New_Image_H := Target_H
			  ; -------------------------------------------
			  Position_X := (Target_W - New_Image_W) * 0.5
			  Position_Y := 0
			  ; -------------------------------------------
		  }
		  else if (Image_W == Image_H)
		  {
  			; -------------------------------------------
			  New_Image_W := Target_W
			  New_Image_H := Target_W
			  ; -------------------------------------------
			  Position_X := 0
			  Position_Y := (Target_H - Target_W) * 0.5
			  ; -------------------------------------------
		  }
	  } ; if (Target_W == Target_H)
	  ; -------------------------------------------
	  ;
	  ; -------------------------------------------
	  Image_ResizeImg(New_Image_W, New_Image_H, ImageToResizePro, ImageToResizePro)
	  ; -------------------------------------------
	  ; [RESIZE] (ImageToResizePro) Proportionally to Target_W/Target_H
	  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	  ;
	  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	  ; [COMBIME IMAGES] 
	  ; -------------------------------------------
	  ImageToResizePro_Temp := A_Temp "\" Image_Name "_Temp.png"
	  ; ------------------------------------------
	  Image_Array := [Target_W, Target_H, ImageToResizePro_Temp, ImageToResizePro, Position_X, Position_Y, ImageToResizePro_BG, 0, 0]
	  Image_Combine(Image_Array)
	  ; -------------------------------------------
	  FileMove, %ImageToResizePro_Temp%, %ImageToResizePro%, 1
	  Sleep, 100
	  ; -------------------------------------------
	  FileDelete, %ImageToResizePro_BG%
	  Sleep, 100
	  ; -------------------------------------------
	  ; [COMBIME IMAGES] 
	  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>				
  } ; if (Image_W != Target_W or Image_H != Target_H)
  ; -------------------------------------------
	return ImageToResizePro
	; -------------------------------------------
} ; Function (Image_ResizeImgPro)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; END OF FILE
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
