﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Gosub, WindowsConstants
Debug=1
Debug_Success=1
;//TokenInformationClass:=TokenType
TokenInformationClass:=TokenElevationType
DllCall("SetLastError", "UInt", 0)
ret:=DllCall("Advapi32.dll\OpenProcessToken", "UInt", DllCall("GetCurrentProcess"), "UInt", TOKEN_QUERY, "UIntP", hToken)
;//NumGet_hToken:=NumGet(hToken)
msgbox.="`nret(" ret ") el(" errorlevel ") le(" A_LastError ")`t`tOpenProcessToken`t`thToken(" hToken ") NumGet_hToken(" NumGet_hToken ")"
DllCall("SetLastError", "UInt", 0)
DllCall("Advapi32.dll\GetTokenInformation"
  , "UInt", hToken					;//__in       HANDLE TokenHandle,
  , "UInt", TokenInformationClass		;//__in       TOKEN_INFORMATION_CLASS TokenInformationClass,
  , "Int", 0							;//__out_opt  LPVOID TokenInformation,
  , "Int", 0							;//__in       DWORD TokenInformationLength,
  , "UIntP", ReturnLength)			;//__out      PDWORD ReturnLength
msgbox.="`nret(" ret ") el(" errorlevel ") le(" A_LastError ")`t`tGetTokenInformation1`tReturnLength(" ReturnLength ") NumGet(" NumGet(ReturnLength) ")"
sizeof_elevationType:=VarSetCapacity(elevationType, ReturnLength, 0)
DllCall("SetLastError", "UInt", 0)
DllCall("Advapi32.dll\GetTokenInformation"
  , "UInt", hToken					;//__in       HANDLE TokenHandle,
  , "UInt", TokenInformationClass		;//__in       TOKEN_INFORMATION_CLASS TokenInformationClass,
  , "UIntP", elevationType			;//__out_opt  LPVOID TokenInformation,
  , "Int", sizeof_elevationType		;//__in       DWORD TokenInformationLength,
  , "UIntP", ReturnLength)			;//__out      PDWORD ReturnLength
msgbox.="`nret(" ret ") el(" errorlevel ") le(" A_LastError ")`t`tGetTokenInformation2`televationType(" elevationType ")"
if ((Debug && elevationType="") || (Debug_Success && elevationType!="")) {
  debuginfo=
  (LTrim
    `n`n*** DEBUG ***
    TokenInformationClass(%TokenInformationClass%)
    elevationType(%elevationType%) sizeof_elevationType(%sizeof_elevationType%)
    ReturnLength(%ReturnLength%) NumGet_ReturnLength(%NumGet_ReturnLength%)
    %msgbox%
    *** /DEBUG ***
  )
}
if (elevationType=TokenElevationTypeDefault)
{
  ThisUserHasAdminRights := 0
}
else if (elevationType=TokenElevationTypeFull)
{
  ThisUserHasAdminRights := 1
}
else if (elevationType=TokenElevationTypeLimited)
{
  ThisUserHasAdminRights := 1
}
else
{
  ThisUserHasAdminRights := 0
}
if (hToken)
{
  DllCall("CloseHandle", "UInt", hToken)
}
; -------------------------------------------
CheckFolder := A_Temp "\PopUpMenuTempFolder"
if !FileExist(CheckFolder)
{
  FileCreateDir, %CheckFolder%
}
; -------------------------------------------
File_HasAdminRights := A_Temp "\PopUpMenuTempFolder\HasAdminRights.txt"
if FileExist(File_HasAdminRights)
{
  FileDelete, %File_HasAdminRights%
}
; -------------------------------------------
FileEncoding, UTF-8 ; UTF-8
FileAppend, %ThisUserHasAdminRights%`n, %File_HasAdminRights% ; UTF-8
FileAppend, %A_UserName%`n, %File_HasAdminRights% ; UTF-8
; -------------------------------------------
BreakTime := A_TickCount + 2000
while !FileExist(File_HasAdminRights)
{
  if (A_TickCount > BreakTime)
  {
    break
  }
  Sleep, 100
}
; -------------------------------------------
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
WindowsConstants:
TOKEN_QUERY:=0x0008
TokenElevationTypeDefault:=1
TokenElevationTypeFull:=2
TokenElevationTypeLimited:=3
TokenType:=8
TokenElevationType:=18
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
