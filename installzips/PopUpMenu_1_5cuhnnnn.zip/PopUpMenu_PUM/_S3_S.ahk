﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\String_Reverse.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Url_ConnectCheck.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_GuiControl.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Array_ItemExist.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Default_Browser.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Gui_AdjustTextWidth.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\f_102.ahk ; (102_1)(Obj_DisplayedIcon)
#Include %A_ProgramFiles%\PopUpMenu_PUM\UIS.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Img_Mnu134.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Img_New135.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Img_Del135.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Img_Mnu137.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_ExeToPng.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_MultIconDisplay.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\CplMnu_MenuDisplay.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Img_OflIco.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Img_RunIco.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Img_RwhIco.ahk
; -------------------------------------------
#Include %A_ProgramFiles%\PopUpMenu_PUM\Img_Error440.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Img_Error450.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Img_Error460.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Img_Error470.ahk
; -------------------------------------------
#Include %A_ProgramFiles%\PopUpMenu_PUM\Url_GetUrl.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
_S3_S(DataArray)
{
  ; -------------------------------------------
  /*
  ; -------------------------------------------
  FontColor := "199524" ; Green
  FontColor := "a30404" ; Red
  FontColor := "000000" ; Black
  FontColor := "921297" ; Purple
  FontColor := "040e47" ; Blue
  ; -------------------------------------------
  */
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; -------------------------------------------
  UserPictureFolder := DataArray.363.12 ; (363_12)(ThisUserPictureFolder)
  ; -------------------------------------------
  Key_ArrayNumbers := DataArray.301.2 ; (301_2)(Key_ArrayNumbers [Array])
  ; -------------------------------------------
  ofl_FolderPathName := DataArray.303.2 ; (303_2)(ofl_FolderPathName [Folder Name With Path])
  Reversed_String_1 := String_Reverse(ofl_FolderPathName)
  Backslash_Position := InStr(Reversed_String_1, "\")
  Reversed_String_2 := SubStr(Reversed_String_1, 1, Backslash_Position - 1)
  ofl_FolderName := String_Reverse(Reversed_String_2)
  DataArray.303.3 := ofl_FolderName ; (303_3)(ofl_FolderName [Folder Name NO Path])
  ; -------------------------------------------
  HasConnection := Url_ConnectCheck(flag=0x40)
  ; -------------------------------------------
  ;
  LimitedArray := DataArray.363.9 ; (363_9)(LinitDataArray [Limited DataArray])
  if (LimitedArray == "")
  {
    LimitedArray := DataArray
  }
  ;
  for Index, ThisItem in LimitedArray
  {
    ; -------------------------------------------
    ThisItem := ThisItem.1
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (ThisItem == "GuiVarEnd")
    {
      break
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_001_1") ; (001_1)(Obj_KeyOflRunRwh_1RAppIco)
    {
      ; Image_ExeToPng.ahk
      ; Image_MultIconDisplay.ahk
      ; PopUpMenu
      ; _Include.ahk
      ; _S2_H.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_002_1") ; (002_1)(Obj_KeyOflRunRwh_2RAppIco)
    {
      ; Image_ExeToPng.ahk
      ; Image_MultIconDisplay.ahk
      ; PopUpMenu
      ; _Include.ahk
      ; _S2_H.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_003_1") ; (003_1)(Obj_KeyOfl_3RAppIco)
    {
      ; Image_ExeToPng.ahk
      ; Image_MultIconDisplay.ahk
      ; PopUpMenu
      ; _Include.ahk
      ; _S2_H.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_004_1") ; (004_1)(Obj_ok)
    {
      ; -------------------------------------------
      ; [ScriptError = 0] (No Error)
      ; [ScriptError = 2] (rwh)(No Application to Open File)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; [ScriptError = 21] (url)(Right Clicked Existing url Shortcut, NO Browser Active)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.133.2 == 2 or DataArray.366.6 == 13 or DataArray.366.6 == 21) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])/(366_6)(ScriptError [Integer])
      {
        ThisImage := A_ProgramFiles "\PopUpMenu_PUM\image\gui\(004)_1.png"
        GuiControl, PopUpMenu:, g_004, %ThisImage% ; (004_1)(Obj_ok)
        GuiControl, PopUpMenu:Show, g_004 ; (004_1)(Obj_ok)
        DataArray.4.2 := 1 ; (004_2)(Obj_ok_Sel [0,1,3])
        DataArray.4.3 := ThisImage ; (004_3)(Obj_ok_Img [Image Path])
      }
      else
      {
        ; -------------------------------------------
      ; [ScriptError = 1] (run)(rwh)(Application Target [exe] File Not Found)
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 4] (xxx)(Enpty Icon Grid Selected)
      ; [ScriptError = 5] (mnu)(Addon Not Installed)(Addon is Available)
      ; [ScriptError = 6] (ofl)(Folder Not Found)
      ; [ScriptError = 7] (mnu_cpl_key)(No Error)(Country Image)
      ; [ScriptError = 8] (run_rwh_url_ofl)(No Error)(Country Image)
      ; [ScriptError = 9] (mnu)(No Error)(Menu Bar Item Not Selected)
      ; [ScriptError = 10] (mnu)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError = 11] (cpl)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError = 12] (mnu)(Addon Not Installed)(Addon Not Available)(Addon HAS Been Requested)
      ; [ScriptError = 14] (cpl)(No Error)(Menu Bar Item Not Selected)
      ; [ScriptError = 15] (url)(No Selected URL)
      ; [ScriptError = 17] (mnu)(Addon Not Installed)(Addon Not Available)(Addon Not Been Requested)
      ; [ScriptError = 18] (url)(Source Not Found)
      ; [ScriptError = 19] (url)(No Internet Connection)
      ; [ScriptError = 20] (AppProcessName = "windows")
      ; [ScriptError = 21] (url)(Previous URL Does Not Match Current URL)
      ; [ScriptError = 22] (pumtom)(No Error)
      ; -------------------------------------------
        ThisImage := A_ProgramFiles "\PopUpMenu_PUM\image\gui\(004)_3.png"
        GuiControl, PopUpMenu:, g_004, %ThisImage% ; (004_1)(Obj_ok)
        GuiControl, PopUpMenu:Show, g_004 ; (004_1)(Obj_ok)
        DataArray.4.2 := 3 ; (004_2)(Obj_ok_Sel [0,1,3])
        DataArray.4.3 := ThisImage ; (004_3)(Obj_ok_Img [Image Path])
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_005_1") ; (005_1)(ORG_ScriptType)
    {
      ; Image_MultIconDisplay.ahk
      ; PopUpMenu
      ; _Include.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_006_1") ; (006_1)(Obj_ShortcutToDefaultPum)
    {
      ; -------------------------------------------
      ThisPumProcessXml := DataArray.361.9 ; (361)(9)(ThisPumProcessXml [Full File Path])
      ; -------------------------------------------
      if (InStr(ThisPumProcessXml, "\pumdefault\") == 0) ; (Default Pum NOT Active is Active)
      {
        if (DataArray.366.5 == "xxx") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (DataArray.305.18 != 1) ; (305_18)(Run_CatPaw [0,1][Selected Shortcut is to the CatPaw])
          {
            if (DataArray.305.17 != 1) ; (305_17)(Run_DefaultPum [0,1][Selected Shortcut is to the Default pum])
            {
              DataArray := Image_GuiControl("006", 1, 1, DataArray) ; (006_1)(Obj_ShortcutToDefaultPum)
            }
            else if (DataArray.305.17 == 1) ; (305_17)(Run_DefaultPum [0,1][Selected Shortcut is to the Default pum])
            {
              DataArray := Image_GuiControl("006", 2, 1, DataArray) ; (006_1)(Obj_ShortcutToDefaultPum)
            }
          }
        } ; [End] (ScriptType [xxx])
      } ; [End] (Default Pum NOT Active is Active)
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_007_1") ; (007_1)(Obj_KeyOfl_RFolderImage)
    {
      ; Image_ExeToPng.ahk
      ; Image_MultIconDisplay.ahk
      ; PopUpMenu
      ; _Include.ahk
      ; _S2_H.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_008_1") ; (008_1)(Obj_Key_Alt)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          ; -------------------------------------------
          if (Array_ItemExist(Key_ArrayNumbers, "(008)") == 0 && Array_ItemExist(Key_ArrayNumbers, "(010)") == 0 && Array_ItemExist(Key_ArrayNumbers, "(011)") == 0)
          {
            DataArray := Image_GuiControl("008", 1, 1, DataArray) ; (008_1)(Obj_Key_Alt)
          }
          else
          {
            if (Array_ItemExist(Key_ArrayNumbers, "(009)") == Array_ItemExist(Key_ArrayNumbers, "(012)"))
            {
              DataArray := Image_GuiControl("008", 2, 1, DataArray) ; (008_1)(Obj_Key_Alt)
            }
            else
            {
              DataArray := Image_GuiControl("008", 3, 1, DataArray) ; (008_1)(Obj_Key_Alt)
            }
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_009_1") ; (009_1)(Obj_Key_AltDown)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (Array_ItemExist(Key_ArrayNumbers, "(009)") == 0)
          {
            DataArray := Image_GuiControl("009", 1, 0, DataArray) ; (009_1)(Obj_Key_AltDown)
          }
          else if (Array_ItemExist(Key_ArrayNumbers, "(012)") == 0)
          {
            DataArray := Image_GuiControl("009", 3, 0, DataArray) ; (009_1)(Obj_Key_AltDown)
          }
          else if (Array_ItemExist(Key_ArrayNumbers, "(012)") == 1)
          {
            DataArray := Image_GuiControl("009", 2, 0, DataArray) ; (009_1)(Obj_Key_AltDown)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_010_1") ; (010_1)(Obj_Key_AltLeft)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (Array_ItemExist(Key_ArrayNumbers, "(009)") == Array_ItemExist(Key_ArrayNumbers, "(012)"))
          {
            if (Array_ItemExist(Key_ArrayNumbers, "(010)") > 0)
            {
              DataArray := Image_GuiControl("010", 2, 0, DataArray) ; (010_1)(Obj_Key_AltLeft)
            }
            else
            {
              DataArray := Image_GuiControl("010", 1, 0, DataArray) ; (010_1)(Obj_Key_AltLeft)
            }
          }
          else
          {
            if (Array_ItemExist(Key_ArrayNumbers, "(010)") > 0)
            {
              DataArray := Image_GuiControl("010", 3, 0, DataArray) ; (010_1)(Obj_Key_AltLeft)
            }
            else
            {
              DataArray := Image_GuiControl("010", 1, 0, DataArray) ; (010_1)(Obj_Key_AltLeft)
            }
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_011_1") ; (011_1)(Obj_Key_AltRight)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          ; -------------------------------------------
          if (Array_ItemExist(Key_ArrayNumbers, "(009)") == Array_ItemExist(Key_ArrayNumbers, "(012)"))
          {
            if (Array_ItemExist(Key_ArrayNumbers, "(011)") > 0)
            {
              DataArray := Image_GuiControl("011", 2, 0, DataArray) ; (011_1)(Obj_Key_AltRight)
            }
            else
            {
              DataArray := Image_GuiControl("011", 1, 0, DataArray) ; (011_1)(Obj_Key_AltRight)
            }
          }
          else
          {
            if (Array_ItemExist(Key_ArrayNumbers, "(011)") > 0)
            {
              DataArray := Image_GuiControl("011", 3, 0, DataArray) ; (011_1)(Obj_Key_AltRight)
            }
            else
            {
              DataArray := Image_GuiControl("011", 1, 0, DataArray) ; (011_1)(Obj_Key_AltRight)
            }
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_012_1") ; (012_1)(Obj_Key_AltUp)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          ; -------------------------------------------
          if (Array_ItemExist(Key_ArrayNumbers, "(012)") == 0)
          {
            if (Array_ItemExist(Key_ArrayNumbers, "(009)") != 0)
            {
              DataArray := Image_GuiControl("012", 1, 0, DataArray) ; (012_1)(Obj_Key_AltUp)
            }
          }
          else
          {
            DataArray := Image_GuiControl("012", 2, 0, DataArray) ; (012_1)(Obj_Key_AltUp)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_013_1") ; (013_1)(Obj_Key_CapsLock)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (Array_ItemExist(Key_ArrayNumbers, "(013)") == 0)
          {
            DataArray := Image_GuiControl("013", 1, 1, DataArray) ; (013_1)(Obj_Key_CapsLock)
          }
          else
          {
            DataArray := Image_GuiControl("013", 2, 1, DataArray) ; (013_1)(Obj_Key_CapsLock)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_014_1") ; (014_1)(Obj_Key_CtrlDown)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (Array_ItemExist(Key_ArrayNumbers, "(014)") == 0)
          {
            DataArray := Image_GuiControl("014", 1, 0, DataArray) ; (014_1)(Obj_Key_CtrlDown)
          }
          else if (Array_ItemExist(Key_ArrayNumbers, "(017)") == 0)
          {
            DataArray := Image_GuiControl("014", 3, 0, DataArray) ; (014_1)(Obj_Key_CtrlDown)
          }
          else if (Array_ItemExist(Key_ArrayNumbers, "(017)") == 1)
          {
            DataArray := Image_GuiControl("014", 2, 0, DataArray) ; (014_1)(Obj_Key_CtrlDown)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_015_1") ; (015_1)(Obj_Key_CtrlLeft)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (Array_ItemExist(Key_ArrayNumbers, "(014)") == Array_ItemExist(Key_ArrayNumbers, "(017)"))
          {
            if (Array_ItemExist(Key_ArrayNumbers, "(015)") > 0)
            {
              DataArray := Image_GuiControl("015", 2, 0, DataArray) ; (015_1)(Obj_Key_CtrlLeft)
            }
            else
            {
              DataArray := Image_GuiControl("015", 1, 0, DataArray) ; (015_1)(Obj_Key_CtrlLeft)
            }
          }
          else
          {
            if (Array_ItemExist(Key_ArrayNumbers, "(015)") > 0)
            {
              DataArray := Image_GuiControl("015", 3, 0, DataArray) ; (015_1)(Obj_Key_CtrlLeft)
            }
            else
            {
              DataArray := Image_GuiControl("015", 1, 0, DataArray) ; (015_1)(Obj_Key_CtrlLeft)
            }
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_016_1") ; (016_1)(Obj_Key_CtrlRight)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (Array_ItemExist(Key_ArrayNumbers, "(014)") == Array_ItemExist(Key_ArrayNumbers, "(017)"))
          {
            if (Array_ItemExist(Key_ArrayNumbers, "(016)") > 0)
            {
              DataArray := Image_GuiControl("016", 2, 0, DataArray) ; (016_1)(Obj_Key_CtrlRight)
            }
            else
            {
              DataArray := Image_GuiControl("016", 1, 0, DataArray) ; (016_1)(Obj_Key_CtrlRight)
            }
          }
          else
          {
            if (Array_ItemExist(Key_ArrayNumbers, "(016)") > 0)
            {
              DataArray := Image_GuiControl("016", 3, 0, DataArray) ; (016_1)(Obj_Key_CtrlRight)
            }
            else
            {
              DataArray := Image_GuiControl("016", 1, 0, DataArray) ; (016_1)(Obj_Key_CtrlRight)
            }
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_017_1") ; (017_1)(Obj_Key_CtrlUp)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          ; -------------------------------------------
          if (Array_ItemExist(Key_ArrayNumbers, "(017)") == 0)
          {
            if (Array_ItemExist(Key_ArrayNumbers, "(014)") != 0)
            {
              DataArray := Image_GuiControl("017", 1, 0, DataArray) ; (017_1)(Obj_Key_CtrlUp)
            }
          }
          else
          {
            DataArray := Image_GuiControl("017", 2, 0, DataArray) ; (017_1)(Obj_Key_CtrlUp)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_018_1") ; (018_1)(Obj_Key_Enter)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (Array_ItemExist(Key_ArrayNumbers, "(018)") == 0)
          {
            DataArray := Image_GuiControl("018", 1, 1, DataArray) ; (018_1)(Obj_Key_Enter)
          }
          else
          {
            DataArray := Image_GuiControl("018", 2, 1, DataArray) ; (018_1)(Obj_Key_Enter)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_019_1") ; (019_1)(Obj_Key_EnterX2)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          IsInArray := Array_ItemExist(Key_ArrayNumbers, "(018)")
          DataArray := Image_GuiControl("019", IsInArray, 0, DataArray) ; (019_1)(Obj_Key_EnterX2)
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_020_1") ; (020_1)(Obj_Key_Esc)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (Array_ItemExist(Key_ArrayNumbers, "(020)") == 0)
          {
            DataArray := Image_GuiControl("020", 1, 1, DataArray) ; (020_1)(Obj_Key_Esc)
          }
          else
          {
            DataArray := Image_GuiControl("020", 2, 1, DataArray) ; (020_1)(Obj_Key_Esc)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_021_1") ; (021_1)(Obj_Key_EscX2)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          IsInArray := Array_ItemExist(Key_ArrayNumbers, "(020)")
          DataArray := Image_GuiControl("021", IsInArray, 0, DataArray) ; (021_1)(Obj_Key_EscX2)
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_022_1") ; (022_1)(Obj_Key_F1)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (Array_ItemExist(Key_ArrayNumbers, "(022)") == 0)
          {
            DataArray := Image_GuiControl("022", 1, 0, DataArray) ; (022_1)(Obj_Key_F1)
          }
          else
          {
            DataArray := Image_GuiControl("022", 2, 0, DataArray) ; (022_1)(Obj_Key_F1)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_023_1") ; (023_1)(Obj_Key_F2)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (Array_ItemExist(Key_ArrayNumbers, "(023)") == 0)
          {
            DataArray := Image_GuiControl("023", 1, 0, DataArray) ; (023_1)(Obj_Key_F2)
          }
          else
          {
            DataArray := Image_GuiControl("023", 2, 0, DataArray) ; (023_1)(Obj_Key_F2)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_024_1") ; (024_1)(Obj_Key_F3)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (Array_ItemExist(Key_ArrayNumbers, "(024)") == 0)
          {
            DataArray := Image_GuiControl("024", 1, 0, DataArray) ; (024_1)(Obj_Key_F3)
          }
          else
          {
            DataArray := Image_GuiControl("024", 2, 0, DataArray) ; (024_1)(Obj_Key_F3)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_025_1") ; (025_1)(Obj_Key_F4)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (Array_ItemExist(Key_ArrayNumbers, "(025)") == 0)
          {
            DataArray := Image_GuiControl("025", 1, 0, DataArray) ; (025_1)(Obj_Key_F4)
          }
          else
          {
            DataArray := Image_GuiControl("025", 2, 0, DataArray) ; (025_1)(Obj_Key_F4)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_026_1") ; (026_1)(Obj_Key_F5)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (Array_ItemExist(Key_ArrayNumbers, "(026)") == 0)
          {
            DataArray := Image_GuiControl("026", 1, 0, DataArray) ; (026_1)(Obj_Key_F5)
          }
          else
          {
            DataArray := Image_GuiControl("026", 2, 0, DataArray) ; (026_1)(Obj_Key_F5)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_027_1") ; (027_1)(Obj_Key_F6)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (Array_ItemExist(Key_ArrayNumbers, "(027)") == 0)
          {
            DataArray := Image_GuiControl("027", 1, 0, DataArray) ; (027_1)(Obj_Key_F6)
          }
          else
          {
            DataArray := Image_GuiControl("027", 2, 0, DataArray) ; (027_1)(Obj_Key_F6)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_028_1") ; (028_1)(Obj_Key_F7)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (Array_ItemExist(Key_ArrayNumbers, "(028)") == 0)
          {
            DataArray := Image_GuiControl("028", 1, 0, DataArray) ; (028_1)(Obj_Key_F7)
          }
          else
          {
            DataArray := Image_GuiControl("028", 2, 0, DataArray) ; (028_1)(Obj_Key_F7)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_029_1") ; (029_1)(Obj_Key_F8)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (Array_ItemExist(Key_ArrayNumbers, "(029)") == 0)
          {
            DataArray := Image_GuiControl("029", 1, 0, DataArray) ; (029_1)(Obj_Key_F8)
          }
          else
          {
            DataArray := Image_GuiControl("029", 2, 0, DataArray) ; (029_1)(Obj_Key_F8)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_030_1") ; (030_1)(Obj_Key_F9)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (Array_ItemExist(Key_ArrayNumbers, "(030)") == 0)
          {
            DataArray := Image_GuiControl("030", 1, 0, DataArray) ; (030_1)(Obj_Key_F9)
          }
          else
          {
            DataArray := Image_GuiControl("030", 2, 0, DataArray) ; (030_1)(Obj_Key_F9)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_031_1") ; (031_1)(Obj_Key_F10)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (Array_ItemExist(Key_ArrayNumbers, "(031)") == 0)
          {
            DataArray := Image_GuiControl("031", 1, 0, DataArray) ; (031_1)(Obj_Key_F10)
          }
          else
          {
            DataArray := Image_GuiControl("031", 2, 0, DataArray) ; (031_1)(Obj_Key_F10)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_032_1") ; (032_1)(Obj_Key_F11)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (Array_ItemExist(Key_ArrayNumbers, "(032)") == 0)
          {
            DataArray := Image_GuiControl("032", 1, 0, DataArray) ; (032_1)(Obj_Key_F11)
          }
          else
          {
            DataArray := Image_GuiControl("032", 2, 0, DataArray) ; (032_1)(Obj_Key_F11)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_033_1") ; (033_1)(Obj_Key_F12)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (Array_ItemExist(Key_ArrayNumbers, "(033)") == 0)
          {
            DataArray := Image_GuiControl("033", 1, 0, DataArray) ; (033_1)(Obj_Key_F12)
          }
          else
          {
            DataArray := Image_GuiControl("033", 2, 0, DataArray) ; (033_1)(Obj_Key_F12)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_034_1") ; (034_1)(Obj_Key_Numpad0)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (Array_ItemExist(Key_ArrayNumbers, "(034)") == 0)
          {
            DataArray := Image_GuiControl("034", 1, 0, DataArray) ; (034_1)(Obj_Key_Numpad0)
          }
          else
          {
            DataArray := Image_GuiControl("034", 2, 0, DataArray) ; (034_1)(Obj_Key_Numpad0)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_035_1") ; (035_1)(Obj_Key_Numpad1)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (Array_ItemExist(Key_ArrayNumbers, "(035)") == 0)
          {
            DataArray := Image_GuiControl("035", 1, 0, DataArray) ; (035_1)(Obj_Key_Numpad1)
          }
          else
          {
            DataArray := Image_GuiControl("035", 2, 0, DataArray) ; (035_1)(Obj_Key_Numpad1)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_036_1") ; (036_1)(Obj_Key_Numpad2)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (Array_ItemExist(Key_ArrayNumbers, "(036)") == 0)
          {
            DataArray := Image_GuiControl("036", 1, 0, DataArray) ; (036_1)(Obj_Key_Numpad2)
          }
          else
          {
            DataArray := Image_GuiControl("036", 2, 0, DataArray) ; (036_1)(Obj_Key_Numpad2)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_037_1") ; (037_1)(Obj_Key_Numpad3)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (Array_ItemExist(Key_ArrayNumbers, "(037)") == 0)
          {
            DataArray := Image_GuiControl("037", 1, 0, DataArray) ; (037_1)(Obj_Key_Numpad3)
          }
          else
          {
            DataArray := Image_GuiControl("037", 2, 0, DataArray) ; (037_1)(Obj_Key_Numpad3)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_038_1") ; (038_1)(Obj_Key_Numpad4)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (Array_ItemExist(Key_ArrayNumbers, "(038)") == 0)
          {
            DataArray := Image_GuiControl("038", 1, 0, DataArray) ; (038_1)(Obj_Key_Numpad4)
          }
          else
          {
            DataArray := Image_GuiControl("038", 2, 0, DataArray) ; (038_1)(Obj_Key_Numpad4)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_039_1") ; (039_1)(Obj_Key_Numpad5)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (Array_ItemExist(Key_ArrayNumbers, "(039)") == 0)
          {
            DataArray := Image_GuiControl("039", 1, 0, DataArray) ; (039_1)(Obj_Key_Numpad5)
          }
          else
          {
            DataArray := Image_GuiControl("039", 2, 0, DataArray) ; (039_1)(Obj_Key_Numpad5)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_040_1") ; (040_1)(Obj_Key_Numpad6)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (Array_ItemExist(Key_ArrayNumbers, "(040)") == 0)
          {
            DataArray := Image_GuiControl("040", 1, 0, DataArray) ; (040_1)(Obj_Key_Numpad6)
          }
          else
          {
            DataArray := Image_GuiControl("040", 2, 0, DataArray) ; (040_1)(Obj_Key_Numpad6)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_041_1") ; (041_1)(Obj_Key_Numpad7)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (Array_ItemExist(Key_ArrayNumbers, "(041)") == 0)
          {
            DataArray := Image_GuiControl("041", 1, 0, DataArray) ; (041_1)(Obj_Key_Numpad7)
          }
          else
          {
            DataArray := Image_GuiControl("041", 2, 0, DataArray) ; (041_1)(Obj_Key_Numpad7)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_042_1") ; (042_1)(Obj_Key_Numpad8)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (Array_ItemExist(Key_ArrayNumbers, "(042)") == 0)
          {
            DataArray := Image_GuiControl("042", 1, 0, DataArray) ; (042_1)(Obj_Key_Numpad8)
          }
          else
          {
            DataArray := Image_GuiControl("042", 2, 0, DataArray) ; (042_1)(Obj_Key_Numpad8)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_043_1") ; (043_1)(Obj_Key_Numpad9)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (Array_ItemExist(Key_ArrayNumbers, "(043)") == 0)
          {
            DataArray := Image_GuiControl("043", 1, 0, DataArray) ; (043_1)(Obj_Key_Numpad9)
          }
          else
          {
            DataArray := Image_GuiControl("043", 2, 0, DataArray) ; (043_1)(Obj_Key_Numpad9)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_044_1") ; (044_1)(Obj_Key_NumpadAdd)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (Array_ItemExist(Key_ArrayNumbers, "(044)") == 0)
          {
            DataArray := Image_GuiControl("044", 1, 0, DataArray) ; (044_1)(Obj_Key_NumpadAdd)
          }
          else
          {
            DataArray := Image_GuiControl("044", 2, 0, DataArray) ; (044_1)(Obj_Key_NumpadAdd)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_045_1") ; (045_1)(Obj_Key_NumpadDiv)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (Array_ItemExist(Key_ArrayNumbers, "(045)") == 0)
          {
            DataArray := Image_GuiControl("045", 1, 0, DataArray) ; (045_1)(Obj_Key_NumpadDiv)
          }
          else
          {
            DataArray := Image_GuiControl("045", 2, 0, DataArray) ; (045_1)(Obj_Key_NumpadDiv)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_046_1") ; (046_1)(Obj_Key_NumpadDot)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (Array_ItemExist(Key_ArrayNumbers, "(046)") == 0)
          {
            DataArray := Image_GuiControl("046", 1, 0, DataArray) ; (046_1)(Obj_Key_NumpadDot)
          }
          else
          {
            DataArray := Image_GuiControl("046", 2, 0, DataArray) ; (046_1)(Obj_Key_NumpadDot)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_047_1") ; (047_1)(Obj_Key_NumpadEnter)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (Array_ItemExist(Key_ArrayNumbers, "(047)") == 0)
          {
            DataArray := Image_GuiControl("047", 1, 0, DataArray) ; (047_1)(Obj_Key_NumpadEnter)
          }
          else
          {
            DataArray := Image_GuiControl("047", 2, 0, DataArray) ; (047_1)(Obj_Key_NumpadEnter)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_048_1") ; (048_1)(Obj_Key_NumpadMult)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (Array_ItemExist(Key_ArrayNumbers, "(048)") == 0)
          {
            DataArray := Image_GuiControl("048", 1, 0, DataArray) ; (048_1)(Obj_Key_NumpadMult)
          }
          else
          {
            DataArray := Image_GuiControl("048", 2, 0, DataArray) ; (048_1)(Obj_Key_NumpadMult)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_049_1") ; (049_1)(Obj_Key_NumpadSub)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (Array_ItemExist(Key_ArrayNumbers, "(049)") == 0)
          {
            DataArray := Image_GuiControl("049", 1, 0, DataArray) ; (049_1)(Obj_Key_NumpadSub)
          }
          else
          {
            DataArray := Image_GuiControl("049", 2, 0, DataArray) ; (049_1)(Obj_Key_NumpadSub)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_050_1") ; (050_1)(Obj_Key_Shift)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (Array_ItemExist(Key_ArrayNumbers, "(050)") == 0 && Array_ItemExist(Key_ArrayNumbers, "(052)") == 0 && Array_ItemExist(Key_ArrayNumbers, "(053)") == 0)
          {
            DataArray := Image_GuiControl("050", 1, 1, DataArray) ; (050_1)(Obj_Key_Shift)
          }
          else
          {
           
           
            if (Array_ItemExist(Key_ArrayNumbers, "(051)") == Array_ItemExist(Key_ArrayNumbers, "(054)"))
            {
              DataArray := Image_GuiControl("050", 2, 1, DataArray) ; (050_1)(Obj_Key_Shift)
            }
            else
            {
              DataArray := Image_GuiControl("050", 3, 1, DataArray) ; (050_1)(Obj_Key_Shift)
            }
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_051_1") ; (051_1)(Obj_Key_ShiftDown)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (Array_ItemExist(Key_ArrayNumbers, "(051)") == 0)
          {
            DataArray := Image_GuiControl("051", 1, 0, DataArray) ; (051_1)(Obj_Key_ShiftDown)
          }
          else if (Array_ItemExist(Key_ArrayNumbers, "(054)") == 0)
          {
            DataArray := Image_GuiControl("051", 3, 0, DataArray) ; (051_1)(Obj_Key_ShiftDown)
          }
          else if (Array_ItemExist(Key_ArrayNumbers, "(054)") == 1)
          {
            DataArray := Image_GuiControl("051", 2, 0, DataArray) ; (051_1)(Obj_Key_ShiftDown)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_052_1") ; (052_1)(Obj_Key_ShiftLeft)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (Array_ItemExist(Key_ArrayNumbers, "(051)") == Array_ItemExist(Key_ArrayNumbers, "(054)"))
          {
            if (Array_ItemExist(Key_ArrayNumbers, "(052)") > 0)
            {
              DataArray := Image_GuiControl("052", 2, 0, DataArray) ; (052_1)(Obj_Key_ShiftLeft)
            }
            else
            {
              DataArray := Image_GuiControl("052", 1, 0, DataArray) ; (052_1)(Obj_Key_ShiftLeft)
            }
          }
          else
          {
            if (Array_ItemExist(Key_ArrayNumbers, "(052)") > 0)
            {
              DataArray := Image_GuiControl("052", 3, 0, DataArray) ; (052_1)(Obj_Key_ShiftLeft)
            }
            else
            {
              DataArray := Image_GuiControl("052", 1, 0, DataArray) ; (052_1)(Obj_Key_ShiftLeft)
            }
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_053_1") ; (053_1)(Obj_Key_ShiftRight)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (Array_ItemExist(Key_ArrayNumbers, "(051)") == Array_ItemExist(Key_ArrayNumbers, "(054)"))
          {
            if (Array_ItemExist(Key_ArrayNumbers, "(053)") > 0)
            {
              DataArray := Image_GuiControl("053", 2, 0, DataArray) ; (053_1)(Obj_Key_ShiftRight)
            }
            else
            {
              DataArray := Image_GuiControl("053", 1, 0, DataArray) ; (053_1)(Obj_Key_ShiftRight)
            }
          }
          else
          {
            if (Array_ItemExist(Key_ArrayNumbers, "(053)") > 0)
            {
              DataArray := Image_GuiControl("053", 3, 0, DataArray) ; (053_1)(Obj_Key_ShiftRight)
            }
            else
            {
              DataArray := Image_GuiControl("053", 1, 0, DataArray) ; (053_1)(Obj_Key_ShiftRight)
            }
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_054_1") ; (054_1)(Obj_Key_ShiftUp)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          ; -------------------------------------------
          if (Array_ItemExist(Key_ArrayNumbers, "(054)") == 0)
          {
            if (Array_ItemExist(Key_ArrayNumbers, "(051)") != 0)
            {
              DataArray := Image_GuiControl("054", 1, 0, DataArray) ; (054_1)(Obj_Key_ShiftUp)
            }
          }
          else
          {
            DataArray := Image_GuiControl("054", 2, 0, DataArray) ; (054_1)(Obj_Key_ShiftUp)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_055_1") ; (055_1)(Obj_Key_Tab)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (Array_ItemExist(Key_ArrayNumbers, "(055)") == 0)
          {
            DataArray := Image_GuiControl("055", 1, 1, DataArray) ; (055_1)(Obj_Key_Tab)
          }
          else
          {
            DataArray := Image_GuiControl("055", 2, 1, DataArray) ; (055_1)(Obj_Key_Tab)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_056_1") ; (056_1)(Obj_Key_TabX2)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          IsInArray := Array_ItemExist(Key_ArrayNumbers, "(055)")
          DataArray := Image_GuiControl("056", IsInArray, 0, DataArray) ; (056_1)(Obj_Key_TabX2)
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_057_1") ; (057_1)(Obj_Key_Win_Sel)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (Array_ItemExist(Key_ArrayNumbers, "(057)") == 0 && Array_ItemExist(Key_ArrayNumbers, "(059)") == 0 && Array_ItemExist(Key_ArrayNumbers, "(060)") == 0)
          {
            DataArray := Image_GuiControl("057", 1, 0, DataArray) ; (057_1)(Obj_Key_Win_Sel)
          }
          else
          {
            if (Array_ItemExist(Key_ArrayNumbers, "(058)") == Array_ItemExist(Key_ArrayNumbers, "(061)"))
            {
              DataArray := Image_GuiControl("057", 2, 0, DataArray) ; (057_1)(Obj_Key_Win_Sel)
            }
            else
            {
              DataArray := Image_GuiControl("057", 3, 0, DataArray) ; (057_1)(Obj_Key_Win_Sel)
            }
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_058_1") ; (058_1)(Obj_Key_WinDown)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (Array_ItemExist(Key_ArrayNumbers, "(058)") == 0)
          {
            DataArray := Image_GuiControl("058", 1, 0, DataArray) ; (058_1)(Obj_Key_WinDown)
          }
          else if (Array_ItemExist(Key_ArrayNumbers, "(061)") == 0)
          {
            DataArray := Image_GuiControl("058", 3, 0, DataArray) ; (058_1)(Obj_Key_WinDown)
          }
          else if (Array_ItemExist(Key_ArrayNumbers, "(061)") == 1)
          {
            DataArray := Image_GuiControl("058", 2, 0, DataArray) ; (058_1)(Obj_Key_WinDown)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_059_1") ; (059_1)(Obj_Key_WinLeft)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (Array_ItemExist(Key_ArrayNumbers, "(058)") == Array_ItemExist(Key_ArrayNumbers, "(061)"))
          {
            if (Array_ItemExist(Key_ArrayNumbers, "(059)") > 0)
            {
              DataArray := Image_GuiControl("059", 2, 0, DataArray) ; (059_1)(Obj_Key_WinLeft)
            }
            else
            {
              DataArray := Image_GuiControl("059", 1, 0, DataArray) ; (059_1)(Obj_Key_WinLeft)
            }
          }
          else
          {
            if (Array_ItemExist(Key_ArrayNumbers, "(059)") > 0)
            {
              DataArray := Image_GuiControl("059", 3, 0, DataArray) ; (059_1)(Obj_Key_WinLeft)
            }
            else
            {
              DataArray := Image_GuiControl("059", 1, 0, DataArray) ; (059_1)(Obj_Key_WinLeft)
            }
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_060_1") ; (060_1)(Obj_Key_WinRight)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (Array_ItemExist(Key_ArrayNumbers, "(058)") == Array_ItemExist(Key_ArrayNumbers, "(061)"))
          {
            if (Array_ItemExist(Key_ArrayNumbers, "(060)") > 0)
            {
              DataArray := Image_GuiControl("060", 2, 0, DataArray) ; (060_1)(Obj_Key_WinRight)
            }
            else
            {
              DataArray := Image_GuiControl("060", 1, 0, DataArray) ; (060_1)(Obj_Key_WinRight)
            }
          }
          else
          {
            if (Array_ItemExist(Key_ArrayNumbers, "(060)") > 0)
            {
              DataArray := Image_GuiControl("060", 3, 0, DataArray) ; (060_1)(Obj_Key_WinRight)
            }
            else
            {
              DataArray := Image_GuiControl("060", 1, 0, DataArray) ; (060_1)(Obj_Key_WinRight)
            }
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_061_1") ; (061_1)(Obj_Key_WinUp)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          ; -------------------------------------------
          if (Array_ItemExist(Key_ArrayNumbers, "(061)") == 0)
          {
            if (Array_ItemExist(Key_ArrayNumbers, "(058)") != 0)
            {
              DataArray := Image_GuiControl("061", 1, 0, DataArray) ; (061_1)(Obj_Key_WinUp)
            }
          }
          else
          {
            DataArray := Image_GuiControl("061", 2, 0, DataArray) ; (061_1)(Obj_Key_WinUp)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_062_1") ; (062_1)(Obj_Cancel)
    {
      ; -------------------------------------------
      ThisImage := A_ProgramFiles "\PopUpMenu_PUM\image\gui\(062)_1.png"
      GuiControl, PopUpMenu:, g_062, %ThisImage% ; (062_1)(Obj_Cancel)
      GuiControl, PopUpMenu:Show, g_062 ; (062_1)(Obj_Cancel)
      DataArray.62.2 := 1 ; (062_2)(Obj_Cancel_Sel [0,1,2,3])
      DataArray.62.3 := ThisImage ; (062_3) (Obj_Cancel_Img [Image Path])
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_063_1") ; (063_1)(Obj_SelectIconImage)
    {
      ; -------------------------------------------
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; [ScriptError = 15] (url)(No Selected URL)
      ; [ScriptError = 18] (url)(Source Not Found)
      ; [ScriptError = 19] (url)(No Internet Connection)
      ; [ScriptError = 21] (url)(Previous URL Does Not Match Current URL)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 13 or DataArray.366.6 == 15 or DataArray.366.6 == 18 or DataArray.366.6 == 19 or DataArray.366.6 == 21) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key" or DataArray.366.5 == "run" or DataArray.366.5 == "rwh" or DataArray.366.5 == "url") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (DataArray.4.2 == 1) ; (004_2)(Obj_ok_Sel [0,1,3])
          {
            DataArray := Image_GuiControl("063", 1, 1, DataArray) ; (063_1)(Obj_SelectIconImage)
          }
        } ; [End] (ScriptType [key,run,rwh,url])
      } ; [End] [ScriptError = 13,15,18,19,21]
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_064_1") ; (064_1)(Obj_HotKey_LangArray)
    {
      ; (064_1)(Empty)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_065_1") ; (065_1)(Obj_ImageText_StatusBar)
    {
      ; -------------------------------------------
      ; [ScriptError = 1] (run)(rwh)(Application Target [exe] File Not Found)
      ; [ScriptError = 2] (rwh)(No Application to Open File)
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 6] (ofl)(Folder Not Found)
      ; [ScriptError = 10] (mnu)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError = 11] (cpl)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; [ScriptError = 14] (cpl)(No Error)(Menu Bar Item Not Selected)
      ; [ScriptError = 15] (url)(No Selected URL)
      ; [ScriptError = 18] (url)(Source Not Found)
      ; [ScriptError = 19] (url)(No Internet Connection)
      ; [ScriptError = 21] (url)(Previous URL Does Not Match Current URL)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 1 or DataArray.366.6 == 2 or DataArray.366.6 == 3 or DataArray.366.6 == 6 or DataArray.366.6 == 10 or DataArray.366.6 == 11 or DataArray.366.6 == 13 or DataArray.366.6 == 14 or DataArray.366.6 == 15 or DataArray.366.6 == 18 or DataArray.366.6 == 19 or DataArray.366.6 == 21) ; (366_6)(ScriptError [Integer])      {
      {
        if (DataArray.366.5 == "mnu" or DataArray.366.5 == "cpl" or DataArray.366.5 == "key" or DataArray.366.5 == "ofl" or DataArray.366.5 == "run" or DataArray.366.5 == "rwh" or DataArray.366.5 == "url") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("065", 1, 1, DataArray) ; (065_1)(Obj_ImageText_StatusBar)
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_066_1") ; (066_1)(Obj_Key_ImageText_TextInput)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("066", 1, 1, DataArray) ; (066_1)(Obj_Key_ImageText_TextInput)
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_067_1") ; (067_1)(Obj_Key_ImageText_NumericKeypad)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("067", 1, 1, DataArray) ; (067_1)(Obj_Key_ImageText_NumericKeypad)
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_068_1") ; (068_1)(Obj_RwhUrl_OpenWith)
    {
      ; -------------------------------------------
      if (DataArray.366.5 == "rwh") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        DataArray := Image_GuiControl("068", "1rwh", 1, DataArray) ; (068_1)(Obj_RwhUrl_OpenWith)
        ; -------------------------------------------
      } ; [End] (ScriptType [rwh])
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_069_1") ; (069_1)(Obj_RwhUrl_OpenWithReset)
    {
      ; -------------------------------------------
      ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,pum,url])
      if (DataArray.366.5 == "rwh") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (DataArray.305.8 == 1) ; (305_8)(Rwh_UseAppDefault [0/1])
        {
          DataArray := Image_GuiControl("069", 1, 1, DataArray) ; (069_1)(Obj_RwhUrl_OpenWithReset)
        }
        else
        {
          DataArray := Image_GuiControl("069", 2, 1, DataArray) ; (069_1)(Obj_RwhUrl_OpenWithReset)
        }
      } ; [End] (ScriptType [rwh])
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_070_1") ; (070_1)(Obj_Cpl_WinControl)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 5] (mnu)(Addon Not Installed)(Addon is Available)
      ; [ScriptError = 9] (mnu)(No Error)(Menu Bar Item Not Selected)
      ; [ScriptError = 10] (mnu)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError = 11] (cpl)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError = 12] (mnu)(Addon Not Installed)(Addon Not Available)(Addon HAS Been Requested)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; [ScriptError = 14] (cpl)(No Error)(Menu Bar Item Not Selected)
      ; [ScriptError = 17] (mnu)(Addon Not Installed)(Addon Not Available)(Addon Not Been Requested)
      ; [ScriptError = 20] (AppProcessName = "windows")
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 5 or DataArray.366.6 == 7 or DataArray.366.6 == 9 or DataArray.366.6 == 10 or DataArray.366.6 == 11 or DataArray.366.6 == 12 or DataArray.366.6 == 13 or DataArray.366.6 == 14 or DataArray.366.6 == 17 or DataArray.366.6 == 20) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "mnu_cpl_key" or DataArray.366.5 == "mnu" or DataArray.366.5 == "cpl" or DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (DataArray.366.5 == "cpl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
          {
            DataArray := Image_GuiControl("070", 2, 1, DataArray) ; (070_1)(Obj_Cpl_WinControl)
          }
          else if (DataArray.366.5 == "mnu_cpl_key" or DataArray.366.5 == "mnu" or DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
          {
            DataArray := Image_GuiControl("070", 1, 1, DataArray) ; (070_1)(Obj_4701Cpl_WinControl)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_071_1") ; (071_1)(Obj_URL)
    {
      ; -------------------------------------------
      if (DataArray.366.5 == "run_rwh_url_ofl" or DataArray.366.5 == "run" or DataArray.366.5 == "rwh" or DataArray.366.5 == "url" or DataArray.366.5 == "ofl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (IsInternetBrowser(DataArray.367.1, DataArray.367.3, DataArray.367.4) == 0) ; All Supported Internet Browsers
        {
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          ; No Browser is Active
          ; -------------------------------------------
          if (DataArray.366.5 != "url") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
          {
            DataArray := Image_GuiControl("071", 3, 1, DataArray) ; (071_1)(Obj_URL)
          }
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          ;
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          ; No Browser is Active
          ; User has Right Clicked a Existing url Shortcut
          ; -------------------------------------------
          else if (DataArray.366.5 == "url") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
          {
            DataArray := Image_GuiControl("071", 2, 1, DataArray) ; (071_1)(Obj_URL)
          } ; [End] (ScriptType [url])
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        } ; [End] No Browser is Active
        else ; A Browser is Active
        {
          ; -------------------------------------------
          if (DataArray.307.2 == "") ; (307_2)(Url_Address) is Blank
          {
            
            
            
            
            
            
            
            
            
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ; (_27_Aug_2023_)(_09_20_38_) (ADDED)
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ; -------------------------------------------
            ; (367)(1)(AppProcessName [Name][LowerCase][NoSpace])
            ; (367)(3)(AppProcessClass)
            ; (367)(4)(AppProcessTitle)_(367)(5)(AppProcessPathNameExt [Path,Name,Ext])
            ; -------------------------------------------
            URL_Array := Url_GetUrl(DataArray.367.1, DataArray.367.3, DataArray.367.4) ; > [URL_Address, Url_Title, Browser_Name]
            DataArray.307.2 := URL_Array.1 ; (307_2)(Url_Address)
            DataArray.307.4 := URL_Array.2 ; (307_4)(Url_Title [Web Page Title])
            DataArray.307.11 := URL_Array.3 ; (307_11)(Url_BrowserTitle [Browser Name from Window Title])
            ; -------------------------------------------
            if (DataArray.307.2 == "") ; (307_2)(Url_Address) is Blank
            {
              ; -------------------------------------------
              ; (307_2)(Url_Address) is Blank
              ; Disable URL
              ; -------------------------------------------
              DataArray := Image_GuiControl("071", 3, 1, DataArray) ; (071_1)(Obj_URL)
              ; -------------------------------------------
            }
            else
            {
              DataArray := Image_GuiControl("071", 1, 1, DataArray) ; (071_1)(Obj_URL)
            }
            
            
            
            
            
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ; (_27_Aug_2023_)(_09_20_38_) (REMARKED OUT)
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ;~ ; -------------------------------------------
            ;~ ; (307_2)(Url_Address) is Blank
            ;~ ; Disable URL
            ;~ ; -------------------------------------------
            ;~ DataArray := Image_GuiControl("071", 3, 1, DataArray) ; (071_1)(Obj_URL)
            ;~ ; -------------------------------------------
            
            
            
            
            
            
            
            
            
          }
          ; -------------------------------------------
          else if (DataArray.366.5 != "url") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
          {
            DataArray := Image_GuiControl("071", 1, 1, DataArray) ; (071_1)(Obj_URL)
          } ; [End] NOT (ScriptType [url])
          else if (DataArray.366.5 == "url") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
          {
            DataArray := Image_GuiControl("071", 2, 1, DataArray) ; (071_1)(Obj_URL)
          } ; [End] (ScriptType [url])
          ; -------------------------------------------
        } ; [End] A Browser is Active
      } ; [End] (ScriptType [ofl,run,rwh,url])
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_072_1") ; (072_1)(Obj_Key_AppOnly)
    {
      ; -------------------------------------------
      if (DataArray.301.11  == 0) ; (301_11)(Key_ShortcutInAppPum [0,1])
      {
        ; -------------------------------------------
        ; [ScriptError = 3] (key)(Invalid KeyStroke)
        ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
        ; -------------------------------------------
        if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
        {
          if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
          {
            if (DataArray.72.2 == "" or DataArray.72.2 == 0) ; (072_2)(Obj_Key_AppOnly_Sel [0,1,2])
            {
              DataArray.72.2 := 1 ; (072_2)(Obj_Key_AppOnly_Sel [0,1,2])
            }
            ; -------------------------------------------
            DataArray := Image_GuiControl("072", DataArray.72.2, 1, DataArray) ; (072_1)(Obj_Key_AppOnly)/(072_2)(Obj_Key_AppOnly_Sel [0,1,2])
          }
        }
      } ; [End] (Key_ShortcutInAppPum == 0)
      else if (DataArray.301.11  == 1) ; (301_11)(Key_ShortcutInAppPum [0,1])
      {
        DataArray.72.2 := 2 ; (072_2)(Obj_Key_AppOnly_Sel [0,1,2])
      } ; [End] (Key_ShortcutInAppPum == 1)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_073_1") ; (073_1)(Obj_Run_AsAdmin)
    {
      if (A_IsAdmin == 1) ; User is Admin (Show)
      {
        if (DataArray.366.6 == 0) ; (366_6)(ScriptError [Integer])
        {
          if (DataArray.366.5 == "run" or DataArray.366.5 == "rwh") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
          {
            if (DataArray.73.2 == "" or DataArray.73.2 == 0 or DataArray.73.2 == 1) ; (073_2)(Obj_Run_AsAdmin_Sel [0,1,2])
            {
             
              DataArray := Image_GuiControl("073", 1, 1, DataArray) ; (073_1)(Obj_Run_AsAdmin)
            }
            else if (DataArray.73.2 == 2) ; (073_2)(Obj_Run_AsAdmin_Sel [0,1,2])
            {
             
              DataArray := Image_GuiControl("073", 2, 1, DataArray) ; (073_1)(Obj_Run_AsAdmin)
            }
          }
        }
      } ; [End] if (A_IsAdmin == 1) ; User is Admin (Show)
      else
      {
        DataArray.73.2 := 0 ; (073_2)(Obj_Run_AsAdmin_Sel [0,1,2])
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_074_1") ; (074_1)(Obj_Key_Ctrl)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (Array_ItemExist(Key_ArrayNumbers, "(074)") == 0 && Array_ItemExist(Key_ArrayNumbers, "(015)") == 0 && Array_ItemExist(Key_ArrayNumbers, "(016)") == 0)
          {
            DataArray := Image_GuiControl("074", 1, 1, DataArray) ; (074_1)(Obj_Key_Ctrl)
          }
          else
          {
            if (Array_ItemExist(Key_ArrayNumbers, "(014)") == Array_ItemExist(Key_ArrayNumbers, "(017)"))
            {
              DataArray := Image_GuiControl("074", 2, 1, DataArray) ; (074_1)(Obj_Key_Ctrl)
            }
            else
            {
              DataArray := Image_GuiControl("074", 3, 1, DataArray) ; (074_1)(Obj_Key_Ctrl)
            }
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_075_1") ; (075_1)(Obj_Key_Delete)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (Array_ItemExist(Key_ArrayNumbers, "(075)") == 0)
          {
            DataArray := Image_GuiControl("075", 1, 1, DataArray) ; (075_1)(Obj_Key_Delete)
          }
          else
          {
            DataArray := Image_GuiControl("075", 2, 1, DataArray) ; (075_1)(Obj_Key_Delete)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_076_1") ; (076_1)(Obj_Key_End)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (Array_ItemExist(Key_ArrayNumbers, "(076)") == 0)
          {
            DataArray := Image_GuiControl("076", 1, 1, DataArray) ; (076_1)(Obj_Key_End)
          }
          else
          {
            DataArray := Image_GuiControl("076", 2, 1, DataArray) ; (076_1)(Obj_Key_End)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_077_1") ; (077_1)(Obj_Key_Home)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (Array_ItemExist(Key_ArrayNumbers, "(077)") == 0)
          {
            DataArray := Image_GuiControl("077", 1, 1, DataArray) ; (077_1)(Obj_Key_Home)
          }
          else
          {
            DataArray := Image_GuiControl("077", 2, 1, DataArray) ; (077_1)(Obj_Key_Home)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_078_1") ; (078_1)(Obj_Key_Insert)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (Array_ItemExist(Key_ArrayNumbers, "(078)") == 0)
          {
            DataArray := Image_GuiControl("078", 1, 1, DataArray) ; (078_1)(Obj_Key_Insert)
          }
          else
          {
            DataArray := Image_GuiControl("078", 2, 1, DataArray) ; (078_1)(Obj_Key_Insert)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_079_1") ; (079_1)(Obj_Key_PgDn)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (Array_ItemExist(Key_ArrayNumbers, "(079)") == 0)
          {
            DataArray := Image_GuiControl("079", 1, 1, DataArray) ; (079_1)(Obj_Key_PgDn)
          }
          else
          {
            DataArray := Image_GuiControl("079", 2, 1, DataArray) ; (079_1)(Obj_Key_PgDn)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_080_1") ; (080_1)(Obj_Key_PgUp)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (Array_ItemExist(Key_ArrayNumbers, "(080)") == 0)
          {
            DataArray := Image_GuiControl("080", 1, 1, DataArray) ; (080_1)(Obj_Key_PgUp)
          }
          else
          {
            DataArray := Image_GuiControl("080", 2, 1, DataArray) ; (080_1)(Obj_Key_PgUp)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_081_1") ; (081_1)(Obj_RunRwh_File)
    {
      ; -------------------------------------------
      ; [ScriptError = 1] (run)(rwh)(Application Target [exe] File Not Found)
      ; [ScriptError = 2] (rwh)(No Application to Open File)
      ; [ScriptError = 6] (ofl)(Folder Not Found)
      ; [ScriptError = 15] (url)(No Selected URL)
      ; [ScriptError = 18] (url)(Source Not Found)
      ; [ScriptError = 19] (url)(No Internet Connection)
      ; [ScriptError = 20] (AppProcessName = "windows")
      ; [ScriptError = 21] (url)(Right Clicked Existing url Shortcut, NO Browser Active)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 1 or DataArray.366.6 == 2 or DataArray.366.6 == 6 or DataArray.366.6 == 8 or DataArray.366.6 == 15 or DataArray.366.6 == 18 or DataArray.366.6 == 19 or DataArray.366.6 == 20 or DataArray.366.6 == 21) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "run_rwh_url_ofl" or DataArray.366.5 == "ofl" or DataArray.366.5 == "run" or DataArray.366.5 == "rwh" or DataArray.366.5 == "url") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (DataArray.366.5 == "run" or DataArray.366.5 == "rwh") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
          {
            DataArray := Image_GuiControl("081", 2, 1, DataArray) ; (081_1)(Obj_RunRwh_File)
          } ; [End] (ScriptType [run,rwh])
          else ; (ScriptType [run_rwh_url_ofl,ofl,run,rwh,url])
          {
            DataArray := Image_GuiControl("081", 1, 1, DataArray) ; (081_1)(Obj_RunRwh_File)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_082_1") ; (082_1)(Obj_Ofl_Folder)
    {
      ; -------------------------------------------
      ; [ScriptError = 1] (run)(rwh)(Application Target [exe] File Not Found)
      ; [ScriptError = 2] (rwh)(No Application to Open File)
      ; [ScriptError = 6] (ofl)(Folder Not Found)
      ; [ScriptError = 15] (url)(No Selected URL)
      ; [ScriptError = 18] (url)(Source Not Found)
      ; [ScriptError = 19] (url)(No Internet Connection)
      ; [ScriptError = 20] (AppProcessName = "windows")
      ; [ScriptError = 21] (url)(Right Clicked Existing url Shortcut, NO Browser Active)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 1 or DataArray.366.6 == 2 or DataArray.366.6 == 6 or DataArray.366.6 == 8 or DataArray.366.6 == 15 or DataArray.366.6 == 18 or DataArray.366.6 == 19 or DataArray.366.6 == 20 or DataArray.366.6 == 21) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "run_rwh_url_ofl" or DataArray.366.5 == "ofl" or DataArray.366.5 == "run" or DataArray.366.5 == "rwh" or DataArray.366.5 == "url") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (DataArray.366.5 == "ofl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
          {
            DataArray := Image_GuiControl("082", 2, 1, DataArray) ; (082_1)(Obj_Ofl_Folder)
          } ; [End] (ScriptType [ofl])
          else
          {
            DataArray := Image_GuiControl("082", 1, 1, DataArray) ; (082_1)(Obj_Ofl_Folder)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_083_1") ; (083_1)(Obj_Tom_Pum)
    {
      ; -------------------------------------------
      if (InStr(DataArray.366.5, "pumtom") > 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        if (HasConnection == 0) ; NO Internet Connection
        {
          DataArray := Image_GuiControl("083", "2b", 1, DataArray) ; (083_1)(Obj_Tom_Pum)
        }
        else
        {
          DataArray := Image_GuiControl("083", "2a", 1, DataArray) ; (083_1)(Obj_Tom_Pum)
        }
      }
      else
      {
        if (HasConnection == 0) ; NO Internet Connection
        {
          DataArray := Image_GuiControl("083", "1b", 1, DataArray) ; (083_1)(Obj_Tom_Pum)
        }
        else
        {
          DataArray := Image_GuiControl("083", "1a", 1, DataArray) ; (083_1)(Obj_Tom_Pum)
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_084_1") ; (084_1)(Obj_Tom_FileUrlFolder)
    {
      if (DataArray.366.5 == "run_rwh_url_ofl" or DataArray.366.5 == "ofl" or DataArray.366.5 == "run" or DataArray.366.5 == "rwh" or DataArray.366.5 == "url") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        if (IsInternetBrowser(DataArray.367.1, DataArray.367.3, DataArray.367.4) == 0) ; All Supported Internet Browsers
        {
          ; -------------------------------------------
          ; No Browser is Active
          ; -------------------------------------------
          DataArray := Image_GuiControl("071", "3", 1, DataArray) ; (071_1)(Obj_URL)
        }
        ; -------------------------------------------
        if (HasConnection == 0) ; NO Internet Connection
        {
          DataArray := Image_GuiControl("084", "2b", 1, DataArray) ; (084_1)(Obj_Tom_FileUrlFolder)
        }
        else
        {
          DataArray := Image_GuiControl("084", "2a", 1, DataArray) ; (084_1)(Obj_Tom_FileUrlFolder)
        }
      }
      else
      {
        if (HasConnection == 0) ; NO Internet Connection
        {
          DataArray := Image_GuiControl("084", "1b", 1, DataArray) ; (084_1)(Obj_Tom_FileUrlFolder)
        }
        else
        {
          DataArray := Image_GuiControl("084", "1a", 1, DataArray) ; (084_1)(Obj_Tom_FileUrlFolder)
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_085_1") ; (085_1)(Obj_Key_Keyboard)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 5] (mnu)(Addon Not Installed)(Addon is Available)
      ; [ScriptError = 9] (mnu)(No Error)(Menu Bar Item Not Selected)
      ; [ScriptError = 10] (mnu)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError = 11] (cpl)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError = 12] (mnu)(Addon Not Installed)(Addon Not Available)(Addon HAS Been Requested)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; [ScriptError = 14] (cpl)(No Error)(Menu Bar Item Not Selected)
      ; [ScriptError = 17] (mnu)(Addon Not Installed)(Addon Not Available)(Addon Not Been Requested)
      ; [ScriptError = 20] (AppProcessName = "windows")
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 5 or DataArray.366.6 == 7 or DataArray.366.6 == 9 or DataArray.366.6 == 10 or DataArray.366.6 == 11 or DataArray.366.6 == 12 or DataArray.366.6 == 13 or DataArray.366.6 == 14 or DataArray.366.6 == 17 or DataArray.366.6 == 20) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "mnu_cpl_key" or DataArray.366.5 == "mnu" or DataArray.366.5 == "cpl" or DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
          {
            DataArray := Image_GuiControl("085", 2, 1, DataArray) ; (085_1)(Obj_Key_Keyboard)
          }
          else if (DataArray.366.5 == "mnu_cpl_key" or DataArray.366.5 == "cpl" or DataArray.366.5 == "mnu") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
          {
            DataArray := Image_GuiControl("085", 1, 1, DataArray) ; (085_1)(Obj_Key_Keyboard)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_086_1") ; (086_1)(Obj_Tom_MenuControlKey)
    {
      if (DataArray.366.5 == "mnu_cpl_key" or DataArray.366.5 == "mnu" or DataArray.366.5 == "key" or DataArray.366.5 == "cpl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("086", 2, 1, DataArray) ; (086_1)(Obj_Tom_MenuControlKey)
      }
      else
      {
        DataArray := Image_GuiControl("086", 1, 1, DataArray) ; (086_1)(Obj_Tom_MenuControlKey)
      }
    }
    ; >>>>>>>>>>>>>>>7>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_087_1") ; (087_1)(Obj_Mnu_Menu)
    {
      if (DataArray.367.1 != "windows") ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
      {
        ; -------------------------------------------
        ; [ScriptError = 3] (key)(Invalid KeyStroke)
        ; [ScriptError = 5] (mnu)(Addon Not Installed)(Addon is Available)
        ; [ScriptError = 9] (mnu)(No Error)(Menu Bar Item Not Selected)
        ; [ScriptError = 10] (mnu)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
        ; [ScriptError = 11] (cpl)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
        ; [ScriptError = 12] (mnu)(Addon Not Installed)(Addon Not Available)(Addon HAS Been Requested)
        ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
        ; [ScriptError = 14] (cpl)(No Error)(Menu Bar Item Not Selected)
        ; [ScriptError = 17] (mnu)(Addon Not Installed)(Addon Not Available)(Addon Not Been Requested)
        ; -------------------------------------------
        if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 5 or DataArray.366.6 == 7 or DataArray.366.6 == 9 or DataArray.366.6 == 10 or DataArray.366.6 == 11 or DataArray.366.6 == 12 or DataArray.366.6 == 13 or DataArray.366.6 == 14 or DataArray.366.6 == 17) ; (366_6)(ScriptError [Integer])
        {
          if (DataArray.366.5 == "mnu_cpl_key" or DataArray.366.5 == "mnu" or DataArray.366.5 == "cpl" or DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
          {
            if (DataArray.302.7 == 1) ; (302_7)(Mnu_ActiveAddonInstalled [0/1])
            {
              if (DataArray.366.5 == "mnu") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
              {
                DataArray := Image_GuiControl("087", 2, 1, DataArray) ; (087_1)(Obj_Mnu_Menu)
              }
              else
              {
                DataArray := Image_GuiControl("087", 1, 1, DataArray) ; (087_1)(Obj_Mnu_Menu)
              }
            }
            else
            {
              DataArray := Image_GuiControl("087", 3, 1, DataArray) ; (087_1)(Obj_Mnu_Menu)
            }
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_088_1") ; (088_1)(Obj_Mnu_AppMenu1)
    {
      ; -------------------------------------------
      ; [ScriptError = 9] (mnu)(No Error)(Menu Bar Item Not Selected)
      ; [ScriptError = 10] (mnu)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 9 or DataArray.366.6 == 10) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "mnu") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (DataArray.302.6 >= 2) ; (302_6)(Mnu_MenuSize [#])
          {
            if (DataArray.367.1 != "windows") ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
            {
              if (DataArray.302.2 == 1) ; (302_2)(Mnu_Number_x000 [#_X_X_X])
              {
                DataArray := Image_GuiControl("Menu_088", 2, 1, DataArray) ; GuiVarNum, SelectImgNum, HasLanguage, DataArray > DataArray
              }
              else
              {
                DataArray := Image_GuiControl("Menu_088", 1, 1, DataArray) ; GuiVarNum, SelectImgNum, HasLanguage, DataArray > DataArray
              }
            }
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_089_1") ; (089_1)(Obj_Mnu_AppMenu2)
    {
      ; -------------------------------------------
      ; [ScriptError = 9] (mnu)(No Error)(Menu Bar Item Not Selected)
      ; [ScriptError = 10] (mnu)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 9 or DataArray.366.6 == 10) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "mnu") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (DataArray.302.6 >= 2) ; (302_6)(Mnu_MenuSize [#])
          {
            if (DataArray.367.1 != "windows") ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
            {
              if (DataArray.302.2 == 2) ; (302_2)(Mnu_Number_x000 [#_X_X_X])
              {
                DataArray := Image_GuiControl("Menu_089", 2, 1, DataArray) ; GuiVarNum, SelectImgNum, HasLanguage, DataArray > DataArray
              }
              else
              {
                DataArray := Image_GuiControl("Menu_089", 1, 1, DataArray) ; GuiVarNum, SelectImgNum, HasLanguage, DataArray > DataArray
              }
            }
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_090_1") ; (090_1)(Obj_Mnu_AppMenu3)
    {
      ; -------------------------------------------
      ; [ScriptError = 9] (mnu)(No Error)(Menu Bar Item Not Selected)
      ; [ScriptError = 10] (mnu)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 9 or DataArray.366.6 == 10) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "mnu") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (DataArray.302.6 >= 3) ; (302_6)(Mnu_MenuSize [#])
          {
            if (DataArray.367.1 != "windows") ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
            {
              if (DataArray.302.2 == 3) ; (302_2)(Mnu_Number_x000 [#_X_X_X])
              {
                DataArray := Image_GuiControl("Menu_090", 2, 1, DataArray) ; GuiVarNum, SelectImgNum, HasLanguage, DataArray > DataArray
              }
              else
              {
                DataArray := Image_GuiControl("Menu_090", 1, 1, DataArray) ; GuiVarNum, SelectImgNum, HasLanguage, DataArray > DataArray
              }
            }
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_091_1") ; (091_1)(Obj_Mnu_AppMenu4)
    {
      ; -------------------------------------------
      ; [ScriptError = 9] (mnu)(No Error)(Menu Bar Item Not Selected)
      ; [ScriptError = 10] (mnu)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 9 or DataArray.366.6 == 10) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "mnu") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (DataArray.302.6 >= 4) ; (302_6)(Mnu_MenuSize [#])
          {
            if (DataArray.367.1 != "windows") ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
            {
              if (DataArray.302.2 == 4) ; (302_2)(Mnu_Number_x000 [#_X_X_X])
              {
                DataArray := Image_GuiControl("Menu_091", 2, 1, DataArray) ; GuiVarNum, SelectImgNum, HasLanguage, DataArray > DataArray
              }
              else
              {
                DataArray := Image_GuiControl("Menu_091", 1, 1, DataArray) ; GuiVarNum, SelectImgNum, HasLanguage, DataArray > DataArray
              }
            }
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_092_1") ; (092_1)(Obj_Mnu_AppMenu5)
    {
      ; -------------------------------------------
      ; [ScriptError = 9] (mnu)(No Error)(Menu Bar Item Not Selected)
      ; [ScriptError = 10] (mnu)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 9 or DataArray.366.6 == 10) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "mnu") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (DataArray.302.6 >= 5) ; (302_6)(Mnu_MenuSize [#])
          {
            if (DataArray.367.1 != "windows") ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
            {
              if (DataArray.302.2 == 5) ; (302_2)(Mnu_Number_x000 [#_X_X_X])
              {
                DataArray := Image_GuiControl("Menu_092", 2, 1, DataArray) ; GuiVarNum, SelectImgNum, HasLanguage, DataArray > DataArray
              }
              else
              {
                DataArray := Image_GuiControl("Menu_092", 1, 1, DataArray) ; GuiVarNum, SelectImgNum, HasLanguage, DataArray > DataArray
              }
            }
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_093_1") ; (093_1)(Obj_Mnu_AppMenu6)
    {
      ; -------------------------------------------
      ; [ScriptError = 9] (mnu)(No Error)(Menu Bar Item Not Selected)
      ; [ScriptError = 10] (mnu)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 9 or DataArray.366.6 == 10) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "mnu") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (DataArray.302.6 >= 6) ; (302_6)(Mnu_MenuSize [#])
          {
            if (DataArray.367.1 != "windows") ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
            {
              if (DataArray.302.2 == 6) ; (302_2)(Mnu_Number_x000 [#_X_X_X])
              {
                DataArray := Image_GuiControl("Menu_093", 2, 1, DataArray) ; GuiVarNum, SelectImgNum, HasLanguage, DataArray > DataArray
              }
              else
              {
                DataArray := Image_GuiControl("Menu_093", 1, 1, DataArray) ; GuiVarNum, SelectImgNum, HasLanguage, DataArray > DataArray
              }
            }
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_094_1") ; (094_1)(Obj_Mnu_AppMenu7)
    {
      ; -------------------------------------------
      ; [ScriptError = 9] (mnu)(No Error)(Menu Bar Item Not Selected)
      ; [ScriptError = 10] (mnu)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 9 or DataArray.366.6 == 10) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "mnu") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (DataArray.302.6 >= 7) ; (302_6)(Mnu_MenuSize [#])
          {
            if (DataArray.367.1 != "windows") ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
            {
              if (DataArray.302.2 == 7) ; (302_2)(Mnu_Number_x000 [#_X_X_X])
              {
                DataArray := Image_GuiControl("Menu_094", 2, 1, DataArray) ; GuiVarNum, SelectImgNum, HasLanguage, DataArray > DataArray
              }
              else
              {
                DataArray := Image_GuiControl("Menu_094", 1, 1, DataArray) ; GuiVarNum, SelectImgNum, HasLanguage, DataArray > DataArray
              }
            }
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_095_1") ; (095_1)(Obj_Mnu_AppMenu8)
    {
      ; -------------------------------------------
      ; [ScriptError = 9] (mnu)(No Error)(Menu Bar Item Not Selected)
      ; [ScriptError = 10] (mnu)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 9 or DataArray.366.6 == 10) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "mnu") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (DataArray.302.6 >= 8) ; (302_6)(Mnu_MenuSize [#])
          {
            if (DataArray.367.1 != "windows") ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
            {
              if (DataArray.302.2 == 8) ; (302_2)(Mnu_Number_x000 [#_X_X_X])
              {
                DataArray := Image_GuiControl("Menu_095", 2, 1, DataArray) ; GuiVarNum, SelectImgNum, HasLanguage, DataArray > DataArray
              }
              else
              {
                DataArray := Image_GuiControl("Menu_095", 1, 1, DataArray) ; GuiVarNum, SelectImgNum, HasLanguage, DataArray > DataArray
              }
            }
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_096_1") ; (096_1)(Obj_Mnu_AppMenu9)
    {
      ; -------------------------------------------
      ; [ScriptError = 9] (mnu)(No Error)(Menu Bar Item Not Selected)
      ; [ScriptError = 10] (mnu)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 9 or DataArray.366.6 == 10) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "mnu") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (DataArray.302.6 >= 9) ; (302_6)(Mnu_MenuSize [#])
          {
            if (DataArray.367.1 != "windows") ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
            {
              if (DataArray.302.2 == 9) ; (302_2)(Mnu_Number_x000 [#_X_X_X])
              {
                DataArray := Image_GuiControl("Menu_096", 2, 1, DataArray) ; GuiVarNum, SelectImgNum, HasLanguage, DataArray > DataArray
              }
              else
              {
                DataArray := Image_GuiControl("Menu_096", 1, 1, DataArray) ; GuiVarNum, SelectImgNum, HasLanguage, DataArray > DataArray
              }
            }
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_097_1") ; (097_1)(Obj_Mnu_AppMenu10)
    {
      ; -------------------------------------------
      ; [ScriptError = 9] (mnu)(No Error)(Menu Bar Item Not Selected)
      ; [ScriptError = 10] (mnu)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 9 or DataArray.366.6 == 10) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "mnu") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (DataArray.302.6 >= 10) ; (302_6)(Mnu_MenuSize [#])
          {
            if (DataArray.367.1 != "windows") ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
            {
              if (DataArray.302.2 == 10) ; (302_2)(Mnu_Number_x000 [#_X_X_X])
              {
                DataArray := Image_GuiControl("Menu_097", 2, 1, DataArray) ; GuiVarNum, SelectImgNum, HasLanguage, DataArray > DataArray
              }
              else
              {
                DataArray := Image_GuiControl("Menu_097", 1, 1, DataArray) ; GuiVarNum, SelectImgNum, HasLanguage, DataArray > DataArray
              }
            }
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_098_1") ; (098_1)(Obj_Mnu_AppMenu11)
    {
      ; -------------------------------------------
      ; [ScriptError = 9] (mnu)(No Error)(Menu Bar Item Not Selected)
      ; [ScriptError = 10] (mnu)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 9 or DataArray.366.6 == 10) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "mnu") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (DataArray.302.6 >= 11) ; (302_6)(Mnu_MenuSize [#])
          {
            if (DataArray.367.1 != "windows") ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
            {
              if (DataArray.302.2 == 11) ; (302_2)(Mnu_Number_x000 [#_X_X_X])
              {
                DataArray := Image_GuiControl("Menu_098", 2, 1, DataArray) ; GuiVarNum, SelectImgNum, HasLanguage, DataArray > DataArray
              }
              else
              {
                DataArray := Image_GuiControl("Menu_098", 1, 1, DataArray) ; GuiVarNum, SelectImgNum, HasLanguage, DataArray > DataArray
              }
            }
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_099_1") ; (099_1)(Obj_PopUpMenuWebLink)
    {
      ; (099_1)(Obj_PopUpMenuWebLink)
      ; Hotkey_gui
      ; PopUpMenu
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_100_1") ; (100_1)(Obj_DisplayText_Top1)
    {
      ; -------------------------------------------
      Obj_DisplayText_Top1_Val := ""
      ; -------------------------------------------
      if (DataArray.366.5 == "run" or DataArray.366.5 == "rwh") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (DataArray.366.5 == "run") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          Obj_DisplayText_Top1_Val := DataArray.305.11 ; (305_11)(Run_OutTarget [PathExtName])
          Obj_DisplayText_Top1_Val := StrReplace(Obj_DisplayText_Top1_Val, """", "")
        }
        else
        {
          Obj_DisplayText_Top1_Val := DataArray.305.4 ; (305_4)(Run_FilePathNameExt [Selected File] [Path,Name,Ext])
          Obj_DisplayText_Top1_Val := StrReplace(Obj_DisplayText_Top1_Val, """", "")
        }
        ; -------------------------------------------
      }
      else if (DataArray.366.5 == "ofl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        Obj_DisplayText_Top1_Val := DataArray.303.2 ; (303_2)(ofl_FolderPathName [Folder Name With Path])
        Obj_DisplayText_Top1_Val := StrReplace(Obj_DisplayText_Top1_Val, """", "")
        ; -------------------------------------------
      }
      ; -------------------------------------------
      if (Obj_DisplayText_Top1_Val != "")
      {
        ; -------------------------------------------
        if (DataArray.366.6 == 0) ; (366_6)(ScriptError [Integer])
        {
          FontColor := "199524" ; Green
        }
        else
        {
          FontColor := "a30404" ; Red
        }
        ; -------------------------------------------
        GuiFont := DataArray.366.2 ; (366_2)(GuiFont [Set in DataArray_Set])
        FontSize := 12
        MaxWidth := 480
        Gui_AdjustTextWidth("g_100", Obj_DisplayText_Top1_Val, GuiFont, FontSize, FontColor, MaxWidth) ; (100_1)(Obj_DisplayText_Top1)
        DataArray.100.3 := Obj_DisplayText_Top1_Val ; (100_3)(Obj_DisplayText_Top1_Val [Text Value])
        ; -------------------------------------------
      } ; [End] else if (Obj_DisplayText_Top1_Val != "")
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_101_1") ; (101_1)(Obj_LangFlag)
    {
      ; -------------------------------------------
      ThisImage := A_ProgramFiles "\PopUpMenu_PUM\image\gui\(101)_" DataArray.365.2 ".png" ; (365_2)(UserLang [Current User language])
      GuiControl, PopUpMenu:, g_101, %ThisImage% ; (101_1)(Obj_LangFlag)
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_102_1") ; (102_1)(Obj_DisplayedIcon)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; -------------------------------------------
      if (DataArray.366.6 == 3) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.102.3 == "") ; (102_3)(Obj_DisplayedIcon_Img [Image Path])
        {
          ; -------------------------------------------
          DataArray := f_102("ScriptError", DataArray) ; (102_1)(Obj_DisplayedIcon)
          ; -------------------------------------------
        }
        else
        {
          ; -------------------------------------------
          DataArray := f_102(DataArray.102.3, DataArray) ; (102_3)(Obj_DisplayedIcon_Img [Image Path])/(102_1)(Obj_DisplayedIcon)
          ; -------------------------------------------
        }
      }
      ; -------------------------------------------
      ; [ScriptError = 1] (Application Target [exe] File Not Found)
      ; [ScriptError = 2] (rwh)(No Application to Open File)
      ; [ScriptError = 6] (ofl)(Folder Not Found)
      ; -------------------------------------------
      else if (DataArray.366.6 == 1 or DataArray.366.6 == 2 or DataArray.366.6 == 6) ; (366_6)(ScriptError [Integer])
      {
        ; -------------------------------------------
        DataArray := f_102("Default", DataArray) ; (102_1)(Obj_DisplayedIcon)
        ; -------------------------------------------
      }
      else if (DataArray.102.3 == "") ; (102_3)(Obj_DisplayedIcon_Img [Image Path])
      {
        if (DataArray.366.5 != "cpl" && DataArray.366.5 != "mnu") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          ; -------------------------------------------
          DataArray := f_102("Default", DataArray) ; (102_1)(Obj_DisplayedIcon)
          ; -------------------------------------------
        }
      }
      else if (DataArray.366.5 == "key" or DataArray.366.5 == "ofl" or DataArray.366.5 == "run" or DataArray.366.5 == "rwh" or DataArray.366.5 == "url") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        Obj_DisplayedIcon_Img := DataArray.102.3 ; (102_3)(Obj_DisplayedIcon_Img [Image Path])
        ; -------------------------------------------
        ; SplitPath, InputVar, OutFileName, OutDir, OutExtension, OutNameNoExt, OutDrive
        SplitPath, Obj_DisplayedIcon_Img, , , , DisplayedIconName
        ; -------------------------------------------
        if (inStr(DisplayedIconName, "PopUpMenu") == 0) ; (102_3)(Obj_DisplayedIcon_Img [Image Path])
        {
          ; -------------------------------------------
          DataArray := f_102(Obj_DisplayedIcon_Img, DataArray) ; (102_1)(Obj_DisplayedIcon)
          ; -------------------------------------------
        }
        else
        {
          ; -------------------------------------------
          DataArray := f_102("Default", DataArray) ; (102_1)(Obj_DisplayedIcon)
          ; -------------------------------------------
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_103_1") ; (103_1)(Obj_RwhUrl_OpeningAppImage)
    {
      ; -------------------------------------------
      if (DataArray.366.5 == "rwh") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        ; [ScriptError = 2] (rwh)(No Application to Open File)
        ; -------------------------------------------
        if (DataArray.366.6 == 2) ; (366_6)(ScriptError [Integer])
        {
          ; -------------------------------------------
          ThisImage := A_ProgramFiles "\PopUpMenu_PUM\image\gui\(103)_Error.png"
          ; -------------------------------------------
          DataArray := Image_GuiControl("Image_103", ThisImage, 0, DataArray) ; GuiVarNum, SelectImgNum, HasLanguage, DataArray > DataArray
          ; -------------------------------------------
        } ; [End] [ScriptError = 2] (rwh)(No Application to Open File)
        else if (DataArray.366.5 == "rwh") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          ; -------------------------------------------
          if (DataArray.305.5 == "") ; (305_5)(Rwh_OpeningApp [Full File Path])
          { ; No User Selected OpeningApp
            DataArray.305.5 := DataArray.305.6 ; (305_5)(Rwh_OpeningApp [Full File Path])/(305_6)(Rwh_DefaultApp [Full File Path])
          } ; [End] No User Selected OpeningApp
          ; -------------------------------------------
          DataArray := Image_GuiControl("Image_103", DataArray.305.5, 0, DataArray) ; (305_5)(Rwh_OpeningApp [Full File Path])
          ; -------------------------------------------
        } ; [End] (ScriptType [rwh])
        ; -------------------------------------------
      } ; [End] (ScriptType [rwh])
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_104_1") ; (104_1)(Obj_DisplayText_Bottom1)
    {
      ; CplMnu_MenuDisplay.ahk
      ; (084_1)(Obj_Tom_FileUrlFolder)
      ; PopUpMenu
      ; _Include.ahk
      ; _S1_C.ahk
      ; _S2_H.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_105_1") ; (105_1)(Obj_DisplayText_Top2)
    {
      ; -------------------------------------------
      ; [ScriptError = 1] (run)(rwh)(Application Target [exe] File Not Found)
      ; [ScriptError = 2] (rwh)(No Application to Open File)
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 6] (ofl)(Folder Not Found)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      Obj_DisplayText_Top2_Val := ""
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 1 or DataArray.366.6 == 2 or DataArray.366.6 == 3 or DataArray.366.6 == 6 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        ; -------------------------------------------
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          ; -------------------------------------------
          Obj_DisplayText_Top2_Val := DataArray.301.7 ; (301_7)(Key_KeyArrayDisplay [String] [by Lang])
          ; -------------------------------------------
          Obj_DisplayText_Top2_Val := UIS(Obj_DisplayText_Top2_Val)
          ; -------------------------------------------
          ; [ScriptError = 3] (key)(Invalid KeyStroke)
          ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
          ; -------------------------------------------
          if (Obj_DisplayText_Top2_Val != "")
          {
            ; -------------------------------------------
            ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
            ; -------------------------------------------
            if (DataArray.366.6 == 0 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
            {
              FontColor := "199524" ; Green
            }
            else
            {
              FontColor := "a30404" ; Red
            }
            ; -------------------------------------------
            GuiFont := DataArray.366.2 ; (366_2)(GuiFont [Set in DataArray_Set])
            FontSize := 12
            MaxWidth := 480
            Gui_AdjustTextWidth("g_105", Obj_DisplayText_Top2_Val, GuiFont, FontSize, FontColor, MaxWidth) ; (105_1)(Obj_DisplayText_Top2)
            DataArray.105.3 := Obj_DisplayText_Top2_Val ; (105_3)(Obj_DisplayText_Top2_Val [Text Value])
            ; -------------------------------------------
          } ; if (Obj_DisplayText_Top2_Val != "")
          ; -------------------------------------------
        } ; if (DataArray.366.5 == "key")
        ; -------------------------------------------
      } ; [ScriptError]
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_106_1") ; (106_1)(Obj_KeyOfl_DisplayText_RNumberOfIcons)
    {
      ; (106_1)(Obj_KeyOfl_DisplayText_RNumberOfIcons)
      ; Image_ExeToPng.ahk
      ; Image_MultIconDisplay.ahk
      ; PopUpMenu
      ; _Include.ahk
      ; _S2_H.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_107_1") ; (107_1)(Obj_DisplayText_Bottom2)
    {
      ; CplMnu_MenuDisplay.ahk
      ; (084_1)(Obj_Tom_FileUrlFolder)
      ; PopUpMenu
      ; _Include.ahk
      ; _S1_C.ahk
      ; _S2_H.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_108_1") ; (108_1)(Obj_Url_SameNewTab)
    {
      ; -------------------------------------------
      if (DataArray.366.5 == "url") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (DataArray.307.9 == "" or DataArray.307.9 == 0) ; (307_9)(Url_NewTab [Open URL Address in New Tab] [0/1])
        {
          DataArray.307.9 := 1 ; (307_9)(Url_NewTab [Open URL Address in New Tab] [0/1])
        }
        ; -------------------------------------------
        if (DataArray.307.9 == 1) ; (307_9)(Url_NewTab [Open URL Address in New Tab] [0/1])
        {
          DataArray := Image_GuiControl("108", 1, 1, DataArray) ; (108_1)(Obj_Url_SameNewTab)
        }
        else if (DataArray.307.9 == 2) ; (307_9)(Url_NewTab [Open URL Address in New Tab] [0/1])
        {
          DataArray := Image_GuiControl("108", 2, 1, DataArray) ; (108_1)(Obj_Url_SameNewTab)
        }
        ; -------------------------------------------
      } ; [End] (ScriptType [url])
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_109_1") ; (109_1)(Obj_CatPaw)
    {
      ; -------------------------------------------
      if (DataArray.366.5 == "xxx" && DataArray.305.17 != 1) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])/(305_17)(Run_DefaultPum [0,1][Selected Shortcut is to the Default pum])
      {
        if (DataArray.305.18 != 1) ; (305_18)(Run_CatPaw [0,1][Selected Shortcut is to the CatPaw])
        {
          DataArray := Image_GuiControl("109", 1, 1, DataArray) ; (109_1)(Obj_CatPaw)
        }
        else if (DataArray.305.18 == 1) ; (305_18)(Run_CatPaw [0,1][Selected Shortcut is to the CatPaw])
        {
          DataArray := Image_GuiControl("109", 2, 1, DataArray) ; (109_1)(Obj_CatPaw)
        }
      } ; [End] (ScriptType [xxx])
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_110_1") ; (110_1)(Obj_CplMnu_DisplayText_ListLeft)[cpl]
    {
      ; CplMnu_MenuDisplay.ahk
      ; (070_1)(Obj_MnuCplKey_WinControl)
      ; (087_1)(Obj_Mnu_Menu)
      ; PopUpMenu
      ; _Include.ahk
      ; _S2_H.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_111_1") ; (111_1)(Obj_CplMnu_DisplayText_ListCenter)
    {
      ; CplMnu_MenuDisplay.ahk
      ; (070_1)(Obj_MnuCplKey_WinControl)
      ; (087_1)(Obj_Mnu_Menu)
      ; PopUpMenu
      ; _Include.ahk
      ; _S2_H.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_112_1") ; (112_1)(Obj_CplMnu_DisplayText_ListRight)
    {
      ; CplMnu_MenuDisplay.ahk
      ; (070_1)(Obj_MnuCplKey_WinControl)
      ; (087_1)(Obj_Mnu_Menu)
      ; PopUpMenu
      ; _Include.ahk
      ; _S2_H.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_113_1") ; (113_1)(Obj_RwhUrl_DisplayText_OpeningApp)
    {
      ; -------------------------------------------
      if (DataArray.366.5 == "rwh") ; [ScriptType rwh]
      {
        ; -------------------------------------------
        ; [ScriptError = 2] (rwh)(No Application to Open File)
        ; -------------------------------------------
        if (DataArray.366.6 == 2) ; (366_6)(ScriptError [Integer])
        {
          ; -------------------------------------------
          ; [ScriptError = 2] (rwh)(No Application to Open File)
          ; -------------------------------------------
          FontColor := "a30404" ; Red
          ; -------------------------------------------
          if (DataArray.365.2 == "de") ; (365_2)(UserLang [Current User language])
          {
            TextValue := "Keine Anwendung zum Öffnen der Datei"
          }
          ; -------------------------------------------
          else if (DataArray.365.2 == "en") ; (365_2)(UserLang [Current User language])
          {
            TextValue := "No Application to open File"
          }
          ; -------------------------------------------
          else if (DataArray.365.2 == "es") ; (365_2)(UserLang [Current User language])
          {
            TextValue := "No hay aplicación para abrir el archivo"
          }
          ; -------------------------------------------
          else if (DataArray.365.2 == "fr") ; (365_2)(UserLang [Current User language])
          {
            TextValue := "Aucune application pour ouvrir le fichier"
          }
          ; -------------------------------------------
          else if (DataArray.365.2 == "it") ; (365_2)(UserLang [Current User language])
          {
            TextValue := "Nessuna applicazione per aprire il file"
          }
          ; -------------------------------------------
          else if (DataArray.365.2 == "pl") ; (365_2)(UserLang [Current User language])
          {
            TextValue := "Brak aplikacji do otwierania pliku"
          }
          ; -------------------------------------------
          else if (DataArray.365.2 == "pt") ; (365_2)(UserLang [Current User language])
          {
            TextValue := "Sem aplicativo para abrir arquivo"
          }
          ; -------------------------------------------
          else if (DataArray.365.2 == "ru") ; (365_2)(UserLang [Current User language])
          {
            TextValue := "Нет приложения для открытия файла"
          }
          ; -------------------------------------------
          else if (DataArray.365.2 == "sv") ; (365_2)(UserLang [Current User language])
          {
            TextValue := "Inget program för att öppna filen"
          }
          ; -------------------------------------------
          else if (DataArray.365.2 == "tr") ; (365_2)(UserLang [Current User language])
          {
            TextValue := "Dosyayı Açmak Için Uygulama Yok"
          }
          ; -------------------------------------------
        } ; [End] [ScriptError = 2] (rwh)(No Application to Open File)
        ; -------------------------------------------
        else ; [ScriptError != 2]
        {
          ; -------------------------------------------
          FontColor := "921297" ; Purple
          ; -------------------------------------------
          if (DataArray.305.8 == 0) ; (305_8)(Rwh_UseAppDefault [0/1])
          {
            if (DataArray.305.5 == "") ; (305_5)(Rwh_OpeningApp [Full File Path])
            {
              DataArray.305.8 := 1 ; (305_8)(Rwh_UseAppDefault [0/1])
              TextValue := DataArray.305.6 ; (305_6)(Rwh_DefaultApp [Full File Path])
            }
            else
            {
              TextValue := DataArray.305.5 ; (305_5)(Rwh_OpeningApp [Full File Path])
            }
          } ; [End] (Rwh_UseAppDefault [0])
          else if (DataArray.305.8 == 1) ; (305_8)(Rwh_UseAppDefault [0/1])
          {
            TextValue := DataArray.305.6 ; (305_6)(Rwh_DefaultApp [Full File Path])
          } ; [End] (Rwh_UseAppDefault [1])
          ; -------------------------------------------
        } ; [End] [ScriptError != 2]
        ; -------------------------------------------
        GuiFont := DataArray.366.2 ; (366_2)(GuiFont [Set in DataArray_Set])
        FontSize := 12
        MaxWidth := 480
        Gui_AdjustTextWidth("g_113", TextValue, GuiFont, FontSize, FontColor, MaxWidth) ; (113_1)(Obj_RwhUrl_DisplayText_OpeningApp)
        DataArray.113.3 := TextValue ; (113_3)(Obj_RwhUrl_DisplayText_OpeningApp_Val [Text Value])
        ; -------------------------------------------
      } ; [End] (ScriptType [rwh])
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_114_1") ; (114_1)(Obj_DisplayText_Title1)
    {
      if (DataArray.133.2 == 2) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])
      {
        ; -------------------------------------------
        FontColor := "ffffff"
        ; -------------------------------------------
        if (DataArray.365.2 == "de") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title1_Val := "Verknüpfung Löschen"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "en") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title1_Val := "Delete Shortcut"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "es") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title1_Val := "Eliminar acceso directo"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "fr") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title1_Val := "Supprimer Le Raccourci"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "it") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title1_Val := "Elimina Collegamento"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "pl") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title1_Val := "Usuń Skrót"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "pt") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title1_Val := "Excluir atalho"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "ru") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title1_Val := "Удалить Ярлык"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "sv") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title1_Val := "Ta Bort Genväg"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "tr") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title1_Val := "Kısayolu Sil"
        }
        ; -------------------------------------------
      } ; [End] Obj_DeleteShortcut_Sel == [2])
      ; -------------------------------------------
      else if (DataArray.366.5 == "mnu_cpl_key" or DataArray.366.5 == "run_rwh_url_ofl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        FontColor := "921297" ; Purple
        ; -------------------------------------------
        if (DataArray.365.2 == "de") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title1_Val := "Neue erstellen"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "en") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title1_Val := "Create New"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "es") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title1_Val := "Crear nuevo"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "fr") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title1_Val := "Créer de nouveaux"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "it") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title1_Val := "Crea nuovo"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "pl") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title1_Val := "Tworzenie nowego"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "pt") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title1_Val := "Criar novo"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "ru") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title1_Val := "Создать новый"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "sv") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title1_Val := "Skapa nya"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "tr") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title1_Val := "Yeni Oluştur"
        }
        ; -------------------------------------------
      } ; [End] (ScriptType [mnu_cpl_key,run_rwh_url_ofl])
      ; -------------------------------------------
      else if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (DataArray.72.2 == 1) ; (072_2)(Obj_Key_AppOnly_Sel [0,1,2])
        {
          FontColor := "199524" ; Green
        }
        ; -------------------------------------------
        else
        {
          FontColor := "921297" ; Purple
        }
        ; -------------------------------------------
        if (DataArray.365.2 == "de") ; (365_2)(UserLang [Current User language])
        {
          if (DataArray.72.2 == 1) ; (072_2)(Obj_Key_AppOnly_Sel [0,1,2])
          {
            Obj_DisplayText_Title1_Val := "Jede Anwendung"
          }
          else
          {
            Obj_DisplayText_Title1_Val := "Nur " DataArray.367.1 ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
          }
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "en") ; (365_2)(UserLang [Current User language])
        {
          if (DataArray.72.2 == 1) ; (072_2)(Obj_Key_AppOnly_Sel [0,1,2])
          {
            Obj_DisplayText_Title1_Val := "Any Application"
          }
          else
          {
            Obj_DisplayText_Title1_Val := DataArray.367.1 " Only" ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
          }
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "es") ; (365_2)(UserLang [Current User language])
        {
          if (DataArray.72.2 == 1) ; (072_2)(Obj_Key_AppOnly_Sel [0,1,2])
          {
            Obj_DisplayText_Title1_Val := "Cualquier Aplicación"
          }
          else
          {
            Obj_DisplayText_Title1_Val := "Solo " DataArray.367.1 ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
          }
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "fr") ; (365_2)(UserLang [Current User language])
        {
          if (DataArray.72.2 == 1) ; (072_2)(Obj_Key_AppOnly_Sel [0,1,2])
          {
            Obj_DisplayText_Title1_Val := "Toute Application"
          }
          else
          {
            Obj_DisplayText_Title1_Val := DataArray.367.1 " Uniquement" ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
          }
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "it") ; (365_2)(UserLang [Current User language])
        {
          if (DataArray.72.2 == 1) ; (072_2)(Obj_Key_AppOnly_Sel [0,1,2])
          {
            Obj_DisplayText_Title1_Val := "Qualsiasi Applicazione"
          }
          else
          {
            Obj_DisplayText_Title1_Val := "Solo " DataArray.367.1 ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
          }
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "pl") ; (365_2)(UserLang [Current User language])
        {
          if (DataArray.72.2 == 1) ; (072_2)(Obj_Key_AppOnly_Sel [0,1,2])
          {
            Obj_DisplayText_Title1_Val := "Kazda Aplikacja"
          }
          else
          {
            Obj_DisplayText_Title1_Val := "Tylko " DataArray.367.1 ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
          }
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "pt") ; (365_2)(UserLang [Current User language])
        {
          if (DataArray.72.2 == 1) ; (072_2)(Obj_Key_AppOnly_Sel [0,1,2])
          {
            Obj_DisplayText_Title1_Val := "Qualquer Aplicação"
          }
          else
          {
            Obj_DisplayText_Title1_Val := "Apenas " DataArray.367.1 ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
          }
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "ru") ; (365_2)(UserLang [Current User language])
        {
          if (DataArray.72.2 == 1) ; (072_2)(Obj_Key_AppOnly_Sel [0,1,2])
          {
            Obj_DisplayText_Title1_Val := "Любое приложение"
          }
          else
          {
            Obj_DisplayText_Title1_Val := "Только " DataArray.367.1 ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
          }
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "sv") ; (365_2)(UserLang [Current User language])
        {
          if (DataArray.72.2 == 1) ; (072_2)(Obj_Key_AppOnly_Sel [0,1,2])
          {
            Obj_DisplayText_Title1_Val := "Alla Program"
          }
          else
          {
            Obj_DisplayText_Title1_Val := "Endast " DataArray.367.1 ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
          }
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "tr") ; (365_2)(UserLang [Current User language])
        {
          if (DataArray.72.2 == 1) ; (072_2)(Obj_Key_AppOnly_Sel [0,1,2])
          {
            Obj_DisplayText_Title1_Val := "Herhangi bir Uygulama"
          }
          else
          {
            Obj_DisplayText_Title1_Val := "Sadece " DataArray.367.1 ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
          }
        }
      ; -------------------------------------------
      } ; [End] (ScriptType [key])
      ; -------------------------------------------
      else if (DataArray.366.5 == "mnu") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        FontColor := "921297" ; Purple
        ; -------------------------------------------
        Obj_DisplayText_Title1_Val := DataArray.367.1 ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
        ; -------------------------------------------
      } ; [End] (ScriptType [mnu])
      ; -------------------------------------------
      else if (DataArray.366.5 == "ofl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        ; [ScriptError = 6] (ofl)(Folder Not Found)
        ; -------------------------------------------
        if (DataArray.366.6 == 6) ; (366_6)(ScriptError [Integer])
        {
          FontColor := "a30404" ; Red
        }
        else
        {
          FontColor := "199524" ; Green
        }
        ; -------------------------------------------
        if (DataArray.365.2 == "de") ; (365_2)(UserLang [Current User language])
        {
          if (StrLen(DataArray.303.3) == 3) ; (303_3)(ofl_FolderName [Folder Name NO Path])
          {
            ; -------------------------------------------
            Obj_DisplayText_Title1_Val := "Laufwerk öffnen"
            ; -------------------------------------------
          }
          else
          {
            ; -------------------------------------------
            Obj_DisplayText_Title1_Val := "Offener Ordner"
            ; -------------------------------------------
          }
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "en") ; (365_2)(UserLang [Current User language])
        {
          if (StrLen(DataArray.303.3) == 3) ; (303_3)(ofl_FolderName [Folder Name NO Path])
          {
            ; -------------------------------------------
            Obj_DisplayText_Title1_Val := "Open Drive"
            ; -------------------------------------------
          }
          else
          {
            ; -------------------------------------------
            Obj_DisplayText_Title1_Val := "Open Folder"
            ; -------------------------------------------
          }
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "es") ; (365_2)(UserLang [Current User language])
        {
          if (StrLen(DataArray.303.3) == 3) ; (303_3)(ofl_FolderName [Folder Name NO Path])
          {
            ; -------------------------------------------
            Obj_DisplayText_Title1_Val := "Unidad Drive"
            ; -------------------------------------------
          }
          else
          {
            ; -------------------------------------------
            Obj_DisplayText_Title1_Val := "Abrir Carpeta"
            ; -------------------------------------------
          }
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "fr") ; (365_2)(UserLang [Current User language])
        {
          if (StrLen(DataArray.303.3) == 3) ; (303_3)(ofl_FolderName [Folder Name NO Path])
          {
            ; -------------------------------------------
            Obj_DisplayText_Title1_Val := "Ouvrez le lecteur"
            ; -------------------------------------------
          }
          else
          {
            ; -------------------------------------------
            Obj_DisplayText_Title1_Val := "Dossier ouvert"
            ; -------------------------------------------
          }
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "it") ; (365_2)(UserLang [Current User language])
        {
          if (StrLen(DataArray.303.3) == 3) ; (303_3)(ofl_FolderName [Folder Name NO Path])
          {
            ; -------------------------------------------
            Obj_DisplayText_Title1_Val := "Apri l'unità"
            ; -------------------------------------------
          }
          else
          {
            ; -------------------------------------------
            Obj_DisplayText_Title1_Val := "Apri Cartella"
            ; -------------------------------------------
          }
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "pl") ; (365_2)(UserLang [Current User language])
        {
          if (StrLen(DataArray.303.3) == 3) ; (303_3)(ofl_FolderName [Folder Name NO Path])
          {
            ; -------------------------------------------
            Obj_DisplayText_Title1_Val := "Otwórz dysk"
            ; -------------------------------------------
          }
          else
          {
            ; -------------------------------------------
            Obj_DisplayText_Title1_Val := "Otwórz folder"
            ; -------------------------------------------
          }
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "pt") ; (365_2)(UserLang [Current User language])
        {
          if (StrLen(DataArray.303.3) == 3) ; (303_3)(ofl_FolderName [Folder Name NO Path])
          {
            ; -------------------------------------------
            Obj_DisplayText_Title1_Val := "Unidade acionar"
            ; -------------------------------------------
          }
          else
          {
            ; -------------------------------------------
            Obj_DisplayText_Title1_Val := "Pasta Aberta"
            ; -------------------------------------------
          }
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "ru") ; (365_2)(UserLang [Current User language])
        {
          if (StrLen(DataArray.303.3) == 3) ; (303_3)(ofl_FolderName [Folder Name NO Path])
          {
            ; -------------------------------------------
            Obj_DisplayText_Title1_Val := "Открыть диск"
            ; -------------------------------------------
          }
          else
          {
            ; -------------------------------------------
            Obj_DisplayText_Title1_Val := "Открыть папку"
            ; -------------------------------------------
          }
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "sv") ; (365_2)(UserLang [Current User language])
        {
          if (StrLen(DataArray.303.3) == 3) ; (303_3)(ofl_FolderName [Folder Name NO Path])
          {
            ; -------------------------------------------
            Obj_DisplayText_Title1_Val := "Öppna Drive"
            ; -------------------------------------------
          }
          else
          {
            ; -------------------------------------------
            Obj_DisplayText_Title1_Val := "Öppna Mapp"
            ; -------------------------------------------
          }
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "tr") ; (365_2)(UserLang [Current User language])
        {
          if (StrLen(DataArray.303.3) == 3) ; (303_3)(ofl_FolderName [Folder Name NO Path])
          {
            ; -------------------------------------------
            Obj_DisplayText_Title1_Val := "Açık Sürücü"
            ; -------------------------------------------
          }
          else
          {
            ; -------------------------------------------
            Obj_DisplayText_Title1_Val := "Klasörü Aç"
            ; -------------------------------------------
          }
        }
        ; -------------------------------------------
      } ; [End] (ScriptType [ofl])
      ; -------------------------------------------
      else if (DataArray.366.5 == "run") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        ; [ScriptError = 1] (Application Target [exe] File Not Found)
        ; -------------------------------------------
        if (DataArray.366.6 == 1) ; (366_6)(ScriptError [Integer])
        {
          FontColor := "a30404" ; Red
        }
        else if (DataArray.73.2 == 2) ; (073_2)(Obj_Run_AsAdmin_Sel [0,1,2])
        {
          FontColor := "040e47" ; Blue
        }
        else
        {
          FontColor := "199524" ; Green
        }
        ; -------------------------------------------
        if (DataArray.365.2 == "de") ; (365_2)(UserLang [Current User language])
        {
          if (DataArray.73.2 == 2) ; (073_2)(Obj_Run_AsAdmin_Sel [0,1,2])
          {
            Obj_DisplayText_Title1_Val := "Ausführen als Administrator"
          }
          else
          {
            Obj_DisplayText_Title1_Val := "Betreiben"
          }
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "en") ; (365_2)(UserLang [Current User language])
        {
          if (DataArray.73.2 == 2) ; (073_2)(Obj_Run_AsAdmin_Sel [0,1,2])
          {
            Obj_DisplayText_Title1_Val := "Run As Administrator"
          }
          else
          {
            Obj_DisplayText_Title1_Val := "Run"
          }
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "es") ; (365_2)(UserLang [Current User language])
        {
          if (DataArray.73.2 == 2) ; (073_2)(Obj_Run_AsAdmin_Sel [0,1,2])
          {
            Obj_DisplayText_Title1_Val := "Ejecutar como administrador"
          }
          else
          {
            Obj_DisplayText_Title1_Val := "Ejecutar"
          }
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "fr") ; (365_2)(UserLang [Current User language])
        {
          if (DataArray.73.2 == 2) ; (073_2)(Obj_Run_AsAdmin_Sel [0,1,2])
          {
            Obj_DisplayText_Title1_Val := "Exécuter en tant qu'administrateur"
          }
          else
          {
            Obj_DisplayText_Title1_Val := "Fonctionner"
          }
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "it") ; (365_2)(UserLang [Current User language])
        {
          if (DataArray.73.2 == 2) ; (073_2)(Obj_Run_AsAdmin_Sel [0,1,2])
          {
            Obj_DisplayText_Title1_Val := "Esegui come Amministratore"
          }
          else
          {
            Obj_DisplayText_Title1_Val := "Funzionare"
          }
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "pl") ; (365_2)(UserLang [Current User language])
        {
          if (DataArray.73.2 == 2) ; (073_2)(Obj_Run_AsAdmin_Sel [0,1,2])
          {
            Obj_DisplayText_Title1_Val := "Uruchom jako Administrator"
          }
          else
          {
            Obj_DisplayText_Title1_Val := "Uruchomić"
          }
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "pt") ; (365_2)(UserLang [Current User language])
        {
          if (DataArray.73.2 == 2) ; (073_2)(Obj_Run_AsAdmin_Sel [0,1,2])
          {
            Obj_DisplayText_Title1_Val := "Executado como Administrador"
          }
          else
          {
            Obj_DisplayText_Title1_Val := "Executar"
          }
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "ru") ; (365_2)(UserLang [Current User language])
        {
          if (DataArray.73.2 == 2) ; (073_2)(Obj_Run_AsAdmin_Sel [0,1,2])
          {
            Obj_DisplayText_Title1_Val := "Выполнить в качестве администратора"
          }
          else
          {
            Obj_DisplayText_Title1_Val := "Запустить"
          }
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "sv") ; (365_2)(UserLang [Current User language])
        {
          if (DataArray.73.2 == 2) ; (073_2)(Obj_Run_AsAdmin_Sel [0,1,2])
          {
            Obj_DisplayText_Title1_Val := "Kör som Administratör"
          }
          else
          {
            Obj_DisplayText_Title1_Val := "Köra"
          }
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "tr") ; (365_2)(UserLang [Current User language])
        {
          if (DataArray.73.2 == 2) ; (073_2)(Obj_Run_AsAdmin_Sel [0,1,2])
          {
            Obj_DisplayText_Title1_Val := "Yönetici Olarak Çalıştır"
          }
          else
          {
            Obj_DisplayText_Title1_Val := "Çalıştırmak"
          }
        }
        ; -------------------------------------------
      } ; [End] (ScriptType [run])
      ; -------------------------------------------
      else if (DataArray.366.5 == "rwh") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        ; [ScriptError = 1] (Application Target [exe] File Not Found)
        ; -------------------------------------------
        ; [ScriptError = 2] (rwh)(No Application to Open File)
        ; -------------------------------------------
        if (DataArray.366.6 == 1 or DataArray.366.6 == 2) ; (366_6)(ScriptError [Integer])
        {
          FontColor := "a30404" ; Red            
        }
        else
        {
          FontColor := "199524" ; Green
        }
        ; -------------------------------------------
        Obj_DisplayText_Title1_Val := DataArray.305.3 ; (305_3)(Run_FileNameExt [Selected File] [Name,Ext])
        ; -------------------------------------------
      } ; [End] (ScriptType [rwh])
      ; -------------------------------------------
      else if (DataArray.366.5 == "cpl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        FontColor := "199524" ; Green
        ; -------------------------------------------
        Obj_DisplayText_Title1_Val := "windows"
        ; -------------------------------------------
      } ; [End] (ScriptType [cpl])
      ; -------------------------------------------
      else if (DataArray.366.5 == "url") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        FontColor := "199524" ; Green
        ; -------------------------------------------
        Obj_DisplayText_Title1_Val := "URL"
        ; -------------------------------------------
      } ; [End] (ScriptType [url])
      ; -------------------------------------------
      else if (DataArray.366.5 == "xxx") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        FontColor := "921297" ; Purple
        ; -------------------------------------------
        if (DataArray.365.2 == "de") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title1_Val := "Neue erstellen"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "en") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title1_Val := "Create New"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "es") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title1_Val := "Crear nuevo"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "fr") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title1_Val := "Créer de nouveaux"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "it") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title1_Val := "Crea nuovo"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "pl") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title1_Val := "Tworzenie nowego"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "pt") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title1_Val := "Criar novos"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "ru") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title1_Val := "Создать новый"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "sv") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title1_Val := "Skapa nya"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "tr") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title1_Val := "Yeni Oluştur"
        }
        ; -------------------------------------------
      } ; [End] (ScriptType [xxx])
      ; -------------------------------------------
      if (InStr(DataArray.366.5, "pum") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        GuiFont := DataArray.366.2 ; (366_2)(GuiFont [Set in DataArray_Set])
        FontSize := 14
        Gui_AdjustTextWidth("g_114", Obj_DisplayText_Title1_Val, GuiFont, FontSize, FontColor, 158)  ; (114_1)(Obj_DisplayText_Title1)
        DataArray.114.3 := Obj_DisplayText_Title1_Val ; (114_3)(Obj_DisplayText_Title1_Val [Text Value])
        ; -------------------------------------------
      } ; [End] NOT (ScriptType [pum])
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_115_1") ; (115_1)(Obj_DisplayText_Title2)
    {
      if (DataArray.133.2 == 2) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])
      {
        ; -------------------------------------------
        FontColor := "ffffff"
        ; -------------------------------------------
        if (DataArray.365.2 == "de") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "Drücken Akzeptieren"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "en") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "Press Accept"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "es") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "Pulsar Aceptar"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "fr") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "Pousser Accepter"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "it") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "Spingere Accettare"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "pl") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "Naciśnij Zaakceptować"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "pt") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "Pressione Aceitar"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "ru") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "Нажмите Принять"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "sv") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "Trycka Acceptera"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "tr") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "Kabul Et'e basın"
        }
        ; -------------------------------------------
      } ; [End] (Obj_DeleteShortcut_Sel == [2])
      ; -------------------------------------------
      else if (DataArray.366.5 == "mnu_cpl_key" or DataArray.366.5 == "run_rwh_url_ofl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        FontColor := "921297" ; Purple
        ; -------------------------------------------
        if (DataArray.365.2 == "de") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "Verknüpfung"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "en") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "Shortcut"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "es") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "Acceso directo"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "fr") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "Raccourci"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "it") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "Collegamento"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "pl") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "Skrótu"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "pt") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "Atalho"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "ru") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "ярлык"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "sv") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "Genväg"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "tr") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "Kısayol"
        }
        ; -------------------------------------------
      } ; [End] (ScriptType [mnu_cpl_key,run_rwh_url_ofl])
      ; -------------------------------------------
      else if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (DataArray.366.6 == 3) ; (366_6)(ScriptError [Integer])
        {
          FontColor := "a30404" ; Red
        }
        else
        {
          FontColor := "199524" ; Green
        }
        ; -------------------------------------------
        if (DataArray.365.2 == "de") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "Tastenanschlag Eintrag"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "en") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "Keystroke Entry"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "es") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "Entrada de pulsación de tecla"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "fr") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "Entrée de frappe"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "it") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "Immissione della sequenza di tasti"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "pl") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "Wpisywanie Klawiszy"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "pt") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "Entrada de teclas"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "ru") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "Ключевой удар Вступление"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "sv") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "Tangenttryckningar"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "tr") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "Tuş vuruşu Girişi"
        }
        ; -------------------------------------------
      } ; [End] (ScriptType [key])
      ; -------------------------------------------
      else if (DataArray.366.5 == "mnu") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        FontColor := "921297" ; Purple
        ; -------------------------------------------
        if (DataArray.365.2 == "de") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "Kontextmenü"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "en") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "Context Menu"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "es") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "Menú Contextual"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "fr") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "Menu Contexte"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "it") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "Menu contestuale"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "pl") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "Menu kontekstowe"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "pt") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "Menu contextual"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "ru") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "Контекстное меню"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "sv") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "Snabbmenyn"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "tr") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "Bağlam Menüsü"
        }
        ; -------------------------------------------
      } ; [End] (ScriptType [mnu])
      ; -------------------------------------------
      else if (DataArray.366.5 == "ofl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (StrLen(DataArray.303.3) == 3) ; (303_3)(ofl_FolderName [Folder Name NO Path])
        {
          FontColor := "199524" ; Green
        }
        else
        {
          FontColor := "921297" ; Purple
        }
        ; -------------------------------------------
        if (StrLen(DataArray.303.2) == 3) ; (303_2)(ofl_FolderPathName [Folder Name With Path])
        {
          ; ------------------------------------------(303_2)([ofl] Folder Path)_(303_3)([ofl] Folder Name)
          StringUpper, UpperCase_ofl_FolderPathName, ofl_FolderPathName
          Obj_DisplayText_Title2_Val := UpperCase_ofl_FolderPathName
          ; -------------------------------------------
        } ; [End] is NOT a Folder
        else ; is a Folder
        {
          ; -------------------------------------------
          ofl_FolderName := DataArray.303.3 ; (303_3)(ofl_FolderName [Folder Name NO Path])
          ; -------------------------------------------
          Obj_DisplayText_Title2_Val := ofl_FolderName
          ; -------------------------------------------
        } ; [End] is a Folder
        ; -------------------------------------------
      } ; [End] (ScriptType [ofl])
      ; -------------------------------------------
      else if (DataArray.366.5 == "run") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        ; [ScriptError = 1] (run)(rwh)(Application Target [exe] File Not Found)
        ; -------------------------------------------
        if (DataArray.366.6 == 1) ; (366_6)(ScriptError [Integer])
        {
          ; -------------------------------------------
          FontColor := "a30404" ; Red
          ; -------------------------------------------
          if (DataArray.365.2 == "de") ; (365_2)(UserLang [Current User language])
          {
            Obj_DisplayText_Title2_Val := "Zieldatei nicht gefunden"
          }
          ; -------------------------------------------
          else if (DataArray.365.2 == "en") ; (365_2)(UserLang [Current User language])
          {
            Obj_DisplayText_Title2_Val := "Target File Not Found"
          }
          ; -------------------------------------------
          else if (DataArray.365.2 == "es") ; (365_2)(UserLang [Current User language])
          {
            Obj_DisplayText_Title2_Val := "Archivo de destino no encontrado"
          }
          ; -------------------------------------------
          else if (DataArray.365.2 == "fr") ; (365_2)(UserLang [Current User language])
          {
            Obj_DisplayText_Title2_Val := "Fichier cible introuvable"
          }
          ; -------------------------------------------
          else if (DataArray.365.2 == "it") ; (365_2)(UserLang [Current User language])
          {
            Obj_DisplayText_Title2_Val := "File di destinazione non trovato"
          }
          ; -------------------------------------------
          else if (DataArray.365.2 == "pl") ; (365_2)(UserLang [Current User language])
          {
            Obj_DisplayText_Title2_Val := "Nie znaleziono pliku docelowego"
          }
          ; -------------------------------------------
          else if (DataArray.365.2 == "pt") ; (365_2)(UserLang [Current User language])
          {
            Obj_DisplayText_Title2_Val := "Arquivo de destino não encontrado"
          }
          ; -------------------------------------------
          else if (DataArray.365.2 == "ru") ; (365_2)(UserLang [Current User language])
          {
            Obj_DisplayText_Title2_Val := "Целевой файл не найден"
          }
          ; -------------------------------------------
          else if (DataArray.365.2 == "sv") ; (365_2)(UserLang [Current User language])
          {
            Obj_DisplayText_Title2_Val := "Målfil hittades inte"
          }
          ; -------------------------------------------
          else if (DataArray.365.2 == "tr") ; (365_2)(UserLang [Current User language])
          {
            Obj_DisplayText_Title2_Val := "Hedef Dosya Bulunamadı"
          }
          ; -------------------------------------------
        } ; [End] (ScriptError [1])
        ; -------------------------------------------
        else ; NOT (ScriptError [1])
        {
          ; -------------------------------------------
          if (DataArray.73.2 == 1) ; (073_2)(Obj_Run_AsAdmin_Sel [0,1,2])
          {
            FontColor := "199524" ; Green
          }
          else
          {
            FontColor := "921297" ; Purple
          }
          ; -------------------------------------------
          Obj_DisplayText_Title2_Val := DataArray.305.2 ; (305_2)(Run_FileName [Selected File] [Name])
          ; -------------------------------------------
        } ; [End] NOT (ScriptError [1])
        ; -------------------------------------------
      } ; [End] (ScriptType [run])
      ; -------------------------------------------
      else if (DataArray.366.5 == "rwh") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
         ; -------------------------------------------
         ; [ScriptError = 1] (run)(rwh)(Application Target [exe] File Not Found)
         ; -------------------------------------------
        if (DataArray.366.6 == 1) ; (366_6)(ScriptError [Integer])
        {
          ; -------------------------------------------
          FontColor := "a30404" ; Red
          ; -------------------------------------------
          if (DataArray.365.2 == "de") ; (365_2)(UserLang [Current User language])
          {
            Obj_DisplayText_Title2_Val := "Zieldatei nicht gefunden"
          }
          ; -------------------------------------------
          else if (DataArray.365.2 == "en") ; (365_2)(UserLang [Current User language])
          {
            Obj_DisplayText_Title2_Val := "Target File Not Found"
          }
          ; -------------------------------------------
          else if (DataArray.365.2 == "es") ; (365_2)(UserLang [Current User language])
          {
            Obj_DisplayText_Title2_Val := "Archivo de destino no encontrado"
          }
          ; -------------------------------------------
          else if (DataArray.365.2 == "fr") ; (365_2)(UserLang [Current User language])
          {
            Obj_DisplayText_Title2_Val := "Fichier cible introuvable"
          }
          ; -------------------------------------------
          else if (DataArray.365.2 == "it") ; (365_2)(UserLang [Current User language])
          {
            Obj_DisplayText_Title2_Val := "File di destinazione non trovato"
          }
          ; -------------------------------------------
          else if (DataArray.365.2 == "pl") ; (365_2)(UserLang [Current User language])
          {
            Obj_DisplayText_Title2_Val := "Nie znaleziono pliku docelowego"
          }
          ; -------------------------------------------
          else if (DataArray.365.2 == "pt") ; (365_2)(UserLang [Current User language])
          {
            Obj_DisplayText_Title2_Val := "Arquivo de destino não encontrado"
          }
          ; -------------------------------------------
          else if (DataArray.365.2 == "ru") ; (365_2)(UserLang [Current User language])
          {
            Obj_DisplayText_Title2_Val := "Целевой файл не найден"
          }
          ; -------------------------------------------
          else if (DataArray.365.2 == "sv") ; (365_2)(UserLang [Current User language])
          {
            Obj_DisplayText_Title2_Val := "Målfil hittades inte"
          }
          ; -------------------------------------------
          else if (DataArray.365.2 == "tr") ; (365_2)(UserLang [Current User language])
          {
            Obj_DisplayText_Title2_Val := "Hedef Dosya Bulunamadı"
          }
          ; -------------------------------------------
        } ; [End] (ScriptError [1])
        ; -------------------------------------------
        ; [ScriptError = 2] (rwh)(No Application to Open File)
        ; -------------------------------------------
        else if (DataArray.366.6 == 2) ; (366_6)(ScriptError [Integer])
        {
          ; -------------------------------------------
          FontColor := "a30404" ; Red
          ; -------------------------------------------
          if (DataArray.365.2 == "de") ; (365_2)(UserLang [Current User language])
          {
            Obj_DisplayText_Title2_Val := "Keine Anwendung zum Öffnen der Datei"
          }
          ; -------------------------------------------
          else if (DataArray.365.2 == "en") ; (365_2)(UserLang [Current User language])
          {
            Obj_DisplayText_Title2_Val := "No Application to open File"
          }
          ; -------------------------------------------
          else if (DataArray.365.2 == "es") ; (365_2)(UserLang [Current User language])
          {
            Obj_DisplayText_Title2_Val := "No hay aplicación para abrir el archivo"
          }
          ; -------------------------------------------
          else if (DataArray.365.2 == "fr") ; (365_2)(UserLang [Current User language])
          {
            Obj_DisplayText_Title2_Val := "Aucune application pour ouvrir le fichier"
          }
          ; -------------------------------------------
          else if (DataArray.365.2 == "it") ; (365_2)(UserLang [Current User language])
          {
            Obj_DisplayText_Title2_Val := "Nessuna applicazione per aprire il file"
          }
          ; -------------------------------------------
          else if (DataArray.365.2 == "pl") ; (365_2)(UserLang [Current User language])
          {
            Obj_DisplayText_Title2_Val := "Brak aplikacji do otwierania pliku"
          }
          ; -------------------------------------------
          else if (DataArray.365.2 == "pt") ; (365_2)(UserLang [Current User language])
          {
            Obj_DisplayText_Title2_Val := "Sem aplicativo para abrir arquivo"
          }
          ; -------------------------------------------
          else if (DataArray.365.2 == "ru") ; (365_2)(UserLang [Current User language])
          {
            Obj_DisplayText_Title2_Val := "Нет приложения для открытия файла"
          }
          ; -------------------------------------------
          else if (DataArray.365.2 == "sv") ; (365_2)(UserLang [Current User language])
          {
            Obj_DisplayText_Title2_Val := "Inget program för att öppna filen"
          }
          ; -------------------------------------------
          else if (DataArray.365.2 == "tr") ; (365_2)(UserLang [Current User language])
          {
            Obj_DisplayText_Title2_Val := "Dosyayı Açmak Için Uygulama Yok"
          }
          ; -------------------------------------------
        } ; [End] (ScriptError [2])
        ; -------------------------------------------
        else ; NOT (ScriptError [1,2])
        {
          ; -------------------------------------------
          FontColor := "921297" ; Purple
          ; -------------------------------------------
          if (DataArray.365.2 == "de") ; (365_2)(UserLang [Current User language])
          {
            Obj_DisplayText_Title2_Val := "Öffnen Mit"
          }
          ; -------------------------------------------
          else if (DataArray.365.2 == "en") ; (365_2)(UserLang [Current User language])
          {
            Obj_DisplayText_Title2_Val := "Open With"
          }
          ; -------------------------------------------
          else if (DataArray.365.2 == "es") ; (365_2)(UserLang [Current User language])
          {
            Obj_DisplayText_Title2_Val := "Abrir con"
          }
          ; -------------------------------------------
          else if (DataArray.365.2 == "fr") ; (365_2)(UserLang [Current User language])
          {
            Obj_DisplayText_Title2_Val := "Ouvrir avec"
          }
          ; -------------------------------------------
          else if (DataArray.365.2 == "it") ; (365_2)(UserLang [Current User language])
          {
            Obj_DisplayText_Title2_Val := "Aperta con"
          }
          ; -------------------------------------------
          else if (DataArray.365.2 == "pl") ; (365_2)(UserLang [Current User language])
          {
            Obj_DisplayText_Title2_Val := "Otwierać z"
          }
          ; -------------------------------------------
          else if (DataArray.365.2 == "pt") ; (365_2)(UserLang [Current User language])
          {
            Obj_DisplayText_Title2_Val := "Abrir com"
          }
          ; -------------------------------------------
          else if (DataArray.365.2 == "ru") ; (365_2)(UserLang [Current User language])
          {
            Obj_DisplayText_Title2_Val := "Открыть с"
          }
          ; -------------------------------------------
          else if (DataArray.365.2 == "sv") ; (365_2)(UserLang [Current User language])
          {
            Obj_DisplayText_Title2_Val := "Öppna med"
          }
          ; -------------------------------------------
          else if (DataArray.365.2 == "tr") ; (365_2)(UserLang [Current User language])
          {
            Obj_DisplayText_Title2_Val := "Bununla aç"
          }
          ; -------------------------------------------
        } ; [End] NOT (ScriptError [1,2])
        ; -------------------------------------------
      } ; [End] (ScriptType [rwh])
      ; -------------------------------------------
      else if (DataArray.366.5 == "cpl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        FontColor := "199524" ; Green
        ; -------------------------------------------
        if (DataArray.365.2 == "de") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "Steuerung"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "en") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "Control"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "es") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "Control"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "fr") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "Contrôle"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "it") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "Controllo"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "pl") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "Kontroli"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "pt") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "Controle"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "ru") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "Управления"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "sv") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "Kontroll"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "tr") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "Denetim"
        }
        ; -------------------------------------------
      } ; [End] (ScriptType [cpl])
      ; -------------------------------------------
      else if (DataArray.366.5 == "url" or DataArray.366.5 == "xxx") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        FontColor := "921297" ; Purple
        ; -------------------------------------------
        if (DataArray.365.2 == "de") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "Verknüpfung"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "en") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "Shortcut"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "es") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "Acceso directo"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "fr") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "Raccourci"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "it") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "Scelta rapida"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "pl") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "Skrótów"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "pt") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "Atalho"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "ru") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "ярлык"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "sv") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "Genväg"
        }
        ; -------------------------------------------
        else if (DataArray.365.2 == "tr") ; (365_2)(UserLang [Current User language])
        {
          Obj_DisplayText_Title2_Val := "Kısayol"
        }
        ; -------------------------------------------
      } ; [End] (ScriptType [xxx,url])
      ; -------------------------------------------
      if (InStr(DataArray.366.5, "pum") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        GuiFont := DataArray.366.2 ; (366_2)(GuiFont [Set in DataArray_Set])
        FontSize := 14
        Gui_AdjustTextWidth("g_115", Obj_DisplayText_Title2_Val, GuiFont, FontSize, FontColor, 158) ; (115_1)(Obj_DisplayText_Title2)
        Obj_DisplayText_Title2_Val := DataArray.115.3 ; (115_3)(Obj_DisplayText_Title2_Val [Text Value])
        ; -------------------------------------------
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_116_1") ; (116_1)(Obj_CplMnu_List100)
    {
      ; CplMnu_MenuDisplay.ahk
      ; (070_1)(Obj_MnuCplKey_WinControl)
      ; (087_1)(Obj_Mnu_Menu)
      ; (116_1)(Obj_CplMnu_List100)
      ; PopUpMenu
      ; Sys_EnableDisable.ahk
      ; _Include.ahk
      ; _S2_H.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_117_1") ; (117_1)(Obj_CplMnu_ListRight60)
    {
      ; CplMnu_MenuDisplay.ahk
      ; (070_1)(Obj_MnuCplKey_WinControl)
      ; (087_1)(Obj_Mnu_Menu)
      ; (117_1)(Obj_CplMnu_ListRight60)
      ; PopUpMenu
      ; Sys_EnableDisable.ahk
      ; _Include.ahk
      ; _S2_H.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_118_1") ; (118_1)(Obj_CplMnu_ListLeft30)
    {
      ; CplMnu_MenuDisplay.ahk
      ; (070_1)(Obj_MnuCplKey_WinControl)
      ; (087_1)(Obj_Mnu_Menu)
      ; (118_1)(Obj_CplMnu_ListLeft30)
      ; PopUpMenu
      ; Sys_EnableDisable.ahk
      ; _Include.ahk
      ; _S2_H.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_119_1") ; (119_1)(Mkb_KeyStroke)
    {
      ; (119_1)(Empty)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_120_1") ; (120_1)(Obj_CplMnu_ListCenter30)
    {
      ; CplMnu_MenuDisplay.ahk
      ; (070_1)(Obj_MnuCplKey_WinControl)
      ; (087_1)(Obj_Mnu_Menu)
      ; (120_1)(Obj_CplMnu_ListCenter30)
      ; PopUpMenu
      ; Sys_EnableDisable.ahk
      ; _Include.ahk
      ; _S2_H.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_121_1") ; (121_1)(Obj_CplMnu_ListRight30)
    {
      ; CplMnu_MenuDisplay.ahk
      ; (070_1)(Obj_MnuCplKey_WinControl)
      ; (087_1)(Obj_Mnu_Menu)
      ; (121_1)(Obj_CplMnu_ListRight30)
      ; PopUpMenu
      ; Sys_EnableDisable.ahk
      ; _Include.ahk
      ; _S2_H.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_122_1") ; (122_1)(Obj_EditFeild_StatusBar)
    {
      ; -------------------------------------------
      ; [ScriptError = 1] (run)(rwh)(Application Target [exe] File Not Found)
      ; [ScriptError = 2] (rwh)(No Application to Open File)
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 6] (ofl)(Folder Not Found)
      ; [ScriptError = 10] (mnu)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError = 11] (cpl)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; [ScriptError = 14] (cpl)(No Error)(Menu Bar Item Not Selected)
      ; [ScriptError = 15] (url)(No Selected URL)
      ; [ScriptError = 18] (url)(Source Not Found)
      ; [ScriptError = 19] (url)(No Internet Connection)
      ; [ScriptError = 21] (url)(Right Clicked Existing url Shortcut, NO Browser Active)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 1 or DataArray.366.6 == 2 or DataArray.366.6 == 3 or DataArray.366.6 == 6 or DataArray.366.6 == 10 or DataArray.366.6 == 11 or DataArray.366.6 == 13 or DataArray.366.6 == 14 or DataArray.366.6 == 15 or DataArray.366.6 == 18 or DataArray.366.6 == 19 or DataArray.366.6 == 21) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "mnu" or DataArray.366.5 == "cpl" or DataArray.366.5 == "key" or DataArray.366.5 == "ofl" or DataArray.366.5 == "run" or DataArray.366.5 == "rwh" or DataArray.366.5 == "url") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (DataArray.122.3 != "") ; (122_3)(Obj_EditFeild_StatusBar_Val [Text Value])
          {
            ; -------------------------------------------
            Obj_EditFeild_StatusBar_Val := DataArray.122.3 ; (122_3)(Obj_EditFeild_StatusBar_Val [Text Value])
            Obj_EditFeild_StatusBar_Val := StrReplace(Obj_EditFeild_StatusBar_Val, "&&&&&&&&&&&&&", "&")
            Obj_EditFeild_StatusBar_Val := StrReplace(Obj_EditFeild_StatusBar_Val, "&&&&&&&&&&&&", "&")
            Obj_EditFeild_StatusBar_Val := StrReplace(Obj_EditFeild_StatusBar_Val, "&&&&&&&&&&&", "&")
            Obj_EditFeild_StatusBar_Val := StrReplace(Obj_EditFeild_StatusBar_Val, "&&&&&&&&&&", "&")
            Obj_EditFeild_StatusBar_Val := StrReplace(Obj_EditFeild_StatusBar_Val, "&&&&&&&&&", "&")
            Obj_EditFeild_StatusBar_Val := StrReplace(Obj_EditFeild_StatusBar_Val, "&&&&&&&&", "&")
            Obj_EditFeild_StatusBar_Val := StrReplace(Obj_EditFeild_StatusBar_Val, "&&&&&&&", "&")
            Obj_EditFeild_StatusBar_Val := StrReplace(Obj_EditFeild_StatusBar_Val, "&&&&&&", "&")
            Obj_EditFeild_StatusBar_Val := StrReplace(Obj_EditFeild_StatusBar_Val, "&&&&&", "&")
            Obj_EditFeild_StatusBar_Val := StrReplace(Obj_EditFeild_StatusBar_Val, "&&&&", "&")
            Obj_EditFeild_StatusBar_Val := StrReplace(Obj_EditFeild_StatusBar_Val, "&&&", "&")
            Obj_EditFeild_StatusBar_Val := StrReplace(Obj_EditFeild_StatusBar_Val, "&&", "&")
            ; -------------------------------------------
            DataArray.122.3 := Obj_EditFeild_StatusBar_Val ; (122_3)(Obj_EditFeild_StatusBar_Val [Text Value])
            ; -------------------------------------------
            GuiControl, PopUpMenu:, g_122, %Obj_EditFeild_StatusBar_Val% ; (122_1)(Obj_EditFeild_StatusBar)
          }
          GuiControl, PopUpMenu:Show, g_122 ; (122_1)(Obj_EditFeild_StatusBar)
          ; -------------------------------------------
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_123_1") ; (123_1)(Obj_Key_EditFeild_TextInput)
    {
      ; -------------------------------------------
      ; [ScriptError = 3] (key)(Invalid KeyStroke)
      ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 3 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          for Index, CheckThisKey in Key_ArrayNumbers
          {
            if (SubStr(CheckThisKey, 1, 1) == "~")
            {
              Obj_Key_EditFeild_TextInput_Val := SubStr(CheckThisKey, 2, StrLen(CheckThisKey) - 2)
              DataArray.123.3 := Obj_Key_EditFeild_TextInput_Val ; (123_3)(Obj_Key_EditFeild_TextInput_Val [Text Value])
              GuiControl, PopUpMenu:, g_123, %Obj_Key_EditFeild_TextInput_Val% ; (123_1)(Obj_Key_EditFeild_TextInput)
              break
            } ; [End] if (SubStr(CheckThisKey, 1, 1) == "~")
          } ; [End] for Index, CheckThisKey in Key_ArrayNumbers
          ; -------------------------------------------
          DataArray.123.2 := 1 ; (123_2)(Obj_Key_EditFeild_TextInput_Sel [0,1,2,3])
          GuiControl, PopUpMenu:Show, g_123 ; (123_1)(Obj_Key_EditFeild_TextInput)
          ; -------------------------------------------
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_124_1") ; (124_1)(Obj_DropDownListLang)
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; (Empty)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_125_1") ; (125_1)(Obj_Cpl_Menu1)
    {
      ; -------------------------------------------
      ; [ScriptError = 11] (cpl)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError = 14] (cpl)(No Error)(Menu Bar Item Not Selected)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 11 or DataArray.366.6 == 14) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "cpl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (DataArray.300.2 == 1) ; (300_2)(Cpl_Number_x000 [#_X_X_X])
          {
            DataArray := Image_GuiControl("Menu_125", 2, 0, DataArray) ; (125_1)(Obj_Cpl_Menu1)
          }
          else
          {
            DataArray := Image_GuiControl("Menu_125", 1, 0, DataArray) ; (125_1)(Obj_Cpl_Menu1)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_126_1") ; (126_1)(Obj_Cpl_Menu2)
    {
      ; -------------------------------------------
      ; [ScriptError = 11] (cpl)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError = 14] (cpl)(No Error)(Menu Bar Item Not Selected)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 11 or DataArray.366.6 == 14) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "cpl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (DataArray.300.2 == 2) ; (300_2)(Cpl_Number_x000 [#_X_X_X])
          {
            DataArray := Image_GuiControl("Menu_126", 2, 0, DataArray) ; (126_1)(Obj_Cpl_Menu2)
          }
          else
          {
            DataArray := Image_GuiControl("Menu_126", 1, 0, DataArray) ; (126_1)(Obj_Cpl_Menu2)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_127_1") ; (127_1)(Obj_Cpl_Menu3)
    {
      ; -------------------------------------------
      ; [ScriptError = 11] (cpl)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError = 14] (cpl)(No Error)(Menu Bar Item Not Selected)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 11 or DataArray.366.6 == 14) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "cpl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (DataArray.300.2 == 3) ; (300_2)(Cpl_Number_x000 [#_X_X_X])
          {
            DataArray := Image_GuiControl("Menu_127", 2, 0, DataArray) ; (127_1)(Obj_Cpl_Menu3)
          }
          else
          {
            DataArray := Image_GuiControl("Menu_127", 1, 0, DataArray) ; (127_1)(Obj_Cpl_Menu3)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_128_1") ; (128_1)(Obj_Cpl_Menu4)
    {
      ; -------------------------------------------
      ; [ScriptError = 11] (cpl)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError = 14] (cpl)(No Error)(Menu Bar Item Not Selected)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 11 or DataArray.366.6 == 14) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "cpl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (DataArray.300.2 == 4) ; (300_2)(Cpl_Number_x000 [#_X_X_X])
          {
            DataArray := Image_GuiControl("Menu_128", 2, 0, DataArray) ; (128_1)(Obj_Cpl_Menu4)
          }
          else
          {
            DataArray := Image_GuiControl("Menu_128", 1, 0, DataArray) ; (128_1)(Obj_Cpl_Menu4)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_129_1") ; (129_1)(Obj_Cpl_Menu5)
    {
      ; -------------------------------------------
      ; [ScriptError = 11] (cpl)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError = 14] (cpl)(No Error)(Menu Bar Item Not Selected)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 11 or DataArray.366.6 == 14) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "cpl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (DataArray.300.2 == 5) ; (300_2)(Cpl_Number_x000 [#_X_X_X])
          {
            DataArray := Image_GuiControl("Menu_129", 2, 0, DataArray) ; (129_1)(Obj_Cpl_Menu5)
          }
          else
          {
            DataArray := Image_GuiControl("Menu_129", 1, 0, DataArray) ; (129_1)(Obj_Cpl_Menu5)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_130_1") ; (130_1)(Obj_Cpl_Menu6)
    {
      ; -------------------------------------------
      ; [ScriptError = 11] (cpl)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError = 14] (cpl)(No Error)(Menu Bar Item Not Selected)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 11 or DataArray.366.6 == 14) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "cpl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (DataArray.300.2 == 6) ; (300_2)(Cpl_Number_x000 [#_X_X_X])
          {
            DataArray := Image_GuiControl("Menu_130", 2, 0, DataArray) ; (130_1)(Obj_Cpl_Menu6)
          }
          else
          {
            DataArray := Image_GuiControl("Menu_130", 1, 0, DataArray) ; (130_1)(Obj_Cpl_Menu6)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_131_1") ; (131_1)(Obj_DisplayText_UrlAddress)
    {
      if (DataArray.133.2 != 2) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])
      {
        if (DataArray.366.5 == "url") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          ; -------------------------------------------
          Url_Address := DataArray.307.2 ; (307_2)(Url_Address)
          ; -------------------------------------------
          if (Url_Address == "")
          {
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ; (_27_Aug_2023_)(_09_20_38_)
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ; -------------------------------------------
            ; (367)(1)(AppProcessName [Name][LowerCase][NoSpace])
            ; (367)(3)(AppProcessClass)
            ; (367)(4)(AppProcessTitle)_(367)(5)(AppProcessPathNameExt [Path,Name,Ext])
            ; -------------------------------------------
		        if (IsInternetBrowser(DataArray.367.1, DataArray.367.3, DataArray.367.4) == 1) ; (AppProcessName) (AppProcessClass) (AppProcessTitle)
            {
							; -------------------------------------------
              URL_Array := Url_GetUrl(DataArray.367.1, DataArray.367.3, DataArray.367.4) ; > [URL_Address, Url_Title, Browser_Name]
              DataArray.307.2 := URL_Array.1 ; (307_2)(Url_Address)
              DataArray.307.4 := URL_Array.2 ; (307_4)(Url_Title [Web Page Title])
              DataArray.307.11 := URL_Array.3 ; (307_11)(Url_BrowserTitle [Browser Name from Window Title])
              ; -------------------------------------------
            }
          }
          ; -------------------------------------------
          
          
          
          
          
          
          ; (_27_Aug_2023_)(_09_53_29_)
          ;~ if (InStr(Url_Address, "chrome://") == 0 && InStr(Url_Address, "http://") == 0 && InStr(Url_Address, "https://") == 0 && InStr(Url_Address, "ftp://") == 0) ; (307_2)(Url_Address)
          if (InStr(Url_Address, "http://") == 0 && InStr(Url_Address, "https://") == 0 && InStr(Url_Address, "ftp://") == 0) ; (307_2)(Url_Address)
          {
            Url_Address := "http://" DataArray.307.2 ; (307_2)(Url_Address)
            DataArray.307.2 := Url_Address ; (307_2)(Url_Address)
          }
          ; -------------------------------------------
          
          
          
          
          
          
          
          DataArray.131.2 := 1 ; (131_2)(Obj_DisplayText_UrlAddress_Sel [0,1,2,3])
          DataArray.131.3 := Url_Address ; (131_3)(Obj_DisplayText_UrlAddress_Val [Text Value])
          ; -------------------------------------------
          GuiControl, PopUpMenu:, g_131, %Url_Address% ; (131_1)(Obj_DisplayText_UrlAddress)
          GuiControl, PopUpMenu:Show, g_131 ; (131_1)(Obj_DisplayText_UrlAddress)
          ; -------------------------------------------
        } ; [End] (ScriptType [url])
      } ; [End] (133_2)(Obj_DeleteShortcut_Sel != 2)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_132_1") ; (132_1)(Empty)
    {
      ; (132_1)(Empty)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_133_1") ; (133_1)(Obj_DeleteShortcut)
    {
      if (DataArray.370.8 != "") ; (370_8)(XmlScriptPath [Full File Path])
      {
        if (DataArray.366.5 != "xxx" && DataArray.366.5 != "mnu_cpl_key" && DataArray.366.5 != "run_rwh_url_ofl" && DataArray.366.5 != "pumtom") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
       
        {
          if (DataArray.133.2 == 0) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])
          {
            DataArray.133.2 := 1 ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])
          }
          DataArray.133.3 := "" ; (133_3)(Obj_DeleteShortcut_Img [Image Path])
          Obj_DeleteShortcut_Sel := DataArray.133.2 ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])
          DataArray := Image_GuiControl("133", Obj_DeleteShortcut_Sel, 1, DataArray) ; (133_1)(Obj_DeleteShortcut)
        }
        else
        {
          DataArray.133.2 := 0 ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])
          DataArray.133.3 := "" ; (133_3)(Obj_DeleteShortcut_Img [Image Path])
        }
      }
      else
      {
        DataArray.133.2 := 0 ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])
        DataArray.133.3 := "" ; (133_3)(Obj_DeleteShortcut_Img [Image Path])
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_134_1") ; (134_1)(Obj_ImageSelect1)
    {
      ; -------------------------------------------
      ; [ScriptError = 8] (run_rwh_url_ofl)(No Error)(Country Image)
      ; [ScriptError = 22] (No Error)(pumtom)
      ; -------------------------------------------
      ; [ScriptError = 5] (mnu)(Addon Not Installed)(Addon is Available)
      ; [ScriptError = 7] (mnu_cpl_key)(No Error)(Country Image)
      ; [ScriptError = 12] (mnu)(Addon Not Installed)(Addon Not Available)(Addon HAS Been Requested)
      ; [ScriptError = 17] (mnu)(Addon Not Installed)(Addon Not Available)(Addon Not Been Requested)
      ; -------------------------------------------
      if (DataArray.366.6 == 5 or DataArray.366.6 == 7 or DataArray.366.6 == 8 or DataArray.366.6 == 12 or DataArray.366.6 == 17 or DataArray.366.6 == 22) ; (366_6)(ScriptError [Integer])
      {
        ; -------------------------------------------
        if (DataArray.366.6 == 8) ; [ScriptError = 8] (run_rwh_url_ofl)(No Error)(Country Image)
        {
          ; -------------------------------------------
          ; [ScriptError = 8] (run_rwh_url_ofl)(No Error)(Country Image)
          ; -------------------------------------------
          DataArray := Image_GuiControl("134", "run", 0, DataArray) ; (134_1)(Obj_ImageSelect1)
          ; -------------------------------------------
        } ; [End] [ScriptError = 8]
        ; -------------------------------------------
        else if (DataArray.366.6 == 22) ; [ScriptError = 22] (No Error)(pumtom)
        {
          ; -------------------------------------------
          ; [ScriptError = 22] (No Error)(pumtom)
          ; -------------------------------------------
          DataArray := Image_GuiControl("134", "pum", 0, DataArray) ; (134_1)(Obj_ImageSelect1)
          ; -------------------------------------------
        } ; [End] [ScriptError = 22]
        ; -------------------------------------------
        else if (DataArray.366.6 == 5 or DataArray.366.6 == 7 or DataArray.366.6 == 12 or DataArray.366.6 == 17) ; (366_6)(ScriptError [Integer])
        {
          ; -------------------------------------------
          ; [ScriptError = 5] (mnu)(Addon Not Installed)(Addon is Available)
          ; [ScriptError = 7] (mnu_cpl_key)(No Error)(Country Image)
          ; [ScriptError = 12] (mnu)(Addon Not Installed)(Addon Not Available)(Addon HAS Been Requested)
          ; [ScriptError = 17] (mnu)(Addon Not Installed)(Addon Not Available)(Addon Not Been Requested)
          ; -------------------------------------------
          ArrayIn := [DataArray.367.5, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
          FileMnu134 := Img_Mnu134(ArrayIn)
          DataArray := Image_GuiControl("Image_134", FileMnu134, 0, DataArray)
          ; -------------------------------------------
        } ; [End] [ScriptError = 5,7.12.17]
        ; -------------------------------------------
      } ; [End] [ScriptError = 7,12,17]
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_135_1") ; (135_1)(Obj_ImageSelect2)
    {
      ; -------------------------------------------
      ; Conditions to Show
      ; -------------------------------------------
      ; [ScriptError = 5] (mnu)(Addon Not Installed)(Addon is Available)
      ; [ScriptError = 7] (mnu_cpl_key)(No Error)(Country Image)
      ; [ScriptError = 8] (run_rwh_url_ofl)(No Error)(Country Image)
      ; [ScriptError = 12] (mnu)(Addon Not Installed)(Addon Not Available)(Addon HAS Been Requested)
      ; [ScriptError = 17] (mnu)(Addon Not Installed)(Addon Not Available)(Addon Not Been Requested)
      ; [ScriptError = 20] (AppProcessName = "windows")
      ; -------------------------------------------
      if (DataArray.366.6 == 5 or DataArray.366.6 == 7 or DataArray.366.6 == 8 or DataArray.366.6 == 12 or DataArray.366.6 == 17 or DataArray.366.6 == 20) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "run_rwh_url_ofl" or DataArray.366.5 == "run" or DataArray.366.5 == "rwh" or DataArray.366.5 == "url" or DataArray.366.5 == "ofl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (IsInternetBrowser(DataArray.367.1, DataArray.367.3, DataArray.367.4) == 1) ; All Supported Internet Browsers
          {
            ; -------------------------------------------
            ; A Browser is Active
            ; -------------------------------------------
            
            
            
            
            
            
            if (DataArray.307.2 == "") ; (307_2)(Url_Address) is Blank
            {
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ; (_27_Aug_2023_)(_09_20_38_)
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ; -------------------------------------------
              ; (367)(1)(AppProcessName [Name][LowerCase][NoSpace])
              ; (367)(3)(AppProcessClass)
              ; (367)(4)(AppProcessTitle)_(367)(5)(AppProcessPathNameExt [Path,Name,Ext])
              ; -------------------------------------------
              URL_Array := Url_GetUrl(DataArray.367.1, DataArray.367.3, DataArray.367.4) ; > [URL_Address, Url_Title, Browser_Name]
              DataArray.307.2 := URL_Array.1 ; (307_2)(Url_Address)
              DataArray.307.4 := URL_Array.2 ; (307_4)(Url_Title [Web Page Title])
              DataArray.307.11 := URL_Array.3 ; (307_11)(Url_BrowserTitle [Browser Name from Window Title])
              ; -------------------------------------------
            }
            
            
            
            
            
            
            
            
            
            
            
            
            if (DataArray.307.2 != "") ; (307_2)(Url_Address) is NOT Blank
            {
              DataArray := Image_GuiControl("135", "1_url", 0, DataArray) ; (135_1)(Obj_ImageSelect2)
            }
            
            
            
            
            
            
            ; -------------------------------------------
          } ; [End] A Browser is Active
          else ; NO Borwser is Active
          {
            ; -------------------------------------------
            ThisImage := A_ProgramFiles "\PopUpMenu_PUM\image\gui\(135)_3_url_" UserLang ".png"
            DataArray := Image_GuiControl("Image_135", ThisImage, 0, DataArray) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
            ; -------------------------------------------
          } ; [End] NO Borwser is Active
        }
        else if (DataArray.366.5 == "mnu_cpl_key" or DataArray.366.5 == "mnu" or DataArray.366.5 == "cpl" or DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("135", "cpl", 0, DataArray) ; (135_1)(Obj_ImageSelect2)
        }
      } ; [End] [ScriptError = 5,7,8,12,17,20]
      ; -------------------------------------------
      ;
      ; -------------------------------------------
      ; [ScriptError = 22] (pumtom)(No Error)
      ; -------------------------------------------
      else if (DataArray.366.6 == 22) ; [ScriptError = 22] (pumtom)(No Error)
      {
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        ; [ScriptError = 22] (pumtom)(No Error)
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        ;
        ; -------------------------------------------
        if (DataArray.367.1 != "windows") ; [Windows Desktop is NOT Active]
        {
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ; [ScriptError = 22] (pumtom)(No Error)
          ;
          ; [Windows Desktop is NOT Active]
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ;
          ; -------------------------------------------
          if (InStr(DataArray.361.9, "\pumdefault\") > 0) ; (361)(9)(ThisPumProcessXml [Full File Path])
          {
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ; [ScriptError = 22] (pumtom)(No Error)
            ; [Windows Desktop is NOT Active]
            ;
            ; [Default pum Active]
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ;
            ; -------------------------------------------
            if (IsInternetBrowser(DataArray.367.1, DataArray.367.3, DataArray.367.4) == 1) ; All Supported Internet Browsers
            {
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ; [ScriptError = 22] (pumtom)(No Error)
              ; [Windows Desktop is NOT Active]
              ; [Default pum Active]
              ;
              ; [Internet Browser Application Active]
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ;
              ; -------------------------------------------
              if (DataArray.290.2 == 1) ; [UseCommonBrowser = 1][All Browsers Same Pum]
              {
                ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                ; [ScriptError = 22] (pumtom)(No Error)
                ; [Windows Desktop is NOT Active]
                ; [Default pum Active]
                ; [Internet Browser Application Active]
                ;
                ; [UseCommonBrowser = 1][All Browsers Same Pum]
                ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                ;
                ; -------------------------------------------
                ThisPum := A_AppData "\PopUpMenu_PUM\pums\pumcommonbrowser\pum_pumcommonbrowser.exe"
                ; -------------------------------------------
                if FileExist(ThisPum) ; [Common Browser pum Exist]
                {
                  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                  ; [ScriptError = 22] (pumtom)(No Error)
                  ; [Windows Desktop is NOT Active]
                  ; [Default pum Active]
                  ; [Internet Browser Application Active]
                  ; [UseCommonBrowser = 1][All Browsers Same Pum]
                  ;
                  ; [Common Browser pum Exist]
                  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                  ;
                  ; -------------------------------------------
                  ThisAppPath := A_ProgramFiles "\PopUpMenu_PUM\image\ico\pumcommonbrowser.txt"
                  ArrayIn := [ThisAppPath, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
                  Img135 := Img_Del135(ArrayIn)
                  DataArray := Image_GuiControl("Image_135", Img135, 0, DataArray)
                  ; -------------------------------------------
                } ; [Common Browser pum Exist]
                else  ; [Common Browser pum does NOT Exist]
                {
                  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                  ; [ScriptError = 22] (pumtom)(No Error)
                  ; [Windows Desktop is NOT Active]
                  ; [Default pum Active]
                  ; [Internet Browser Application Active]
                  ; [UseCommonBrowser = 1][All Browsers Same Pum]
                  ;
                  ; [Common Browser pum does NOT Exist]
                  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                  ;
                  ; -------------------------------------------
                  ThisAppPath := A_ProgramFiles "\PopUpMenu_PUM\image\ico\pumcommonbrowser.txt"
                  ArrayIn := [ThisAppPath, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
                  Img135 := Img_New135(ArrayIn)
                  DataArray := Image_GuiControl("Image_135", Img135, 0, DataArray)
                  ; -------------------------------------------
                } ; [Common Browser pum does NOT Exist]
                ; -------------------------------------------
              } ; [UseCommonBrowser = 1][All Browsers Same Pum]
              ; -------------------------------------------
              else if (DataArray.290.2 == 2) ; [UseCommonBrowser = 2][Each Browser Different pum]
              {
                ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                ; [ScriptError = 22] (pumtom)(No Error)
                ; [Windows Desktop is NOT Active]
                ; [Default pum Active]
                ; [Internet Browser Application Active]
                ;
                ; [UseCommonBrowser = 2][Each Browser Different pum]
                ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                ;
                ; -------------------------------------------
                AppProcessName := DataArray.367.1 ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
                ThisPum := A_AppData "\PopUpMenu_PUM\pums\" AppProcessName "\pum_" AppProcessName ".exe"
                ; -------------------------------------------
                if FileExist(ThisPum) ; [pun Exist]
                {
                  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                  ; [ScriptError = 22] (pumtom)(No Error)
                  ; [Windows Desktop is NOT Active]
                  ; [Default pum Active]
                  ; [Internet Browser Application Active]
                  ; [UseCommonBrowser = 2][Each Browser Different pum]
                  ;
                  ; [pun Exist]
                  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                  ;
  							  ; -------------------------------------------
                  ThisAppPath := DataArray.367.5
                  ArrayIn := [ThisAppPath, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
                  Img135 := Img_Del135(ArrayIn)
                  DataArray := Image_GuiControl("Image_135", Img135, 0, DataArray)
                  ; -------------------------------------------
                } ; [pun Exist]
                else 
                {
                  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                  ; [ScriptError = 22] (pumtom)(No Error)
                  ; [Windows Desktop is NOT Active]
                  ; [Default pum Active]
                  ; [Internet Browser Application Active]
                  ; [UseCommonBrowser = 2][Each Browser Different pum]
                  ;
                  ; [pun Does NOT Exist]
                  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                  ;
  							  ; -------------------------------------------
                  ThisAppPath := DataArray.367.5
                  ArrayIn := [ThisAppPath, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
                  Img135 := Img_New135(ArrayIn)
                  DataArray := Image_GuiControl("Image_135", Img135, 0, DataArray)
                  ; -------------------------------------------
                } ; [pun Does NOT Exist]
                ; -------------------------------------------
              } ; [UseCommonBrowser = 2][Each Browser Different pum]
              ; -------------------------------------------
            } ; [Internet Browser Active]
            else ; [Any Other Application (Non-Internet Browser) is Active]
            {
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ; [ScriptError = 22] (pumtom)(No Error)
              ; [Windows Desktop is NOT Active]
              ; [Default pum Active]
              ;
              ; [Any Other Application (Non-Internet Browser) is Active]
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ;
              ; -------------------------------------------
              AppProcessName := DataArray.367.1 ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
              ThisPum := A_AppData "\PopUpMenu_PUM\pums\" AppProcessName "\pum_" AppProcessName ".exe"
              ; -------------------------------------------
              if FileExist(ThisPum) ; [pun Exist]
              {
                ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                ; [ScriptError = 22] (pumtom)(No Error)
                ; [Windows Desktop is NOT Active]
                ; [Default pum Active]
                ; [Any Other Application (Non-Internet Browser) is Active]
                ;
                ; [pun Exist]
                ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                ;
							  ; -------------------------------------------
                ThisAppPath := DataArray.367.5
                ArrayIn := [ThisAppPath, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
                Img135 := Img_Del135(ArrayIn)
                DataArray := Image_GuiControl("Image_135", Img135, 0, DataArray)
							  ; -------------------------------------------
              } ; [pun Exist]
              ; -------------------------------------------
              else ; [pun does NOT Exist]
              {
                ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                ; [ScriptError = 22] (pumtom)(No Error)
                ; [Windows Desktop is NOT Active]
                ; [Default pum Active]
                ; [Any Other Application (Non-Internet Browser) is Active]
                ;
                ; [pun does NOT Exist]
                ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                ;
							  ; -------------------------------------------
                ThisAppPath := DataArray.367.5
                ArrayIn := [ThisAppPath, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
                Img135 := Img_New135(ArrayIn)
                DataArray := Image_GuiControl("Image_135", Img135, 0, DataArray)
							  ; -------------------------------------------
              } ; [pun does NOT Exist]
              ; -------------------------------------------
            } ; else ; [Any Other Application (Non-Internet Browser) is Active]
            ; -------------------------------------------
          } ; (Default pum) is (Active)
          else ; [Default pum is NOT Active]
          {
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ; [ScriptError = 22] (pumtom)(No Error)
            ; [Windows Desktop is NOT Active]
            ;
            ; [Default pum is NOT Active]
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ;
            ; -------------------------------------------
            if (IsInternetBrowser(DataArray.367.1, DataArray.367.3, DataArray.367.4) == 1) ; All Supported Internet Browsers
            {
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ; [ScriptError = 22] (pumtom)(No Error)
              ; [Windows Desktop is NOT Active]
              ; [Default pum is NOT Active]
              ;
              ; [Internet Browser Active]
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ;
              if (DataArray.290.2 == 1) ; [UseCommonBrowser = 1][All Browsers Same Pum]
              {
                ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                ; [ScriptError = 22] (pumtom)(No Error)
                ; [Windows Desktop is NOT Active]
                ; [Default pum is NOT Active]
                ; [Internet Browser Active]
                ;
                ; [UseCommonBrowser = 1][All Browsers Same Pum]
                ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                ;
                ; -------------------------------------------
                ThisPum := A_AppData "\PopUpMenu_PUM\pums\pumcommonbrowser\pum_pumcommonbrowser.exe"
                ; -------------------------------------------
                if FileExist(ThisPum) ; [Common Browser pum Exist]
                {
                  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                  ; [ScriptError = 22] (pumtom)(No Error)
                  ; [Windows Desktop is NOT Active]
                  ; [Default pum is NOT Active]
                  ; [Internet Browser Active]
                  ; [UseCommonBrowser = 1][All Browsers Same Pum]
                  ;
                  ; [Common Browser pum Exist]
                  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                  ;
  							  ; -------------------------------------------
                  ThisAppPath := A_ProgramFiles "\PopUpMenu_PUM\image\ico\pumcommonbrowser.txt"
                  ArrayIn := [ThisAppPath, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
                  Img135 := Img_Del135(ArrayIn)
                  DataArray := Image_GuiControl("Image_135", Img135, 0, DataArray)
                  ; -------------------------------------------
                } ; [Common Browser pum Exist]
                else ; [Common Browser pum does NOT Exist]
                {
                  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                  ; [ScriptError = 22] (pumtom)(No Error)
                  ; [Windows Desktop is NOT Active]
                  ; [Default pum is NOT Active]
                  ; [Internet Browser Active]
                  ; [UseCommonBrowser = 1][All Browsers Same Pum]
                  ;
                  ; [Common Browser pum does NOT Exist]
                  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                  ;
  							  ; -------------------------------------------
                  ThisAppPath := A_ProgramFiles "\PopUpMenu_PUM\image\ico\pumcommonbrowser.txt"
                  ArrayIn := [ThisAppPath, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
                  Img135 := Img_New135(ArrayIn)
                  DataArray := Image_GuiControl("Image_135", Img135, 0, DataArray)
                  ; -------------------------------------------
                } ; [Common Browser pum does NOT Exist]
                ; -------------------------------------------
              } ; [UseCommonBrowser = 1][All Browsers Same Pum]
              else if (DataArray.290.2 == 2) ; [UseCommonBrowser = 2][Each Browser Different pum]
              {
                ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                ; [ScriptError = 22] (pumtom)(No Error)
                ; [Windows Desktop is NOT Active]
                ; [Default pum is NOT Active]
                ; [Internet Browser Active]
                ;
                ; [UseCommonBrowser = 2][Each Browser Different pum]
                ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                ;
								; -------------------------------------------
								AppProcessName := DataArray.367.1 ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
                ThisPum := A_AppData "\PopUpMenu_PUM\pums\" AppProcessName "\pum_" AppProcessName ".exe"
                ; -------------------------------------------
                if FileExist(ThisPum) ; [pum Exist]
                {
                  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                  ; [ScriptError = 22] (pumtom)(No Error)
                  ; [Windows Desktop is NOT Active]
                  ; [Default pum is NOT Active]
                  ; [Internet Browser Active]
                  ; [UseCommonBrowser = 2][Each Browser Different pum]
                  ;
                  ; [pum Exist]
                  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                  ;
  							  ; -------------------------------------------
                  ThisAppPath := DataArray.367.5
                  ArrayIn := [ThisAppPath, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
                  Img135 := Img_Del135(ArrayIn)
                  DataArray := Image_GuiControl("Image_135", Img135, 0, DataArray)
                  ; -------------------------------------------
                } ; [pum Exist]
                else ; [pum does NOT Exist]
                {
                  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                  ; [ScriptError = 22] (pumtom)(No Error)
                  ; [Windows Desktop is NOT Active]
                  ; [Default pum is NOT Active]
                  ; [Internet Browser Active]
                  ; [UseCommonBrowser = 2][Each Browser Different pum]
                  ;
                  ; [pum does NOT Exist]
                  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                  ;
  							  ; -------------------------------------------
                  ThisAppPath := DataArray.367.5
                  ArrayIn := [ThisAppPath, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
                  Img135 := Img_New135(ArrayIn)
                  DataArray := Image_GuiControl("Image_135", Img135, 0, DataArray)
                  ; -------------------------------------------
                } ; [Common Browser pum does NOT Exist]
                ; -------------------------------------------
              } ; [UseCommonBrowser = 2][Each Browser Different pum]
            } ; [Internet Browser Active]
            else ; [Any Other Application (Non-Internet Browser) is Active]
            {
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ; [ScriptError = 22] (pumtom)(No Error)
              ; [Windows Desktop is NOT Active]
              ; [Default pum is NOT Active]
              ;
              ; [Any Other Application (Non-Internet Browser) is Active]
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ;
							; -------------------------------------------
							AppProcessName := DataArray.367.1 ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
							ThisPum := A_AppData "\PopUpMenu_PUM\pums\" AppProcessName "\pum_" AppProcessName ".exe"
							; -------------------------------------------
							if FileExist(ThisPum) ; [pum Exist]
							{
								; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                ; [ScriptError = 22] (pumtom)(No Error)
                ; [Windows Desktop is NOT Active]
                ; [Default pum is NOT Active]
                ; [Any Other Application (Non-Internet Browser) is Active]
								;
								; [pum Exist]
								; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
								;
								; -------------------------------------------
                ThisAppPath := DataArray.367.5
                ArrayIn := [ThisAppPath, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
                Img135 := Img_Del135(ArrayIn)
                DataArray := Image_GuiControl("Image_135", Img135, 0, DataArray)
								; -------------------------------------------
							} ; [pum Exist]
							else ; [pum does NOT Exist]
							{
								; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                ; [ScriptError = 22] (pumtom)(No Error)
                ; [Windows Desktop is NOT Active]
                ; [Default pum is NOT Active]
                ; [Any Other Application (Non-Internet Browser) is Active]
								;
								; [pum does NOT Exist]
								; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
								;
								; -------------------------------------------
                ThisAppPath := DataArray.367.5
                ArrayIn := [ThisAppPath, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
                Img135 := Img_New135(ArrayIn)
                DataArray := Image_GuiControl("Image_135", Img135, 0, DataArray)
								; -------------------------------------------
							} ; [pum does NOT Exist]
							; -------------------------------------------
            } ; else ; [Any Other Application (Non-Internet Browser) is Active]
            ; -------------------------------------------
          } ; else ; [Default pum is NOT Active]
          ; -------------------------------------------
        } ; [Windows Desktop is NOT Active]
        ; -------------------------------------------
      } ; [ScriptError = 22] (pumtom)(No Error)
      ; -------------------------------------------
    } ; [End] (135_1)(Obj_ImageSelect2)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_136_1") ; (136_1)(Obj_ImageSelect3)
    {
      ; -------------------------------------------
      ; [ScriptError = 5] (mnu)(Addon Not Installed)(Addon is Available)
      ; [ScriptError = 7] (mnu_cpl_key)(No Error)(Country Image)
      ; [ScriptError = 8] (run_rwh_url_ofl)(No Error)(Country Image)
      ; [ScriptError = 12] (mnu)(Addon Not Installed)(Addon Not Available)(Addon HAS Been Requested)
      ; [ScriptError = 17] (mnu)(Addon Not Installed)(Addon Not Available)(Addon Not Been Requested)
      ; [ScriptError = 20] (AppProcessName = "windows")
      ; -------------------------------------------
      if (DataArray.366.6 == 5 or DataArray.366.6 == 7 or DataArray.366.6 == 8 or DataArray.366.6 == 12 or DataArray.366.6 == 17 or DataArray.366.6 == 20) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "run_rwh_url_ofl" or DataArray.366.5 == "run" or DataArray.366.5 == "rwh" or DataArray.366.5 == "url" or DataArray.366.5 == "ofl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("136", "ofl", 0, DataArray) ; (136_1)(Obj_ImageSelect3)
        }
        else if (DataArray.366.5 == "mnu_cpl_key" or DataArray.366.5 == "mnu" or DataArray.366.5 == "cpl" or DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("136", "key", 0, DataArray) ; (136_1)(Obj_ImageSelect3)
        }
      }
      else if (DataArray.366.6 == 22) ; (366_6)(ScriptError [Integer])
      {
        ; -------------------------------------------
        ; [ScriptError = 22] (pumtom)(No Error)
        ; -------------------------------------------
        if (HasConnection == 1) ; Has Internet Connection
        {
          DataArray := Image_GuiControl("136", "pum", 0, DataArray) ; (136_1)(Obj_ImageSelect3)
        }
      } ; [End] (ScriptError 22)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_137_1") ; (137_1)(Obj_MsgImg480x270)
    {
      ; -------------------------------------------
      ; [ScriptError = 1] (run)(rwh)(Application Target [exe] File Not Found)
      ; [ScriptError = 2] (rwh)(No Application to Open File)
      ; [ScriptError = 4] (xxx)(Enpty Icon Grid Selected)
      ; [ScriptError = 5] (mnu)(Addon Not Installed)(Addon is Available)
      ; [ScriptError = 6] (ofl)(Folder Not Found)
      ; [ScriptError = 7] (mnu_cpl_key)(No Error)(Country Image)
      ; [ScriptError = 8] (run_rwh_url_ofl)(No Error)(Country Image)
      ; [ScriptError = 9] (mnu)(No Error)(Menu Bar Item Not Selected)
      ; [ScriptError = 12] (mnu)(Addon Not Installed)(Addon Not Available)(Addon HAS Been Requested)
      ; [ScriptError = 14] (cpl)(No Error)(Menu Bar Item Not Selected)
      ; [ScriptError = 17] (mnu)(Addon Not Installed)(Addon Not Available)(Addon Not Been Requested)
      ; [ScriptError = 19] (url)(No Internet Connection)
      ; [ScriptError = 20] (AppProcessName = "windows")
      ; [ScriptError = 21] (url)(Previous URL Does Not Match Current URL)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 && (DataArray.366.5 == "run_rwh_url_ofl" or DataArray.366.5 == "run" or DataArray.366.5 == "rwh" or DataArray.366.5 == "ofl")) ; (366_6)(ScriptError [Integer])/(366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        ; [ScriptError = 8] (run_rwh_url_ofl)(No Error)(Country Image)
        ; -------------------------------------------
        DataArray := Image_GuiControl("137", "SE8", 1, DataArray) ; (137_1)(Obj_MsgImg480x270)
      }
      else if (DataArray.366.6 == 1 or DataArray.366.6 == 2 or DataArray.366.6 == 4 or DataArray.366.6 == 5 or DataArray.366.6 == 6 or DataArray.366.6 == 7 or DataArray.366.6 == 8 or DataArray.366.6 == 9 or DataArray.366.6 == 12 or DataArray.366.6 == 14 or DataArray.366.6 == 17 or DataArray.366.6 == 19 or DataArray.366.6 == 20 or DataArray.366.6 == 21) ; (366_6)(ScriptError [Integer])
      {
        ; -------------------------------------------
        ; [ScriptError = 9] (mnu)(No Error)(Menu Bar Item Not Selected)
        ; -------------------------------------------
        if (DataArray.366.6 == 9) ; (366_6)(ScriptError [Integer])
        {
          ; -------------------------------------------
          ; [ScriptError = 9] (mnu)(No Error)(Menu Bar Item Not Selected)
          ; -------------------------------------------
          ArrayIn := [DataArray.367.5, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
          FileMnu137 := Img_Mnu137(ArrayIn)
          DataArray := Image_GuiControl("Image_137", FileMnu137, 0, DataArray)
          ; -------------------------------------------
        }
        ; -------------------------------------------
        ; [ScriptError = 7] (mnu_cpl_key)(No Error)(Country Image)
        ; -------------------------------------------
        else if (DataArray.366.6 == 7) ; (366_6)(ScriptError [Integer])
        {
          ; -------------------------------------------
          ; [ScriptError = 7] (mnu_cpl_key)(No Error)(Country Image)
          ; -------------------------------------------
          DataArray := Image_GuiControl("137", "SE8", 1, DataArray) ; (137_1)(Obj_MsgImg480x270)
          ; -------------------------------------------
        }
        ; -------------------------------------------
        ; [ScriptError = 21] (url)(Previous URL Does Not Match Current URL)
        ; -------------------------------------------
        else if (DataArray.366.6 == 21) ; (366_6)(ScriptError [Integer])
        {
          ; -------------------------------------------
          ; [ScriptError = 21] (url)(Previous URL Does Not Match Current URL)
          ; -------------------------------------------
          if (n_520 == "")
          {
            n_520 := 1
          }
          ; -------------------------------------------
          DataArray := Image_GuiControl("520_137", n_520, 0, DataArray) ; (520_1)(_Msg 4_)(_w480 x h270_)_URL)
          ; -------------------------------------------
        }
        else
        {
          ; -------------------------------------------
          ScriptError := DataArray.366.6 ; (366_6)(ScriptError [Integer])
          ScriptErrorImage := "SE" ScriptError
          DataArray := Image_GuiControl("137", ScriptErrorImage, 1, DataArray) ; (137_1)(Obj_MsgImg480x270)
          ; -------------------------------------------
        }
        ; -------------------------------------------
      }
      else if (DataArray.366.5 == "url") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (n_520 == "")
        {
          n_520 := 1
        }
        ; -------------------------------------------
        DataArray := Image_GuiControl("520_137", n_520, 0, DataArray) ; (520_1)(_Msg 4_)(_w480 x h270_)_URL)
        ; -------------------------------------------
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_138_1") ; (138_1)(Obj_Cpl_Menu7)
    {
      ; -------------------------------------------
      ; [ScriptError = 11] (cpl)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError = 14] (cpl)(No Error)(Menu Bar Item Not Selected)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 11 or DataArray.366.6 == 14) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "cpl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (DataArray.300.2 == 7) ; (300_2)(Cpl_Number_x000 [#_X_X_X])
          {
            DataArray := Image_GuiControl("Menu_138", 2, 0, DataArray) ; (138_1)(Obj_Cpl_Menu7)
          }
          else
          {
            DataArray := Image_GuiControl("Menu_138", 1, 0, DataArray) ; (138_1)(Obj_Cpl_Menu7)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_139_1") ; (139_1)(Obj_Cpl_Menu8)
    {
      ; -------------------------------------------
      ; [ScriptError = 11] (cpl)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; [ScriptError = 14] (cpl)(No Error)(Menu Bar Item Not Selected)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 11 or DataArray.366.6 == 14) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "cpl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (DataArray.300.2 == 8) ; (300_2)(Cpl_Number_x000 [#_X_X_X])
          {
            DataArray := Image_GuiControl("Menu_139", 2, 0, DataArray) ; (139_1)(Obj_Cpl_Menu8)
          }
          else
          {
            DataArray := Image_GuiControl("Menu_139", 1, 0, DataArray) ; (139_1)(Obj_Cpl_Menu8)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_140_1") ; (140_1)(Obj_Mnu_AddonExtra)
    {
      ; -------------------------------------------
      ; [ScriptError = 9] (mnu)(No Error)(Menu Bar Item Not Selected)
      ; [ScriptError = 10] (mnu)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
      ; -------------------------------------------
      if (DataArray.366.6 == 0 or DataArray.366.6 == 9 or DataArray.366.6 == 10) ; (366_6)(ScriptError [Integer])
      {
        if (DataArray.366.5 == "mnu") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (DataArray.302.6 >= 1) ; (302_6)(Mnu_MenuSize [#])
          {
            if (DataArray.367.1 != "windows") ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
            {
              CkImage := A_ProgramFiles "\PopUpMenu_PUM\menu\mnu\" DataArray.367.1 "\" DataArray.365.2 "\image\(140)_1_" DataArray.365.2 ".png" ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])/(365_2)(UserLang [Current User language])
              if FileExist(CkImage)
              {
                if (DataArray.302.2 == 12) ; (302_2)(Mnu_Number_x000 [#_X_X_X])
                {
                  DataArray := Image_GuiControl("Menu_140", 2, 1, DataArray) ; GuiVarNum, SelectImgNum, HasLanguage, DataArray > DataArray
                }
                else
                {
                  DataArray := Image_GuiControl("Menu_140", 1, 1, DataArray) ; GuiVarNum, SelectImgNum, HasLanguage, DataArray > DataArray
                }
              }
            }
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_141_1") ; (141_1)(Obj_DisplayText_Title3)
    {
      ; -------------------------------------------
      if (DataArray.133.2 != 2) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])
      {
        ; -------------------------------------------
        ; [ScriptError = 3] (key)(Invalid KeyStroke)
        ; [ScriptError = 10] (mnu)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
        ; [ScriptError = 11] (cpl)(No Error)(Menu Bar Item Is Selected)(List Item Not Selected)
        ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
        ; -------------------------------------------
        if (DataArray.366.6 == 0) ; (366_6)(ScriptError [Integer])
        {
          DataArray := Image_GuiControl("141", 0, 0, DataArray) ; (141_1)(Obj_DisplayText_Title3)
        }
        else if (DataArray.366.6 == 3 or DataArray.366.6 == 10 or DataArray.366.6 == 11 or DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
        {
          if (DataArray.366.5 == "mnu" or DataArray.366.5 == "cpl" or DataArray.366.5 == "key" or DataArray.366.5 == "rwh") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
          {
            if (DataArray.366.5 == "rwh") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
            {
              ; -------------------------------------------
              FontColor := "921297" ; Purple
              ; -------------------------------------------
              Rwh_OpeningApp := DataArray.305.5 ; (305_5)(Rwh_OpeningApp [Full File Path])
              ; SplitPath, InputVar, OutFileName, OutDir, OutExtension, OutNameNoExt, OutDrive
              SplitPath, Rwh_OpeningApp, Obj_DisplayText_Title3_Val
              ; -------------------------------------------
            } ; [End] (ScriptType [rwh])
            ; -------------------------------------------
            ; [ScriptError = 3] (key)(Invalid KeyStroke)
            ; -------------------------------------------
            else if (DataArray.366.6 == 3) ; (366_6)(ScriptError [Integer])
            {
              ; -------------------------------------------
              FontColor := "a30404" ; Red
              ; -------------------------------------------
              if (DataArray.365.2 == "de") ; (365_2)(UserLang [Current User language])
              {
                Obj_DisplayText_Title3_Val := "Ungültiger Tastenanschlag"
              }
              ; -------------------------------------------
              else if (DataArray.365.2 == "en") ; (365_2)(UserLang [Current User language])
              {
                Obj_DisplayText_Title3_Val := "Invalid Keystroke"
              }
              ; -------------------------------------------
              else if (DataArray.365.2 == "es") ; (365_2)(UserLang [Current User language])
              {
                Obj_DisplayText_Title3_Val := "Pulsación de tecla no válida"
              }
              ; -------------------------------------------
              else if (DataArray.365.2 == "fr") ; (365_2)(UserLang [Current User language])
              {
                Obj_DisplayText_Title3_Val := "Frappe non valide"
              }
              ; -------------------------------------------
              else if (DataArray.365.2 == "it") ; (365_2)(UserLang [Current User language])
              {
                Obj_DisplayText_Title3_Val := "Sequenza di tasti non valida"
              }
              ; -------------------------------------------
              else if (DataArray.365.2 == "pl") ; (365_2)(UserLang [Current User language])
              {
                Obj_DisplayText_Title3_Val := "Nieprawidłowe naciśnięcie klawisza"
              }
              ; -------------------------------------------
              else if (DataArray.365.2 == "pt") ; (365_2)(UserLang [Current User language])
              {
                Obj_DisplayText_Title3_Val := "Tecla inválida"
              }
              ; -------------------------------------------
              else if (DataArray.365.2 == "ru") ; (365_2)(UserLang [Current User language])
              {
                Obj_DisplayText_Title3_Val := "Недействительный ключ-удар"
              }
              ; -------------------------------------------
              else if (DataArray.365.2 == "sv") ; (365_2)(UserLang [Current User language])
              {
                Obj_DisplayText_Title3_Val := "Ogiltig tangenttryckning"
              }
              ; -------------------------------------------
              else if (DataArray.365.2 == "tr") ; (365_2)(UserLang [Current User language])
              {
                Obj_DisplayText_Title3_Val := "Geçersiz Tuş vuruşu"
              }
              ; -------------------------------------------
            } ; [End] (ScriptError [3])
            ; -------------------------------------------
            ; [ScriptError = 13] (key)(No Error)(Changing Application)(AppOnly = 1)
            ; -------------------------------------------
            else if (DataArray.366.6 == 13) ; (366_6)(ScriptError [Integer])
            {
              ; -------------------------------------------
              FontColor := "a30404" ; Red
              ; -------------------------------------------
              if (DataArray.365.2 == "de") ; (365_2)(UserLang [Current User language])
              {
                Obj_DisplayText_Title3_Val := "Ändern der Anwendung"
              }
              ; -------------------------------------------
              else if (DataArray.365.2 == "en") ; (365_2)(UserLang [Current User language])
              {
                Obj_DisplayText_Title3_Val := "Changing Application"
              }
              ; -------------------------------------------
              else if (DataArray.365.2 == "es") ; (365_2)(UserLang [Current User language])
              {
                Obj_DisplayText_Title3_Val := "Cambio de aplicación"
              }
              ; -------------------------------------------
              else if (DataArray.365.2 == "fr") ; (365_2)(UserLang [Current User language])
              {
                Obj_DisplayText_Title3_Val := "Modification de l’application"
              }
              ; -------------------------------------------
              else if (DataArray.365.2 == "it") ; (365_2)(UserLang [Current User language])
              {
                Obj_DisplayText_Title3_Val := "Modifica dell'applicazione"
              }
              ; -------------------------------------------
              else if (DataArray.365.2 == "pl") ; (365_2)(UserLang [Current User language])
              {
                Obj_DisplayText_Title3_Val := "Zmiana aplikacji"
              }
              ; -------------------------------------------
              else if (DataArray.365.2 == "pt") ; (365_2)(UserLang [Current User language])
              {
                Obj_DisplayText_Title3_Val := "Alteração de aplicação"
              }
              ; -------------------------------------------
              else if (DataArray.365.2 == "ru") ; (365_2)(UserLang [Current User language])
              {
                Obj_DisplayText_Title3_Val := "Изменение приложения"
              }
              ; -------------------------------------------
              else if (DataArray.365.2 == "sv") ; (365_2)(UserLang [Current User language])
              {
                Obj_DisplayText_Title3_Val := "Ändra program"
              }
              ; -------------------------------------------
              else if (DataArray.365.2 == "tr") ; (365_2)(UserLang [Current User language])
              {
                Obj_DisplayText_Title3_Val := "Uygulamayı Değiştirme"
              }
              ; -------------------------------------------
            } ; [End] (ScriptError [13])
            ; -------------------------------------------
            if (InStr(DataArray.366.5, "pum") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
            {
              ; -------------------------------------------
              GuiFont := DataArray.366.2 ; (366_2)(GuiFont [Set in DataArray_Set])
              FontSize := 14
              Gui_AdjustTextWidth("g_141", Obj_DisplayText_Title3_Val, GuiFont, FontSize, FontColor, 200) ; (141_1)(Obj_DisplayText_Title3)
              DataArray.141.3 := Obj_DisplayText_Title3_Val ; (141_3)(Obj_DisplayText_Title3_Val [Text Value])
              ; -------------------------------------------
            }
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_142_1") ; (142_1)(Obj_HotKeyLangFlag)
    {
      ; HotKey_CheckSelected.ahk
      ; Hotkey_gui
      ; HotKey_SelectKey.ahk
      ; HotKey_UnSelectKey.ahk
      ; HotKey_Validate.ahk
      ; PopUpMenu
      ; _Include.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_143_1") ; (143_1)(Obj_SelFlag_de)
    {
      ; HotKey_CheckSelected.ahk
      ; Hotkey_gui
      ; HotKey_SelectKey.ahk
      ; HotKey_UnSelectKey.ahk
      ; HotKey_Validate.ahk
      ; PopUpMenu
      ; _Include.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_144_1") ; (144_1)(Obj_SelFlag_en)
    {
      ; HotKey_CheckSelected.ahk
      ; Hotkey_gui
      ; HotKey_SelectKey.ahk
      ; HotKey_UnSelectKey.ahk
      ; HotKey_Validate.ahk
      ; PopUpMenu
      ; _Include.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_145_1") ; (145_1)(Obj_SelFlag_es)
    {
      ; HotKey_CheckSelected.ahk
      ; Hotkey_gui
      ; HotKey_SelectKey.ahk
      ; HotKey_UnSelectKey.ahk
      ; HotKey_Validate.ahk
      ; PopUpMenu
      ; _Include.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_146_1") ; (146_1)(Obj_SelFlag_fr)
    {
      ; HotKey_CheckSelected.ahk
      ; Hotkey_gui
      ; HotKey_SelectKey.ahk
      ; HotKey_UnSelectKey.ahk
      ; HotKey_Validate.ahk
      ; PopUpMenu
      ; _Include.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_147_1") ; (147_1)(Obj_SelFlag_it)
    {
      ; HotKey_CheckSelected.ahk
      ; Hotkey_gui
      ; HotKey_SelectKey.ahk
      ; HotKey_UnSelectKey.ahk
      ; HotKey_Validate.ahk
      ; PopUpMenu
      ; _Include.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_148_1") ; (148_1)(Obj_SelFlag_pl)
    {
      ; HotKey_CheckSelected.ahk
      ; Hotkey_gui
      ; HotKey_SelectKey.ahk
      ; HotKey_UnSelectKey.ahk
      ; HotKey_Validate.ahk
      ; PopUpMenu
      ; _Include.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_149_1") ; (149_1)(Obj_SelFlag_pt)
    {
      ; HotKey_CheckSelected.ahk
      ; Hotkey_gui
      ; HotKey_SelectKey.ahk
      ; HotKey_UnSelectKey.ahk
      ; HotKey_Validate.ahk
      ; PopUpMenu
      ; _Include.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_150_1") ; (150_1)(Obj_SelFlag_ru)
    {
      ; HotKey_CheckSelected.ahk
      ; Hotkey_gui
      ; HotKey_SelectKey.ahk
      ; HotKey_UnSelectKey.ahk
      ; HotKey_Validate.ahk
      ; PopUpMenu
      ; _Include.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_151_1") ; (151_1)(Obj_SelFlag_sv)
    {
      ; HotKey_CheckSelected.ahk
      ; Hotkey_gui
      ; HotKey_SelectKey.ahk
      ; HotKey_UnSelectKey.ahk
      ; HotKey_Validate.ahk
      ; PopUpMenu
      ; _Include.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_152_1") ; (152_1)(Obj_SelFlag_tr)
    {
      ; HotKey_CheckSelected.ahk
      ; Hotkey_gui
      ; HotKey_SelectKey.ahk
      ; HotKey_UnSelectKey.ahk
      ; HotKey_Validate.ahk
      ; PopUpMenu
      ; _Include.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_153_1") ; (153_1)(Empty)
    {
      ; HotKey_CheckSelected.ahk
      ; Hotkey_gui
      ; HotKey_SelectKey.ahk
      ; HotKey_UnSelectKey.ahk
      ; HotKey_Validate.ahk
      ; PopUpMenu
      ; _Include.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_154_1") ; (154_1)(Obj_Pum_BgImage)
    {
      if (InStr(DataArray.366.5, "pum") > 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        if (InStr(DataArray.366.5, "pumSetting") > 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (InStr(DataArray.366.5, "pumBgImage") > 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
          {
            DataArray := Image_GuiControl("154", 2, 1, DataArray) ; (154_1)(Obj_Pum_BgImage)
          }
          else
          {
            DataArray := Image_GuiControl("154", 1, 1, DataArray) ; (154_1)(Obj_Pum_BgImage)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_155_1") ; (155_1)(Obj_Pum_BgText)
    {
      if (InStr(DataArray.366.5, "pum") > 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        if (InStr(DataArray.366.5, "pumSetting") > 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (InStr(DataArray.366.5, "pumBgText") > 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
          {
            DataArray := Image_GuiControl("155", 2, 1, DataArray) ; (155_1)(Obj_Pum_BgText)
          }
          else
          {
            DataArray := Image_GuiControl("155", 1, 1, DataArray) ; (155_1)(Obj_Pum_BgText)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_156_1") ; (156_1)(Obj_Pum_BgDim)
    {
      if (InStr(DataArray.366.5, "pum") > 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        if (InStr(DataArray.366.5, "pumSetting") > 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          if (InStr(DataArray.366.5, "pumDimension") > 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
          {
            DataArray := Image_GuiControl("156", 2, 1, DataArray) ; (156_1)(Obj_Pum_BgDim)
          }
          else
          {
            DataArray := Image_GuiControl("156", 1, 1, DataArray) ; (156_1)(Obj_Pum_BgDim)
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_157_1") ; (157_1)(Obj_Pum_Setting)
    {
      if (InStr(DataArray.366.5, "pum") > 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        if (InStr(DataArray.366.5, "pumSetting") > 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          DataArray := Image_GuiControl("157", 2, 1, DataArray) ; (157_1)(Obj_Pum_Setting)
        }
        else
        {
          DataArray := Image_GuiControl("157", 1, 1, DataArray) ; (157_1)(Obj_Pum_Setting)
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_158_1") ; (158_1)(Empty)
    {
      ; (158_1)(Empty)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_159_1") ; (159_1)(Obj_Pum_Contact)
    {
      if (InStr(DataArray.366.5, "pum") > 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        if (HasConnection == 1) ; Has Internet Connection
        {
          if (InStr(DataArray.366.5, "pumContact") > 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
          {
            if (HasConnection == 1) ; Has Internet Connection
            {
            DataArray := Image_GuiControl("159", 2, 1, DataArray) ; (159_1)(Obj_Pum_Contact)
            }
          }
          else
          {
            if (HasConnection == 1) ; Has Internet Connection
            {
              DataArray := Image_GuiControl("159", 1, 1, DataArray) ; (159_1)(Obj_Pum_Contact)
            }
          }
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_160_1") ; (160_1)(Obj_Pum_App))
    {
      ; -------------------------------------------
      if (DataArray.367.1 != "windows") ; [Windows Desktop NOT Active]
      {
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        ; Contitions to [Show] (160)(Obj_Pum_App)
        ;
        ; [Windows Desktop NOT Active]
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        ;
        ; -------------------------------------------
        if (InStr(DataArray.361.9, "\pumdefault\") > 0) ; [Default pum Active]
        {
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ; Contitions to [Show] (160)(Obj_Pum_App)
          ; [Windows Desktop NOT Active]
          ;
          ; [Default pum Active]
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ;
          ; -------------------------------------------
          if (InStr(DataArray.366.5, "pum") > 0) ; [ScriptType] pum is inStr
          {
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ; Contitions to [Show] (160)(Obj_Pum_App)
            ; [Windows Desktop NOT Active]
            ; [Default pum Active]
            ;
            ; [ScriptType] pum is inStr
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ;
            ; -------------------------------------------
            if (IsInternetBrowser(DataArray.367.1, DataArray.367.3, DataArray.367.4) == 1) ; All Supported Internet Browsers
            {
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ; Contitions to [Show] (160)(Obj_Pum_App)
              ; [Windows Desktop NOT Active]
              ; [Default pum Active]
              ; [ScriptType] pum is inStr
              ; 
              ; [Internet Browser Application Active]
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ;
              ; -------------------------------------------
              if (DataArray.290.2 == 1) ; [UseCommonBrowser = 1][All Browsers Same Pum]
              {
                ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                ; Contitions to [Show] (160)(Obj_Pum_App)
                ; [Windows Desktop NOT Active]
                ; [Default pum Active]
                ; [ScriptType] pum is inStr
                ; [Internet Browser Application Active]
                ;
                ; [UseCommonBrowser = 1][All Browsers Same Pum]
                ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                ;
                ; -------------------------------------------
                ThisPum := A_AppData "\PopUpMenu_PUM\pums\pumcommonbrowser\pum_pumcommonbrowser.exe"
                ; -------------------------------------------
                if !FileExist(ThisPum) ; [Common Browser pum NOT Exist]
                {
                  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                  ; Contitions to [Show] (160)(Obj_Pum_App)
                  ; [Windows Desktop NOT Active]
                  ; [Default pum Active]
                  ; [ScriptType] pum is inStr
                  ; [Internet Browser Application Active]
                  ; [UseCommonBrowser = 1][All Browsers Same Pum]
                  ;
                  ; [Common Browser pum NOT Exist] [Show] (160)(Obj_Pum_App)
                  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                  ;
                  ; -------------------------------------------
                  DataArray := Image_GuiControl("160", 1, 1, DataArray) ; (160)(Obj_Pum_App)
                  ; -------------------------------------------
                } ; [Common Browser pum NOT Exist]
                ; -------------------------------------------
              } ; [UseCommonBrowser = 1][All Browsers Same Pum]
              ; -------------------------------------------
              else if (DataArray.290.2 == 2) ; [UseCommonBrowser = 2][Each Browser Different pum]
              {
                ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                ; Contitions to [Show] (160)(Obj_Pum_App)
                ; [Windows Desktop NOT Active]
                ; [Default pum Active]
                ; [ScriptType] pum is inStr
                ; [Internet Browser Application Active]
                ;
                ; [UseCommonBrowser = 2][Each Browser Different pum]
                ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                ;
                ; -------------------------------------------
                AppProcessName := DataArray.367.1 ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
                ThisPum := A_AppData "\PopUpMenu_PUM\pums\" AppProcessName "\pum_" AppProcessName ".exe"
                ; -------------------------------------------
                if !FileExist(ThisPum) ; [pum NOT Exist]
                {
                  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                  ; Contitions to [Show] (160)(Obj_Pum_App)
                  ; [Windows Desktop NOT Active]
                  ; [Default pum Active]
                  ; [ScriptType] pum is inStr
                  ; [Internet Browser Application Active]
                  ; [UseCommonBrowser = 2][Each Browser Different pum]
                  ;
                  ; [pum NOT Exist] [Show] (160)(Obj_Pum_App)
                  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                  ;
                  ; -------------------------------------------
                  DataArray := Image_GuiControl("160", 1, 1, DataArray) ; (160)(Obj_Pum_App)
                  ; -------------------------------------------
                } ; [pum NOT Exist]
                ; -------------------------------------------
              } ; [UseCommonBrowser = 2][Each Browser Different pum]
              ; -------------------------------------------
            } ; [Internet Browser Application Active]
            ; -------------------------------------------
            else ; [Any Other Application (Non-Internet Browser) Active]
            {
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ; Contitions to [Show] (160)(Obj_Pum_App)
              ; [Windows Desktop NOT Active]
              ; [Default pum Active]
              ; [ScriptType] pum is inStr
              ; 
              ; [Any Other Application (Non-Internet Browser) Active]
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ;
              ; -------------------------------------------
              AppProcessName := DataArray.367.1 ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
              ThisPum := A_AppData "\PopUpMenu_PUM\pums\" AppProcessName "\pum_" AppProcessName ".exe"
              ; -------------------------------------------
              if !FileExist(ThisPum) ; [pum NOT Exist]
              {
                ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                ; Contitions to [Show] (160)(Obj_Pum_App)
                ; [Windows Desktop NOT Active]
                ; [Default pum Active]
                ; [ScriptType] pum is inStr
                ; [Any Other Application (Non-Internet Browser) Active]
                ;
                ; [pum NOT Exist] [Show] (160)(Obj_Pum_App)
                ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                ;
                ; -------------------------------------------
                DataArray := Image_GuiControl("160", 1, 1, DataArray) ; (160)(Obj_Pum_App)
                ; -------------------------------------------
              } ; [pum NOT Exist]
              ; -------------------------------------------
            } ; [Any Other Application (Non-Internet Browser) Active]
            ; -------------------------------------------
          } ; [End] ScriptType [pum]
        } ; [Default pum Active]
        else if (IsInternetBrowser(DataArray.367.1, DataArray.367.3, DataArray.367.4) == 1) ; All Supported Internet Browsers
        {
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ; Contitions to [Show] (160)(Obj_Pum_App)
          ; [Windows Desktop NOT Active]
          ;
          ; [Internet Browser Application Active]
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ;
          ; -------------------------------------------
          if (DataArray.290.2 == 1) ; [UseCommonBrowser = 1][All Browsers Same Pum]
          {
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ; Contitions to [Show] (160)(Obj_Pum_App)
            ; [Windows Desktop NOT Active]
            ; [Internet Browser Application Active]
            ;
            ; [UseCommonBrowser = 1][All Browsers Same Pum]
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ;
            ; -------------------------------------------
            ThisPum := A_AppData "\PopUpMenu_PUM\pums\pumcommonbrowser\pum_pumcommonbrowser.exe"
            ; -------------------------------------------
            if !FileExist(ThisPum) ; [Common Browser pum NOT Exist]
            {
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ; Contitions to [Show] (160)(Obj_Pum_App)
              ; [Windows Desktop NOT Active]
              ; [Internet Browser Application Active]
              ; [UseCommonBrowser = 1][All Browsers Same Pum]
              ;
              ; [Common Browser pum NOT Exist] [Show] (160)(Obj_Pum_App)
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ;
              ; -------------------------------------------
              DataArray := Image_GuiControl("160", 1, 1, DataArray) ; (160)(Obj_Pum_App)
              ; -------------------------------------------
            } ; [Common Browser pum NOT Exist]
            ; -------------------------------------------
          } ; [UseCommonBrowser = 1][All Browsers Same Pum]
          ; -------------------------------------------
          else if (DataArray.290.2 == 2) ; [UseCommonBrowser = 2][Each Browser Different pum]
          {
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ; Contitions to [Show] (160)(Obj_Pum_App)
            ; [Windows Desktop NOT Active]
            ; [Internet Browser Application Active]
            ;
            ; [UseCommonBrowser = 2][Each Browser Different pum]
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ;
            ; -------------------------------------------
            AppProcessName := DataArray.367.1 ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
            ThisPum := A_AppData "\PopUpMenu_PUM\pums\" AppProcessName "\pum_" AppProcessName ".exe"
            ; -------------------------------------------
            if !FileExist(ThisPum) ; [pum NOT Exist]
            {
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ; Contitions to [Show] (160)(Obj_Pum_App)
              ; [Windows Desktop NOT Active]
              ; [Internet Browser Application Active]
              ; [UseCommonBrowser = 2][Each Browser Different pum]
              ;
              ; [pum NOT Exist] [Show] (160)(Obj_Pum_App)
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ;
              ; -------------------------------------------
              DataArray := Image_GuiControl("160", 1, 1, DataArray) ; (160)(Obj_Pum_App)
              ; -------------------------------------------
            } ; [pum NOT Exist]
            ; -------------------------------------------
          } ; [UseCommonBrowser = 2][Each Browser Different pum]
          ; -------------------------------------------
        } ; [Internet Browser Application Active]
        ; -------------------------------------------
        else ; [Any Other Application (Non-Internet Browser) Active]
        {
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ; Contitions to [Show] (160)(Obj_Pum_App)
          ; [Windows Desktop NOT Active]
          ;
          ; [Any Other Application (Non-Internet Browser) Active]
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ;
          ; -------------------------------------------
          AppProcessName := DataArray.367.1 ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
          ThisPum := A_AppData "\PopUpMenu_PUM\pums\" AppProcessName "\pum_" AppProcessName ".exe"
          ; -------------------------------------------
          if !FileExist(ThisPum) ; [pum NOT Exist]
          {
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ; Contitions to [Show] (160)(Obj_Pum_App)
            ; [Windows Desktop NOT Active]
            ; [Any Other Application (Non-Internet Browser) Active]
            ;
            ; [pum NOT Exist] [Show] (160)(Obj_Pum_App)
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ;
            ; -------------------------------------------
            DataArray := Image_GuiControl("160", 1, 1, DataArray) ; (160)(Obj_Pum_App)
            ; -------------------------------------------
          } ; [pum NOT Exist]
          ; -------------------------------------------
        } ; else ; [Any Other Application (Non-Internet Browser) Active]
        ; -------------------------------------------
      } ; [Windows Desktop NOT Active]
      ; -------------------------------------------
    } ; (160_1)(Obj_Pum_App))
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_161_1") ; (161_1)(Obj_Pum_Del)
    {
      ; -------------------------------------------
      if (DataArray.367.1 != "windows") ; [Windows Desktop NOT Active]
      {
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        ; Contitions to [Show] (161)(Obj_Pum_Del)
        ;
        ; [Windows Desktop NOT Active]
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        ;
        ; -------------------------------------------
        if (InStr(DataArray.361.9, "\pumdefault\") > 0) ; [Default pum Active]
        {
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ; Contitions to [Show] (161)(Obj_Pum_Del)
          ; [Windows Desktop NOT Active]
          ;
          ; [Default pum Active]
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ;
          ; -------------------------------------------
          if (InStr(DataArray.366.5, "pum") > 0) ; [ScriptType] pum is inStr
          {
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ; Contitions to [Show] (161)(Obj_Pum_Del)
            ; [Windows Desktop NOT Active]
            ; [Default pum Active]
            ;
            ; [ScriptType] pum is inStr
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ;
            ; -------------------------------------------
            if (IsInternetBrowser(DataArray.367.1, DataArray.367.3, DataArray.367.4) == 1) ; All Supported Internet Browsers
            {
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ; Contitions to [Show] (161)(Obj_Pum_Del)
              ; [Windows Desktop NOT Active]
              ; [Default pum Active]
              ; [ScriptType] pum is inStr
              ; 
              ; [Internet Browser Application Active]
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ;
              ; -------------------------------------------
              if (DataArray.290.2 == 1) ; [UseCommonBrowser = 1][All Browsers Same Pum]
              {
                ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                ; Contitions to [Show] (161)(Obj_Pum_Del)
                ; [Windows Desktop NOT Active]
                ; [Default pum Active]
                ; [ScriptType] pum is inStr
                ; [Internet Browser Application Active]
                ;
                ; [UseCommonBrowser = 1][All Browsers Same Pum]
                ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                ;
                ; -------------------------------------------
                ThisPum := A_AppData "\PopUpMenu_PUM\pums\pumcommonbrowser\pum_pumcommonbrowser.exe"
                ; -------------------------------------------
                if FileExist(ThisPum) ; [Common Browser pum Exist]
                {
                  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                  ; Contitions to [Show] (161)(Obj_Pum_Del)
                  ; [Windows Desktop NOT Active]
                  ; [Default pum Active]
                  ; [ScriptType] pum is inStr
                  ; [Internet Browser Application Active]
                  ; [UseCommonBrowser = 1][All Browsers Same Pum]
                  ;
                  ; [Common Browser pum Exist] [Show] (161)(Obj_Pum_Del)
                  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                  ;
                  ; -------------------------------------------
                  DataArray := Image_GuiControl("161", 1, 1, DataArray) ; (161)(Obj_Pum_Del)
                  ; -------------------------------------------
                } ; [Common Browser pum NOT Exist]
                ; -------------------------------------------
              } ; [UseCommonBrowser = 1][All Browsers Same Pum]
              ; -------------------------------------------
              else if (DataArray.290.2 == 2) ; [UseCommonBrowser = 2][Each Browser Different pum]
              {
                ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                ; Contitions to [Show] (161)(Obj_Pum_Del)
                ; [Windows Desktop NOT Active]
                ; [Default pum Active]
                ; [ScriptType] pum is inStr
                ; [Internet Browser Application Active]
                ;
                ; [UseCommonBrowser = 2][Each Browser Different pum]
                ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                ;
                ; -------------------------------------------
                AppProcessName := DataArray.367.1 ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
                ThisPum := A_AppData "\PopUpMenu_PUM\pums\" AppProcessName "\pum_" AppProcessName ".exe"
                ; -------------------------------------------
                if FileExist(ThisPum) ; [pum Exist]
                {
                  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                  ; Contitions to [Show] (161)(Obj_Pum_Del)
                  ; [Windows Desktop NOT Active]
                  ; [Default pum Active]
                  ; [ScriptType] pum is inStr
                  ; [Internet Browser Application Active]
                  ; [UseCommonBrowser = 2][Each Browser Different pum]
                  ;
                  ; [pum Exist] [Show] (161)(Obj_Pum_Del)
                  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                  ;
                  ; -------------------------------------------
                  DataArray := Image_GuiControl("161", 1, 1, DataArray) ; (161)(Obj_Pum_Del)
                  ; -------------------------------------------
                } ; [pum Exist]
                ; -------------------------------------------
              } ; [UseCommonBrowser = 2][Each Browser Different pum]
              ; -------------------------------------------
            } ; [Internet Browser Application Active]
            else ; [Any Other Application (Non-Internet Browser) Active]
            {
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ; Contitions to [Show] (161)(Obj_Pum_Del)
              ; [Windows Desktop NOT Active]
              ; [Default pum Active]
              ; [ScriptType] pum is inStr
              ; 
              ; [Any Other Application (Non-Internet Browser) Active]
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ;
              ; -------------------------------------------
              AppProcessName := DataArray.367.1 ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
              ThisPum := A_AppData "\PopUpMenu_PUM\pums\" AppProcessName "\pum_" AppProcessName ".exe"
              ; -------------------------------------------
              if FileExist(ThisPum) ; [pum Exist]
              {
                ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                ; Contitions to [Show] (161)(Obj_Pum_Del)
                ; [Windows Desktop NOT Active]
                ; [Default pum Active]
                ; [ScriptType] pum is inStr
                ; [Any Other Application (Non-Internet Browser) Active]
                ;
                ; [pum Exist] [Show] (161)(Obj_Pum_Del)
                ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                ;
                ; -------------------------------------------
                DataArray := Image_GuiControl("161", 1, 1, DataArray) ; (161)(Obj_Pum_Del)
                ; -------------------------------------------
              } ; [pum Exist]
              ; -------------------------------------------
            } ; [Any Other Application (Non-Internet Browser) Active]
            ; -------------------------------------------
          } ; [ScriptType] pum is inStr
          ; -------------------------------------------
        } ; [Default pum Active]
        ; -------------------------------------------
        ; [Internet Browser Application Active]
        else if (IsInternetBrowser(DataArray.367.1, DataArray.367.3, DataArray.367.4) == 1) ; All Supported Internet Browsers
        {
          ; -------------------------------------------
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ; Contitions to [Show] (161)(Obj_Pum_Del)
          ; [Windows Desktop NOT Active]
          ;
          ; [Internet Browser Application Active]
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ;
          ; -------------------------------------------
          if (InStr(DataArray.366.5, "pum") > 0) ; [ScriptType] pum is inStr
          {
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ; Contitions to [Show] (161)(Obj_Pum_Del)
            ; [Windows Desktop NOT Active]
            ; [Internet Browser Application Active]
            ;
            ; [ScriptType] pum is inStr
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ;
            ; -------------------------------------------
            if (DataArray.290.2 == 1) ; [UseCommonBrowser = 1][All Browsers Same Pum]
            {
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ; Contitions to [Show] (161)(Obj_Pum_Del)
              ; [Windows Desktop NOT Active]
              ; [Internet Browser Application Active]
              ; [ScriptType] pum is inStr
              ;
              ; [UseCommonBrowser = 1][All Browsers Same Pum]
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ;
              ; -------------------------------------------
              ThisPum := A_AppData "\PopUpMenu_PUM\pums\pumcommonbrowser\pum_pumcommonbrowser.exe"
              ; -------------------------------------------
              if FileExist(ThisPum) ; [Common Browser pum Exist]
              {
                ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                ; Contitions to [Show] (161)(Obj_Pum_Del)
                ; [Windows Desktop NOT Active]
                ; [Internet Browser Application Active]
                ; [ScriptType] pum is inStr
                ; [UseCommonBrowser = 1][All Browsers Same Pum]
                ;
                ; [Common Browser pum NOT Exist] [Show] (161)(Obj_Pum_Del)
                ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                ;
                ; -------------------------------------------
                DataArray := Image_GuiControl("161", 1, 1, DataArray) ; (161)(Obj_Pum_Del)
                ; -------------------------------------------
              } ; [Common Browser pum NOT Exist]
              ; -------------------------------------------
            } ; [UseCommonBrowser = 1][All Browsers Same Pum]
            ; -------------------------------------------
            else if (DataArray.290.2 == 2) ; [UseCommonBrowser = 2][Each Browser Different pum]
            {
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ; Contitions to [Show] (161)(Obj_Pum_Del)
              ; [Windows Desktop NOT Active]
              ; [Internet Browser Application Active]
              ; [ScriptType] pum is inStr
              ;
              ; [UseCommonBrowser = 2][Each Browser Different pum]
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ;
              ; -------------------------------------------
              AppProcessName := DataArray.367.1 ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
              ThisPum := A_AppData "\PopUpMenu_PUM\pums\" AppProcessName "\pum_" AppProcessName ".exe"
              ; -------------------------------------------
              if FileExist(ThisPum) ; [pum Exist]
              {
                ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                ; Contitions to [Show] (161)(Obj_Pum_Del)
                ; [Windows Desktop NOT Active]
                ; [Internet Browser Application Active]
                ; [ScriptType] pum is inStr
                ; [UseCommonBrowser = 2][Each Browser Different pum]
                ;
                ; [pum Exist] [Show] (161)(Obj_Pum_Del)
                ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                ;
                ; -------------------------------------------
                DataArray := Image_GuiControl("161", 1, 1, DataArray) ; (161)(Obj_Pum_Del)
                ; -------------------------------------------
              } ; [pum Exist]
              ; -------------------------------------------
            } ; [UseCommonBrowser = 2][Each Browser Different pum]
            ; -------------------------------------------
          } ; [ScriptType] pum is inStr
          ; -------------------------------------------
        } ; [Internet Browser Application Active]
        ; -------------------------------------------
        else ; [Any Other Application (Non-Internet Browser) Active]
        {
          ; -------------------------------------------
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ; Contitions to [Show] (161)(Obj_Pum_Del)
          ; [Windows Desktop NOT Active]
          ;
          ; [Any Other Application (Non-Internet Browser) Active]
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ;
          ; -------------------------------------------
          if (InStr(DataArray.366.5, "pum") > 0) ; [ScriptType] pum is inStr
          {
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ; Contitions to [Show] (161)(Obj_Pum_Del)
            ; [Windows Desktop NOT Active]
            ; [Any Other Application (Non-Internet Browser) Active]
            ;
            ; [ScriptType] pum is inStr
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ;
            ; -------------------------------------------
            AppProcessName := DataArray.367.1 ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
            ThisPum := A_AppData "\PopUpMenu_PUM\pums\" AppProcessName "\pum_" AppProcessName ".exe"
            ; -------------------------------------------
            if FileExist(ThisPum) ; [pum Exist]
            {
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ; Contitions to [Show] (161)(Obj_Pum_Del)
              ; [Windows Desktop NOT Active]
              ; [Internet Browser Application Active]
              ; [ScriptType] pum is inStr
              ;
              ; [pum Exist] [Show] (161)(Obj_Pum_Del)
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ;
              ; -------------------------------------------
              DataArray := Image_GuiControl("161", 1, 1, DataArray) ; (161)(Obj_Pum_Del)
              ; -------------------------------------------
            } ; [pum Exist]
            ; -------------------------------------------
          } ; [ScriptType] pum is inStr
          ; -------------------------------------------
        } ; [Any Other Application (Non-Internet Browser) Active]
        ; -------------------------------------------
      } ; [Windows Desktop NOT Active]
      ; -------------------------------------------
    } ; (161_1)(Obj_Pum_Del)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_162_1") ; (162)(Obj_Pum_Backup)
    {
      if (InStr(DataArray.366.5, "pum") > 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("162", 1, 1, DataArray) ; (162)(Obj_Pum_Backup)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_163_1") ; (163)(01)(Obj_Pum_Restore)
    {
      if (InStr(DataArray.366.5, "pum") > 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("163", 1, 1, DataArray) ; (163)(01)(Obj_Pum_Restore)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_164_1") ; (164_1)(Obj_Pum_BgTxtImg)
    {
      if (InStr(DataArray.366.5, "pumBgText") > 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if FileExist(DataArray.362.33) ; (362_33)(Temp_Selected_Img [FilePath])
        {
          if (XmlBgType == "1")
          {
            DataArray := Image_GuiControl("164", 2, 1, DataArray) ; (164_1)(Obj_Pum_BgTxtImg)
          }
          else
          {
            DataArray := Image_GuiControl("164", 1, 1, DataArray) ; (164_1)(Obj_Pum_BgTxtImg)
          }
        }
        ; -------------------------------------------
        else if !FileExist(DataArray.362.33) ; (362_33)(Temp_Selected_Img [FilePath])
        {
          DataArray := Image_GuiControl("164", 3, 1, DataArray) ; (164_1)(Obj_Pum_BgTxtImg)
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_165_1") ; (165_1)(Obj_Pum_BgImageSelect)
    {
      if (InStr(DataArray.366.5, "pumBgImage") > 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        
        DataArray := Image_GuiControl("165", 1, 1, DataArray) ; (165_1)(Obj_Pum_BgImageSelect)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_166_1") ; (166_1)(Obj_Pum_BgColor)
    {
      if (InStr(DataArray.366.5, "pumBgColor") > 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("166", 2, 1, DataArray) ; (166_1)(Obj_Pum_BgColor)
      }
      else if (InStr(DataArray.366.5, "pumBgText") > 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("166", 1, 1, DataArray) ; (166_1)(Obj_Pum_BgColor)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_167_1") ; (167_1)(Obj_Pum_BgFitImage)
    {
      if (InStr(DataArray.366.5, "pumBgFitImage") > 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("167", 2, 1, DataArray) ; (167_1)(Obj_Pum_BgFitImage)
      }
      else if (InStr(DataArray.366.5, "pumBgImage") > 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("167", 1, 1, DataArray) ; (167_1)(Obj_Pum_BgFitImage)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_168_1") ; (168_1)(Empty)
    {
      ; (168_1)(Empty)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_169_1") ; (169_1)(Obj_CatPawAutoStart)
    {
      ; -------------------------------------------
      if (DataArray.366.5 == "xxx" && DataArray.305.17 != 1) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])/(305_17)(Run_DefaultPum [0,1][Selected Shortcut is to the Default pum])
      {
        if (DataArray.169.2 == 1) ; (169_2)(Obj_CatPawAutoStart_Sel [1,2])
        {
          DataArray := Image_GuiControl("169", 1, 1, DataArray) ; (169_1)(Obj_CatPawAutoStart)
        }
        else if (DataArray.169.2 == 2) ; (169_2)(Obj_CatPawAutoStart_Sel [1,2])
        {
          DataArray := Image_GuiControl("169", 2, 1, DataArray) ; (169_1)(Obj_CatPawAutoStart)
        }
      } ; [End] (ScriptType [xxx])
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_170_1") ; (170_1)(Obj_CatPawDropDown)
    {
      ; -------------------------------------------
      if (DataArray.366.5 == "xxx" && DataArray.305.17 != 1) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])/(305_17)(Run_DefaultPum [0,1][Selected Shortcut is to the Default pum])
      {
        if (DataArray.169.2 == 1) ; (169_2)(Obj_CatPawAutoStart_Sel [1,2])
        {
          DataArray := Image_GuiControl("170", 0, 0, DataArray) ; (170_1)(Obj_CatPawDropDown)
        }
        else if (DataArray.169.2 == 2) ; (169_2)(Obj_CatPawAutoStart_Sel [1,2])
        {
          ; -------------------------------------------
          if (DataArray.365.2 == "de") ; (365_2)(UserLang [Current User language])
          {
            CatPawListBox := "|1 Minute|2 Minuten|3 Minuten|4 Minuten|5 Minuten" ; (170_3)(Obj_CatPawDropDown [List Box])
            DataArray.170.3 := CatPawListBox ; (170_3)(Obj_CatPawDropDown [List Box])
          }
          else if (DataArray.365.2 == "en") ; (365_2)(UserLang [Current User language])
          {
            CatPawListBox := "|1 Minute|2 Minutes|3 Minutes|4 Minutes|5 Minutes" ; (170_3)(Obj_CatPawDropDown [List Box])
            DataArray.170.3 := CatPawListBox ; (170_3)(Obj_CatPawDropDown [List Box])
          }
          else if (DataArray.365.2 == "en") ; (365_2)(UserLang [Current User language])
          {
            CatPawListBox := "|1 Minuto|2 Minutos|3 Minutos|4 Minutos|5 Minutos" ; (170_3)(Obj_CatPawDropDown [List Box])
            DataArray.170.3 := CatPawListBox ; (170_3)(Obj_CatPawDropDown [List Box])
          }
          else if (DataArray.365.2 == "fr") ; (365_2)(UserLang [Current User language])
          {
            CatPawListBox := "|1 Minute|2 Minutes|3 Minutes|4 Minutes|5 Minutes" ; (170_3)(Obj_CatPawDropDown [List Box])
            DataArray.170.3 := CatPawListBox ; (170_3)(Obj_CatPawDropDown [List Box])
          }
          else if (DataArray.365.2 == "it") ; (365_2)(UserLang [Current User language])
          {
            CatPawListBox := "|1 Minuto|2 Minuti|3 Minuti|4 Minuti|5 Minuti" ; (170_3)(Obj_CatPawDropDown [List Box])
            DataArray.170.3 := CatPawListBox ; (170_3)(Obj_CatPawDropDown [List Box])
          }
          else if (DataArray.365.2 == "pl") ; (365_2)(UserLang [Current User language])
          {
            CatPawListBox := "|1 Minuta|2 Minuty|3 Minuty|4 Minuty|5 Minuty" ; (170_3)(Obj_CatPawDropDown [List Box])
            DataArray.170.3 := CatPawListBox ; (170_3)(Obj_CatPawDropDown [List Box])
          }
          else if (DataArray.365.2 == "pt") ; (365_2)(UserLang [Current User language])
          {
            CatPawListBox := "|1 Minuto|2 Minutos|3 Minutos|4 Minutos|5 Minutos" ; (170_3)(Obj_CatPawDropDown [List Box])
            DataArray.170.3 := CatPawListBox ; (170_3)(Obj_CatPawDropDown [List Box])
          }
          else if (DataArray.365.2 == "ru") ; (365_2)(UserLang [Current User language])
          {
            CatPawListBox := "|1 Минута|2 Минуты|3 Минуты|4 Минуты|5 Минуты" ; (170_3)(Obj_CatPawDropDown [List Box])
            DataArray.170.3 := CatPawListBox ; (170_3)(Obj_CatPawDropDown [List Box])
          }
          else if (DataArray.365.2 == "sv") ; (365_2)(UserLang [Current User language])
          {
            CatPawListBox := "|1 Minut|2 Minuter|3 Minuter|4 Minuter|5 Minuter" ; (170_3)(Obj_CatPawDropDown [List Box])
            DataArray.170.3 := CatPawListBox ; (170_3)(Obj_CatPawDropDown [List Box])
          }
          else if (DataArray.365.2 == "tr") ; (365_2)(UserLang [Current User language])
          {
            CatPawListBox := "|1 Dakika|2 Dakika|3 Dakika|4 Dakika|5 Dakika" ; (170_3)(Obj_CatPawDropDown [List Box])
            DataArray.170.3 := CatPawListBox ; (170_3)(Obj_CatPawDropDown [List Box])
          }
          ; -------------------------------------------
          GuiControl, PopUpMenu:, g_170, %CatPawListBox% ; (170_1)(Obj_CatPawDropDown)
          CatPawTime := DataArray.170.2 ; (170_2)(Obj_CatPawDropDown_Time [1,2,3,4,5])
          if (CatPawTime == "")
          {
            CatPawTime := 1
            DataArray.170.2 := CatPawTime ; (170_2)(Obj_CatPawDropDown_Time [1,2,3,4,5])
          }
          GuiControl, PopUpMenu:Choose, g_170, %CatPawTime% ; (170_1)(Obj_CatPawDropDown)
          GuiControl, PopUpMenu:Show, g_170 ; (170_1)(Obj_CatPawDropDown)
          ; -------------------------------------------
        } ; (169_2)(Obj_CatPawAutoStart_Sel == 2)
      } ; [End] (ScriptType [xxx])
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_171_1") ; (171_1)(Empty)
    {
      ; (171_1)(Empty)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_172_1") ; (172_1)(Obj_Pum_MobileText)
    {
      if (InStr(DataArray.366.5, "pumBgText") > 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (DataArray.362.24 == "1") ; (362_24)(Pum_MobileTextOnOff [1 = On, 0 Off])
        {
          DataArray := Image_GuiControl("172", 2, 1, DataArray) ; (172_1)(Obj_Pum_MobileText)
        }
        else
        {
          DataArray := Image_GuiControl("172", 1, 1, DataArray) ; (172_1)(Obj_Pum_MobileText)
        }
        ; -------------------------------------------
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_173_1") ; (173_1)(Obj_Pum_MobileTxtColor)
    {
      if (InStr(DataArray.366.5, "pumMobileTextColor") > 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("173", 2, 1, DataArray) ; (173_1)(Obj_Pum_MobileTxtColor)
      }
      else if (InStr(DataArray.366.5, "pumBgText") > 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("173", 1, 1, DataArray) ; (173_1)(Obj_Pum_MobileTxtColor)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_174_1") ; (174_1)(Obj_Pum_MobileBgColor)
    {
      if (InStr(DataArray.366.5, "pumMobileBgColor") > 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("174", 2, 1, DataArray) ; (174_1)(Obj_Pum_MobileBgColor)
      }
      else if (InStr(DataArray.366.5, "pumBgText") > 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("174", 1, 1, DataArray) ; (174_1)(Obj_Pum_MobileBgColor)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_175_1") ; (175_1)(Empty)
    {
      ; (175_1)(Empty)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_176_1") ; (176_1)(Empty)
    {
      ; (176_1)(Empty)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_177_1") ; (177_1)(Obj_Pum_BgTrans)
    {
      ; (159_1)(Obj_Pum_Contact)
      ; (160_1)(Obj_Pum_App))
      ; (161_1)(Obj_Pum_Del)
      ; PopUpMenu
      ; _Include.ahk
      ; _S2_H.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_178_1") ; (178_1)(Obj_Pum_BgOpacityUp)
    {
      ; (154_1)(Obj_Pum_BgImage)
      ; (155_1)(Obj_Pum_BgText)
      ; (156_1)(Obj_Pum_BgDim)
      ; (157_1)(Obj_Pum_Setting)
      ; (159_1)(Obj_Pum_Contact)
      ; (160_1)(Obj_Pum_App))
      ; (161_1)(Obj_Pum_Del)
      ; (166_1)(Obj_Pum_BgColor)
      ; (172_1)(Obj_Pum_MobileText)
      ; (178_1)(Obj_Pum_BgOpacityUp)
      ; PopUpMenu
      ; Pum_SelectedColorDisplay.ahk
      ; _Include.ahk
      ; _S2_H.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_179_1") ; (179_1)(Obj_Pum_BgOpacityDown)
    {
      ; (154_1)(Obj_Pum_BgImage)
      ; (155_1)(Obj_Pum_BgText)
      ; (156_1)(Obj_Pum_BgDim)
      ; (157_1)(Obj_Pum_Setting)
      ; (159_1)(Obj_Pum_Contact)
      ; (160_1)(Obj_Pum_App))
      ; (161_1)(Obj_Pum_Del)
      ; (166_1)(Obj_Pum_BgColor)
    ; (172_1)(Obj_Pum_MobileText)
      ; (179_1)(Obj_Pum_BgOpacityDown)
      ; PopUpMenu
      ; Pum_SelectedColorDisplay.ahk
      ; _Include.ahk
      ; _S2_H.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_180_1") ; (180_1)(Obj_Pum_DisplayText_Opacity)
    {
      if (InStr(DataArray.366.5, "pumBgColor") > 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("180", 1, 1, DataArray) ; (180_1)(Obj_Pum_DisplayText_Opacity)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_181_1") ; (181_1)(Obj_Pum_Opacity)
    {
      ; (154_1)(Obj_Pum_BgImage)
      ; (155_1)(Obj_Pum_BgText)
      ; (156_1)(Obj_Pum_BgDim)
      ; (157_1)(Obj_Pum_Setting)
      ; (159_1)(Obj_Pum_Contact)
      ; (160_1)(Obj_Pum_App))
      ; (161_1)(Obj_Pum_Del)
      ; (172_1)(Obj_Pum_MobileText)
      ; (178_1)(Obj_Pum_BgOpacityUp)
      ; (179_1)(Obj_Pum_BgOpacityDown)
      ; PopUpMenu
      ; Pum_ColorSelect.ahk
      ; Pum_SelectedColorDisplay.ahk
      ; _Include.ahk
      ; _S2_H.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_182_1") ; (182_1)(Obj_Pum_BgRotateLeft)
    {
      ; (154_1)(Obj_Pum_BgImage)
      ; (155_1)(Obj_Pum_BgText)
      ; (156_1)(Obj_Pum_BgDim)
      ; (157_1)(Obj_Pum_Setting)
      ; (159_1)(Obj_Pum_Contact)
      ; (160_1)(Obj_Pum_App))
      ; (161_1)(Obj_Pum_Del)
      ; (165_1)(Obj_Pum_BgImageSelect)
      ; (167_1)(Obj_Pum_BgFitImage)
      ; (182_1)(Obj_Pum_BgRotateLeft)
      ; (183_1)(Obj_Pum_BgRotateRight)
      ; (241_1)(Obj_Pum_CropLeft)
      ; (242_1)(Obj_Pum_CropRight)
      ; (243_1)(Obj_Pum_CropUp)
      ; (244_1)(Obj_Pum_CropDown)
      ; (245_1)(Obj_Pum_CropCenter)
      ; (246_1)(Obj_Pum_ZoomIn)
      ; (247_1)(Obj_Pum_ZoomOut)
      ; PopUpMenu
      ; Pum_ColorSelect.ahk
      ; Pum_DisplayImageImg.ahk
      ; Pum_SelectedColorDisplay.ahk
      ; _Include.ahk
      ; _S2_H.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_183_1") ; (183_1)(Obj_Pum_BgRotateRight)
    {
      ; (154_1)(Obj_Pum_BgImage)
      ; (155_1)(Obj_Pum_BgText)
      ; (156_1)(Obj_Pum_BgDim)
      ; (157_1)(Obj_Pum_Setting)
      ; (159_1)(Obj_Pum_Contact)
      ; (160_1)(Obj_Pum_App))
      ; (161_1)(Obj_Pum_Del)
      ; (165_1)(Obj_Pum_BgImageSelect)
      ; (167_1)(Obj_Pum_BgFitImage)
      ; (182_1)(Obj_Pum_BgRotateLeft)
      ; (183_1)(Obj_Pum_BgRotateRight)
      ; (241_1)(Obj_Pum_CropLeft)
      ; (242_1)(Obj_Pum_CropRight)
      ; (243_1)(Obj_Pum_CropUp)
      ; (244_1)(Obj_Pum_CropDown)
      ; (245_1)(Obj_Pum_CropCenter)
      ; (246_1)(Obj_Pum_ZoomIn)
      ; (247_1)(Obj_Pum_ZoomOut)
      ; PopUpMenu
      ; Pum_DisplayImageImg.ahk
      ; _Include.ahk
      ; _S2_H.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_184_1") ; (184_1)(Obj_Pum_ImageText_EmailAddress)
    {
      ; (157_1)(Obj_Pum_Setting)
      ; (159_1)(Obj_Pum_Contact)
      ; (160_1)(Obj_Pum_App))
      ; (161_1)(Obj_Pum_Del)
      ; PopUpMenu
      ; _Include.ahk
      ; _S2_H.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_185_1") ; (185_1)(Obj_Pum_ImageText_ContactName)
    {
      ; (157_1)(Obj_Pum_Setting)
      ; (159_1)(Obj_Pum_Contact)
      ; (160_1)(Obj_Pum_App))
      ; (161_1)(Obj_Pum_Del)
      ; PopUpMenu
      ; _Include.ahk
      ; _S2_H.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_186_1") ; (186_1)(Obj_Pum_ImageText_PopUpMenuEmail)
    {
      ; (157_1)(Obj_Pum_Setting)
      ; (159_1)(Obj_Pum_Contact)
      ; (160_1)(Obj_Pum_App))
      ; (161_1)(Obj_Pum_Del)
      ; PopUpMenu
      ; _Include.ahk
      ; _S2_H.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_187_1") ; (187_1)(Obj_Pum_SendEmailAnimate)
    {
      ; (004_1)(Obj_ok)
      ; (157_1)(Obj_Pum_Setting)
      ; (160_1)(Obj_Pum_App))
      ; (161_1)(Obj_Pum_Del)
      ; PopUpMenu
      ; Sys_ResetDataArray.ahk
      ; _Include.ahk
      ; _S2_H.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_188_1") ; (188_1)(Obj_Pum_EditFeild_EmailAddress)
    {
      ; Email_Validate.ahk
      ; (004_1)(Obj_ok)
      ; (157_1)(Obj_Pum_Setting)
      ; (159_1)(Obj_Pum_Contact)
      ; (160_1)(Obj_Pum_App))
      ; (188_1)(Obj_Pum_EditFeild_EmailAddress)
      ; PopUpMenu
      ; Sys_EnableDisable.ahk
      ; _Include.ahk
      ; _S2_H.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_189_1") ; (189_1)(Obj_Pum_EditFeild_ContactName)
    {
      ; Email_Validate.ahk
      ; (004_1)(Obj_ok)
      ; (159_1)(Obj_Pum_Contact)
      ; (160_1)(Obj_Pum_App))
      ; (189_1)(Obj_Pum_EditFeild_ContactName)
      ; PopUpMenu
      ; Sys_EnableDisable.ahk
      ; _Include.ahk
      ; _S2_H.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_190_1") ; (190_1)(Obj_Pum_EditFeild_EmailBody)
    {
      ; Email_Validate.ahk
      ; (004_1)(Obj_ok)
      ; (159_1)(Obj_Pum_Contact)
      ; (160_1)(Obj_Pum_App))
      ; (190_1)(Obj_Pum_EditFeild_EmailBody)
      ; PopUpMenu
      ; Sys_EnableDisable.ahk
      ; _Include.ahk
      ; _S2_H.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_191_1") ; (191_1)(Obj_Pum_ColorA1)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") != 0) or (InStr(DataArray.366.5, "pumTextColor") != 0) or (InStr(DataArray.366.5, "pumMobileBgColor") != 0) or (InStr(DataArray.366.5, "pumMobileTextColor") != 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (DataArray.191.2 == 2) ; (191_2)(Obj_Pum_ColorA1_Sel [0,1,2])
        {
          DataArray := Image_GuiControl("191", 2, 0, DataArray) ; (191_1)(Obj_Pum_ColorA1)
        }
        else
        {
          DataArray := Image_GuiControl("191", 1, 0, DataArray) ; (191_1)(Obj_Pum_ColorA1)
        }
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_192_1") ; (192_1)(Obj_Pum_ColorA2)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") != 0) or (InStr(DataArray.366.5, "pumTextColor") != 0) or (InStr(DataArray.366.5, "pumMobileBgColor") != 0) or (InStr(DataArray.366.5, "pumMobileTextColor") != 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (DataArray.192.2 == 2) ; (192_2)(Obj_Pum_ColorA2_Sel [0,1,2])
        {
          DataArray := Image_GuiControl("192", 2, 0, DataArray) ; (192_1)(Obj_Pum_ColorA2)
        }
        else
        {
          DataArray := Image_GuiControl("192", 1, 0, DataArray) ; (192_1)(Obj_Pum_ColorA2)
        }
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_193_1") ; (193_1)(Obj_Pum_ColorA3)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") != 0) or (InStr(DataArray.366.5, "pumTextColor") != 0) or (InStr(DataArray.366.5, "pumMobileBgColor") != 0) or (InStr(DataArray.366.5, "pumMobileTextColor") != 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (DataArray.193.2 == 2) ; (193_2)(Obj_Pum_ColorA3_Sel [0,1,2])
        {
          DataArray := Image_GuiControl("193", 2, 0, DataArray) ; (193_1)(Obj_Pum_ColorA3)
        }
        else
        {
          DataArray := Image_GuiControl("193", 1, 0, DataArray) ; (193_1)(Obj_Pum_ColorA3)
        }
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_194_1") ; (194_1)(Obj_Pum_ColorA4)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") != 0) or (InStr(DataArray.366.5, "pumTextColor") != 0) or (InStr(DataArray.366.5, "pumMobileBgColor") != 0) or (InStr(DataArray.366.5, "pumMobileTextColor") != 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (DataArray.194.2 == 2) ; (194_2)(Obj_Pum_ColorA4_Sel [0,1,2])
        {
          DataArray := Image_GuiControl("194", 2, 0, DataArray) ; (194_1)(Obj_Pum_ColorA4)
        }
        else
        {
          DataArray := Image_GuiControl("194", 1, 0, DataArray) ; (194_1)(Obj_Pum_ColorA4)
        }
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_195_1") ; (195_1)(Obj_Pum_ColorA5)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") != 0) or (InStr(DataArray.366.5, "pumTextColor") != 0) or (InStr(DataArray.366.5, "pumMobileBgColor") != 0) or (InStr(DataArray.366.5, "pumMobileTextColor") != 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (DataArray.195.2 == 2) ; (195_2)(Obj_Pum_ColorA5_Sel [0,1,2])
        {
          DataArray := Image_GuiControl("195", 2, 0, DataArray) ; (195_1)(Obj_Pum_ColorA5)
        }
        else
        {
          DataArray := Image_GuiControl("195", 1, 0, DataArray) ; (195_1)(Obj_Pum_ColorA5)
        }
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_196_1") ; (196_1)(Obj_Pum_ColorA6)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") != 0) or (InStr(DataArray.366.5, "pumTextColor") != 0) or (InStr(DataArray.366.5, "pumMobileBgColor") != 0) or (InStr(DataArray.366.5, "pumMobileTextColor") != 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (DataArray.196.2 == 2) ; (196_2)(Obj_Pum_ColorA6_Sel [0,1,2])
        {
          DataArray := Image_GuiControl("196", 2, 0, DataArray) ; (196_1)(Obj_Pum_ColorA6)
        }
        else
        {
          DataArray := Image_GuiControl("196", 1, 0, DataArray) ; (196_1)(Obj_Pum_ColorA6)
        }
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_197_1") ; (197_1)(Obj_Pum_ColorB1)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") != 0) or (InStr(DataArray.366.5, "pumTextColor") != 0) or (InStr(DataArray.366.5, "pumMobileBgColor") != 0) or (InStr(DataArray.366.5, "pumMobileTextColor") != 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (DataArray.197.2 == 2) ; (197_2)(Obj_Pum_ColorB1_Sel [0,1,2])
        {
          DataArray := Image_GuiControl("197", 2, 0, DataArray) ; (197_1)(Obj_Pum_ColorB1)
        }
        else
        {
          DataArray := Image_GuiControl("197", 1, 0, DataArray) ; (197_1)(Obj_Pum_ColorB1)
        }
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_198_1") ; (198_1)(Obj_Pum_ColorB2)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") != 0) or (InStr(DataArray.366.5, "pumTextColor") != 0) or (InStr(DataArray.366.5, "pumMobileBgColor") != 0) or (InStr(DataArray.366.5, "pumMobileTextColor") != 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (DataArray.198.2 == 2) ; (198_2)(Obj_Pum_ColorB2_Sel [0,1,2])
        {
          DataArray := Image_GuiControl("198", 2, 0, DataArray) ; (198_1)(Obj_Pum_ColorB2)
        }
        else
        {
          DataArray := Image_GuiControl("198", 1, 0, DataArray) ; (198_1)(Obj_Pum_ColorB2)
        }
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_199_1") ; (199_1)(Obj_Pum_ColorB3)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") != 0) or (InStr(DataArray.366.5, "pumTextColor") != 0) or (InStr(DataArray.366.5, "pumMobileBgColor") != 0) or (InStr(DataArray.366.5, "pumMobileTextColor") != 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (DataArray.199.2 == 2) ; (199_2)(Obj_Pum_ColorB3_Sel [0,1,2])
        {
          DataArray := Image_GuiControl("199", 2, 0, DataArray) ; (199_1)(Obj_Pum_ColorB3)
        }
        else
        {
          DataArray := Image_GuiControl("199", 1, 0, DataArray) ; (199_1)(Obj_Pum_ColorB3)
        }
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_200_1") ; (200_1)(Obj_Pum_ColorB4)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") != 0) or (InStr(DataArray.366.5, "pumTextColor") != 0) or (InStr(DataArray.366.5, "pumMobileBgColor") != 0) or (InStr(DataArray.366.5, "pumMobileTextColor") != 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (DataArray.200.2 == 2) ; (200_2)(Obj_Pum_ColorB4_Sel [0,1,2])
        {
          DataArray := Image_GuiControl("200", 2, 0, DataArray) ; (200_1)(Obj_Pum_ColorB4)
        }
        else
        {
          DataArray := Image_GuiControl("200", 1, 0, DataArray) ; (200_1)(Obj_Pum_ColorB4)
        }
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_201_1") ; (201_1)(Obj_Pum_ColorB5)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") != 0) or (InStr(DataArray.366.5, "pumTextColor") != 0) or (InStr(DataArray.366.5, "pumMobileBgColor") != 0) or (InStr(DataArray.366.5, "pumMobileTextColor") != 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (DataArray.201.2 == 2) ; (201_2)(Obj_Pum_ColorB5_Sel [0,1,2])
        {
          DataArray := Image_GuiControl("201", 2, 0, DataArray) ; (201_1)(Obj_Pum_ColorB5)
        }
        else
        {
          DataArray := Image_GuiControl("201", 1, 0, DataArray) ; (201_1)(Obj_Pum_ColorB5)
        }
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_202_1") ; (202_1)(Obj_Pum_ColorB6)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") != 0) or (InStr(DataArray.366.5, "pumTextColor") != 0) or (InStr(DataArray.366.5, "pumMobileBgColor") != 0) or (InStr(DataArray.366.5, "pumMobileTextColor") != 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (DataArray.202.2 == 2) ; (202_2)(Obj_Pum_ColorB6_Sel [0,1,2])
        {
          DataArray := Image_GuiControl("202", 2, 0, DataArray) ; (202_1)(Obj_Pum_ColorB6)
        }
        else
        {
          DataArray := Image_GuiControl("202", 1, 0, DataArray) ; (202_1)(Obj_Pum_ColorB6)
        }
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_203_1") ; (203_1)(Obj_Pum_ColorC1)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") != 0) or (InStr(DataArray.366.5, "pumTextColor") != 0) or (InStr(DataArray.366.5, "pumMobileBgColor") != 0) or (InStr(DataArray.366.5, "pumMobileTextColor") != 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (DataArray.203.2 == 2) ; (203_2)(Obj_Pum_ColorC1_Sel [0,1,2])
        {
          DataArray := Image_GuiControl("203", 2, 0, DataArray) ; (203_1)(Obj_Pum_ColorC1)
      }
        else
        {
          DataArray := Image_GuiControl("203", 1, 0, DataArray) ; (203_1)(Obj_Pum_ColorC1)
        }
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_204_1") ; (204_1)(Obj_Pum_ColorC2)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") != 0) or (InStr(DataArray.366.5, "pumTextColor") != 0) or (InStr(DataArray.366.5, "pumMobileBgColor") != 0) or (InStr(DataArray.366.5, "pumMobileTextColor") != 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (DataArray.204.2 == 2) ; (204_2)(Obj_Pum_ColorC2_Sel [0,1,2])
        {
          DataArray := Image_GuiControl("204", 2, 0, DataArray) ; (204_1)(Obj_Pum_ColorC2)
        }
        else
        {
          DataArray := Image_GuiControl("204", 1, 0, DataArray) ; (204_1)(Obj_Pum_ColorC2)
        }
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_205_1") ; (205_1)(Obj_Pum_ColorC3)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") != 0) or (InStr(DataArray.366.5, "pumTextColor") != 0) or (InStr(DataArray.366.5, "pumMobileBgColor") != 0) or (InStr(DataArray.366.5, "pumMobileTextColor") != 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (DataArray.205.2 == 2) ; (205_2)(Obj_Pum_ColorC3_Sel [0,1,2])
        {
          DataArray := Image_GuiControl("205", 2, 0, DataArray) ; (205_1)(Obj_Pum_ColorC3)
        }
        else
        {
          DataArray := Image_GuiControl("205", 1, 0, DataArray) ; (205_1)(Obj_Pum_ColorC3)
        }
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_206_1") ; (206_1)(Obj_Pum_ColorC4)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") != 0) or (InStr(DataArray.366.5, "pumTextColor") != 0) or (InStr(DataArray.366.5, "pumMobileBgColor") != 0) or (InStr(DataArray.366.5, "pumMobileTextColor") != 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (DataArray.206.2 == 2) ; (206_2)(Obj_Pum_ColorC4_Sel [0,1,2])
        {
          DataArray := Image_GuiControl("206", 2, 0, DataArray) ; (206_1)(Obj_Pum_ColorC4)
        }
        else
        {
          DataArray := Image_GuiControl("206", 1, 0, DataArray) ; (206_1)(Obj_Pum_ColorC4)
        }
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_207_1") ; (207_1)(Obj_Pum_ColorC5)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") != 0) or (InStr(DataArray.366.5, "pumTextColor") != 0) or (InStr(DataArray.366.5, "pumMobileBgColor") != 0) or (InStr(DataArray.366.5, "pumMobileTextColor") != 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (DataArray.207.2 == 2) ; (207_2)(Obj_Pum_ColorC5_Sel [0,1,2])
        {
          DataArray := Image_GuiControl("207", 2, 0, DataArray) ; (207_1)(Obj_Pum_ColorC5)
        }
        else
        {
          DataArray := Image_GuiControl("207", 1, 0, DataArray) ; (207_1)(Obj_Pum_ColorC5)
        }
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_208_1") ; (208_1)(Obj_Pum_ColorC6)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") != 0) or (InStr(DataArray.366.5, "pumTextColor") != 0) or (InStr(DataArray.366.5, "pumMobileBgColor") != 0) or (InStr(DataArray.366.5, "pumMobileTextColor") != 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (DataArray.208.2 == 2) ; (208_2)(Obj_Pum_ColorC6_Sel [0,1,2])
        {
          DataArray := Image_GuiControl("208", 2, 0, DataArray) ; (208_1)(Obj_Pum_ColorC6)
        }
        else
        {
          DataArray := Image_GuiControl("208", 1, 0, DataArray) ; (208_1)(Obj_Pum_ColorC6)
        }
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_209_1") ; (209_1)(Obj_Pum_ColorD1)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") != 0) or (InStr(DataArray.366.5, "pumTextColor") != 0) or (InStr(DataArray.366.5, "pumMobileBgColor") != 0) or (InStr(DataArray.366.5, "pumMobileTextColor") != 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (DataArray.209.2 == 2) ; (209_2)(Obj_Pum_ColorD1_Sel [0,1,2])
        {
          DataArray := Image_GuiControl("209", 2, 0, DataArray) ; (209_1)(Obj_Pum_ColorD1)
        }
        else
        {
          DataArray := Image_GuiControl("209", 1, 0, DataArray) ; (209_1)(Obj_Pum_ColorD1)
        }
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_210_1") ; (210_1)(Obj_Pum_ColorD2)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") != 0) or (InStr(DataArray.366.5, "pumTextColor") != 0) or (InStr(DataArray.366.5, "pumMobileBgColor") != 0) or (InStr(DataArray.366.5, "pumMobileTextColor") != 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (DataArray.210.2 == 2) ; (210_2)(Obj_Pum_ColorD2_Sel [0,1,2])
        {
          DataArray := Image_GuiControl("210", 2, 0, DataArray) ; (210_1)(Obj_Pum_ColorD2)
        }
        else
        {
          DataArray := Image_GuiControl("210", 1, 0, DataArray) ; (210_1)(Obj_Pum_ColorD2)
        }
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_211_1") ; (211_1)(Obj_Pum_ColorD3)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") != 0) or (InStr(DataArray.366.5, "pumTextColor") != 0) or (InStr(DataArray.366.5, "pumMobileBgColor") != 0) or (InStr(DataArray.366.5, "pumMobileTextColor") != 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (DataArray.211.2 == 2) ; (211_2)(Obj_Pum_ColorD3_Sel [0,1,2])
        {
          DataArray := Image_GuiControl("211", 2, 0, DataArray) ; (211_1)(Obj_Pum_ColorD3)
        }
        else
        {
          DataArray := Image_GuiControl("211", 1, 0, DataArray) ; (211_1)(Obj_Pum_ColorD3)
        }
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_212_1") ; (212_1)(Obj_Pum_ColorD4)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") != 0) or (InStr(DataArray.366.5, "pumTextColor") != 0) or (InStr(DataArray.366.5, "pumMobileBgColor") != 0) or (InStr(DataArray.366.5, "pumMobileTextColor") != 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (DataArray.212.2 == 2) ; (212_2)(Obj_Pum_ColorD4_Sel [0,1,2])
        {
          DataArray := Image_GuiControl("212", 2, 0, DataArray) ; (212_1)(Obj_Pum_ColorD4)
        }
        else
        {
          DataArray := Image_GuiControl("212", 1, 0, DataArray) ; (212_1)(Obj_Pum_ColorD4)
        }
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_213_1") ; (213_1)(Obj_Pum_ColorD5)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") != 0) or (InStr(DataArray.366.5, "pumTextColor") != 0) or (InStr(DataArray.366.5, "pumMobileBgColor") != 0) or (InStr(DataArray.366.5, "pumMobileTextColor") != 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (DataArray.213.2 == 2) ; (213_2)(Obj_Pum_ColorD5_Sel [0,1,2])
        {
          DataArray := Image_GuiControl("213", 2, 0, DataArray) ; (213_1)(Obj_Pum_ColorD5)
        }
        else
        {
          DataArray := Image_GuiControl("213", 1, 0, DataArray) ; (213_1)(Obj_Pum_ColorD5)
        }
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_214_1") ; (214_1)(Obj_Pum_ColorD6)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") != 0) or (InStr(DataArray.366.5, "pumTextColor") != 0) or (InStr(DataArray.366.5, "pumMobileBgColor") != 0) or (InStr(DataArray.366.5, "pumMobileTextColor") != 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (DataArray.214.2 == 2) ; (214_2)(Obj_Pum_ColorD6_Sel [0,1,2])
        {
          DataArray := Image_GuiControl("214", 2, 0, DataArray) ; (214_1)(Obj_Pum_ColorD6)
        }
        else
        {
          DataArray := Image_GuiControl("214", 1, 0, DataArray) ; (214_1)(Obj_Pum_ColorD6)
        }
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_215_1") ; (215_1)(Obj_Pum_ColorE1)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") != 0) or (InStr(DataArray.366.5, "pumTextColor") != 0) or (InStr(DataArray.366.5, "pumMobileBgColor") != 0) or (InStr(DataArray.366.5, "pumMobileTextColor") != 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (DataArray.215.2 == 2) ; (215_2)(Obj_Pum_ColorE1_Sel [0,1,2])
        {
          DataArray := Image_GuiControl("215", 2, 0, DataArray) ; (215_1)(Obj_Pum_ColorE1)
        }
        else
        {
          DataArray := Image_GuiControl("215", 1, 0, DataArray) ; (215_1)(Obj_Pum_ColorE1)
        }
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_216_1") ; (216_1)(Obj_Pum_ColorE2)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") != 0) or (InStr(DataArray.366.5, "pumTextColor") != 0) or (InStr(DataArray.366.5, "pumMobileBgColor") != 0) or (InStr(DataArray.366.5, "pumMobileTextColor") != 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (DataArray.216.2 == 2) ; (216_2)(Obj_Pum_ColorE2_Sel [0,1,2])
        {
          DataArray := Image_GuiControl("216", 2, 0, DataArray) ; (216_1)(Obj_Pum_ColorE2)
        }
        else
        {
          DataArray := Image_GuiControl("216", 1, 0, DataArray) ; (216_1)(Obj_Pum_ColorE2)
        }
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_217_1") ; (217_1)(Obj_Pum_ColorE3)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") != 0) or (InStr(DataArray.366.5, "pumTextColor") != 0) or (InStr(DataArray.366.5, "pumMobileBgColor") != 0) or (InStr(DataArray.366.5, "pumMobileTextColor") != 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (DataArray.217.2 == 2) ; (217_2)(Obj_Pum_ColorE3_Sel [0,1,2])
        {
          DataArray := Image_GuiControl("217", 2, 0, DataArray) ; (217_1)(Obj_Pum_ColorE3)
        }
        else
        {
          DataArray := Image_GuiControl("217", 1, 0, DataArray) ; (217_1)(Obj_Pum_ColorE3)
        }
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_218_1") ; (218_1)(Obj_Pum_ColorE4)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") != 0) or (InStr(DataArray.366.5, "pumTextColor") != 0) or (InStr(DataArray.366.5, "pumMobileBgColor") != 0) or (InStr(DataArray.366.5, "pumMobileTextColor") != 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (DataArray.218.2 == 2) ; (218_2)(Obj_Pum_ColorE4_Sel [0,1,2])
        {
          DataArray := Image_GuiControl("218", 2, 0, DataArray) ; (218_1)(Obj_Pum_ColorE4)
        }
        else
        {
          DataArray := Image_GuiControl("218", 1, 0, DataArray) ; (218_1)(Obj_Pum_ColorE4)
        }
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_219_1") ; (219_1)(Obj_Pum_ColorE5)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") != 0) or (InStr(DataArray.366.5, "pumTextColor") != 0) or (InStr(DataArray.366.5, "pumMobileBgColor") != 0) or (InStr(DataArray.366.5, "pumMobileTextColor") != 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (DataArray.219.2 == 2) ; (219_2)(Obj_Pum_ColorE5_Sel [0,1,2])
        {
          DataArray := Image_GuiControl("219", 2, 0, DataArray) ; (219_1)(Obj_Pum_ColorE5)
        }
        else
        {
          DataArray := Image_GuiControl("219", 1, 0, DataArray) ; (219_1)(Obj_Pum_ColorE5)
        }
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_220_1") ; (220_1)(Obj_Pum_ColorE6)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") != 0) or (InStr(DataArray.366.5, "pumTextColor") != 0) or (InStr(DataArray.366.5, "pumMobileBgColor") != 0) or (InStr(DataArray.366.5, "pumMobileTextColor") != 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (DataArray.220.2 == 2) ; (220_2)(Obj_Pum_ColorE6_Sel [0,1,2])
        {
          DataArray := Image_GuiControl("220", 2, 0, DataArray) ; (220_1)(Obj_Pum_ColorE6)
        }
        else
        {
          DataArray := Image_GuiControl("220", 1, 0, DataArray) ; (220_1)(Obj_Pum_ColorE6)
        }
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_221_1") ; (221_1)(Obj_Pum_ColorF1)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") != 0) or (InStr(DataArray.366.5, "pumTextColor") != 0) or (InStr(DataArray.366.5, "pumMobileBgColor") != 0) or (InStr(DataArray.366.5, "pumMobileTextColor") != 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (DataArray.221.2 == 2) ; (221_2)(Obj_Pum_ColorF1_Sel [0,1,2])
        {
          DataArray := Image_GuiControl("221", 2, 0, DataArray) ; (221_1)(Obj_Pum_ColorF1)
        }
        else
        {
          DataArray := Image_GuiControl("221", 1, 0, DataArray) ; (221_1)(Obj_Pum_ColorF1)
        }
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_222_1") ; (222_1)(Obj_Pum_ColorF2)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") != 0) or (InStr(DataArray.366.5, "pumTextColor") != 0) or (InStr(DataArray.366.5, "pumMobileBgColor") != 0) or (InStr(DataArray.366.5, "pumMobileTextColor") != 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (DataArray.222.2 == 2) ; (222_2)(Obj_Pum_ColorF2_Sel [0,1,2])
        {
          DataArray := Image_GuiControl("222", 2, 0, DataArray) ; (222_1)(Obj_Pum_ColorF2)
        }
        else
        {
          DataArray := Image_GuiControl("222", 1, 0, DataArray) ; (222_1)(Obj_Pum_ColorF2)
        }
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_223_1") ; (223_1)(Obj_Pum_ColorF3)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") != 0) or (InStr(DataArray.366.5, "pumTextColor") != 0) or (InStr(DataArray.366.5, "pumMobileBgColor") != 0) or (InStr(DataArray.366.5, "pumMobileTextColor") != 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (DataArray.223.2 == 2) ; (223_2)(Obj_Pum_ColorF3_Sel [0,1,2])
        {
          DataArray := Image_GuiControl("223", 2, 0, DataArray) ; (223_1)(Obj_Pum_ColorF3)
        }
        else
        {
          DataArray := Image_GuiControl("223", 1, 0, DataArray) ; (223_1)(Obj_Pum_ColorF3)
        }
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_224_1") ; (224_1)(Obj_Pum_ColorF4)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") != 0) or (InStr(DataArray.366.5, "pumTextColor") != 0) or (InStr(DataArray.366.5, "pumMobileBgColor") != 0) or (InStr(DataArray.366.5, "pumMobileTextColor") != 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (DataArray.224.2 == 2) ; (224_2)(Obj_Pum_ColorF4_Sel [0,1,2])
        {
          DataArray := Image_GuiControl("224", 2, 0, DataArray) ; (224_1)(Obj_Pum_ColorF4)
        }
        else
        {
          DataArray := Image_GuiControl("224", 1, 0, DataArray) ; (224_1)(Obj_Pum_ColorF4)
        }
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_225_1") ; (225_1)(Obj_Pum_ColorF5)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") != 0) or (InStr(DataArray.366.5, "pumTextColor") != 0) or (InStr(DataArray.366.5, "pumMobileBgColor") != 0) or (InStr(DataArray.366.5, "pumMobileTextColor") != 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (DataArray.225.2 == 2) ; (225_2)(Obj_Pum_ColorF5_Sel [0,1,2])
        {
          DataArray := Image_GuiControl("225", 2, 0, DataArray) ; (225_1)(Obj_Pum_ColorF5)
        }
        else
        {
          DataArray := Image_GuiControl("225", 1, 0, DataArray) ; (225_1)(Obj_Pum_ColorF5)
        }
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_226_1") ; (226_1)(Obj_Pum_ColorF6)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") != 0) or (InStr(DataArray.366.5, "pumTextColor") != 0) or (InStr(DataArray.366.5, "pumMobileBgColor") != 0) or (InStr(DataArray.366.5, "pumMobileTextColor") != 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (DataArray.226.2 == 2) ; (226_2)(Obj_Pum_ColorF6_Sel [0,1,2])
        {
          DataArray := Image_GuiControl("226", 2, 0, DataArray) ; (226_1)(Obj_Pum_ColorF6)
      }
        else
        {
          DataArray := Image_GuiControl("226", 1, 0, DataArray) ; (226_1)(Obj_Pum_ColorF6)
        }
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_227_1") ; (227_1)(Obj_Pum_ColorG1)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") != 0) or (InStr(DataArray.366.5, "pumTextColor") != 0) or (InStr(DataArray.366.5, "pumMobileBgColor") != 0) or (InStr(DataArray.366.5, "pumMobileTextColor") != 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (DataArray.227.2 == 2) ; (227_2)(Obj_Pum_ColorG1_Sel [0,1,2])
        {
          DataArray := Image_GuiControl("227", 2, 0, DataArray) ; (227_1)(Obj_Pum_ColorG1)
        }
        else
        {
          DataArray := Image_GuiControl("227", 1, 0, DataArray) ; (227_1)(Obj_Pum_ColorG1)
        }
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_228_1") ; (228_1)(Obj_Pum_ColorG2)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") != 0) or (InStr(DataArray.366.5, "pumTextColor") != 0) or (InStr(DataArray.366.5, "pumMobileBgColor") != 0) or (InStr(DataArray.366.5, "pumMobileTextColor") != 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (DataArray.228.2 == 2) ; (228_2)(Obj_Pum_ColorG2_Sel [0,1,2])
        {
          DataArray := Image_GuiControl("228", 2, 0, DataArray) ; (228_1)(Obj_Pum_ColorG2)
        }
        else
        {
          DataArray := Image_GuiControl("228", 1, 0, DataArray) ; (228_1)(Obj_Pum_ColorG2)
        }
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_229_1") ; (229_1)(Obj_Pum_ColorG3)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") != 0) or (InStr(DataArray.366.5, "pumTextColor") != 0) or (InStr(DataArray.366.5, "pumMobileBgColor") != 0) or (InStr(DataArray.366.5, "pumMobileTextColor") != 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (DataArray.229.2 == 2) ; (229_2)(Obj_Pum_ColorG3_Sel [0,1,2])
        {
          DataArray := Image_GuiControl("229", 2, 0, DataArray) ; (229_1)(Obj_Pum_ColorG3)
        }
        else
        {
          DataArray := Image_GuiControl("229", 1, 0, DataArray) ; (229_1)(Obj_Pum_ColorG3)
        }
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_230_1") ; (230_1)(Obj_Pum_ColorG4)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") != 0) or (InStr(DataArray.366.5, "pumTextColor") != 0) or (InStr(DataArray.366.5, "pumMobileBgColor") != 0) or (InStr(DataArray.366.5, "pumMobileTextColor") != 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (DataArray.230.2 == 2) ; (230_2)(Obj_Pum_ColorG4_Sel [0,1,2])
        {
          DataArray := Image_GuiControl("230", 2, 0, DataArray) ; (230_1)(Obj_Pum_ColorG4)
        }
        else
        {
          DataArray := Image_GuiControl("230", 1, 0, DataArray) ; (230_1)(Obj_Pum_ColorG4)
        }
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_231_1") ; (231_1)(Obj_Pum_ColorG5)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") != 0) or (InStr(DataArray.366.5, "pumTextColor") != 0) or (InStr(DataArray.366.5, "pumMobileBgColor") != 0) or (InStr(DataArray.366.5, "pumMobileTextColor") != 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (DataArray.231.2 == 2) ; (231_2)(Obj_Pum_ColorG5_Sel [0,1,2])
        {
          DataArray := Image_GuiControl("231", 2, 0, DataArray) ; (231_1)(Obj_Pum_ColorG5)
        }
        else
        {
          DataArray := Image_GuiControl("231", 1, 0, DataArray) ; (231_1)(Obj_Pum_ColorG5)
        }
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_232_1") ; (232_1)(Obj_Pum_ColorG6)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") != 0) or (InStr(DataArray.366.5, "pumTextColor") != 0) or (InStr(DataArray.366.5, "pumMobileBgColor") != 0) or (InStr(DataArray.366.5, "pumMobileTextColor") != 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (DataArray.232.2 == 2) ; (232_2)(Obj_Pum_ColorG6_Sel [0,1,2])
        {
          DataArray := Image_GuiControl("232", 2, 0, DataArray) ; (232_1)(Obj_Pum_ColorG6)
        }
        else
        {
          DataArray := Image_GuiControl("232", 1, 0, DataArray) ; (232_1)(Obj_Pum_ColorG6)
        }
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_233_1") ; (233_1)(Obj_Pum_ColorH1)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") != 0) or (InStr(DataArray.366.5, "pumTextColor") != 0) or (InStr(DataArray.366.5, "pumMobileBgColor") != 0) or (InStr(DataArray.366.5, "pumMobileTextColor") != 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (DataArray.233.2 == 2) ; (233_2)(Obj_Pum_ColorH1_Sel [0,1,2])
        {
          DataArray := Image_GuiControl("233", 2, 0, DataArray) ; (233_1)(Obj_Pum_ColorH1)
        }
        else
        {
          DataArray := Image_GuiControl("233", 1, 0, DataArray) ; (233_1)(Obj_Pum_ColorH1)
        }
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_234_1") ; (234_1)(Obj_Pum_ColorH2)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") != 0) or (InStr(DataArray.366.5, "pumTextColor") != 0) or (InStr(DataArray.366.5, "pumMobileBgColor") != 0) or (InStr(DataArray.366.5, "pumMobileTextColor") != 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (DataArray.234.2 == 2) ; (234_2)(Obj_Pum_ColorH2_Sel [0,1,2])
        {
          DataArray := Image_GuiControl("234", 2, 0, DataArray) ; (234_1)(Obj_Pum_ColorH2)
        }
        else
        {
          DataArray := Image_GuiControl("234", 1, 0, DataArray) ; (234_1)(Obj_Pum_ColorH2)
        }
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_235_1") ; (235_1)(Obj_Pum_ColorH3)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") != 0) or (InStr(DataArray.366.5, "pumTextColor") != 0) or (InStr(DataArray.366.5, "pumMobileBgColor") != 0) or (InStr(DataArray.366.5, "pumMobileTextColor") != 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (DataArray.235.2 == 2) ; (235_2)(Obj_Pum_ColorH3_Sel [0,1,2])
        {
          DataArray := Image_GuiControl("235", 2, 0, DataArray) ; (235_1)(Obj_Pum_ColorH3)
        }
        else
        {
          DataArray := Image_GuiControl("235", 1, 0, DataArray) ; (235_1)(Obj_Pum_ColorH3)
        }
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_236_1") ; (236_1)(Obj_Pum_ColorH4)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") != 0) or (InStr(DataArray.366.5, "pumTextColor") != 0) or (InStr(DataArray.366.5, "pumMobileBgColor") != 0) or (InStr(DataArray.366.5, "pumMobileTextColor") != 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (DataArray.236.2 == 2) ; (236_2)(Obj_Pum_ColorH4_Sel [0,1,2])
        {
          DataArray := Image_GuiControl("236", 2, 0, DataArray) ; (236_1)(Obj_Pum_ColorH4)
        }
        else
        {
          DataArray := Image_GuiControl("236", 1, 0, DataArray) ; (236_1)(Obj_Pum_ColorH4)
        }
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_237_1") ; (237_1)(Obj_Pum_ColorH5)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") != 0) or (InStr(DataArray.366.5, "pumTextColor") != 0) or (InStr(DataArray.366.5, "pumMobileBgColor") != 0) or (InStr(DataArray.366.5, "pumMobileTextColor") != 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (DataArray.237.2 == 2) ; (237_2)(Obj_Pum_ColorH5_Sel [0,1,2])
        {
          DataArray := Image_GuiControl("237", 2, 0, DataArray) ; (237_1)(Obj_Pum_ColorH5)
        }
        else
        {
          DataArray := Image_GuiControl("237", 1, 0, DataArray) ; (237_1)(Obj_Pum_ColorH5)
        }
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_238_1") ; (238_1)(Obj_Pum_ColorH6)
    {
      ; -------------------------------------------
      if ((InStr(DataArray.366.5, "pumBgColor") != 0) or (InStr(DataArray.366.5, "pumTextColor") != 0) or (InStr(DataArray.366.5, "pumMobileBgColor") != 0) or (InStr(DataArray.366.5, "pumMobileTextColor") != 0)) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (DataArray.238.2 == 2) ; (238_2)(Obj_Pum_ColorH6_Sel [0,1,2])
        {
          DataArray := Image_GuiControl("238", 2, 0, DataArray) ; (238_1)(Obj_Pum_ColorH6)
        }
        else
        {
          DataArray := Image_GuiControl("238", 1, 0, DataArray) ; (238_1)(Obj_Pum_ColorH6)
        }
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_239_1") ; (239_1)(Empty)
    {
      ; (239_1)(Empty)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_240_1") ; (240_1)(Empty)
    {
      ; (240_1)(Empty)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_241_1") ; (241_1)(Obj_Pum_CropLeft)
    {
      ; -------------------------------------------
      if (InStr(DataArray.366.5, "pumBgImage") > 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (InStr(DataArray.366.5, "pumBgFitImage") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          ; -------------------------------------------
          DataArray := Image_GuiControl("241", 1, 0, DataArray) ; (241_1)(Obj_Pum_CropLeft)
          ; -------------------------------------------
        }
        ; -------------------------------------------
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_242_1") ; (242_1)(Obj_Pum_CropRight)
    {
      ; -------------------------------------------
      if (InStr(DataArray.366.5, "pumBgImage") > 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (InStr(DataArray.366.5, "pumBgFitImage") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          ; -------------------------------------------
          DataArray := Image_GuiControl("242", 1, 0, DataArray) ; (242_1)(Obj_Pum_CropRight)
          ; -------------------------------------------
        }
        ; -------------------------------------------
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_243_1") ; (243_1)(Obj_Pum_CropUp)
    {
      ; -------------------------------------------
      if (InStr(DataArray.366.5, "pumBgImage") > 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (InStr(DataArray.366.5, "pumBgFitImage") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          ; -------------------------------------------
        DataArray := Image_GuiControl("243", 1, 0, DataArray) ; (243_1)(Obj_Pum_CropUp)
          ; -------------------------------------------
        }
        ; -------------------------------------------
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_244_1") ; (244_1)(Obj_Pum_CropDown)
    {
      ; -------------------------------------------
      if (InStr(DataArray.366.5, "pumBgImage") > 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (InStr(DataArray.366.5, "pumBgFitImage") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          ; -------------------------------------------
          DataArray := Image_GuiControl("244", 1, 0, DataArray) ; (244_1)(Obj_Pum_CropDown)
          ; -------------------------------------------
        }
        ; -------------------------------------------
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_245_1") ; (245_1)(Obj_Pum_CropCenter)
    {
      ; -------------------------------------------
      if (InStr(DataArray.366.5, "pumBgImage") > 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (InStr(DataArray.366.5, "pumBgFitImage") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          ; -------------------------------------------
          DataArray := Image_GuiControl("245", 1, 0, DataArray) ; (245_1)(Obj_Pum_CropCenter)
          ; -------------------------------------------
        }
        ; -------------------------------------------
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_246_1") ; (246_1)(Obj_Pum_ZoomIn)
    {
      ; -------------------------------------------
      if (InStr(DataArray.366.5, "pumBgImage") > 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (InStr(DataArray.366.5, "pumBgFitImage") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          ; -------------------------------------------
          DataArray := Image_GuiControl("246", 1, 0, DataArray) ; (246_1)(Obj_Pum_ZoomIn)
          ; -------------------------------------------
        }
        ; -------------------------------------------
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_247_1") ; (247_1)(Obj_Pum_ZoomOut)
    {
      ; -------------------------------------------
      if (InStr(DataArray.366.5, "pumBgImage") > 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        ; -------------------------------------------
        if (InStr(DataArray.366.5, "pumBgFitImage") == 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        {
          ; -------------------------------------------
          DataArray := Image_GuiControl("247", 1, 0, DataArray) ; (247_1)(Obj_Pum_ZoomOut)
          ; -------------------------------------------
        }
        ; -------------------------------------------
      }
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_248_1") ; (248_1)(Obj_Ofl_1LAppIco)
    {
      ; (248_1)(Obj_Ofl_1LAppIco)
      ; Image_MultIconDisplay.ahk
      ; PopUpMenu
      ; _Include.ahk
      ; _S2_H.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_249_1") ; (249_1)(Obj_Ofl_2LAppIco)
    {
      ; (249_1)(Obj_Ofl_2LAppIco)
      ; Image_MultIconDisplay.ahk
      ; PopUpMenu
      ; _Include.ahk
      ; _S2_H.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_250_1") ; (250_1)(Obj_Ofl_3LAppIco)
    {
      ; (250_1)(Obj_Ofl_3LAppIco)
      ; Image_MultIconDisplay.ahk
      ; PopUpMenu
      ; _Include.ahk
      ; _S2_H.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_251_1") ; (251_1)(Obj_Ofl_DisplayText_LNumberOfIcons)
    {
      ; (251_1)(Obj_Ofl_DisplayText_LNumberOfIcons)
      ; Image_MultIconDisplay.ahk
      ; PopUpMenu
      ; _Include.ahk
      ; _S2_H.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_252_1") ; (252_1)(Obj_Ofl_LFolderImage)
    {
      ; Image_MultIconDisplay.ahk
      ; PopUpMenu
      ; _Include.ahk
      ; _S2_H.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_253_1") ; (253_1)(Empty)
    {
      ; (253_1)(Empty)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_254_1") ; (254_1)(Obj_MsgImg300x300)
    {
      if (InStr(DataArray.366.5, "pumBgImage") > 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        if (InStr(DataArray.254.3, "SelectImage_") > 0) ; (254_3)(Obj_MsgImg300x300_Img [Image Path])
        {
          Showing_Image := A_ProgramFiles "\PopUpMenu_PUM\image\pum\SelectImage_" DataArray.365.2 ".png" ; (365_2)(UserLang [Current User language])
          GuiControl, PopUpMenu:, g_254, %Showing_Image% ; (254_1)(Obj_MsgImg300x300)
          GuiControl, PopUpMenu:Show, g_254 ; (254_1)(Obj_MsgImg300x300)
        }
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_255_1") ; (255_1)(Empty)
    {
      ; (255_1)(Empty)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_256_1") ; (256_1)(Empty)
    {
      ; (256_1)(Empty)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_257_1") ; (257_1)(Empty)
    {
      ; (257_1)(Empty)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_258_1") ; (258_1)(Empty)
    {
      ; (258_1)(Empty)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_259_1") ; (259_1)(Empty)
    {
      ; (259_1)(Empty)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_260_1") ; (260_1)(Obj_Pum_IconSize)
    {
      ; (154_1)(Obj_Pum_BgImage)
      ; (155_1)(Obj_Pum_BgText)
      ; (157_1)(Obj_Pum_Setting)
      ; (159_1)(Obj_Pum_Contact)
      ; (160_1)(Obj_Pum_App))
      ; (161_1)(Obj_Pum_Del)
      ; PopUpMenu
      ; Pum_Check.ahk
      ; _Include.ahk
      ; _S2_H.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_261_1") ; (261_1)(Obj_Pum_IconUp)
    {
      ; (154_1)(Obj_Pum_BgImage)
      ; (155_1)(Obj_Pum_BgText)
      ; (157_1)(Obj_Pum_Setting)
      ; (159_1)(Obj_Pum_Contact)
      ; (160_1)(Obj_Pum_App))
      ; (161_1)(Obj_Pum_Del)
      ; (262_1)(Obj_Pum_IconDown)
      ; PopUpMenu
      ; Pum_Check.ahk
      ; _Include.ahk
      ; _S2_H.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_262_1") ; (262_1)(Obj_Pum_IconDown)
    {
      ; (154_1)(Obj_Pum_BgImage)
      ; (155_1)(Obj_Pum_BgText)
      ; (157_1)(Obj_Pum_Setting)
      ; (159_1)(Obj_Pum_Contact)
      ; (160_1)(Obj_Pum_App))
      ; (161_1)(Obj_Pum_Del)
      ; (262_1)(Obj_Pum_IconDown)
      ; PopUpMenu
      ; Pum_Check.ahk
      ; _Include.ahk
      ; _S2_H.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_263_1") ; (263_1)(Obj_Pum_ImageText_IconSize)
    {
      if (InStr(DataArray.366.5, "pumDimension") > 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("263", 1, 1, DataArray) ; (263_1)(Obj_Pum_ImageText_IconSize)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_264_1") ; (264_1)(Empty)
    {
      ; (264_1)(Empty)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_265_1") ; (265_1)(Empty)
    {
      ; (265_1)(Empty)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_266_1") ; (266_1)(Obj_Pum_PumRow)
    {
      ; (154_1)(Obj_Pum_BgImage)
      ; (155_1)(Obj_Pum_BgText)
      ; (157_1)(Obj_Pum_Setting)
      ; (159_1)(Obj_Pum_Contact)
      ; (160_1)(Obj_Pum_App))
      ; (161_1)(Obj_Pum_Del)
      ; PopUpMenu
      ; Pum_Check.ahk
      ; Sys_EnableDisable.ahk
      ; _Include.ahk
      ; _S2_H.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_267_1") ; (267_1)(Obj_Pum_PumRowUp)
    {
      ; (154_1)(Obj_Pum_BgImage)
      ; (155_1)(Obj_Pum_BgText)
      ; (157_1)(Obj_Pum_Setting)
      ; (159_1)(Obj_Pum_Contact)
      ; (160_1)(Obj_Pum_App))
      ; (161_1)(Obj_Pum_Del)
      ; (267_1)(Obj_Pum_PumRowUp)
      ; PopUpMenu
      ; Pum_Check.ahk
      ; _Include.ahk
      ; _S2_H.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_268_1") ; (268_1)(Obj_Pum_PumRowDown)
    {
      ; (154_1)(Obj_Pum_BgImage)
      ; (155_1)(Obj_Pum_BgText)
      ; (157_1)(Obj_Pum_Setting)
      ; (159_1)(Obj_Pum_Contact)
      ; (160_1)(Obj_Pum_App))
      ; (161_1)(Obj_Pum_Del)
      ; (268_1)(Obj_Pum_PumRowDown)
      ; PopUpMenu
      ; Pum_Check.ahk
      ; _Include.ahk
      ; _S2_H.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_269_1") ; (269_1)(Obj_Pum_DisplayText_Vertical)
    {
      if (InStr(DataArray.366.5, "pumDimension") > 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("269", 1, 1, DataArray) ; (269_1)(Obj_Pum_DisplayText_Vertical)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_270_1") ; (270_1)(Empty)
    {
      ; (270_1)(Empty)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_271_1") ; (271_1)(Empty)
    {
      ; (271_1)(Empty)
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_272_1") ; (272_1)(Obj_Pum_PumColumn)
    {
      ; (154_1)(Obj_Pum_BgImage)
      ; (155_1)(Obj_Pum_BgText)
      ; (157_1)(Obj_Pum_Setting)
      ; (159_1)(Obj_Pum_Contact)
      ; (160_1)(Obj_Pum_App))
      ; (161_1)(Obj_Pum_Del)
      ; PopUpMenu
      ; Pum_Check.ahk
      ; Sys_EnableDisable.ahk
      ; _Include.ahk
      ; _S2_H.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_273_1") ; (273_1)(Obj_Pum_PumColumnUp)
    {
      ; (154_1)(Obj_Pum_BgImage)
      ; (155_1)(Obj_Pum_BgText)
      ; (157_1)(Obj_Pum_Setting)
      ; (159_1)(Obj_Pum_Contact)
      ; (160_1)(Obj_Pum_App))
      ; (161_1)(Obj_Pum_Del)
      ; (273_1)(Obj_Pum_PumColumnUp)
      ; PopUpMenu
      ; Pum_Check.ahk
      ; _Include.ahk
      ; _S2_H.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_274_1") ; (274_1)(Obj_Pum_PumColumnDown)
    {
      ; (154_1)(Obj_Pum_BgImage)
      ; (155_1)(Obj_Pum_BgText)
      ; (157_1)(Obj_Pum_Setting)
      ; (159_1)(Obj_Pum_Contact)
      ; (160_1)(Obj_Pum_App))
      ; (161_1)(Obj_Pum_Del)
      ; (274_1)(Obj_Pum_PumColumnDown)
      ; PopUpMenu
      ; Pum_Check.ahk
      ; _Include.ahk
      ; _S2_H.ahk
      ; _S3_S.ahk
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_275_1") ; (275_1)(Obj_Pum_DisplayText_Horizontal)
    {
      if (InStr(DataArray.366.5, "pumDimension") > 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        DataArray := Image_GuiControl("275", 1, 1, DataArray) ; (275_1)(Obj_Pum_DisplayText_Horizontal)
      }
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (ThisItem == "v_290_1") ; (290)(Obj_BrowserPum)
    {
      if (InStr(DataArray.366.5, "pum") > 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      {
        if (IsInternetBrowser(DataArray.367.1, DataArray.367.3, DataArray.367.4) == 1) ; All Supported Internet Browsers
        {
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ; [Internet Browser Application Active]
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ;
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          ; [GET] Value (290)(04)(Obj_BrowserPum_UseCommonBrowser [0,1,2])
          ; -------------------------------------------
          File_InternetBrowserPum := A_Appdata "\PopUpMenu_PUM\system\InternetBrowserPum.txt"
          ; -------------------------------------------
          FileReadLine, UseCommonBrowser, %File_InternetBrowserPum%, 1
          ; -------------------------------------------
          if (UseCommonBrowser == "")
          {
            ; -------------------------------------------
            UseCommonBrowser := 1
            DataArray.290.2 := UseCommonBrowser
            ; -------------------------------------------
            FileDelete, %File_InternetBrowserPum%
            Sleep, 250
            FileEncoding, UTF-8
            FileAppend, 1, %File_InternetBrowserPum% ; [UseCommonBrowser = 1][All Browsers Same Pum] (Default)
            Sleep, 250
            ; -------------------------------------------
          }
          ; -------------------------------------------
          DataArray.290.2 := UseCommonBrowser
          ; -------------------------------------------
          ; [GET] Value (290)(04)(Obj_BrowserPum_UseCommonBrowser [0,1,2])
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          ;
          ; -------------------------------------------
          if (DataArray.290.2 == 1) ; [UseCommonBrowser = 1][All Browsers Same Pum]
          {
            DataArray := Image_GuiControl("290", 1, 1, DataArray) ; (290)(Obj_BrowserPum)
          }
          else if (DataArray.290.2 == 2) ; [UseCommonBrowser = 2][Each Browser Different pum]
          {
            DataArray := Image_GuiControl("290", 2, 1, DataArray) ; (290)(Obj_BrowserPum)
          }
          ; -------------------------------------------
        } ; [Internet Browser Application Active]
      } ; (ScriptType)
    } ; (290)(Obj_BrowserPum)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  } ; [End] _S3_S(DataArray)
  if (DataArray.366.5 == "run") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
  {
    ; -------------------------------------------
    ; [ScriptError = 1] (run)(rwh)(Application Target [exe] File Not Found)
    ; -------------------------------------------
    if (DataArray.366.6 != 1) ; (366_6)(ScriptError [Integer])
    {
      ; -------------------------------------------
      ArrayIn := [DataArray.305.11, "", "", DataArray.365.2, DataArray.363.12]
      FileError440 := Img_Error440(ArrayIn)
      FileError450 := Img_Error450(ArrayIn)
      FileError460 := Img_Error460(ArrayIn)
      FileError470 := Img_Error470(ArrayIn)
      ; -------------------------------------------
      ArrayIn := [DataArray.367.5, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
      FileOflIco := Img_OflIco(ArrayIn)
      FileRunIco := Img_RunIco(ArrayIn)
      FileRwhIco := Img_RwhIco(ArrayIn)
      ; -------------------------------------------
      DataArray := Image_ExeToPng(DataArray.305.11, DataArray) ; (305_11)(Run_OutTarget [PathExtName])
      DataArray := Image_MultIconDisplay(DataArray) ; > DataArray
      ; -------------------------------------------
    }
    ; -------------------------------------------
    if (DataArray.305.13 == 1 && DataArray.305.14 != "") ; (305_13)(Run_UseLink [Selected OutTarget File Is a LNK] [0/1])/(305_14)(Run_FileSelected [Selected File PathExtName (Select_FileFolder)])
    {
      DataArray.305.11 := DataArray.305.14 ; (305_11)(Run_OutTarget [PathExtName])/(305_14)(Run_FileSelected [Selected File PathExtName (Select_FileFolder)])
    }
    ; -------------------------------------------
  } ; [End] (ScriptType [run])
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  else if (DataArray.366.5 == "rwh") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
  {
    ; -------------------------------------------
    ; [ScriptError = 1] (run)(rwh)(Application Target [exe] File Not Found)
    ; [ScriptError = 2] (rwh)(No Application to Open File)
    ; -------------------------------------------
    if (DataArray.366.6 != 1 && DataArray.366.6 != 2) ; (366_6)(ScriptError [Integer])
    {
      ; -------------------------------------------
      ArrayIn := [DataArray.305.5, "", "", DataArray.365.2, DataArray.363.12]
      FileError440 := Img_Error440(ArrayIn)
      FileError450 := Img_Error450(ArrayIn)
      FileError460 := Img_Error460(ArrayIn)
      FileError470 := Img_Error470(ArrayIn)
      ; -------------------------------------------
      ArrayIn := [DataArray.367.5, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
      FileOflIco := Img_OflIco(ArrayIn)
      FileRunIco := Img_RunIco(ArrayIn)
      FileRwhIco := Img_RwhIco(ArrayIn)
      ; -------------------------------------------
      DataArray := Image_ExeToPng(DataArray.305.5, DataArray) ; (305_5)(Rwh_OpeningApp [Full File Path])
      DataArray := Image_MultIconDisplay(DataArray) ; > DataArray
      ; -------------------------------------------
    }
  } ; [End] (ScriptType [rwh])
  ; -------------------------------------------
  else if (DataArray.366.5 == "url") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
  {
    ; -------------------------------------------
    DataArray := Image_MultIconDisplay(DataArray) ; > DataArray
    ; -------------------------------------------
  } ; [End] (ScriptType [url])
  ; -------------------------------------------
  else if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
  {
    ; -------------------------------------------
    ; [ScriptError = 3] (key)(Invalid KeyStroke)
    ; -------------------------------------------
    if (DataArray.366.6 != 3) ; (366_6)(ScriptError [Integer])
    {
      DataArray := Image_MultIconDisplay(DataArray) ; > DataArray
    }
  } ; [End] (ScriptType [key])
  ; -------------------------------------------
  else if (DataArray.366.5 == "ofl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
  {
    ; -------------------------------------------
    ; [ScriptError = 6] (ofl)(Folder Not Found)
    ; -------------------------------------------
    if (DataArray.366.6 != 6) ; (366_6)(ScriptError [Integer])
    {
      DataArray := Image_MultIconDisplay(DataArray) ; > DataArray
    }
  } ; [End] (ScriptType [ofl])
  ; -------------------------------------------
  else if (DataArray.366.5 == "mnu" or DataArray.366.5 == "cpl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
  {
    ; -------------------------------------------
    DataArray := CplMnu_MenuDisplay(DataArray) ; > DataArray
    ; -------------------------------------------
    if (DataArray.366.6 != 9 && DataArray.366.6 != 14) ; (366_6)(ScriptError [Integer])
    {
      ; -------------------------------------------
      ; [ScriptError = 9] (mnu)(No Error)(Menu Bar Item Not Selected)
      ; -------------------------------------------
      GuiControl, PopUpMenu:Hide, g_137 ; (137_1)(Obj_MsgImg480x270)
      ; -------------------------------------------
    }
    ; -------------------------------------------
  } ; [End] (ScriptType [cpl,mnu])
  ; -------------------------------------------
  DataArray.363.9 := ""  ; (363_9)(LinitDataArray [Limited DataArray])
  ; -------------------------------------------
  ;
  return DataArray
  ; -------------------------------------------
} ; [End] _S3_S(DataArray)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
