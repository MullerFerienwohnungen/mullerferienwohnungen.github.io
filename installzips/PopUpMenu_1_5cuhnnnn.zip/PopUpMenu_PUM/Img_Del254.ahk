﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\Folder_WindowsUser.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_Combine.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_ResizePng.ahk
; -------------------------------------------
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_PathFolderOrName.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Img_RunPng.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Img_Del254(ArrayIn) ; > FileDel254
{
/*
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
ArrayIn := [DataArray.367.5, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
FileDel254 := Img_Del254(ArrayIn)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
AppProcessPathNameExt := ArrayIn.1 ; (DataArray.367.5)(AppProcessPathNameExt [Path,Name,Ext])
AppProcessName        := ArrayIn.2 ; (DataArray.367.1)(AppProcessName [Name][LowerCase][NoSpace])
UseCommonBrowser      := ArrayIn.3 ; (DataArray.290.2 = 2 [UseCommonBrowser = 2][Each Browser Different pum])(DataArray.290.2 = 1 [UseCommonBrowser = 1][All Browsers Same Pum])
UserLang              := ArrayIn.4 ; (DataArray.365.2)(UserLang [Current User language])
UserPictureFolder     := ArrayIn.5 ; (UserPictureFolder)(ThisUserPictureFolder)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
return FileDel254
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
*/
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; StartUp Vars
  ; -------------------------------------------
  AppProcessPathNameExt := ArrayIn.1 ; (DataArray.367.5)(AppProcessPathNameExt [Path,Name,Ext])
  AppProcessName        := ArrayIn.2 ; (DataArray.367.1)(AppProcessName [Name][LowerCase][NoSpace])
  UseCommonBrowser      := ArrayIn.3 ; (DataArray.290.2 = 2 [UseCommonBrowser = 2][Each Browser Different pum])(DataArray.290.2 = 1 [UseCommonBrowser = 1][All Browsers Same Pum])
  UserLang              := ArrayIn.4 ; (DataArray.365.2)(UserLang [Current User language])
  UserPictureFolder     := ArrayIn.5 ; (UserPictureFolder)(ThisUserPictureFolder)
  ; -------------------------------------------
  ; StartUp Vars
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; if This Value is Blank
  ; -------------------------------------------
  if (UseCommonBrowser == "")
  {
    UseCommonBrowser := 0
  }
  ; -------------------------------------------
  if (UserPictureFolder == "")
  {
    ; -------------------------------------------
    RegRead, UserPictureFolder, HKEY_CURRENT_USER, Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders, My Pictures
    ; -------------------------------------------
  }
  ; -------------------------------------------
  if (AppProcessName == "")
  {
    if (AppProcessPathNameExt != "")
    {
      SplitPath, AppProcessPathNameExt, , , , AppProcessName
    }
  }
  ; -------------------------------------------
  ; if This Value is Blank
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if FileExist(AppProcessPathNameExt) ; Does the App Exist
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; Used When (DataArray.290.2 == 1)
    ; [UseCommonBrowser = 1][All Browsers Same Pum]
    ; -------------------------------------------
    SplitPath, AppProcessPathNameExt, CommonBrowser
    if (CommonBrowser == "pumcommonbrowser.txt") ; [UseCommonBrowser = 1][All Browsers Same Pum]
    {
      ; -------------------------------------------
      FileRunPng := A_ProgramFiles "\PopUpMenu_PUM\image\ico\CommonBrowser_Png.png"
      FileDel254 := A_ProgramFiles "\PopUpMenu_PUM\image\ico\CommonBrowser_Del254_" UserLang ".png"
      ; -------------------------------------------
    }
    else
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; (Image_PathFolderOrName) This Script just sets Paths
      ; -------------------------------------------
      ArrayIn := [AppProcessPathNameExt, AppProcessName, UseCommonBrowser, "FileRunPng", UserLang, UserPictureFolder]
      ArrayOut := Image_PathFolderOrName(ArrayIn)
      FileRunPng := ArrayOut.1
      ; -------------------------------------------
      ; (Image_PathFolderOrName) This Script just sets Paths
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; (Image_PathFolderOrName) This Script just sets Paths
      ; -------------------------------------------
      ArrayIn := [AppProcessPathNameExt, AppProcessName, UseCommonBrowser, "FileDel254", UserLang, UserPictureFolder]
      ArrayOut := Image_PathFolderOrName(ArrayIn)
      FileDel254 := ArrayOut.1
      ; -------------------------------------------
      ; (Image_PathFolderOrName) This Script just sets Paths
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    }
    ; -------------------------------------------
    ; Used When (DataArray.290.2 == 1)
    ; [UseCommonBrowser = 1][All Browsers Same Pum]
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;  [CHECK] [CREATE] [UserPictureFolder "\(_PopUpMenu_)\(_Application_)\Png\" AppProcessName "_(" AppProcessFolder ").png"]
    ; -------------------------------------------
    if !FileExist(FileRunPng)
    {
      ; -------------------------------------------
      ArrayIn := [AppProcessPathNameExt, AppProcessName, UseCommonBrowser, UserLang, UserPictureFolder]
      FileRunPng := Img_RunPng(ArrayIn)
      ; -------------------------------------------
    } ; [End] if !FileExist(FileRunPng)
    ; -------------------------------------------
    ;  [CHECK] [CREATE] [UserPictureFolder "\(_PopUpMenu_)\(_Application_)\Png\" AppProcessName "_(" AppProcessFolder ").png"]
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [CHECK] [UserPictureFolder "\(_PopUpMenu_)\System\FileDel254\" AppProcessName "_(" AppProcessFolder ").png"]
    ; -------------------------------------------
    if !FileExist(FileDel254)
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [CHECK] [CREATE]
      TempFolder := A_AppData "\PopUpMenu_PUM\temp"
      ; -------------------------------------------
      if !FileExist(TempFolder)
      {
        FileCreateDir, %TempFolder%
        Sleep, 10
      } ; [End] if !FileExist(TempFolder)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [CHECK] [CREATE]
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; [RESIZE] [UserPictureFolder "\(_PopUpMenu_)\(_Application_)\Png\" AppProcessName "_(" AppProcessFolder ").png"]
      ; [TO]     [A_AppData "\PopUpMenu_PUM\temp\Del254Temp.png"]
      ; -------------------------------------------
      Del254Temp := A_AppData "\PopUpMenu_PUM\temp\Del254Temp.png" ; w66 h66
      ; -------------------------------------------
      if FileExist(Del254Temp)
      {
        FileDelete, %Del254Temp%
      } ; [End] if !FileExist(Del254Temp)
      ; -------------------------------------------
      Image_ResizePng(66, 66, FileRunPng, Del254Temp) ; Resize_W, Resize_H, ImageIn, ImageOut > 1 / 0
      ; -------------------------------------------
      ; [RESIZE] [UserPictureFolder "\(_PopUpMenu_)\(_Application_)\Png\" AppProcessName "_(" AppProcessFolder ").png"]
      ; [TO]     [A_AppData "\PopUpMenu_PUM\temp\Del254Temp.png"]
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; [CREATE]  [UserPictureFolder "\(_PopUpMenu_)\System\FileDel254\" AppProcessName "_(" AppProcessFolder ").png"]
      ; [COMBINE] [A_AppData "\PopUpMenu_PUM\temp\Del254Temp.png"]
      ; [WITH]    [A_ProgramFiles "\PopUpMenu_PUM\image\ico\Del254_" UserLang ".png"]
      ; -------------------------------------------
      I1 := A_ProgramFiles "\PopUpMenu_PUM\image\ico\FileDel254.png" ; w113, h113
      X1 := 14 ; X Position (Left)
      Y1 := 8 ; Y Postion (Down)
      ;
      I2  := Del254Temp ; w66, h66
      X2 := 38 ; X Position (Left)
      Y2 := 48 ; Y Postion (Down)
      ;
      I3 := A_ProgramFiles "\PopUpMenu_PUM\image\ico\FileDel254_" UserLang ".png"  ; w300 h300
      X3 := 0 ; X Position (Left)
      Y3 := 0 ; Y Postion (Down)
      ;
      ; -------------------------------------------
      Image_Array := [300, 300, FileDel254, I1, X1, Y1, I2, X2, Y2, I3, X3, Y3]
      Image_Combine(Image_Array)
      ; -------------------------------------------
      ; [CREATE]  [UserPictureFolder "\(_PopUpMenu_)\System\FileDel254\" AppProcessName "_(" AppProcessFolder ").png"]
      ; [COMBINE] [A_AppData "\PopUpMenu_PUM\temp\Del254Temp.png"]
      ; [WITH]    [A_ProgramFiles "\PopUpMenu_PUM\image\ico\Del254_" UserLang ".png"]
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; [DELETE] [A_AppData "\PopUpMenu_PUM\temp\Del254Temp.png"]
      ; -------------------------------------------
      if FileExist(Del254Temp)
      {
        FileDelete, %Del254Temp%
      } ; [End] if FileExist(Del254Temp)
      ; -------------------------------------------
      ; [DELETE] [A_AppData "\PopUpMenu_PUM\temp\Del254Temp.png"]
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    } ; [End] if !FileExist(FileDel254)
    ; -------------------------------------------
    ; [CHECK] [UserPictureFolder "\(_PopUpMenu_)\System\FileDel254\" AppProcessName "_(" AppProcessFolder ").png"]
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; -------------------------------------------
    return FileDel254
    ; -------------------------------------------
  } ; [End] if FileExist(AppProcessPathNameExt) ; Does the App Exist
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
