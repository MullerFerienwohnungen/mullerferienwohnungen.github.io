﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\UIS.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
CplMnu_ListBox(ThisArray) ; ThisArray > ThisListBox
{
  ; -------------------------------------------
  ThisArrayLen := ThisArray.MaxIndex() ; ThisArray = %Lang%_MenuArray_%MenuArrayNum1%
  ThisListBox := "|"
  ; -------------------------------------------
  for Index, ThisItem in ThisArray ; ThisArray = %Lang%_MenuArray_%MenuArrayNum1%
  {
    ItemValue := ThisItem.2 ; Menu Item Description
    if (ItemValue == "DIV")
    {
      ItemValue := "-------------------------------------------------------------------------------------------"
    }
    else if (InStr(ItemValue, "(U_Code)") > 0)
    {
      ItemValue := UIS(ItemValue) ; > ItemValue
    }
    ; -------------------------------------------
    if (Index == ThisArrayLen) ; Last Item in Array
    {
      ThisListBox := ThisListBox ItemValue
    } ; End (Index == ThisArrayLen)
    ; -------------------------------------------
    else 
    {
      ThisListBox := ThisListBox ItemValue "|"
    } ; End (Index != ThisArrayLen)
    ; -------------------------------------------
  } ; End or Index, ThisItem in ThisArray
  ; -------------------------------------------
  return ThisListBox
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
