﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
#NoTrayIcon
#SingleInstance, Force
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; (515)(Splash Anamated: Installing Icons)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; [StartUp] PreLoad Image
; -------------------------------------------
; *Note* Splash_Script("Off", 0) is Ran (SysTray.ahk)
; Max 90 Seconds to ExitApp
; -------------------------------------------
BreakTime515 := A_TickCount + 90000
ImagePath := A_ProgramFiles "\PopUpMenu_PUM\image\gui"
; -------------------------------------------
GuiIconNum := 0
; -------------------------------------------
Loop 55
{
	; -------------------------------------------
	GuiIconNum := GuiIconNum + 1
	; -------------------------------------------
	ThisImage := ImagePath "\(515)_" GuiIconNum "_.png"
	; -------------------------------------------
}
; -------------------------------------------
GuiIconNum := 0
; -------------------------------------------
; [StartUp] Vars / PreLoad Image
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Gui
; -------------------------------------------
Gui, PopUpMenu515:Add, Picture, x0  y0   w200 h250 vG_GuiIcon, 
; -------------------------------------------
Gui, PopUpMenu515:+LastFound -Caption +AlwaysOnTop +ToolWindow -Border ; Gui Start (AlwaysOnTop)
Gui, PopUpMenu515:Color, 562958 ; Good Color For Pum Guy 
WinSet, TransColor, 562958
; -------------------------------------------
Gui, PopUpMenu515:Show, , PopUpMenu515
; -------------------------------------------
SetTimer, PopUpMenuLabel515, 200
; -------------------------------------------
;
; -------------------------------------------
return
; -------------------------------------------
; Gui
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Labels
; -------------------------------------------
PopUpMenuLabel515:
{
  ; -------------------------------------------
  if (A_TickCount > BreakTime515)
  {
    ; -------------------------------------------
    SetTimer, PopUpMenuLabel515, Off
    ExitApp
    ; -------------------------------------------
  }
	if (GuiIconNum < 62)
	{
    ; -------------------------------------------
	  GuiIconNum := GuiIconNum + 1
	  ; -------------------------------------------
	  ThisImage := ImagePath "\(515)_" GuiIconNum ".png"
	  GuiControl, PopUpMenu515:, G_GuiIcon, %ThisImage%
    ; -------------------------------------------
	}
	; -------------------------------------------
}
return
; -------------------------------------------
; Labels
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
