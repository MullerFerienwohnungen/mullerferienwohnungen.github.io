﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\Gui_ObjectSize.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
l_522: ; (522_1)(_Msg 4_)(_w480 x h270_)_Nailing_Man)
{
  ; -------------------------------------------
  ; Nailing_Man
  ; -------------------------------------------
  ;
  ; (_w480 x h270_)
  ; This Animation will Repeat
  ; Resets to Frame 1
  ;
  ; if (137_3)(Message Image 4: Image Path) Exist (Original Image)
  ; Returns (137_3)(Message Image 4: Image Path) to (Original Image)
  ; Otherwise Hides (137)(Message Image 4)
  ;
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Start/Show (Nailing_Man)
  ; global n_522 := 1 ; Start Frame Number
  ; global s_522 := 1 ; Show
  ; (522_1)(_Msg 4_)(_w480 x h270_)_Nailing_Man)
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Start/Show (Nailing_Man)
  ;
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Stop/Hide (Nailing_Man)
  ; global s_522 := 0 ; Hide
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Stop/Hide (Nailing_Man)
  ;
  ; [ANIMATE] Start/Show in This File
  ; Pum_DisplayPumApp.ahk
  ;
  ; -------------------------------------------
  if (ShowAnimationChange == "")
  {
    global ShowAnimationChange := 0
  }
  ; -------------------------------------------
  Total_Images := 4
  Pre_Image := DataArray.137.3 ; (137_3)(Obj_MsgImg480x270_Img [Image Path])
  ; -------------------------------------------
  if (s_522 == 1) ; [START] [ANMIMATE]
  {
    ; -------------------------------------------
    if (n_522 > Total_Images) ; 1 Less than Number of Images
    {
      global n_522 := 1
    }
    else
    {
      ; -------------------------------------------
      GuiControl, PopUpMenu:, g_137, %A_ProgramFiles%\PopUpMenu_PUM\image\gui\(522)_%n_522%.png ; (137_1)(Obj_MsgImg480x270)
      ; -------------------------------------------
      Gui_ObjectSize("137", DataArray) ; > Nothing
      ; -------------------------------------------
      if (ShowAnimationChange == 0)
      {
        GuiControl, PopUpMenu:Show, g_137 ; (137_1)(Obj_MsgImg480x270)
        global ShowAnimationChange := 1
      }
      ; -------------------------------------------
      global n_522 := n_522 + 1
      ; -------------------------------------------
    }
  } ; End Start Animation
  else ; Hide/Stop Animation
  {
    ; -------------------------------------------
    global ShowAnimationChange := 0
    ; -------------------------------------------
    SetTimer, l_522, Off ; (522_1)(_Msg 4_)(_w480 x h270_)_Nailing_Man)
    ; -------------------------------------------
    if (Pre_Image != "")
    {
      GuiControl, PopUpMenu:, g_137, %Pre_Image% ; (137_1)(Obj_MsgImg480x270)
      GuiControl, PopUpMenu:Show, g_137 ; (137_1)(Obj_MsgImg480x270)
    }
    ; -------------------------------------------
  } ; End Hide/Stop Animation
  ; -------------------------------------------
} ; [End] (522_1)(_Msg 4_)(_w480 x h270_)_Nailing_Man)
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
