﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\Url_ConnectCheck.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_GuiControl.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Select_FileFolder.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Default_Application.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\_S1_C.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\_S2_H.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\_S3_S.ahk
; -------------------------------------------
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_PathFolderOrName.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Img_RunIco.ahk
; -------------------------------------------
#Include %A_ProgramFiles%\PopUpMenu_PUM\Url_GetUrl.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Select File
; -------------------------------------------
f_081(DataArray) ; (081_1)(Obj_RunRwh_File)
{
  ; -------------------------------------------
  DataArray := Image_GuiControl("081", 2, 1, DataArray) ; (081_1)(Obj_RunRwh_File)
  ; -------------------------------------------
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; A Browser is Active
  if (IsInternetBrowser(DataArray.367.1, DataArray.367.3, DataArray.367.4) == 1) ; All Supported Internet Browsers
  {
    ; -------------------------------------------
    DataArray := Image_GuiControl("071", 1, 1, DataArray) ; (071_1)(Obj_URL)
    ; -------------------------------------------
  }
  else ; NO Borwser is Active
  {
    ; -------------------------------------------
    DataArray := Image_GuiControl("071", 3, 1, DataArray) ; (071_1)(Obj_URL)
    ; -------------------------------------------
  }
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; -------------------------------------------
  DataArray := Image_GuiControl("082", 1, 1, DataArray) ; (082_1)(Obj_Ofl_Folder)
  ; -------------------------------------------
  ;
  ; -------------------------------------------
  StartFolder := DataArray.363.15 ; (363_15)(AllUsersStartMenuFolder)
  ; -------------------------------------------
  ;
  ; -------------------------------------------
  ; [OutTarget, Arguments, UseLink (0,1), Selected_File, LinkIcon]
  ThisPumProcessFolder := DataArray.361.8 ; (361)(8)(ThisPumProcessFolder [Pum Folder Path])
  Selected_Array := Select_FileFolder(DataArray.365.2, "AnyFile", StartFolder, ThisPumProcessFolder) ; (365_2)(UserLang [Current User language])
  ; -------------------------------------------
  Run_OutTarget    := Selected_Array.1 ; (305_11)(Run_OutTarget [PathExtName])
  Run_Arguments    := Selected_Array.2 ; (305_12)(run_Arguments [Executable Arguments])
  Run_UseLink      := Selected_Array.3 ; (305_13)(Run_UseLink [Selected OutTarget File Is a LNK] [0/1])
  Run_FileSelected := Selected_Array.4 ; (305_14)(run_FileSelected [Selected File PathExtName (Select_FileFolder)])
  Run_LinkIcon     := Selected_Array.5 ; (305_15)(Run_LinkIcon [Icon of Selected Link File (Select_FileFolder)])
  Run_LinkName     := Selected_Array.6 ; (305_16)(run_LinkName [Selected Link File Name (Select_FileFolder)])
  ; -------------------------------------------
  DataArray.305.11 := Run_OutTarget    ; (305_11)(Run_OutTarget [PathExtName])
  DataArray.305.12 := Run_Arguments    ; (305_12)(Run_Arguments [Executable Arguments])
  DataArray.305.13 := Run_UseLink      ; (305_13)(Run_UseLink [Selected OutTarget File Is a LNK] [0/1])
  DataArray.305.14 := Run_FileSelected ; (305_14)(Run_FileSelected [Selected File PathExtName (Select_FileFolder)])
  DataArray.305.15 := Run_LinkIcon     ; (305_15)(Run_LinkIcon [Icon of Selected Link File (Select_FileFolder)])
  DataArray.305.16 := Run_LinkName     ; (305_16)(Run_LinkName [Selected Link File Name (Select_FileFolder)])
  ; -------------------------------------------
  if FileExist(Run_OutTarget) ; (305_11)(Run_OutTarget [PathExtName])
  {
    DataArray.305.11
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; (137_1)(Obj_MsgImg480x270)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; StatusBar Description
    ; -------------------------------------------
    ; (305_14)(run_FileSelected [Selected File PathExtName (Select_FileFolder)])
    ; -------------------------------------------
    SplitPath, Run_FileSelected, , , Run_FileSelected_Ext, Run_FileSelected_Name
    StringLower, Run_FileSelected_Ext, Run_FileSelected_Ext
    ; -------------------------------------------
    if (run_FileSelected_Ext == "lnk") ; The Selected File was a Link (lnk)
    {
      ; -------------------------------------------
      ; run_FileSelected was a link
      ; -------------------------------------------
      DataArray.122.3 := Run_LinkName ; (122_3)(Obj_EditFeild_StatusBar_Val [Text Value])
      ; -------------------------------------------
    } ; [End] The Selected File was a Link (lnk)
    else ; The Selected File was NOT Link (lnk)
    {
      ; -------------------------------------------
      ; run_FileSelected was NOT a link
      ; -------------------------------------------
      ; (305_11)(Run_OutTarget [PathExtName])
      ; -------------------------------------------
      SplitPath, Run_OutTarget, , , , Run_OutTarget_Name
      ; -------------------------------------------
      DataArray.122.3 := Run_OutTarget_Name ; (122_3)(Obj_EditFeild_StatusBar_Val [Text Value])
      ; ------------------------------------------
      DataArray.367.5 := 
      ; -------------------------------------------
    } ; [End] The Selected File was NOT Link (lnk)
    ; -------------------------------------------
    ; StatusBar Description
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; (Image_PathFolderOrName) This Script just sets Paths
    ; -------------------------------------------
    ArrayIn := [DataArray.305.11, DataArray.367.1, DataArray.290.2, "FileRunIco", DataArray.365.2, DataArray.363.12]
    ArrayOut := Image_PathFolderOrName(ArrayIn)
    FileRunIco := ArrayOut.1
    AppProcessExt := ArrayOut.3
    ; -------------------------------------------
    ; (Image_PathFolderOrName) This Script just sets Paths
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; -------------------------------------------
    if !FileExist(FileRunIco)
    {
      ; -------------------------------------------
      DataArray := Image_GuiControl("134", 0, 0, DataArray) ; (134_1)(Obj_ImageSelect1)
      DataArray := Image_GuiControl("135", 0, 0, DataArray) ; (135_1)(Obj_ImageSelect2)
      DataArray := Image_GuiControl("136", 0, 0, DataArray) ; (136_1)(Obj_ImageSelect3)
      ; -------------------------------------------
      ; (305_11)(Run_OutTarget [PathExtName])
      ; (367)(1)(AppProcessName [Name][LowerCase][NoSpace])
      ; (290)(2)(Obj_BrowserPum_Sel [0,1,2])
      ; (365)(2)(UserLang [Current User language])
      ; (363)(12)(ThisUserPictureFolder)
      ; -------------------------------------------
      ArrayIn := [DataArray.305.11, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
      FileRunIco := Img_RunIco(ArrayIn)
      ; -------------------------------------------
    } ; [End] if !FileExist(FileRunIco)
    ; -------------------------------------------
    ; AppImgFolder "\(_FileRunIco_).ico"
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; (102_3)(Obj_DisplayedIcon_Img [Image Path])
    ; -------------------------------------------
    if FileExist(Run_LinkIcon)
    {
      ; -------------------------------------------
      SplitPath, InputVar, , , ThisExtension
      StringLower, ThisExtension, ThisExtension
      ; -------------------------------------------
      if (ThisExtension == "ico")
      {
        DataArray.102.3 := Run_LinkIcon ; (102_3)(Obj_DisplayedIcon_Img [Image Path])
      }
      else if (ThisExtension == "exe")
      {
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ; (Image_PathFolderOrName) This Script just sets Paths
        ; -------------------------------------------
        ArrayIn := [Run_LinkIcon, DataArray.367.1, DataArray.290.2, "FileRunIco", DataArray.365.2, DataArray.363.12]
        ArrayOut := Image_PathFolderOrName(ArrayIn)
        FileRunIco := ArrayOut.1
        ; -------------------------------------------
        ; (Image_PathFolderOrName) This Script just sets Paths
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ;
        ; -------------------------------------------
        if FileExist(FileRunIco)
        {
          DataArray.102.3 := FileRunIco ; (102_3)(Obj_DisplayedIcon_Img [Image Path])
        }
      }
    }
    else if FileExist(FileRunIco)
    {
      DataArray.102.3 := FileRunIco ; (102_3)(Obj_DisplayedIcon_Img [Image Path])
    }
    ; -------------------------------------------
    ; (102_3)(Obj_DisplayedIcon_Img [Image Path])
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (Run_UseLink == 1)
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; Create Shortcut to Selected File in User pum Folder
      ; -------------------------------------------
      ThisPumProcessName := DataArray.361.15 ; (361)(15)(ThisPumProcessName [NO pum_,Path,Ext])
      PumLinkPath := A_AppData "\PopUpMenu_PUM\pums\" ThisPumProcessName "\link"
      if !FileExist(PumLinkPath)
      {
        FileCreateDir, %PumLinkPath%
        Sleep, 100
      }
      ; -------------------------------------------
      Link_OutTarget := PumLinkPath "\pumlink_" Run_LinkName ".lnk"
      FileCreateShortcut, %Run_OutTarget%, %Link_OutTarget%, , , , %Run_LinkIcon%
      ; -------------------------------------------
      Run_OutTarget := Link_OutTarget
      ; -------------------------------------------
      DataArray.305.11 := Run_OutTarget    ; (305_11)(Run_OutTarget [PathExtName])
      ; -------------------------------------------
      ; Create Shortcut to Selected File in User pum Folder
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; -------------------------------------------
      ; AppProcessExt == "lnk"
      ; -------------------------------------------
      DataArray.366.5 := "run" ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      ; -------------------------------------------
      DataArray := Image_GuiControl("248", 0, 0, DataArray) ; (248_1)(Obj_Ofl_1LAppIco)
      DataArray := Image_GuiControl("249", 0, 0, DataArray) ; (249_1)(Obj_Ofl_2LAppIco)
      DataArray := Image_GuiControl("250", 0, 0, DataArray) ; (250_1)(Obj_Ofl_3LAppIco)
      DataArray := Image_GuiControl("252", 0, 0, DataArray) ; (252_1)(Obj_Ofl_LFolderImage)
      DataArray := Image_GuiControl("251", 0, 0, DataArray) ; (251_1)(Obj_Ofl_DisplayText_LNumberOfIcons)
      ; -------------------------------------------
    } ; [End] if (Run_UseLink == 1)
    else if (Run_UseLink == 0)
    {
      ; -------------------------------------------
      if (AppProcessExt == "bat" or AppProcessExt == "com" or AppProcessExt == "cmd" or AppProcessExt == "exe")
      {
        ; -------------------------------------------
        DataArray.366.5 := "run" ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        ; -------------------------------------------
        DataArray := Image_GuiControl("248", 0, 0, DataArray) ; (248_1)(Obj_Ofl_1LAppIco)
        DataArray := Image_GuiControl("249", 0, 0, DataArray) ; (249_1)(Obj_Ofl_2LAppIco)
        DataArray := Image_GuiControl("250", 0, 0, DataArray) ; (250_1)(Obj_Ofl_3LAppIco)
        DataArray := Image_GuiControl("252", 0, 0, DataArray) ; (252_1)(Obj_Ofl_LFolderImage)
        DataArray := Image_GuiControl("251", 0, 0, DataArray) ; (251_1)(Obj_Ofl_DisplayText_LNumberOfIcons)
        ; -------------------------------------------
      } ; [End] is a Executable
      else ; Not a Executable
      {
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (rwh)
        ; Script_Line_2 := 1/2                        (073_2)(Obj_Run_AsAdmin_Sel [0,1,2])
        ; Script_Line_3 := "x:\File.ext"              (305_4)(run_FilePathNameExt [Selected File] [Path,Name,Ext])
        ; Script_Line_4 := "x:\Executable.ext"        (305_5)(Rwh_OpeningApp [Full File Path])
        ; Script_Line_5 := ""                         *** EMPTY ***
        ; Script_Line_6 := ""                         *** EMPTY ***
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (rwh)
        ;
        ; -------------------------------------------
        DataArray.366.5 := "rwh" ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
        ; -------------------------------------------
        DataArray.305.5 := Default_Application(AppProcessExt) ; (305_5)(Rwh_OpeningApp [Full File Path])
        ; -------------------------------------------
        DataArray.305.4 := Run_OutTarget ; (305_4)(Run_FilePathNameExt [Selected File] [Path,Name,Ext])
        ; -------------------------------------------
      } ; [End] else ; Not a Executable
      ; -------------------------------------------
    } ; [End] else if (Run_UseLink == 0)
    ; -------------------------------------------
    DataArray := _S1_C(DataArray)
    DataArray := _S2_H(DataArray)
    DataArray := _S3_S(DataArray)
    ; -------------------------------------------
  } ; [End] if FileExist(Run_OutTarget)
  else ; (Run_OutTarget) DOES NOT Exist
  {
    ; -------------------------------------------
    ; Return Previous Script Type Object Values
    ; -------------------------------------------
    ScriptType := DataArray.366.5 ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
    ; -------------------------------------------
    if (ScriptType == "run" or ScriptType == "rwh")
    {
      DataArray := Image_GuiControl("081", 2, 1, DataArray) ; (081_1)(Obj_RunRwh_File)
    }
    else
    {
      DataArray := Image_GuiControl("081", 1, 1, DataArray) ; (081_1)(Obj_RunRwh_File)
    }
    ; -------------------------------------------
    if (ScriptType == "url")
    {
      DataArray := Image_GuiControl("071", 2, 1, DataArray) ; (071_1)(Obj_URL)
    } ; [End] if (ScriptType == "url")
    else
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; A Browser is Active
      if (IsInternetBrowser(DataArray.367.1, DataArray.367.3, DataArray.367.4) == 1) ; All Supported Internet Browsers
      {
        ; -------------------------------------------
        DataArray := Image_GuiControl("071", 1, 1, DataArray) ; (071_1)(Obj_URL)
        ; -------------------------------------------
      }
      else ; NO Borwser is Active
      {
        ; -------------------------------------------
        DataArray := Image_GuiControl("071", 3, 1, DataArray) ; (071_1)(Obj_URL)
        ; -------------------------------------------
      }
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    }
    ; -------------------------------------------
    if (ScriptType == "ofl")
    {
      DataArray := Image_GuiControl("082", 2, 1, DataArray) ; (082_1)(Obj_Ofl_Folder)
    } ; [End] if (ScriptType == "ofl")
    else
    {
      DataArray := Image_GuiControl("082", 1, 1, DataArray) ; (082_1)(Obj_Ofl_Folder)
    }
    ; -------------------------------------------
  } ; End (Selected_File == "")
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
