﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Image_Combine(Image_Array) ; Image_Array := [Out_W, Out_H, Image_Out, (Image, Image_X, Image_Y,) etc]
{
  ; -------------------------------------------
  if IsObject(Image_Array)
  {
    ; -------------------------------------------
    SymPlus := "{+}"
    ; -------------------------------------------
    Out_W     := Image_Array.1  ; Out_W   = Image_Out Width
    Out_H     := Image_Array.2  ; Out_H   = Image_Out Height
    Image_Out := Image_Array.3 ; Return Image_Out
    ;
    Image_0 := Image_Array.4
    Image_X := Image_Array.5
    Image_Y := Image_Array.6
    ; -------------------------------------------
    Support_magick := A_ProgramFiles "\PopUpMenu_PUM\support\magick\magick.exe"
    RunThis := Support_magick " convert -page " Out_W "x" Out_H "+"
    ImgString := Image_X "+" Image_Y " """ Image_0 """"
    ;
    NumCnt := 7
    ; -------------------------------------------
    for NumImg, This_Var in Image_Array
    {
      ; -------------------------------------------
      if (NumImg == NumCnt)
      {
        ; -------------------------------------------
        Img_0  := Image_Array[NumCnt] ; (0  _1)(Empty)
        NumCnt := NumCnt + 1
        Img_X  := Round(Image_Array[NumCnt])
        NumCnt := NumCnt + 1
        Img_Y  := Round(Image_Array[NumCnt])
        NumCnt := NumCnt + 1
        ; -------------------------------------------
        ImgString := ImgString " -page +" Img_X "+" Img_Y " """ Img_0 """"
        ; -------------------------------------------
      } ; End (NumImg == NumCnt)
      ; -------------------------------------------
    } ; End for NumImg, This_Var in Image_Array
    ; -------------------------------------------
    ImgString := ImgString ""
    ; -------------------------------------------
    ;
    RunThis := RunThis ImgString " -background none -layers flatten """ Image_Out """"
    ;
    ;
    Run, %A_ProgramFiles%\PopUpMenu_PUM\PriorityProcess_ImageMagic.ahk
    RunWait, %RunThis%, , Hide
    ; -------------------------------------------
  } ; End if IsObject(Image_Array)
  ; -------------------------------------------
} ; End Image_page_2(Image_Array)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; END OF FILE
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
