﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
#NoTrayIcon
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\Array_FromFile.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
IconLinkFile := "C:\Users\CaveMan\AppData\Roaming\PopUpMenu_PUM\url_cache\IconLinkFile.txt"
; -------------------------------------------
if FileExist(IconLinkFile)
{
	; -------------------------------------------
  FileReadLine, IconLink, %SourceLinkFile%, 1
  ; -------------------------------------------
	if (StrLen(IconLink) > 0)
	{
		; -------------------------------------------
	  IconFile := A_AppData "\PopUpMenu_PUM\url_cache\Url_Icon.ico"
    ; -------------------------------------------
	  static a := "AutoHotkey/" A_AhkVersion
    ; -------------------------------------------
	  if (!(o := FileOpen(IconFile, "w")) || !DllCall("LoadLibrary", "str", "wininet") || !(h := DllCall("wininet\InternetOpen", "str", a, "uint", 1, "ptr", 0, "ptr", 0, "uint", 0, "ptr")))
    {
			FileDelete, %IconFile%
  		return 0
    }
  	; -------------------------------------------
  	c := s := 0
    ; -------------------------------------------
  	if (f := DllCall("wininet\InternetOpenUrl", "ptr", h, "str", IconLink, "ptr", 0, "uint", 0, "uint", 0x80003000, "ptr", 0, "ptr"))
  	{
      ; -------------------------------------------
		  while (DllCall("wininet\InternetQueryDataAvailable", "ptr", f, "uint*", s, "uint", 0, "ptr", 0) && s>0)
		  {
  			; -------------------------------------------
			  VarSetCapacity(b, s, 0)
			  DllCall("wininet\InternetReadFile", "ptr", f, "ptr", &b, "uint", s, "uint*", r)
			  c += r
			  o.rawWrite(b, r)
        ; -------------------------------------------
		  }
		  ; -------------------------------------------
		  DllCall("wininet\InternetCloseHandle", "ptr", f)
		  ; -------------------------------------------
	  }
	  ; -------------------------------------------
	  DllCall("wininet\InternetCloseHandle", "ptr", h)
	  o.close()
	  ; -------------------------------------------
	  ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; Check if is Empty (Access Restricted)
    ; -------------------------------------------
	  CheckArray := Array_FromFile(IconFile)
	  ; -------------------------------------------
	  CheckArray_Len := CheckArray.MaxIndex() ; Highest Length
	  ; -------------------------------------------
	  if (CheckArray_Len == 0 or CheckArray_Len == "") ; is a Empty File
	  {
  		FileDelete, %IconFile%
  	}
    ; -------------------------------------------
    ; Check if is Empty (Access Restricted)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	} ; [End] if (StrLen(IconLink) > 0)
	; -------------------------------------------
} ; [End] if FileExist(IconLinkFile)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
