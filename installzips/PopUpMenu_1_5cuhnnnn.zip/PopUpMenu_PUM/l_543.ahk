﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\Gui_ObjectSize.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
l_543: ; (543_1)(_Msg 8_)(_w300 x h300_)_Sanding_Man)
{
  ; -------------------------------------------
  ; Sanding_Man
  ; -------------------------------------------
  ;
  ; (_w300 x h300_)
  ; This Animation will Repeat
  ; Resets to Frame 1
  ; 
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Start/Show (Sanding_Man)
  ; global n_543 := 0 ; Start Frame Number
  ; global s_543 := 1 ; Show
  ; (543_1)(_Msg 8_)(_w300 x h300_)_Sanding_Man)
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Start/Show (Sanding_Man)
  ;
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Stop/Hide (Sanding_Man)
  ; global s_543 := 0 ; Hide
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Stop/Hide (Sanding_Man)
  ;
  ;
  ; [ANIMATE] Start/Show in This File
  ; Pum_DisplayImageImg.ahk
  ; Pum_DisplayImageTxt.ahk
  ; (165_1)(Obj_Pum_BgImageSelect)
  ; (167_1)(Obj_Pum_BgFitImage)
  ;
  ; -------------------------------------------
  if (ShowAnimationChange == "")
  {
    global ShowAnimationChange := 0
  }
  ; -------------------------------------------
  Total_Images := 9
  ; -------------------------------------------
  if (s_543 == 1) ; [START] [ANMIMATE]
  {
    ; -------------------------------------------
    if (n_543 > Total_Images) ; 1 Less than Number of Images
    {
      global n_543 := 1
    }
    ; -------------------------------------------
    GuiControl, PopUpMenu:, g_254, %A_ProgramFiles%\PopUpMenu_PUM\image\gui\(543)_%n_543%.png ; (254_1)(Obj_MsgImg300x300)
    ; -------------------------------------------
    Gui_ObjectSize("254", DataArray) ; > Nothing
    ; -------------------------------------------
    if (ShowAnimationChange == 0)
    {
      GuiControl, PopUpMenu:Show, g_254 ; (254_1)(Obj_MsgImg300x300)
      global ShowAnimationChange := 1
    }
    ; -------------------------------------------
    global n_543 := n_543 + 1
    ; -------------------------------------------
  } ; [End] [START] [ANMIMATE]
  else ; [STOP] [ANMIMATE]
  {
    ; -------------------------------------------
    global ShowAnimationChange := 0
    ; -------------------------------------------
    SetTimer, l_543, Off ; (543_1)(_Msg 8_)(_w300 x h300_)_Sanding_Man)
    ; -------------------------------------------
  } ; [End] [STOP] [ANMIMATE]
  ; -------------------------------------------
} ; End (543_1)(_Msg 8_)(_w300 x h300_)_Sanding_Man)
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
