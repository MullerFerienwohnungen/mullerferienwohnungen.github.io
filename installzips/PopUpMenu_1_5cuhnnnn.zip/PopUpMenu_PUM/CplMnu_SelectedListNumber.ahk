﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
CplMnu_SelectedListNumber(GuiList, DataArray) ; > DataArray
{
  ; -------------------------------------------
  ScriptType := DataArray.366.5 ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
  ; -------------------------------------------
  if (ScriptType == "cpl") ; (366_5)(Script Type)
  {
    ; -------------------------------------------
    ; (300_2)([cpl] Menu Number #_X_X_[X])
    Item_2 := DataArray.300.3 ; (300_3)(Cpl_Number_0x00 [X_#_X_X])
    Item_3 := DataArray.300.4 ; (300_4)(Cpl_Number_00x0 [X_X_#_X])
    ; (300_5)([cpl] Menu Number X_X_X_[#])
    ; -------------------------------------------
  } ; [End] (Script Type) "cpl"
  else if (ScriptType == "mnu")
  {
    ; -------------------------------------------
    ; (302_2)([mnu] Menu Number #_X_X_[X])
    Item_2 := DataArray.302.3 ; (302_3)(Mnu_Number_0x00 [X_#_X_X])
    Item_3 := DataArray.302.4 ; (302_4)(Mnu_Number_00x0 [X_X_#_X])
    ; -------------------------------------------
    ; (302_5)([mnu] Menu Number X_X_X_[#])
  } ; [End] (Script Type) "mnu"
  ; -------------------------------------------
  GuiControlGet, Text_Selected, PopUpMenu:, %GuiList% ; [SET] Item_Selected (String)
  ; -------------------------------------------
  if (InStr(Text_Selected, "-----------") == 0)
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    DataArray.366.4 := 0 ; (366_4)(cplmnu_IsDivider [Selected List Item is a Divider] [0/1])
    ; ListVarNum = The DataArray.### of Currently Displayed List 
    ListVarNum := SubStr(GuiList, 3)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [SET] Num_Selected
    ; -------------------------------------------
    Displayed_List := DataArray[ListVarNum][3]
    Array_List := StrSplit(Displayed_List, "|", "|")
    Num := 0
    ; -------------------------------------------
    for Index, ThisItem in Array_List
    {
      ; -------------------------------------------
      if (ThisItem == Text_Selected)
      {
        LastCherector := SubStr(ThisItem , StrLen(ThisItem))
        if (LastCherector == ">")
        {
          IsSub := 1
          Num_Selected := Num
        } ; [End] if (LastCherector == ">")
        ; -------------------------------------------
        else if (LastCherector != ">")
        {
          IsSub := 0
          Num_Selected := Num
          break
        } ; [End] else if (LastCherector != ">")
        ; -------------------------------------------
      } ; End (ThisItem == Item_Selected)
      ; -------------------------------------------
      Num := Num + 1
      ; -------------------------------------------
    } ; End for Index, ThisItem in ThisListBox
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (GuiList == "g_116") ; (116_1)(Obj_CplMnu_List100)
    {
      ; -------------------------------------------
      if (IsSub == 1)
      {
        Item_2 := Num_Selected ; (302_3)([mnu] Menu Number X_#_X_[X])
        Item_3 := 0 ; (302_4)([mnu] Menu Number X_X_#_[X])
        Item_Selected := 0 ; (302_5)([mnu] Menu Number X_X_X_[#])
      } ; End (IsSub == 1)
      ; -------------------------------------------
      else if (IsSub == 0)
      {
        Item_2 := 0 ; (302_3)([mnu] Menu Number X_#_X_[X])
        Item_3 := 0 ; (302_4)([mnu] Menu Number X_X_#_[X])
        Item_Selected := Num_Selected ; (302_5)([mnu] Menu Number X_X_X_[#])
      } ; End (IsSub == 0)
      ; -------------------------------------------
    } ; (116)_(mnu)(cpl)(List Full Across)_(2)Select_(3)ListBox
    ; -------------------------------------------
    else if (GuiList == "g_117") ; (117_1)(Obj_CplMnu_ListRight60)
    {
      ; -------------------------------------------
      if (IsSub == 1)
      {
        Item_3 := Num_Selected ; (302_4)([mnu] Menu Number X_X_#_[X])
        Item_Selected := 0 ; (302_5)([mnu] Menu Number X_X_X_[#])
      } ; End (IsSub == 1)
      ; -------------------------------------------
      else if (IsSub == 0)
      {
        Item_3 := 0 ; (302_4)([mnu] Menu Number X_X_#_[X])
        Item_Selected := Num_Selected ; (302_5)([mnu] Menu Number X_X_X_[#])
      } ; End (IsSub == 0)
      ; -------------------------------------------
    } ; (117)_(mnu)(cpl)(List Right 2/3)_(2)Select_(3)ListBox
    ; -------------------------------------------
    else if (GuiList == "g_118") ; (118_1)(Obj_CplMnu_ListLeft30)
    {
      ; -------------------------------------------
      if (IsSub == 1)
      {
        Item_2 := Num_Selected ; (302_3)([mnu] Menu Number X_#_X_[X])
        Item_3 := 0 ; (302_4)([mnu] Menu Number X_X_#_[X])
        Item_Selected := 0 ; (302_5)([mnu] Menu Number X_X_X_[#])
      } ; End (IsSub == 1)
      ; -------------------------------------------
      else if (IsSub == 0)
      {
        Item_2 := 0 ; (302_3)([mnu] Menu Number X_#_X_[X])
        Item_3 := 0 ; (302_4)([mnu] Menu Number X_X_#_[X])
        Item_Selected := Num_Selected ; (302_5)([mnu] Menu Number X_X_X_[#])
        ; -------------------------------------------
      } ; End (IsSub == 0)
      ; -------------------------------------------
    } ; (118)_(mnu)(cpl)(List Left 1/3)_(2)Select_(3)ListBox
    ; -------------------------------------------
    else if (GuiList == "g_120") ; (120_1)(Obj_CplMnu_ListCenter30)
    {
      ; -------------------------------------------
      if (IsSub == 1)
      {
        Item_3 := Num_Selected ; (302_4)([mnu] Menu Number X_X_#_[X])
        Item_Selected := 0 ; (302_5)([mnu] Menu Number X_X_X_[#])
      } ; End (IsSub == 1)
      ; -------------------------------------------
      else if (IsSub == 0)
      {
        Item_3 := 0 ; (302_4)([mnu] Menu Number X_X_#_[X])
        Item_Selected := Num_Selected ; (302_5)([mnu] Menu Number X_X_X_[#])
      } ; End (IsSub == 0)
      ; -------------------------------------------
    } ; (120)_(mnu)(cpl)(List Center 1/3)_(2)Select_(3)ListBox
    ; -------------------------------------------
    else if (GuiList == "g_121") ; (121_1)(Obj_CplMnu_ListRight30)
    {
      ; -------------------------------------------
      Item_Selected := Num_Selected ; (302_5)([mnu] Menu Number X_X_X_[#])
      ; -------------------------------------------
    } ; (121)_(mnu)(cpl)(List Right 1/3)_(2)Select_(3)ListBox
    ; -------------------------------------------
    if (ScriptType == "cpl") ; (366_5)(Script Type)
    {
      ; -------------------------------------------
      DataArray.300.3 := Item_2 ; (300_3)(Cpl_Number_0x00 [X_#_X_X])
      DataArray.300.4 := Item_3 ; (300_4)(Cpl_Number_00x0 [X_X_#_X])
      DataArray.300.5 := Item_Selected ; (300_5)(Cpl_Number_000x [X_X_X_#])
      ; -------------------------------------------
    } ; [End] (Script Type) "cpl"
    ; -------------------------------------------
    else if (ScriptType == "mnu")
    {
      ; -------------------------------------------
      DataArray.302.3 := Item_2 ; (302_3)(Mnu_Number_0x00 [X_#_X_X])
      DataArray.302.4 := Item_3 ; (302_4)(Mnu_Number_00x0 [X_X_#_X])
      DataArray.302.5 := Item_Selected ; (302_5)(Mnu_Number_000x [X_X_X_#])
      ; -------------------------------------------
    } ; [End] (Script Type) "mnu"
    ; -------------------------------------------
  } ; End (InStr(Item_Selected, "--------") == 0)
  else ; Is a Divider
  {
    ; -------------------------------------------
    DataArray.366.4 := 1 ; (366_4)(cplmnu_IsDivider [Selected List Item is a Divider] [0/1])
    ; -------------------------------------------
  } ; [End] else ; Is a Divider
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
} ; [End] CplMnu_SelectedListNumber(GuiList, DataArray) ; > DataArray
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
