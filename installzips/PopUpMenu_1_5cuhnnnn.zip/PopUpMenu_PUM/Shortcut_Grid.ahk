﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\Array_Add.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Shortcut_Grid(PumXmlArray) ; PumXmlArray > Array_ExistingShortcuts [C##R##, C##R##, C##R##]
{
  ; -------------------------------------------
  ; Array of Existing Shortcuts
  ; [C##R##, C##R##]
  ; -------------------------------------------
  for Index, This_Line in PumXmlArray
  {
    ; -------------------------------------------
    if (InStr(This_Line, "<shortcut ") > 0)
    {
      ; -------------------------------------------
      Pos_Y1 := InStr(This_Line, """",,, 1)
      Pos_Y1 := Pos_Y1 + 1
      Pos_Y2 := InStr(This_Line, """",,, 2)
      Pos_YL := Pos_Y2 - Pos_Y1
      Pos_X1 := InStr(This_Line, """",,, 3)
      Pos_X1 := Pos_X1 + 1
      Pos_X2 := InStr(This_Line, """",,, 4)
      Pos_XL := Pos_X2 - Pos_X1
      ; -------------------------------------------
      This_R := SubStr(This_Line, Pos_Y1, Pos_YL)
      This_C := SubStr(This_Line, Pos_X1, Pos_XL)
      if (This_C < 10)
      {
        This_C := "0" This_C
      }
      if (This_R < 10)
      {
        This_R := "0" This_R
      }
      Grid_Num := "C" This_C "R" This_R
      Array_ExistingShortcuts := Array_Add(Array_ExistingShortcuts, Grid_Num, "End") ; ThisArray, AddThis, ThisPos > ThisArray
      ; -------------------------------------------
    } ; End (InStr(This_Line, "<shortcut ") > 0)
  } ; End for Index, This_Line in PumXmlArray
  ; -------------------------------------------
  if IsObject(Array_ExistingShortcuts)
  {
    return Array_ExistingShortcuts
  }
  else
  {
    return ""
  }
  ; -------------------------------------------
} ; End Shortcut_Grid(DataArray) ; > DataArray
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
