﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\Folder_WindowsUser.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Select_FileFolder.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\f_102.ahk ; (102_1)(Obj_DisplayedIcon)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
f_106(DataArray) ; (106_1)(Obj_KeyOfl_DisplayText_RNumberOfIcons)
{
  ; -------------------------------------------
  UserPictureFolder := DataArray.363.12 ; (363_12)(ThisUserPictureFolder)
  ; -------------------------------------------
  if (DataArray.366.5 == "key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
  {
    ; -------------------------------------------
    ArrayIn := [DataArray.367.5, DataArray.367.1, DataArray.290.2, "FolderKey", DataArray.365.2, DataArray.363.12]
    ; -------------------------------------------
  } ; [End] (ScriptType [key])
  else if (DataArray.366.5 == "ofl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
  {
    ; -------------------------------------------
    ArrayIn := [DataArray.367.5, DataArray.367.1, DataArray.290.2, "FolderOflIco", DataArray.365.2, DataArray.363.12]
    ; -------------------------------------------
  } ; [End] (ScriptType [ofl])
  ; -------------------------------------------
  else if (DataArray.366.5 == "run") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
  {
    ; -------------------------------------------
    ArrayIn := [DataArray.367.5, DataArray.367.1, DataArray.290.2, "FolderRunIco", DataArray.365.2, DataArray.363.12]
    ; -------------------------------------------
  } ; [End] (ScriptType [ofl])
  ; -------------------------------------------
  else if (DataArray.366.5 == "rwh") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
  {
    ; -------------------------------------------
    ArrayIn := [DataArray.367.5, DataArray.367.1, DataArray.290.2, "FolderRwhIco", DataArray.365.2, DataArray.363.12]
    ; -------------------------------------------
  } ; [End] (ScriptType [ofl])
  ; -------------------------------------------
  if (DataArray.366.5 == "key" or DataArray.366.5 == "ofl" or DataArray.366.5 == "run" or DataArray.366.5 == "rwh") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
  {
    ; -------------------------------------------
    ArrayOut := Image_PathFolderOrName(ArrayIn)
    ; [Out_FileOrFolder, Out_ProcessName, Out_ProcessExt, Out_ProcessFolder, UserPictureFolder]
    StartFolder := ArrayOut.1
    ; -------------------------------------------
    ; SelectFileFolderType(Lang, ["Folder"or"AnyFile"or"AnyImage"or"Application"or"Browser"], StartFolder, ThisPumPath)
    Selected_Array := Select_FileFolder(DataArray.365.2, "AnyImage", StartFolder, DataArray.361.8)
    ; -------------------------------------------
    ; [OutTarget, Arguments, UseLink (0,1), Selected_File, SelectedItems_LinkIcon]
    ThisIconFile := Selected_Array.1
    ; -------------------------------------------
  }
  ; -------------------------------------------
  if FileExist(ThisIconFile)
  {
    DataArray := f_102(ThisIconFile, DataArray) ; (102_1)(Obj_DisplayedIcon)
  }
  ; -------------------------------------------
  Send, {Home}
  GuiControl, Focus, g_102 ; (102_1)(Obj_DisplayedIcon)
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
