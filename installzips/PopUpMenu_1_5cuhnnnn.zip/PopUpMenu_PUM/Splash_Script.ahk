﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\Script_Close.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Dark Purple 
; Winset, TransColor, 573694
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Splash_Script(Img_Num, Sleep_Time) ; Img_Num ("Off"/Number), Sleep_Time > Nothing
{
  ; -------------------------------------------
  if (Sleep_Time == "")
  {
    Sleep_Time := 0
  }
  ; -------------------------------------------
  if (Img_Num == "Off")
  {
    ; -------------------------------------------
    ; Closes Any Splash Image
    ; Does Not Need DataArray
    ; -------------------------------------------
    if (Sleep_Time > 0)
    {
      Sleep, %Sleep_Time%
    }
    ; -------------------------------------------
    SplashImage, Off
    ; -------------------------------------------
    Splash_Script_Path := A_ProgramFiles "\PopUpMenu_PUM\Splash_5*.ahk"
    Loop, Files, %Splash_Script_Path%, R  ; Recurse into subfolders.
    {
      Splash_Script := A_LoopFileFullPath
      Script_Close(Splash_Script)
    } ; End Loop, Files, %iconcache_Path%, R
    ; -------------------------------------------
  } ; End (Img_Num == "Off")
  else ; run Splash
  {
    ; -------------------------------------------
    if (SubStr(Img_Num, 1, 1) == "4") ; Error Splash
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; User Language [GET] (UserLang)
      ; -------------------------------------------
      File_UserLang := A_AppData "\PopUpMenu_PUM\system\File_UserLang.txt"
      ; -------------------------------------------
      if FileExist(File_UserLang)
      {
        FileReadLINE, UserLang, %File_UserLang%, 1
      }
      if (UserLang == "")
      {
        ; -------------------------------------------
        if FileExist(File_UserLang)
        {
          FileDelete, %File_UserLang%
          Sleep, 100
        } ; [End] if FileExist(File_UserLang)
        ; -------------------------------------------
        if (A_Language == "0407" or A_Language == "0807" or A_Language == "0c07" or A_Language == "1007" or A_Language == "1407")
        {
          ; -------------------------------------------
          UserLang := "de"
          ; -------------------------------------------
        } ; [End] German (de)
        ; -------------------------------------------
        else if (A_Language == "0409" or A_Language == "0809" or A_Language == "0c09" or A_Language == "1009" or A_Language == "1409" or A_Language == "1809" or A_Language == "1c09" or A_Language == "2009" or A_Language == "2409" or A_Language == "2809" or A_Language == "2c09" or A_Language == "3009" or A_Language == "3409")
        {
          ; -------------------------------------------
          UserLang := "en"
          ; -------------------------------------------
        } ; [End] English (en)
        ; -------------------------------------------
        else if (A_Language == "040a" or A_Language == "080a" or A_Language == "0c0a" or A_Language == "100a" or A_Language == "140a" or A_Language == "180a" or A_Language == "1c0a" or A_Language == "200a" or A_Language == "240a" or A_Language == "280a" or A_Language == "2c0a" or A_Language == "300a" or A_Language == "340a" or A_Language == "380a" or A_Language == "3c0a" or A_Language == "400a" or A_Language == "440a" or A_Language == "480a" or A_Language == "4c0a" or A_Language == "500a")
        {
          ; -------------------------------------------
          UserLang := "es"
          ; -------------------------------------------
        } ; [End] Spanish (es)
        ; -------------------------------------------
        else if (A_Language == "040c" or A_Language == "080c" or A_Language == "0c0c" or A_Language == "100c" or A_Language == "140c" or A_Language == "180c")
        {
          ; -------------------------------------------
          UserLang := "fr"
          ; -------------------------------------------
        } ; [End] French (fr)
        ; -------------------------------------------
        else if (A_Language == "0410" or A_Language == "0810")
        {
          ; -------------------------------------------
          UserLang := "it"
          ; -------------------------------------------
        } ; [End] Italian (it)
        ; -------------------------------------------
        else if (A_Language == "0415")
        {
          ; -------------------------------------------
          UserLang := "pl"
          ; -------------------------------------------
        } ; [End] Polish (pl)
        ; -------------------------------------------
        else if (A_Language == "0416" or A_Language == "0816")
        {
          ; -------------------------------------------
          UserLang := "pt"
          ; -------------------------------------------
        } ; [End] Portuguese (pt)
        ; -------------------------------------------
        else if (A_Language == "0419")
        {
          ; -------------------------------------------
          UserLang := "ru"
          ; -------------------------------------------
        } ; [End] Russian (ru)
        ; -------------------------------------------
        else if (A_Language == "041d" or A_Language == "081d")
        {
          ; -------------------------------------------
          UserLang := "sv"
          ; -------------------------------------------
        } ; [End] Swedish (sv)
        ; -------------------------------------------
        else if (A_Language == "041f")
        {
          ; -------------------------------------------
          UserLang := "tr"
          ; -------------------------------------------
        } ; [End] Turkish (tr)
        ; -------------------------------------------
        else ; English (en)
        {
          ; -------------------------------------------
          UserLang := "en"
          ; -------------------------------------------
        } ; [End] else ; English (en)
        ; -------------------------------------------
        FileEncoding, UTF-8 ; UTF-8
        FileAppend, %UserLang%`n, %File_UserLang% ; UTF-8
        ; -------------------------------------------
      } ; [End] if (UserLang == "")
      ; -------------------------------------------
      ; User Language [GET] (UserLang)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; -------------------------------------------
      File_SplashActive := A_AppData "\PopUpMenu_PUM\system\File_SplashActive.txt"
      FileAppend, 1, %File_SplashActive%, UTF-8
      ; -------------------------------------------
      ;
      ; -------------------------------------------
      SetTitleMatchMode, 1
      WinGet, FileSelectGui_Id, ID , PUM -  ahk_class #32770
      WinSet, AlwaysOnTop, Off, ahk_id %FileSelectGui_Id%
      ; -------------------------------------------
      ;
      ; -------------------------------------------
      Splash_Image := A_ProgramFiles "\PopUpMenu_PUM\image\gui\(" Img_Num ")_" UserLang ".png" ; (365_2)(Current User language)
      SplashImage, %Splash_Image%, b
      Sleep, %Sleep_Time%
      SplashImage, Off
      ; -------------------------------------------
      ;
      ; -------------------------------------------
      WinSet, AlwaysOnTop, On, ahk_id %FileSelectGui_Id%
      ; -------------------------------------------
      ;
      ; -------------------------------------------
      FileDelete, %File_SplashActive%
      ; -------------------------------------------
    } ; End (SubStr(Img_Num, 1, 1) == "4") ; Error Splash
    else ; Informational Message
    {
      ; -------------------------------------------
      Splash_Script := A_ProgramFiles "\PopUpMenu_PUM\Splash_" Img_Num ".ahk"
      ; -------------------------------------------
      Run, %Splash_Script%
      ; -------------------------------------------
      ;
      ; -------------------------------------------
      if (Sleep_Time > 0)
      {
        ; -------------------------------------------
        Sleep, %Sleep_Time%
        ; -------------------------------------------
        Script_Close(Splash_Script)
        ; -------------------------------------------
        Splash_Script_Path := A_ProgramFiles "\PopUpMenu_PUM\Splash_5*.ahk"
        Loop, Files, %Splash_Script_Path%, R  ; Recurse into subfolders.
        {
          Splash_Script := A_LoopFileFullPath
          Script_Close(Splash_Script)
        } ; End Loop, Files, %iconcache_Path%, R
        ; -------------------------------------------
      } ; End (Sleep_Time > 0)
    } ; End Informational Message
  } ; End run Splash
} ; End Splash_Script(Img_Num, Sleep_Time)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
