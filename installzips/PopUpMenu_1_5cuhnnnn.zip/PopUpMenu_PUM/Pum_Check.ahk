﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_GuiControl.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Pum_Check(DataArray) ; > DataArray
{
  ; -------------------------------------------
  ; Change Image (Enable 1 / Disable 3)
  ; (261)(IconSize_Up)
  ; (262)(IconSize_Dn)
  ; (267)(PumRow_Up)
  ; (268)(PumRow_Dn)
  ; (273)(PumColumn_Up)
  ; (274)(PumColumn_Dn)
  ;
  ; Update 
  ; (266)(PumRow_Edit)
  ; (272)(PumColumn_Edit)
  ; -------------------------------------------
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  v_261 := 1 ; (261_1)(Obj_Pum_IconUp)
  v_262 := 1 ; (262_1)(Obj_Pum_IconDown)
  v_267 := 1 ; (267_1)(Obj_Pum_PumRowUp)
  v_268 := 1 ; (268_1)(Obj_Pum_PumRowDown)
  v_273 := 1 ; (273_1)(Obj_Pum_PumColumnUp)
  v_274 := 1 ; (274_1)(Obj_Pum_PumColumnDown)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  XmlIconSize := DataArray.362.14 ; (362_14)(XmlIconSize [Displaymode iconsize] [32,48,64])
  XmlColumnsX := DataArray.362.4 ; (362_4)(XmlColumnsX [Pum (X) Columns])
  XmlRowsY    := DataArray.362.3 ; (362_3)(XmlRowsY [Pum (Y) Rows])
  Array_ShortcutGrid := DataArray.362.58 ; (362_58)(Array_ShortcutGrid [C##R##, C##R##, C##R##] of Existing Shortcuts)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  SysGet, Scr_, MonitorWorkArea
  Scr_W := Scr_Right - Scr_Left
  Scr_H := Scr_Bottom - Scr_Top
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  Pum_W := XmlColumnsX * XmlIconSize
  Pum_H := XmlRowsY * XmlIconSize
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (Pum_W >= Scr_W or Pum_H >= Scr_H or XmlIconSize == 64) ; (261)(IconSize_Up)
  {
    v_261 := 3 ; (261_1)(Obj_Pum_IconUp)
  }
  if (XmlIconSize == 32) ; (262)(IconSize_Dn)
  {
    v_262 := 3 ; (262_1)(Obj_Pum_IconDown)
  }
  ; -------------------------------------------
  Icon_Image := A_ProgramFiles "\PopUpMenu_PUM\image\gui\(260)_" XmlIconSize ".png"
  GuiControl, PopUpMenu:, g_260, %Icon_Image% ; (260_1)(Obj_Pum_IconSize)
  GuiControl, PopUpMenu:Show, g_260 ; (260_1)(Obj_Pum_IconSize)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (Pum_W >= Scr_W) ; (X_273)(PumColumn_Up)
  {
    v_273 := 3 ; (273_1)(Obj_Pum_PumColumnUp)
  }
  ; -------------------------------------------
  else if (XmlColumnsX == 32) ; (X_273)(PumColumn_Up)
  {
    v_273 := 3 ; (273_1)(Obj_Pum_PumColumnUp)
  }
  else ; (X_273)(PumColumn_Up)
  {
    ; -------------------------------------------
    Test_C := XmlColumnsX + 2
    ; -------------------------------------------
    Test_W := Test_C * XmlIconSize
    if (Test_W >= Scr_W) ; (Y_267)(PumRow_Up)
    {
      v_273 := 3 ; (273_1)(Obj_Pum_PumColumnUp)
    }
    ; -------------------------------------------
  }
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (Pum_H >= Scr_H) ; (Y_267)(PumRow_Up)
  {
    v_267 := 3 ; (267_1)(Obj_Pum_PumRowUp)
  }
  ; -------------------------------------------
  else if (XmlRowsY == 32) ; (Y_267)(PumRow_Up)
  {
    v_267 := 3 ; (267_1)(Obj_Pum_PumRowUp)
  }
  else ; (Y_267)(PumRow_Up)
  {
    ; -------------------------------------------
    Test_R := XmlRowsY + 2
    ; -------------------------------------------
    Test_H := Test_R * XmlIconSize
    if (Test_H >= Scr_H) ; (Y_267)(PumRow_Up)
    {
      v_267 := 3 ; (267_1)(Obj_Pum_PumRowUp)
    }
    ; -------------------------------------------
  }
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  Max_C := 0
  Max_R := 0
  ; -------------------------------------------
  for Index, This_Grid in Array_ShortcutGrid
  {
    ; -------------------------------------------
    ; C##R##
    ; 123456
    ; -------------------------------------------
    This_C := SubStr(This_Grid, 2, 2)
    if (SubStr(This_C, 1, 1) == 0)
    {
      This_C := SubStr(This_C, 2, 1)
    }
    ; -------------------------------------------
    This_R := SubStr(This_Grid, 5, 2)
    if (SubStr(This_R, 1, 1) == 0)
    {
      This_R := SubStr(This_R, 2, 1)
    }
    ; -------------------------------------------
    if (This_C > Max_C)
    {
      Max_C := This_C
    }
    if (This_R > Max_R)
    {
      Max_R := This_R
    }
    ; -------------------------------------------
  } ; End for Index, This_Grid in Array_ShortcutGrid
  ; -------------------------------------------
  if (XmlColumnsX == Max_C) ; (X_274)(PumColumn_Dn)
  {
    v_274 := 3 ; (274_1)(Obj_Pum_PumColumnDown)
  }
  ; -------------------------------------------
  if (XmlRowsY == Max_R) ; (Y_268)(PumRow_Dn)
  {
    v_268 := 3 ; (268_1)(Obj_Pum_PumRowDown)
  }
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (v_267 == 3 or v_273 == 3) ; (267_1)(Obj_Pum_PumRowUp)/(273_1)(Obj_Pum_PumColumnUp)
  {
    v_261 := 3 ; (261_1)(Obj_Pum_IconUp)
  }
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  DataArray := Image_GuiControl("266", 1, XmlRowsY, DataArray) ; (266_1)(Obj_Pum_PumRow)
  DataArray := Image_GuiControl("272", 1, XmlColumnsX, DataArray) ; (272_1)(Obj_Pum_PumColumn)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  DataArray := Image_GuiControl("261", v_261, 0, DataArray) ; (261_1)(Obj_Pum_IconUp)
  DataArray := Image_GuiControl("262", v_262, 0, DataArray) ; (262_1)(Obj_Pum_IconDown)
  DataArray := Image_GuiControl("267", v_267, 0, DataArray) ; (267_1)(Obj_Pum_PumRowUp)
  DataArray := Image_GuiControl("268", v_268, 0, DataArray) ; (268_1)(Obj_Pum_PumRowDown)
  DataArray := Image_GuiControl("273", v_273, 0, DataArray) ; (273_1)(Obj_Pum_PumColumnUp)
  DataArray := Image_GuiControl("274", v_274, 0, DataArray) ; (274_1)(Obj_Pum_PumColumnDown)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
