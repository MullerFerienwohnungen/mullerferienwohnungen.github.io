#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\Array_FromFile.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\XmlValidate.ahk
;
#Include %A_ProgramFiles%\PopUpMenu_PUM\Array_Add.ahk ; Array_Add(ThisArray, AddThis, ThisPos) ; > ThisArray
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
XmlWrite(Array_PumXml, File_ThisPumXml) ; Array_PumXml, File_ThisPumXml > 1 = Ok , 0 Xml Has Error
{
	; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	/*
	
	Writes a (File_TempPumXml)
	then Checks that (Temp Xml file) Againest the (Array_PumXml)
	if the Written (Temp Xml file) matches the Oranganal (Array_PumXml)
	  > Will Copy and Overwrite (File_ThisPumXml)
	
	*/
	; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; [CHECK] / [CREATE] (A_AppData "\PopUpMenu_PUM\tempxml\)
  ; [CHECK] / [DELETE] (A_AppData "\PopUpMenu_PUM\tempxml\toolbox0.xml)
  ; -------------------------------------------
  Folder_TempPumXml := A_AppData "\PopUpMenu_PUM\tempxml"
  if !FileExist(Folder_TempPumXml)
  {
    FileCreateDir, %Folder_TempPumXml%
    Sleep, 10
  }
  ; -------------------------------------------
  File_TempPumXml := A_AppData "\PopUpMenu_PUM\tempxml\toolbox0.xml"
  if FileExist(File_TempPumXml)
  {
    FileDelete, %File_TempPumXml%
    Sleep, 10
  }
  ; -------------------------------------------
  ; [CHECK] / [CREATE] (A_AppData "\PopUpMenu_PUM\tempxml\)
  ; [CHECK] / [DELETE] (A_AppData "\PopUpMenu_PUM\tempxml\toolbox0.xml)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; [WRITE] [NEW] File_TempPumXml
  ; -------------------------------------------
  for Index, XmlFileLine in Array_PumXml ; (361)(10)(Array_PumXml)
  {
    ; -------------------------------------------
    FileAppend, %XmlFileLine%`n, %File_TempPumXml%, CP20127 ; XmlWrite() 20127 us-ascii US-ASCII (7-bit)
    ; -------------------------------------------
  }
  ; -------------------------------------------
  Sleep, 250
  ; -------------------------------------------
  ; [End] [WRITE] [NEW] File_TempPumXml
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; [VERIFY] (Array_TempPumXml) Matches Entrys in (File_TempPumXml)
  ; -------------------------------------------
  Array_TempPumXml := Array_FromFile(File_TempPumXml)
  OK_XmlWrite := 1
  ; -------------------------------------------
  for Index, XmlFileLine in Array_PumXml ; (361)(10)(Array_PumXml)
  {
    ; -------------------------------------------
    CheckLine := Array_TempPumXml[Index]
    ; -------------------------------------------
    if (CheckLine != XmlFileLine)
    {
      ; -------------------------------------------
      OK_XmlWrite := 0
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  ; -------------------------------------------
  Sleep, 250
  ; -------------------------------------------
  ; [VERIFY] (Array_TempPumXml) Matches Entrys in (File_TempPumXml)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	;
  ; -------------------------------------------
  if (OK_XmlWrite == 1) ; NO ERROR in [VERIFY] (Array_TempPumXml) Matches Entrys in (File_TempPumXml)
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [VALIDATE] XmlValidate (File_TempPumXml)
    ; That XML has Correct Structure
    ; -------------------------------------------
    OK_XmlWrite := XmlValidate(File_TempPumXml) ; > 1 = Ok , 0 Xml Has Error
    ; -------------------------------------------
    ; [VALIDATE] XmlValidate (File_TempPumXml)
    ; That XML has Correct Structure
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; -------------------------------------------
    if (OK_XmlWrite == 1) ; NO ERROR in [VALIDATE] XmlValidate (File_TempPumXml)
    {
	    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	    ; Replace (File_ThisPumXml) with (File_TempPumXml)
      ; -------------------------------------------
      SplitPath, File_ThisPumXml, , Folder_ThisPumXml
      BackupFolder_PumXml := StrReplace(Folder_ThisPumXml, "\pums", "\pums_backup")
      ; -------------------------------------------
      if !FileExist(BackupFolder_PumXml)
      {
        ; -------------------------------------------
        FileCreateDir, %BackupFolder_PumXml%
        Sleep, 100
        ; -------------------------------------------
      } ; if !FileExist(BackupFolder_PumXml)
      ; -------------------------------------------
      BackupFile_ThisPumXml := BackupFolder_PumXml "\toolbox0.xml"
      ; -------------------------------------------
      ;
      ; -------------------------------------------
      FileCopy, %File_TempPumXml%, %File_ThisPumXml%, 1
      FileCopy, %File_TempPumXml%, %BackupFile_ThisPumXml%, 1
      Sleep, 100
      ; -------------------------------------------
      FileDelete, %File_TempPumXml%
      ; -------------------------------------------
	    ; Replace (File_ThisPumXml) with (File_TempPumXml)
	    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    } ; if (OK_XmlWrite == 1) ; NO ERROR in [VALIDATE] XmlValidate (File_TempPumXml)
  } ; if (OK_XmlWrite == 1) ; NO ERROR in [VERIFY] (Array_TempPumXml) Matches Entrys in (File_TempPumXml)
  ; -------------------------------------------
  ;
  ; -------------------------------------------
  return OK_XmlWrite
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; END OF FILE
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>