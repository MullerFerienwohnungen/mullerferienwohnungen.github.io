﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\Gui_ObjectSize.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
l_542: ; (542_1)(_Msg 8_)(_w300 x h300_)_Rotate_Right)
{
  ; -------------------------------------------
  ; Background Image Rotate Right
  ; -------------------------------------------
  ;
  ; (_w300 x h300_)
  ; This Animation will Repeat
  ; Resets to Frame 1
  ; 
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Start/Show (Background Image Rotate Right)
  ; global n_542 := 0 ; Start Frame Number
  ; global s_542 := 1 ; Show
  ; (542_1)(_Msg 8_)(_w300 x h300_)_Rotate_Right)
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Start/Show (Background Image Rotate Right)
  ;
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Stop/Hide (Background Image Rotate Right)
  ; global s_542 := 0 ; Hide
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Stop/Hide (Background Image Rotate Right)
  ;
  ; [ANIMATE] Start/Show in This File
  ; (183_1)(Obj_Pum_BgRotateRight)
  ;
  ; -------------------------------------------
  if (ShowAnimationChange == "")
  {
    global ShowAnimationChange := 0
  }
  ; -------------------------------------------
  Total_Images := 7
  ; -------------------------------------------
  if (s_542 == 1) ; [START] [ANMIMATE]
  {
    ; -------------------------------------------
    if (n_542 > Total_Images) ; 1 Less than Number of Images
    {
      global n_542 := 1
    }
    ; -------------------------------------------
    GuiControl, PopUpMenu:, g_254, %A_ProgramFiles%\PopUpMenu_PUM\image\gui\(542)_%n_542%.png ; (254_1)(Obj_MsgImg300x300)
    ; -------------------------------------------
    Gui_ObjectSize("254", DataArray) ; > Nothing
    ; -------------------------------------------
    if (ShowAnimationChange == 0)
    {
      GuiControl, PopUpMenu:Show, g_254 ; (254_1)(Obj_MsgImg300x300)
      global ShowAnimationChange := 1
    }
    ; -------------------------------------------
    global n_542 := n_542 + 1
    ; -------------------------------------------
  } ; [End] [START] [ANMIMATE]
  else ; [STOP] [ANMIMATE]
  {
    ; -------------------------------------------
    global ShowAnimationChange := 0
    ; -------------------------------------------
    SetTimer, l_542, Off ; (542_1)(_Msg 8_)(_w300 x h300_)_Rotate_Right)
    ; -------------------------------------------
  } ; [End] [STOP] [ANMIMATE]
  ; -------------------------------------------
} ; End (542_1)(_Msg 8_)(_w300 x h300_)_Rotate_Right)
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
