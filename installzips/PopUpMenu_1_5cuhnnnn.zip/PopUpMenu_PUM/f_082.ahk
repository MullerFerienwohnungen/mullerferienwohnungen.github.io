﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\Url_ConnectCheck.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_GuiControl.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Select_FileFolder.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\String_Reverse.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\_S1_C.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\_S2_H.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\_S3_S.ahk
; -------------------------------------------
#Include %A_ProgramFiles%\PopUpMenu_PUM\Url_GetUrl.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
f_082(DataArray) ; (082_1)(Obj_Ofl_Folder)
{
  ; -------------------------------------------
  UserLang := DataArray.365.2 ; (365_2)(UserLang [Current User language])
  HasConnection := Url_ConnectCheck(flag=0x40)
  ; -------------------------------------------
  ;
  ; -------------------------------------------
  DataArray := Image_GuiControl("081", 1, 1, DataArray) ; (081_1)(Obj_RunRwh_File)
  ; -------------------------------------------
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; A Browser is Active
  if (IsInternetBrowser(DataArray.367.1, DataArray.367.3, DataArray.367.4) == 1) ; All Supported Internet Browsers
  {
    ; -------------------------------------------
    DataArray := Image_GuiControl("071", 1, 1, DataArray) ; (071_1)(Obj_URL)
    ; -------------------------------------------
  }
  else ; NO Borwser is Active
  {
    ; -------------------------------------------
    DataArray := Image_GuiControl("071", 3, 1, DataArray) ; (071_1)(Obj_URL)
    ; -------------------------------------------
  }
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; -------------------------------------------
  DataArray := Image_GuiControl("082", 2, 1, DataArray) ; (082_1)(Obj_Ofl_Folder)
  ; -------------------------------------------
  ;
  ; -------------------------------------------
  ; (062_1)(Obj_Cancel)
  ThisPumProcessFolder := DataArray.361.8 ; (361)(8)(ThisPumProcessFolder [Pum Folder Path])
  Selected_Array := Select_FileFolder(DataArray.365.2, "Folder", "", ThisPumProcessFolder) ; (365_2)(UserLang [Current User language])
  ; (062_1)(Obj_Cancel)
  ; -------------------------------------------
  ;
  ; -------------------------------------------
  ofl_FolderPathName := Selected_Array.1
  ; -------------------------------------------
  if FileExist(ofl_FolderPathName)
  {
    ; -------------------------------------------
    DataArray.366.5 := "ofl" ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
    DataArray.303.2 := ofl_FolderPathName ; (303_2)(ofl_FolderPathName [Folder Name With Path])
    ; -------------------------------------------
    Reversed_String_1 := String_Reverse(ofl_FolderPathName)
    Backslash_Position := InStr(Reversed_String_1, "\")
    Reversed_String_2 := SubStr(Reversed_String_1, 1, Backslash_Position - 1)
    ofl_FolderName := String_Reverse(Reversed_String_2)
    ; -------------------------------------------
    DataArray.303.3 := ofl_FolderName ; (303_3)(ofl_FolderName [Folder Name NO Path])
    DataArray.122.3 := ofl_FolderName ; (122_3)(Obj_EditFeild_StatusBar_Val [Text Value])
    ; -------------------------------------------
    DataArray := _S1_C(DataArray)
    DataArray := _S2_H(DataArray)
    DataArray := _S3_S(DataArray)
    ; -------------------------------------------
  } ; (303_2)([ofl] Folder Path)
  else ; (Folder Path == "")
  {
    ; -------------------------------------------
    if (DataArray.366.5 == "run" or DataArray.366.5 == "rwh") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
    {
      DataArray := Image_GuiControl("081", 2, 1, DataArray) ; (081_1)(Obj_RunRwh_File)
    }
    else
    {
      DataArray := Image_GuiControl("081", 1, 1, DataArray) ; (081_1)(Obj_RunRwh_File)
    }
    ; -------------------------------------------
    if (ScriptType == "url")
    {
      DataArray := Image_GuiControl("071", 2, 1, DataArray) ; (071_1)(Obj_URL)
    } ; [End] if (ScriptType == "url")
    else
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; A Browser is Active
      if (IsInternetBrowser(DataArray.367.1, DataArray.367.3, DataArray.367.4) == 1) ; All Supported Internet Browsers
      {
        ; -------------------------------------------
        DataArray := Image_GuiControl("071", 1, 1, DataArray) ; (071_1)(Obj_URL)
        ; -------------------------------------------
      }
      else ; NO Borwser is Active
      {
        ; -------------------------------------------
        DataArray := Image_GuiControl("071", 3, 1, DataArray) ; (071_1)(Obj_URL)
        ; -------------------------------------------
      }
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    }
    ; -------------------------------------------
    if (DataArray.366.5 == "ofl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
    {
      DataArray := Image_GuiControl("082", 2, 1, DataArray) ; (082_1)(Obj_Ofl_Folder)
    }
    else
    {
      DataArray := Image_GuiControl("082", 1, 1, DataArray) ; (082_1)(Obj_Ofl_Folder)
    }
    ; -------------------------------------------
  } ; End (Folder Path == "")
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
