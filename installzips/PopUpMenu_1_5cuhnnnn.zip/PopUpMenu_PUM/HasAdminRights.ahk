#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
HasAdminRights()
{
  ; -------------------------------------------
  TOKEN_QUERY := 0x0008
  TokenElevationTypeDefault := 1
  TokenElevationTypeFull := 2
  TokenElevationTypeLimited := 3
  TokenType := 8
  TokenElevationType := 18
  ; -------------------------------------------
  TokenInformationClass := TokenElevationType
  DllCall("SetLastError", "UInt", 0)
  ret := DllCall("Advapi32.dll\OpenProcessToken", "UInt", DllCall("GetCurrentProcess"), "UInt", TOKEN_QUERY, "UIntP", hToken)
  ; -------------------------------------------
  DllCall("SetLastError", "UInt", 0)
  DllCall("Advapi32.dll\GetTokenInformation", "UInt", hToken, "UInt", TokenInformationClass, "Int", 0, "Int", 0, "UIntP", ReturnLength)
  ; -------------------------------------------
  sizeof_elevationType:=VarSetCapacity(elevationType, ReturnLength, 0)
  DllCall("SetLastError", "UInt", 0)
  DllCall("Advapi32.dll\GetTokenInformation", "UInt", hToken, "UInt", TokenInformationClass, "UIntP", elevationType, "Int", sizeof_elevationType, "UIntP", ReturnLength)
  ; -------------------------------------------
  if (elevationType=TokenElevationTypeDefault)
  {
    ThisUserHasAdminRights := 0
  }
  else if (elevationType=TokenElevationTypeFull)
  {
    ThisUserHasAdminRights := 1
  }
  else if (elevationType=TokenElevationTypeLimited)
  {
    ThisUserHasAdminRights := 1
  }
  else
  {
    ThisUserHasAdminRights := 0
  }
  if (hToken)
  {
    DllCall("CloseHandle", "UInt", hToken)
  }
  ; -------------------------------------------
  return ThisUserHasAdminRights
  ; -------------------------------------------
} ; [End] HasAdminRights()
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
