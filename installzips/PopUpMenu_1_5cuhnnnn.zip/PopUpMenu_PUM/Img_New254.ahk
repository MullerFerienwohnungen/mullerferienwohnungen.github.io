﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\Folder_WindowsUser.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_Combine.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_ResizePng.ahk
; -------------------------------------------
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_PathFolderOrName.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Img_RunPng.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Img_New254(ArrayIn)
{
/*
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
ArrayIn := [DataArray.367.5, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
FileNew254 := Img_New254(ArrayIn)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
AppProcessPathNameExt := ArrayIn.1 ; (DataArray.367.5)(AppProcessPathNameExt [Path,Name,Ext])
AppProcessName        := ArrayIn.2 ; (DataArray.367.1)(AppProcessName [Name][LowerCase][NoSpace])
UseCommonBrowser      := ArrayIn.3 ; (DataArray.290.2 = 2 [UseCommonBrowser = 2][Each Browser Different pum])(DataArray.290.2 = 1 [UseCommonBrowser = 1][All Browsers Same Pum])
UserLang              := ArrayIn.4 ; (DataArray.365.2)(UserLang [Current User language])
UserPictureFolder     := ArrayIn.5 ; (UserPictureFolder)(ThisUserPictureFolder)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
return FileNew254
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
*/
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; StartUp Vars
  ; -------------------------------------------
  AppProcessPathNameExt := ArrayIn.1 ; (DataArray.367.5)(AppProcessPathNameExt [Path,Name,Ext])
  AppProcessName        := ArrayIn.2 ; (DataArray.367.1)(AppProcessName [Name][LowerCase][NoSpace])
  UseCommonBrowser      := ArrayIn.3 ; (DataArray.290.2 = 2 [UseCommonBrowser = 2][Each Browser Different pum])(DataArray.290.2 = 1 [UseCommonBrowser = 1][All Browsers Same Pum])
  UserLang              := ArrayIn.4 ; (DataArray.365.2)(UserLang [Current User language])
  UserPictureFolder     := ArrayIn.5 ; (UserPictureFolder)(ThisUserPictureFolder)
  ; -------------------------------------------
  ; StartUp Vars
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; if This Value is Blank
  ; -------------------------------------------
  if (UseCommonBrowser == "")
  {
    UseCommonBrowser := 0
  }
  ; -------------------------------------------
  if (UserPictureFolder == "")
  {
    ; -------------------------------------------
    RegRead, UserPictureFolder, HKEY_CURRENT_USER, Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders, My Pictures
    ; -------------------------------------------
  }
  ; -------------------------------------------
  if (AppProcessName == "")
  {
    if (AppProcessPathNameExt != "")
    {
      SplitPath, AppProcessPathNameExt, , , , AppProcessName
    }
  }
  ; -------------------------------------------
  ; if This Value is Blank
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if FileExist(AppProcessPathNameExt) ; Does the App Exist
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; Used When (DataArray.290.2 == 1)
    ; [UseCommonBrowser = 1][All Browsers Same Pum]
    ; -------------------------------------------
    SplitPath, AppProcessPathNameExt, CommonBrowser
    if (CommonBrowser == "pumcommonbrowser.txt") ; [UseCommonBrowser = 1][All Browsers Same Pum]
    {
      ; -------------------------------------------
      FileRunPng := A_ProgramFiles "\PopUpMenu_PUM\image\ico\CommonBrowser_Png.png"
      FileNew254 := A_ProgramFiles "\PopUpMenu_PUM\image\ico\CommonBrowser_New254_" UserLang ".png"
      ; -------------------------------------------
    }
    else
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ArrayIn    := [AppProcessPathNameExt, AppProcessName, UseCommonBrowser, "FileRunPng", UserLang, UserPictureFolder]
      ArrayOut   := Image_PathFolderOrName(ArrayIn)
      FileRunPng := ArrayOut.1
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ArrayIn    := [AppProcessPathNameExt, AppProcessName, UseCommonBrowser, "FileNew254", UserLang, UserPictureFolder]
      ArrayOut   := Image_PathFolderOrName(ArrayIn)
      FileNew254 := ArrayOut.1
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    }
    ; -------------------------------------------
    ; Used When (DataArray.290.2 == 1)
    ; [UseCommonBrowser = 1][All Browsers Same Pum]
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;  [CHECK] [CREATE] [UserPictureFolder "\(_PopUpMenu_)\(_Application_)\Png\" AppProcessName "_(" AppProcessFolder ").png"]
    ; -------------------------------------------
    if !FileExist(FileRunPng)
    {
      ; -------------------------------------------
      ArrayIn := [AppProcessPathNameExt, AppProcessName, UseCommonBrowser, UserLang, UserPictureFolder]
      FileRunPng := Img_RunPng(ArrayIn)
      ; -------------------------------------------
    } ; [End] if !FileExist(FileRunPng)
    ; -------------------------------------------
    ;  [CHECK] [CREATE] [UserPictureFolder "\(_PopUpMenu_)\(_Application_)\Png\" AppProcessName "_(" AppProcessFolder ").png"]
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [CHECK] [UserPictureFolder "\(_PopUpMenu_)\System\New254\" AppProcessName "_(" AppProcessFolder ").png"]
    ; -------------------------------------------
    if !FileExist(FileNew254)
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      TempFolder := A_AppData "\PopUpMenu_PUM\temp"
      ; -------------------------------------------
      if !FileExist(TempFolder)
      {
        FileCreateDir, %TempFolder%
        Sleep, 10
      } ; [End] if !FileExist(TempFolder)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; [RESIZE] [UserPictureFolder "\(_PopUpMenu_)\(_Application_)\Png\" AppProcessName "_(" AppProcessFolder ").png"]
      ; [TO]     [A_AppData "\PopUpMenu_PUM\temp\New254Temp.png"]
      ; -------------------------------------------
      New254Temp := A_AppData "\PopUpMenu_PUM\temp\New254Temp.png" ; w111 h111
      ; -------------------------------------------
      if FileExist(New254Temp)
      {
        FileDelete, %New254Temp%
      } ; [End] if !FileExist(New254Temp)
      ; -------------------------------------------
      Image_ResizePng(111, 111, FileRunPng, New254Temp) ; Resize_W, Resize_H, ImageIn, ImageOut > 1 / 0
      ; -------------------------------------------
      ; [RESIZE] [UserPictureFolder "\(_PopUpMenu_)\(_Application_)\Png\" AppProcessName "_(" AppProcessFolder ").png"]
      ; [TO]     [A_AppData "\PopUpMenu_PUM\temp\New254Temp.png"]
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Resize (FileRunPng) to (New254Temp)
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; [CREATE]  [UserPictureFolder "\(_PopUpMenu_)\System\New254\" AppProcessName "_(" AppProcessFolder ").png"]
      ; [COMBINE] [A_ProgramFiles "\PopUpMenu_PUM\image\ico\New254_" UserLang ".png"]
      ; [WITH]    [A_AppData "\PopUpMenu_PUM\temp\New254Temp.png"]
      ; -------------------------------------------
      I1 := A_ProgramFiles "\PopUpMenu_PUM\image\ico\FileNew254_" UserLang ".png" ; w300 h300
      X1 := 0
      Y1 := 0
      ;
      I2  := New254Temp ; w111 h111
      X2 := 95 ; X Position (Left)
      Y2 := 73 ; Y Postion (Down)
      ; -------------------------------------------
      Image_Array := [300, 300, FileNew254, I1, X1, Y1, I2, X2, Y2]
      Image_Combine(Image_Array)
      ; -------------------------------------------
      ; [CREATE]  [UserPictureFolder "\(_PopUpMenu_)\System\New254\" AppProcessName "_(" AppProcessFolder ").png"]
      ; [COMBINE] [A_ProgramFiles "\PopUpMenu_PUM\image\ico\New254_" UserLang ".png"]
      ; [WITH]    [A_AppData "\PopUpMenu_PUM\temp\New254Temp.png"]
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; [DELETE] [A_AppData "\PopUpMenu_PUM\temp\New254Temp.png"]
      ; -------------------------------------------
      if FileExist(New254Temp)
      {
        FileDelete, %New254Temp%
      } ; [End] if FileExist(New254Temp)
      ; -------------------------------------------
      ; [DELETE] [A_AppData "\PopUpMenu_PUM\temp\New254Temp.png"]
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    } ; [End] if !FileExist(FileNew254)
    ; -------------------------------------------
    ; [CHECK] [UserPictureFolder "\(_PopUpMenu_)\System\New254\" AppProcessName "_(" AppProcessFolder ").png"]
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; -------------------------------------------
    return FileNew254
    ; -------------------------------------------
  } ; [End] if FileExist(AppProcessPathNameExt)
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
