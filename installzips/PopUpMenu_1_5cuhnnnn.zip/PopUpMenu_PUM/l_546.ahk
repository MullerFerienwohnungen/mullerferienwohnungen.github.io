﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_GuiControl.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
l_546: ; (546_1)(002_003)(_w40 x h40_)(Process Rotate)
{
  ; -------------------------------------------
  ; Process Rotate
  ; -------------------------------------------
  ;
  ; (w80_x_80)
  ; This Animation will Repeat
  ; Resets to Frame 1
  ; 
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Start/Show (Process Rotate)
  ; global n_546 := 0 ; Start Frame Number
  ; global s_546 := 1 ; Show
  ; SetTimer, l _ 5 4 6, 100
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Start/Show (Process Rotate)
  ;
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Stop/Hide (Process Rotate)
  ; global s_546 := 0 ; Hide
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Stop/Hide (Process Rotate)
  ;
  ; [ANIMATE] Start/Show in This File
  ; Image_ConvertToIco.ahk
  ; Image_ImgToIco.ahk
  ;
  ; -------------------------------------------
  Total_Images := 10
  ; -------------------------------------------
  if (s_546 == 1) ; [START] [ANMIMATE]
  {
    ; -------------------------------------------
    if (n_546 > Total_Images)
    {
      global n_546 := 1
    }
    else
    {
      ; -------------------------------------------
      DataArray := Image_GuiControl("546_001", n_546, 0, DataArray) ; (546_1)(002_003)(_w40 x h40_)(Process Rotate)
      DataArray := Image_GuiControl("546_002", n_546, 0, DataArray) ; (546_1)(002_003)(_w40 x h40_)(Process Rotate)
      ; -------------------------------------------
      global n_546 := n_546 + 1
      ; -------------------------------------------
    }
  } ; [End] [START] [ANMIMATE]
  else ; [STOP] [ANMIMATE]
  {
    ; -------------------------------------------
    SetTimer, l_546, Off ; (546_1)(002_003)(_w40 x h40_)(Process Rotate)
    ; -------------------------------------------
  } ; [End] [STOP] [ANMIMATE]
  ; -------------------------------------------
} ; [End] (545_1)(Display Icon (w80_x_80) Rotate Icon)
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
