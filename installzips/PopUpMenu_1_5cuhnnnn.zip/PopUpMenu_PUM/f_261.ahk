﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\Sys_EnableDisable.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_GuiControl.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Pum_Validate.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Pum_Vars.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_PumDim.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Pum_Check.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
f_261(DataArray) ; (261_1)(Obj_Pum_IconUp)
{
  ; -------------------------------------------
  if (DataArray.261.2 != 3) ; (261_2)(Obj_Pum_IconUp_Sel [0,1])
  {
    ; -------------------------------------------
    global PumLock := 0
    ; -------------------------------------------
    if (PumLock == 0)
    {
      ; -------------------------------------------
      global PumLock := 1
      ; -------------------------------------------
      ;
      ; -------------------------------------------
      Sys_EnableDisable("Disable") ; "Enable" or "Disable"
      ; -------------------------------------------
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      DataArray := Image_GuiControl("004", 3, 0, DataArray) ; (004_1)(Obj_ok)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; -------------------------------------------
      GuiControl, PopUpMenu:Hide, g_102 ; (102_1)(Obj_DisplayedIcon)
      ; -------------------------------------------
      ;
      ; -------------------------------------------
      DataArray := Image_GuiControl("262", 1, 0, DataArray) ; (262_1)(Obj_Pum_IconDown)
      ; -------------------------------------------
      XmlIconSize := DataArray.362.14 ; (362_14)(XmlIconSize [Displaymode iconsize] [32,48,64])
      ; -------------------------------------------
      if (XmlIconSize == 32)
      {
        Check_I := 48
      }
      else if (XmlIconSize == 48 or XmlIconSize == 64)
      {
        Check_I := 64
      }
      Check_C := ""
      Check_R := ""
      ; -------------------------------------------
      Result_Msg := Pum_Validate(Check_I, Check_C, Check_R, DataArray) ; > Result Array
      ; -------------------------------------------
      if (Result_Msg == "Ok")
      {
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ; (IconSize_Up)
        ; -------------------------------------------
        XmlIconSize := Check_I
        DataArray.362.14 := XmlIconSize ; (362_14)(XmlIconSize [Displaymode iconsize] [32,48,64])
        ; -------------------------------------------
        XmlColumnsX := DataArray.362.4 ; (362_4)(XmlColumnsX [Pum (X) Columns])
        XmlRowsY    := DataArray.362.3 ; (362_3)(XmlRowsY [Pum (Y) Rows])
        ; -------------------------------------------
        Pum_W := XmlColumnsX * XmlIconSize
        Pum_H := XmlRowsY * XmlIconSize
        ; -------------------------------------------
        DataArray.362.36 := Pum_W ; (362_36)(Pum_W)
        DataArray.362.37 := Pum_H ; (362_37)(Pum_H)
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      }
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; All with DoNotEnter Sign until Pum_Check
      ; Determines if Pum Size is beyond the bounds of possibility
      ; -------------------------------------------
      DataArray := Image_GuiControl("261", 3, 0, DataArray) ; (261_1)(Obj_Pum_IconUp)
      DataArray := Image_GuiControl("262", 3, 0, DataArray) ; (262_1)(Obj_Pum_IconDown)
      DataArray := Image_GuiControl("267", 3, 0, DataArray) ; (267_1)(Obj_Pum_PumRowUp)
      DataArray := Image_GuiControl("268", 3, 0, DataArray) ; (268_1)(Obj_Pum_PumRowDown)
      DataArray := Image_GuiControl("273", 3, 0, DataArray) ; (273_1)(Obj_Pum_PumColumnUp)
      DataArray := Image_GuiControl("274", 3, 0, DataArray) ; (274_1)(Obj_Pum_PumColumnDown)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      if (Result_Msg == "Ok")
      {
        ; -------------------------------------------
        DataArray.362.38 := "C" ; (362_38)(Bg_Image_Type [C=Crop,F=Fit])
        ; -------------------------------------------
        Icon_Image := A_ProgramFiles "\PopUpMenu_PUM\image\gui\(260)_" Check_I ".png"
        GuiControl, PopUpMenu:, g_260, %Icon_Image% ; (260_1)(Obj_Pum_IconSize)
        GuiControl, PopUpMenu:Show, g_260 ; (260_1)(Obj_Pum_IconSize)
        ; -------------------------------------------
        DataArray := Pum_Vars(DataArray) ; > DataArray
        ; -------------------------------------------
        Image_PumDim(DataArray) ; > Nothing
        ; -------------------------------------------
      }
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      DataArray := Pum_Check(DataArray) ; > DataArray
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      DataArray := Image_GuiControl("004", 1, 0, DataArray) ; (004_1)(Obj_ok)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; -------------------------------------------
      Sys_EnableDisable("Enable") ; "Enable" or "Disable"
      ; -------------------------------------------
      ;
      ; -------------------------------------------
      global PumLock := 0
      ; -------------------------------------------
    } ; End (PumLock == 0)
    ; -------------------------------------------
  }
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
