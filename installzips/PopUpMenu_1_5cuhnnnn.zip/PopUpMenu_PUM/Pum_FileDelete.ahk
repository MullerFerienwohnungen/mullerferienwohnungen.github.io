﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Pum_FileDelete(ThisPumProcessExe)
{
  ; -------------------------------------------
  ThisPumProcessName := ThisPumProcessExe
  ThisPumProcessName := StrReplace(ThisPumProcessName, "pum_", "")
  ThisPumProcessName := StrReplace(ThisPumProcessName, ".exe", "")
  ; -------------------------------------------
  Bmp_Images := A_AppData "\PopUpMenu_PUM\pums\" ThisPumProcessName "\settings\*.bmp" ; (361)(8)(ThisPumProcessFolder [Pum Folder Path])
  FileDelete, %Bmp_Images%
  ; -------------------------------------------
  Icl_Files := A_AppData "\PopUpMenu_PUM\pums\" ThisPumProcessName "\*.icl" ; (361)(8)(ThisPumProcessFolder [Pum Folder Path])
  FileDelete, %Icl_Files%
  ; -------------------------------------------
  Dwl_Files := A_AppData "\PopUpMenu_PUM\pums\" ThisPumProcessName "\*.dwl" ; (361)(8)(ThisPumProcessFolder [Pum Folder Path])
  FileDelete, %Dwl_Files%
  ; -------------------------------------------
  Dwl_Files := A_AppData "\PopUpMenu_PUM\pums\" ThisPumProcessName "\*.dwl2" ; (361)(8)(ThisPumProcessFolder [Pum Folder Path])
  FileDelete, %Dwl_Files%
  ; -------------------------------------------
  Dwl_Files := A_AppData "\PopUpMenu_PUM\pums\" ThisPumProcessName "\*.dwl3" ; (361)(8)(ThisPumProcessFolder [Pum Folder Path])
  FileDelete, %Dwl_Files%
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
