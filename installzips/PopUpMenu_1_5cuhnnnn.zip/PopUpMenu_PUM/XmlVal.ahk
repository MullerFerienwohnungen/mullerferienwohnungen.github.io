﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
XmlVal(ThisXmlArray, GetThis) ; XmlVal(ThisXmlArray, GetThis) ; > ReturnVal
{
  ; -------------------------------------------
  if (GetThis == "toolbox_rows")
  {
    ; <toolbox name="" rows="4" columns="5" left="480" top="384" stayontop="-1" >
    FindLine := "<toolbox"
    FindItem := "rows"
  }
  else if (GetThis == "toolbox_columns")
  {
    ; <toolbox name="" rows="4" columns="5" left="480" top="384" stayontop="-1" >
    FindLine := "<toolbox"
    FindItem := "columns"
  }
  else if (GetThis == "toolbox_left")
  {
    ; <toolbox name="" rows="4" columns="5" left="480" top="384" stayontop="-1" >
    FindLine := "<toolbox"
    FindItem := "left"
  }
  else if (GetThis == "toolbox_top")
  {
    ; <toolbox name="" rows="4" columns="5" left="480" top="384" stayontop="-1" >
    FindLine := "<toolbox"
    FindItem := "top"
  }
  else if (GetThis == "displaymode_iconsize")
  {
    ; <displaymode type="0" iconsize="64" />
    FindLine := "<displaymode"
    FindItem := "iconsize"
  }
  else if (GetThis == "background_color")
  {
    ; <background color="12632256" type="1" effect="0" opacity="50" >
    FindLine := "<background"
    FindItem := "color"
  }
  else if (GetThis == "background_type")
  {
    ; <background color="12632256" type="1" effect="0" opacity="50" >
    FindLine := "<background"
    FindItem := "type"
  }
  else if (GetThis == "background_opacity")
  {
    ; <background color="12632256" type="1" effect="0" opacity="50" >
    FindLine := "<background"
    FindItem := "opacity"
  }
  ; -------------------------------------------
  ReturnVal := ""
  ; -------------------------------------------
  for index, XmlString in ThisXmlArray
  {
    if (InStr(XmlString, FindLine) > 0)
    {
      ; -------------------------------------------
      ItemPos := InStr(XmlString, FindItem)
      ValStringTemp := SubStr(XmlString, ItemPos)
      ValStartPos := InStr(ValStringTemp, """",,, 1)
      ValStartPos := ValStartPos + 1
      ValEndPos := InStr(ValStringTemp, """",,, 2)
      ValLen := ValEndPos - ValStartPos
      ReturnVal := SubStr(ValStringTemp, ValStartPos, ValLen)
      ; -------------------------------------------
      break
      ; -------------------------------------------
    } ; [End] if (InStr(XmlString, FindLine) > 0)
  } ; [End] for index, XmlString in ThisXmlArray
  ; -------------------------------------------
  return ReturnVal
  ; -------------------------------------------
} ; [End] XmlVal(ThisXmlArray, GetThis) ; XmlVal(ThisXmlArray, GetThis) ; > ReturnVal
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
