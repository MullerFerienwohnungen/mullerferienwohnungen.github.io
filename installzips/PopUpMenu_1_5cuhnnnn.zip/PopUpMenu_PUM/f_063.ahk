﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\Folder_WindowsUser.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Select_FileFolder.ahk
; -------------------------------------------
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_GuiControl.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\f_102.ahk ; (102_1)(Obj_DisplayedIcon)
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_ExeToPng.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_MultIconDisplay.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
f_063(DataArray) ; (063_1)(Obj_SelectIconImage)
{
  ; -------------------------------------------
  if (DataArray.366.5 == "key" or DataArray.366.5 == "ofl" or DataArray.366.5 == "run" or DataArray.366.5 == "rwh" or DataArray.366.5 == "url") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
  {
    ; -------------------------------------------
    if (DataArray.366.5 != "ofl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
    {
      DataArray := Image_GuiControl("063", 2, 1, DataArray) ; (063_1)(Obj_SelectIconImage)
    }
    ; -------------------------------------------
    RegRead, StartFolder, HKEY_CURRENT_USER, Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders, My Pictures
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    ; [OutTarget, Arguments, UseLink (0,1), Selected_File, LinkIcon]
    ThisPumProcessFolder := DataArray.361.8 ; (361)(8)(ThisPumProcessFolder [Pum Folder Path])
    Selected_Array := Select_FileFolder(DataArray.365.2, "AnyImage", StartFolder, ThisPumProcessFolder) ; (365_2)(UserLang [Current User language])
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    File_SelectedImage := Selected_Array.1
    ; -------------------------------------------
    if FileExist(File_SelectedImage)
    {
      ; -------------------------------------------
      ; SplitPath, SelectedImagePath, FileNameExt, Folder, Ext, FileName, DriveLetter
      SplitPath, File_SelectedImage, SelectedImage_NameExt, , SelectedImage_Ext, SelectedImage_Name
      StringLower, SelectedImage_Ext, SelectedImage_Ext
      ; -------------------------------------------
      if (SelectedImage_Ext == "ico") ; Selected File_SelectedImage is a Ico
      {
        ; -------------------------------------------
        DataArray := f_102(File_SelectedImage, DataArray) ; (102_1)(Obj_DisplayedIcon)
        ; -------------------------------------------
      } ; End if (SelectedImage_Ext == "ico")
      ; -------------------------------------------
      else if (SelectedImage_Ext == "apng" or SelectedImage_Ext == "avif" or SelectedImage_Ext == "bmp" or SelectedImage_Ext == "gif" or SelectedImage_Ext == "ico" or SelectedImage_Ext == "jfif" or SelectedImage_Ext == "jpeg" or SelectedImage_Ext == "jpg" or SelectedImage_Ext == "png" or SelectedImage_Ext == "svg" or SelectedImage_Ext == "tif" or SelectedImage_Ext == "tiff" or SelectedImage_Ext == "webp")
      {
        ; -------------------------------------------
        if (SelectedImage_Ext == "jfif")
        {
          Temp_jpg := A_AppData "\PopUpMenu_PUM\temp\" SelectedImage_Name ".jpg"
          FileCopy, %File_SelectedImage%, %Temp_jpg%, 1
          Sleep, 10
        }
        ; -------------------------------------------
        DataArray := f_102(File_SelectedImage, DataArray) ; (102_1)(Obj_DisplayedIcon)
        ; -------------------------------------------
      } ; else if (SelectedImage_Ext == "apng" or SelectedImage_Ext == "avif" or SelectedImage_Ext == "bmp" or SelectedImage_Ext == "gif" or SelectedImage_Ext == "ico" or SelectedImage_Ext == "jfif" or SelectedImage_Ext == "jpeg" or SelectedImage_Ext == "jpg" or SelectedImage_Ext == "png" or SelectedImage_Ext == "svg" or SelectedImage_Ext == "tif" or SelectedImage_Ext == "tiff" or SelectedImage_Ext == "webp")
      ; -------------------------------------------
      else if(SelectedImage_Ext == "exe")
      {
        ; -------------------------------------------
        DataArray := Image_ExeToPng(File_SelectedImage, DataArray) ; > DataArray
        DataArray := Image_MultIconDisplay(DataArray) ; > DataArray
        ; -------------------------------------------
      } ; End (SelectedImage_Ext == "exe")
      ; -------------------------------------------
    } ; End if File_SelectedImage
    ; -------------------------------------------
    if (DataArray.366.5 != "ofl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
    {
      DataArray := Image_GuiControl("063", 1, 1, DataArray) ; (063_1)(Obj_SelectIconImage)
    }
    ; -------------------------------------------
  } ; [End] (ScriptType [key,run,rwh])
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
