#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_CutSquare.ahk ; Image_CutSquare(TargetSize, ImageIn, ImageOut) ; TargetSize, ImageIn, ImageOut > Image_Out
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_ResizeImg.ahk ; Image_ResizeImg(Resize_W, Resize_H, ImageIn, ImageOut) ; Resize_W, Resize_H, Image_In, Image_Out > Image_Out
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Image_CutSquare(TargetSize, ImageIn, ImageOut) ; TargetSize, ImageIn, ImageOut > Image_Out
{
	; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	; Get Image Size
	; -------------------------------------------
	Gui, ImageSize:Add, Picture, hwndJustForSize, %ImageIn% ; (368_5)(Selected Pum Background [Full Path])
	ControlGetPos, , , Image_W, Image_H, , ahk_id %JustForSize% ; (368_6)(Pum Background Image X_Width)/(368_7)(Pum Background Image Y_Height)
	; -------------------------------------------
  ; Get Image Size
	; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	;
	; -------------------------------------------
	if (Image_W > Image_H or Image_H > Image_W)
	{
		; -------------------------------------------
		if (Image_W > Image_H)
		{
			; -------------------------------------------
			Shave_X := Round((Image_W - Image_H) * 0.5)
			Shave_Y := 0 
			; -------------------------------------------
		}
		if (Image_H > Image_W)
		{
			; -------------------------------------------
			Shave_X := 0 
			Shave_Y := Round((Image_H - Image_W) * 0.5)
			; -------------------------------------------
		}
		; -------------------------------------------
		Support_magick := A_ProgramFiles "\PopUpMenu_PUM\support\magick\magick.exe"
		RunThis := Support_magick " """ ImageIn """ -shave " Shave_X "x" Shave_Y " -flatten """ ImageOut """"
		Run, %A_ProgramFiles%\PopUpMenu_PUM\PriorityProcess_ImageMagic.ahk
		RunWait, %RunThis%, , Hide
		; -------------------------------------------
		ImageIn := ImageOut
		Image_ResizeImg(TargetSize, TargetSize, ImageIn, ImageOut) ; Resize_W, Resize_H, Image_In, Image_Out > Image_Out
		; -------------------------------------------
	}
	; -------------------------------------------
	return ImageOut
	; -------------------------------------------
} ; Function (Image_CutSquare)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; END OF FILE
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

	