﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
#SingleInstance, force
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\Img_Error440.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Img_Error450.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Img_Error460.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Img_Error470.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\ShellRun.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Folder_WindowsUser.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Array_FromFile.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Shortcut_Run(Script_Type, Script_Line_2, Script_Line_3, Script_Line_4, Script_Line_5, Script_Line_6)
{
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; Close Active pum Process
  ; -------------------------------------------
  WinGet, ThisPumProcessExe, ProcessName, ahk_class TfrmToolbox
  if (InStr(ThisPumProcessExe, "pum_") > 0) ; pum Exist
  {
    ; -------------------------------------------
    ; Relative path to the Shortcut must be (ahk\)
    ; <filename>ahk\run-20211109105138.ahk</filename>
    ; if Holding the LButton Longer than 500
    ; and then releasing it, program will do nothing
    ; which is what the return does "Nothing"
    ; -------------------------------------------
    return
    ; -------------------------------------------
  }
  ; -------------------------------------------
  ; Close Active pum Process
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; -------------------------------------------
  PassOK := 1
  ; -------------------------------------------
  File_ActiveApp := A_AppData "\PopUpMenu_PUM\system\File_ActiveApp.txt"
  ; -------------------------------------------
  SetTitleMatchMode, 2
  ; -------------------------------------------
  ;
  ; -------------------------------------------
  ; Reset Vars
  Check_Lnk := 
  Cpl_ShortcutScript     := ""
  Key_KeyArrayShortcut   := ""
  KeyMnu_Class           := ""
  KeyMnu_ProcessName     := ""
  Mnu_ComNum             := ""
  run_Arguments          := ""
  Run_ExecutableId       := ""
  Run_FilePathNameExt    := ""
  run_OutTarget          := ""
  Rwh_OpeningApp         := ""
  Obj_Run_AsAdmin_Sel    := ""
  Obj_KeyMnu_AppOnly_Sel := ""
  ofl_FolderPathName     := ""
  Url_BrowserPathNameExt := ""
  Url_Address            := ""
  Url_NewTab             := ""
  Url_UseDefaultBrowser  := ""
  ; -------------------------------------------
  ;
  ; -------------------------------------------
  DetectHiddenWindows, On
  if WinExist("Shortcut_Pop_Up_Menu" . "ahk_class AutoHotkeyGUI") ; Close Shortcut Gui
  {
    ; -------------------------------------------
    KeyWait, LButton
    ; -------------------------------------------
  } ; End WinActive("PopUpMenu - Shortcut Icon") ; Shortcut Gui
  else ; Does NOT Exist Gui File Select
  {
    ; -------------------------------------------
    KeyWait, LButton
    ; -------------------------------------------
    ; Can Not use Block Input
    ; Active Pum was not ran as Admin
    ; Thus This Script is Not ran as Admin
    ; -------------------------------------------
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; User Language [GET] (UserLang)
    ; -------------------------------------------
    File_UserLang := A_AppData "\PopUpMenu_PUM\system\File_UserLang.txt"
    ; -------------------------------------------
    if FileExist(File_UserLang)
    {
      FileReadLINE, UserLang, %File_UserLang%, 1
    }
    ; -------------------------------------------
    if (UserLang == "")
    {
      ; -------------------------------------------
      if FileExist(File_UserLang)
      {
        FileDelete, %File_UserLang%
        Sleep, 100
      } ; [End] if FileExist(File_UserLang)
      ; -------------------------------------------
      if (A_Language == "0407" or A_Language == "0807" or A_Language == "0c07" or A_Language == "1007" or A_Language == "1407")
      {
        ; -------------------------------------------
        UserLang := "de"
        ; -------------------------------------------
      } ; [End] German (de)
      ; -------------------------------------------
      else if (A_Language == "0409" or A_Language == "0809" or A_Language == "0c09" or A_Language == "1009" or A_Language == "1409" or A_Language == "1809" or A_Language == "1c09" or A_Language == "2009" or A_Language == "2409" or A_Language == "2809" or A_Language == "2c09" or A_Language == "3009" or A_Language == "3409")
      {
        ; -------------------------------------------
        UserLang := "en"
        ; -------------------------------------------
      } ; [End] English (en)
      ; -------------------------------------------
      else if (A_Language == "040a" or A_Language == "080a" or A_Language == "0c0a" or A_Language == "100a" or A_Language == "140a" or A_Language == "180a" or A_Language == "1c0a" or A_Language == "200a" or A_Language == "240a" or A_Language == "280a" or A_Language == "2c0a" or A_Language == "300a" or A_Language == "340a" or A_Language == "380a" or A_Language == "3c0a" or A_Language == "400a" or A_Language == "440a" or A_Language == "480a" or A_Language == "4c0a" or A_Language == "500a")
      {
        ; -------------------------------------------
        UserLang := "es"
        ; -------------------------------------------
      } ; [End] Spanish (es)
      ; -------------------------------------------
      else if (A_Language == "040c" or A_Language == "080c" or A_Language == "0c0c" or A_Language == "100c" or A_Language == "140c" or A_Language == "180c")
      {
        ; -------------------------------------------
        UserLang := "fr"
        ; -------------------------------------------
      } ; [End] French (fr)
      ; -------------------------------------------
      else if (A_Language == "0410" or A_Language == "0810")
      {
        ; -------------------------------------------
        UserLang := "it"
        ; -------------------------------------------
      } ; [End] Italian (it)
      ; -------------------------------------------
      else if (A_Language == "0415")
      {
        ; -------------------------------------------
        UserLang := "pl"
        ; -------------------------------------------
      } ; [End] Polish (pl)
      ; -------------------------------------------
      else if (A_Language == "0416" or A_Language == "0816")
      {
        ; -------------------------------------------
        UserLang := "pt"
        ; -------------------------------------------
      } ; [End] Portuguese (pt)
      ; -------------------------------------------
      else if (A_Language == "0419")
      {
        ; -------------------------------------------
        UserLang := "ru"
        ; -------------------------------------------
      } ; [End] Russian (ru)
      ; -------------------------------------------
      else if (A_Language == "041d" or A_Language == "081d")
      {
        ; -------------------------------------------
        UserLang := "sv"
        ; -------------------------------------------
      } ; [End] Swedish (sv)
      ; -------------------------------------------
      else if (A_Language == "041f")
      {
        ; -------------------------------------------
        UserLang := "tr"
        ; -------------------------------------------
      } ; [End] Turkish (tr)
      ; -------------------------------------------
      else ; English (en)
      {
        ; -------------------------------------------
        UserLang := "en"
        ; -------------------------------------------
      } ; [End] else ; English (en)
      ; -------------------------------------------
      FileEncoding, UTF-8 ; UTF-8
      FileAppend, %UserLang%`n, %File_UserLang% ; UTF-8
      ; -------------------------------------------
    } ; [End] if (UserLang == "")
    ; -------------------------------------------
    ; User Language [GET] (UserLang)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; -------------------------------------------
    { ; [CHECK] Shortcut Errors
      ; -------------------------------------------
      PassOK := 1
      ; -------------------------------------------
      FileReadLine, Active_Process_Class, %File_ActiveApp%, 3
      ; -------------------------------------------
      if (Script_Type == "cpl") ; (Script Type)
      {
        ; -------------------------------------------
        ;
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (cpl)
        ; Script_Line_2 := "Com_####"                 (300_8)(Cpl_ComNum [Com_#### Used for Icon and Link/ahk Name])
        ; Script_Line_3 := ""                         *** EMPTY ***
        ; Script_Line_4 := ""                         *** EMPTY ***
        ; Script_Line_5 := ""                         *** EMPTY ***
        ; Script_Line_6 := ""                         *** EMPTY ***
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (cpl)
        ;
        ; -------------------------------------------
        Check_Lnk := A_ProgramFiles "\PopUpMenu_PUM\menu\cpl\com\" Script_Line_2 ".lnk"
        Check_Ahk := A_ProgramFiles "\PopUpMenu_PUM\menu\cpl\com\" Script_Line_2 ".ahk"
        Check_Exe := A_ProgramFiles "\PopUpMenu_PUM\menu\cpl\com\" Script_Line_2 ".exe"
        ; -------------------------------------------
        if FileExist(Check_Lnk)
        {
          Cpl_ShortcutScript := Check_Lnk
        }
        else if FileExist(Check_Ahk)
        {
          Cpl_ShortcutScript := Check_Ahk
        }
        else if FileExist(Check_Exe)
        {
          Cpl_ShortcutScript := Check_Exe
        }
        ; -------------------------------------------
        if !FileExist(Cpl_ShortcutScript)
        {
          ; -------------------------------------------
          PassOK := 0
          ; -------------------------------------------
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (436_1)(Splash Error Image File: (mnu,cpl) Link Not Found)
          ; (436)(01)(Splash Error Image File: mnu-*.ahk or cpl-*.ahk Not Found)
          Splash_Image := A_ProgramFiles "\PopUpMenu_PUM\image\gui\(436)_" UserLang ".png"
          SplashImage, %Splash_Image%, b
          Sleep, 1500
          SplashImage, Off
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (436_1)(Splash Error Image File: (mnu,cpl) Link Not Found)
        }
        ; -------------------------------------------
      } ; (Script Type) (cpl)
      ; -------------------------------------------
      else if (Script_Type == "key") ; (Script Type)
      {
        ; -------------------------------------------
        ;
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (key)
        ; Script_Line_2 := 1/2                        (072_2)(Obj_KeyMnu_AppOnly_Sel [0,1,2])
        ; Script_Line_3 := ["[Key]", "~X~"]           (301_8)(Key_KeyArrayShortcut [Array])
        ; Script_Line_4 := "App Class"                (301_5)(KeyMnu_Class)
        ; Script_Line_5 := "App ProcessPathNameExt"   (301_10)(KeyMnu_ProcessPathExtName)
        ; Script_Line_6 := 0/1                        (301_11)(Key_ShortcutInAppPum [0,1])
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (key)
        ;
        ; -------------------------------------------
        Obj_KeyMnu_AppOnly_Sel    := Script_Line_2
        Key_KeyArrayShortcut      := Script_Line_3
        KeyMnu_Class              := Script_Line_4
        KeyMnu_ProcessPathExtName := Script_Line_5
        Key_ShortcutInAppPum      := Script_Line_6
        ; -------------------------------------------
        SplitPath, KeyMnu_ProcessPathExtName, KeyMnu_ProcessExtName, , , KeyMnu_ProcessName
        ; -------------------------------------------
        if (Key_ShortcutInAppPum == 1)
        {
          Obj_KeyMnu_AppOnly_Sel := 2
        }
        ; -------------------------------------------
        ;
        ; -------------------------------------------
        if (Obj_KeyMnu_AppOnly_Sel == 2)
        {
          ; -------------------------------------------
          FileReadLine, AppProcessName, %File_ActiveApp%, 1
          FileReadLine, AppProcessExtName, %File_ActiveApp%, 2
          FileReadLine, AppProcessClass, %File_ActiveApp%, 3 
          ; -------------------------------------------
          ;StringLower, OutputVar, InputVar
          StringLower, Lower_KeyMnu_ProcessName, KeyMnu_ProcessName
          StringLower, Lower_KeyMnu_ProcessExtName, KeyMnu_ProcessExtName
          StringLower, Lower_KeyMnu_Class, KeyMnu_Class
          ; -------------------------------------------
          StringLower, Lower_AppProcessName, AppProcessName
          StringLower, Lower_AppProcessExtName, AppProcessExtName
          StringLower, Lower_AppProcessClass, AppProcessClass
          ; -------------------------------------------
          if (Lower_KeyMnu_Class == "windows" && Lower_KeyMnu_ProcessExtName == "windows") ; In Windows Desktop
          {
            ; -------------------------------------------
            if (Lower_AppProcessClass != Lower_KeyMnu_Class) ; Windows Desktop NOT Active
            {
              ; -------------------------------------------
              PassOK := 0
              ; -------------------------------------------
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Windows Desktop NOT Active
              SplashImage, Off
              Splash_Image := A_ProgramFiles "\PopUpMenu_PUM\image\ico\FileError480_" UserLang ".png"
              ; -------------------------------------------
              SplashImage, %Splash_Image%, b
              Sleep, 1500
              SplashImage, Off
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Windows Desktop NOT Active
            } ; [End] if (Check_AppProcessClass != Check_KeyMnu_Class) ; Windows Desktop NOT Active
            ; -------------------------------------------
          } ; [End] if (KeyMnu_Class == "Windows" && KeyMnu_ProcessExtName == "windows") ; In Windows Desktop
          else ; NOT In Windows Desktop
          {
            ; -------------------------------------------
            Process, Exist, %KeyMnu_ProcessExtName%
            if (ErrorLevel != 0) ; Application Does (Exist), CHECK (Active)
            {
              ; -------------------------------------------
              CheckClass := "ahk_class " KeyMnu_Class
              Var_Active  := WinActive(CheckClass)
              ; -------------------------------------------
              if (Key_ShortcutInAppPum == 0) ; key Shortcut From Default Pum
              {
                if (Var_Active == "0x0") ; Application Does (Exist), Application NOT (Active)
                {
                  ; -------------------------------------------
                  PassOK := 0
                  ; -------------------------------------------
                  RegRead, UserPictureFolder, HKEY_CURRENT_USER, Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders, My Pictures
                  ArrayIn := [KeyMnu_ProcessPathExtName, "", "", UserLang, UserPictureFolder]
                  FileError460 := Img_Error460(ArrayIn)
                  ; -------------------------------------------
                  ;
                  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (460)(Splash Error: [App Logo Image] Application is NOT Active)
                  SplashImage, Off
                  SplashImage, %Error460%, b
                  Sleep, 1500
                  SplashImage, Off
                  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (460)(Splash Error: [App Logo Image] Application is NOT Active)
                } ; [End] if (Var_WinActive == "0x0") ; Application Does (Exist), Application NOT (Active)
              } ; [End] if (Key_ShortcutInAppPum == 0) ; key Shortcut From Default Pum
              else if (Key_ShortcutInAppPum == 1) ; key Shortcut From App Pum
              {
                if (Var_Active == "0x0") ; Application Does (Exist), Application NOT (Active)
                {
                  ; -------------------------------------------
                  HasAdminRights := A_IsAdmin
                  ; -------------------------------------------
                  if (HasAdminRights == 1)
                  {
                    ScriptWinActivate := A_AppData "\PopUpMenu_PUM\temp\ScriptWinActivate.ahk"
                    if FileExist(ScriptWinActivate)
                    {
                      FileDelete, %ScriptWinActivate%
                    }
                    Sleep, 100
                    Line_1 := "`#NoEnv"
                    Line_2 := "`#MaxHotkeysPerInterval 99000000"
                    Line_3 := "`#HotkeyInterval 99000000"
                    Line_4 := "`#KeyHistory 0"
                    Line_5 := "ListLines Off"
                    Line_6 := "Process, Priority, , A"
                    Line_7 := "SetBatchLines, -1"
                    Line_8 := "SetKeyDelay, -1, -1"
                    Line_9 := "SetMouseDelay, -1"
                    Line_10 := "SetDefaultMouseSpeed, 0"
                    Line_11 := "SetWinDelay, -1"
                    Line_12 := "SetControlDelay, -1"
                    Line_13 := "SendMode Input"
                    Line_14 := "WinActivate`, ahk_exe " KeyMnu_ProcessExtName
                    ; -------------------------------------------
                    FileEncoding, UTF-8 ; UTF-8
                    FileAppend, %Line_1%`n, %ScriptWinActivate% ; UTF-8
                    FileAppend, %Line_2%`n, %ScriptWinActivate% ; UTF-8
                    FileAppend, %Line_3%`n, %ScriptWinActivate% ; UTF-8
                    FileAppend, %Line_4%`n, %ScriptWinActivate% ; UTF-8
                    FileAppend, %Line_5%`n, %ScriptWinActivate% ; UTF-8
                    FileAppend, %Line_6%`n, %ScriptWinActivate% ; UTF-8
                    FileAppend, %Line_7%`n, %ScriptWinActivate% ; UTF-8
                    FileAppend, %Line_8%`n, %ScriptWinActivate% ; UTF-8
                    FileAppend, %Line_9%`n, %ScriptWinActivate% ; UTF-8
                    FileAppend, %Line_10%`n, %ScriptWinActivate% ; UTF-8
                    FileAppend, %Line_11%`n, %ScriptWinActivate% ; UTF-8
                    FileAppend, %Line_12%`n, %ScriptWinActivate% ; UTF-8
                    FileAppend, %Line_13%`n, %ScriptWinActivate% ; UTF-8
                    FileAppend, %Line_14%`n, %ScriptWinActivate% ; UTF-8
                    ; -------------------------------------------
                    BreakTime := A_TickCount + 2000
                    while !FileExist(ScriptWinActivate)
                    {
                      if (A_TickCount > BreakTime)
                      {
                        break
                      }
                      Sleep, 100
                    }
                    RunWait, *RunAs %ScriptWinActivate%
                    ; -------------------------------------------
                    if FileExist(ScriptWinActivate)
                    {
                      FileDelete, %ScriptWinActivate%
                    }
                    ; -------------------------------------------
                  } ; [End] if (HasAdminRights == 1)
                  else ; No Admin Rights
                  {
                    ; -------------------------------------------
                    PassOK := 0
                    ; -------------------------------------------
                    RegRead, UserPictureFolder, HKEY_CURRENT_USER, Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders, My Pictures
                    ArrayIn := [KeyMnu_ProcessPathExtName, "", "", UserLang, UserPictureFolder]
                    FileError460 := Img_Error460(ArrayIn)
                    ; -------------------------------------------
                    ;
                    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (460)(Splash Error: [App Logo Image] Application is NOT Active)
                    SplashImage, Off
                    SplashImage, %Error460%, b
                    Sleep, 1500
                    SplashImage, Off
                    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (460)(Splash Error: [App Logo Image] Application is NOT Active)
                  } ; [End] No Admin Rights
                } ; [End] Application Does (Exist), Application NOT (Active)
              } ; [End] else if (Key_ShortcutInAppPum == 1) ; key Shortcut From App Pum
              ; -------------------------------------------
            } ; [End] if (Var_Exist != "0x0") ; Application Does (Exist), CHECK (Active)
            ; -------------------------------------------
            else if (ErrorLevel == 0) ; Window (NOT Exist)
            {
              ; -------------------------------------------
              PassOK := 0
              ; -------------------------------------------
              RegRead, UserPictureFolder, HKEY_CURRENT_USER, Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders, My Pictures
              ArrayIn := [KeyMnu_ProcessPathExtName, "", "", UserLang, UserPictureFolder]
              FileError470 := Img_Error470(ArrayIn)
              ; -------------------------------------------
              ;
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (470)(Splash Error: [App Logo Image] Application is NOT Open)
              SplashImage, Off
              SplashImage, %Error470%, b
              Sleep, 1500
              SplashImage, Off
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (470)(Splash Error: [App Logo Image] Application is NOT Open)
            } ; [End] else ; Window (NOT Exist)
            ; -------------------------------------------
          } ; [End] Not Windows Explorer
          ; -------------------------------------------
        } ; End (Obj_KeyMnu_AppOnly_Sel == 2)
        ; -------------------------------------------
      } ; (Script Type) (key)
      ; -------------------------------------------
      else if (Script_Type == "mnu") ; (Script Type)
      {
        ; -------------------------------------------
        ;
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (mnu)
        ; Script_Line_2 := ["[Key]", "~X~"]           (119_1)(Mkb_KeyStroke)
        ; Script_Line_3 := "Com_####" or "Mkb_####"   (302_8)(Mnu_ComNum [Com_#### Used for Icon and Link/ahk Name])
        ; Script_Line_4 := "App Class"                (301_5)(KeyMnu_Class)
        ; Script_Line_5 := "KeyMnu_ProcessExtName"    (301)(09)(KeyMnu_ProcessExtName)
        ; Script_Line_6 := "Lang"                     (365_2)(UserLang [Current User language])
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (mnu)
        ;
        ; -------------------------------------------
        Mkb_KeyStroke         := Script_Line_2
        Mnu_ComNum            := Script_Line_3
        KeyMnu_Class          := Script_Line_4
        KeyMnu_ProcessExtName := Script_Line_5
        Script_UserLang       := Script_Line_6
        ; -------------------------------------------
        ;
        ; -------------------------------------------
        if (InStr(Mnu_ComNum, "Com_") > 0)
        {
          ; -------------------------------------------
          KeyMnu_ProcessName := SubStr(KeyMnu_ProcessExtName, 1, StrLen(KeyMnu_ProcessExtName) - 4)
          StringLower, Lower_KeyMnu_ProcessName, KeyMnu_ProcessName
          Mnu_ShortcutScript := A_ProgramFiles "\PopUpMenu_PUM\menu\mnu\" Lower_KeyMnu_ProcessName "\" Script_UserLang "\com\" Mnu_ComNum ".ahk" ; (301_6)([key][mnu] [Line 5] Application Only Process [NO Ext] [NO Path])/(365_2)(Current User language)
          ; -------------------------------------------
          if !FileExist(Mnu_ShortcutScript)
          {
            ; -------------------------------------------
            PassOK := 0
            ; -------------------------------------------
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (436_1)(Splash Error Image File: (mnu,cpl) Link Not Found)
            ; (436)(01)(Splash Error Image File: mnu-*.ahk or cpl-*.ahk Not Found)
            Splash_Image := A_ProgramFiles "\PopUpMenu_PUM\image\gui\(444)_" UserLang ".png"
            SplashImage, %Splash_Image%, b
            Sleep, 1500
            SplashImage, Off
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (436_1)(Splash Error Image File: (mnu,cpl) Link Not Found)
          } ; [End] if !FileExist(Mnu_ShortcutScript)
          ; -------------------------------------------
        } ; [End] if (InStr(Mnu_ComNum, "Com_") > 0)
        ; -------------------------------------------
        if (PassOK == 1)
        {
          ; -------------------------------------------
          Process, Exist, %KeyMnu_ProcessExtName%
          if (ErrorLevel != 0) ; Application Does (Exist), CHECK (Active)
          {
            ; -------------------------------------------
            CheckClass := "ahk_class " KeyMnu_Class
            Var_Exist  := WinActive(CheckClass)
            ; -------------------------------------------
            if (Var_Exist == "0x0") ; Application Does (Exist), Application NOT (Active)
            {
              ; -------------------------------------------
              PassOK := 0
              ; -------------------------------------------
              RegRead, UserPictureFolder, HKEY_CURRENT_USER, Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders, My Pictures
              ArrayIn := [KeyMnu_ProcessPathExtName, "", "", UserLang, UserPictureFolder]
              FileError460 := Img_Error460(ArrayIn)
              ; -------------------------------------------
              ;
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (460)(Splash Error: [App Logo Image] Application is NOT Active)
              SplashImage, Off
              SplashImage, %Error460%, b
              Sleep, 1500
              SplashImage, Off
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (460)(Splash Error: [App Logo Image] Application is NOT Active)
            } ; [End] if (Var_WinActive == "0x0") ; Application Does (Exist), Application NOT (Active)
            ; -------------------------------------------
          } ; [End] if (Var_Exist != "0x0") ; Application Does (Exist), CHECK (Active)
          ; -------------------------------------------
          else if (ErrorLevel == 0) ; Window (NOT Exist)
          {
            ; -------------------------------------------
            PassOK := 0
            ; -------------------------------------------
            RegRead, UserPictureFolder, HKEY_CURRENT_USER, Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders, My Pictures
            ArrayIn := [KeyMnu_ProcessPathExtName, "", "", UserLang, UserPictureFolder]
            FileError470 := Img_Error470(ArrayIn)
            ; -------------------------------------------
            ;
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (470)(Splash Error: [App Logo Image] Application is NOT Open)
            SplashImage, Off
            SplashImage, %Error470%, b
            Sleep, 1500
            SplashImage, Off
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (470)(Splash Error: [App Logo Image] Application is NOT Open)
          } ; [End] else ; Window (NOT Exist)
        } ; [End] if (PassOK == 1)
      } ; (Script Type) (mnu)
      ; -------------------------------------------
      else if (Script_Type == "ofl") ; (Script Type)
      {
        ; -------------------------------------------
        ;
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (ofl)
        ; Script_Line_2 := ""                         *** EMPTY ***
        ; Script_Line_3 := "x:\Folder"                (303_2)(ofl_FolderPathName [Folder Name With Path])
        ; Script_Line_4 := ""                         *** EMPTY ***
        ; Script_Line_5 := ""                         *** EMPTY ***
        ; Script_Line_6 := ""                         *** EMPTY ***
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (ofl)
        ;
        ; -------------------------------------------
        ofl_FolderPathName := Script_Line_3
        ; -------------------------------------------
        ;
        FolderExist := FileExist(ofl_FolderPathName)
        if (FolderExist == "")
        {
          FolderExist := 0
        }
        else
        {
          FolderExist := 1
        }
        ; -------------------------------------------
        if (FolderExist == 0) ; (303_2)([ofl] Folder Path)
        {
          ; -------------------------------------------
          PassOK := 0
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (406_1)(Splash Error File: Folder Not Found)
          SplashImage, Off
          Splash_Image := A_ProgramFiles "\PopUpMenu_PUM\image\gui\(406)_" UserLang ".png" ; (365_2)(Current User language)
          SplashImage, %Splash_Image%, b
          Sleep, 1500
          SplashImage, Off
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (406_1)(Splash Error File: Folder Not Found)
        } ; End (303_2)([ofl] Folder Path) [Not Exist]
      } ; (Script Type) (ofl)
      ; -------------------------------------------
      else if (Script_Type == "run") ; (Script Type)
      {
        ; -------------------------------------------
        ;
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (run)
        ; Script_Line_2 := 0/1/2                      (073_2)(Obj_Run_AsAdmin_Sel [0,1,2])
        ; Script_Line_3 := "x:\Executable.ext"        (305_11)(run_OutTarget [FullPath])
        ; Script_Line_4 := "run_Arguments"            (305_12)(run_Arguments [Executable Arguments])
        ; Script_Line_5 := 0/1                        (305_13)(run_UseLink [Selected OutTarget File Is a LNK] [0/1])
        ; Script_Line_6 := ""                         (Empty)
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (run)
        ;
        ; -------------------------------------------
        Obj_Run_AsAdmin_Sel := Script_Line_2
        run_OutTarget       := Script_Line_3
        run_Arguments       := Script_Line_4
        ; -------------------------------------------
        ;
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ; Obj_Run_AsAdmin_Sel, Default is (1)(run as User)
        ; -------------------------------------------
        if (Obj_Run_AsAdmin_Sel != 0 && Obj_Run_AsAdmin_Sel != 1 && Obj_Run_AsAdmin_Sel != 2) ; (073_2)(Obj_Run_AsAdmin_Sel [0,1,2])
        {
          ; -------------------------------------------
          ; Obj_Run_AsAdmin_Sel = 0 (Hide Object)
          ; Obj_Run_AsAdmin_Sel = 1 (run as User)
          ; Obj_Run_AsAdmin_Sel = 2 (run as Admin)
          ; -------------------------------------------
          Obj_Run_AsAdmin_Sel := 1 ; (073_2)(Obj_Run_AsAdmin_Sel [0,1,2])
        }
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ;
        ;
        ; -------------------------------------------
        if !FileExist(run_OutTarget)
        {
          ; -------------------------------------------
          PassOK := 0
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (429_1)(Splash Error File: Application Not Found)
          SplashImage, Off
          Splash_Image := A_ProgramFiles "\PopUpMenu_PUM\image\gui\(429)_" UserLang ".png" ; (365_2)(Current User language)
          SplashImage, %Splash_Image%, b
          Sleep, 1500
          SplashImage, Off
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (429_1)(Splash Error File: Application Not Found)
        }
      } ; (Script Type) (run)
      ; -------------------------------------------
      else if (Script_Type == "rwh") ; (Script Type)
      {
        ; -------------------------------------------
        ;
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (rwh)
        ; Script_Line_2 := 1/2                        (073_2)(Obj_Run_AsAdmin_Sel [0,1,2])
        ; Script_Line_3 := "x:\File.ext"              (305_4)(Run_FilePathNameExt [Selected File] [Path,Name,Ext])
        ; Script_Line_4 := "x:\Executable.ext"        (305_5)(Rwh_OpeningApp [Full File Path])
        ; Script_Line_5 := ""                         *** EMPTY ***
        ; Script_Line_6 := ""                         *** EMPTY ***
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (rwh)
        ;
        ; -------------------------------------------
        Obj_Run_AsAdmin_Sel := Script_Line_2 ; (073_2)([run] As Admin: Select [0]Hide/[1]Nor/[2]Sel)
        Run_FilePathNameExt := Script_Line_3 ; (305_4)([run] Selected File [File Name] [File Ext] [File Path])
        Rwh_OpeningApp      := Script_Line_4 ; (305_5)([rwh] Selected Opening Application [Full File Path])
        ; -------------------------------------------
        ;
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ; Obj_Run_AsAdmin_Sel, Default is (1)(run as User)
        ; -------------------------------------------
        if (Obj_Run_AsAdmin_Sel != 0 && Obj_Run_AsAdmin_Sel != 1 && Obj_Run_AsAdmin_Sel != 2) ; (073_2)(Obj_Run_AsAdmin_Sel [0,1,2])
        {
          ; -------------------------------------------
          ; Obj_Run_AsAdmin_Sel = 0 (Hide Object)
          ; Obj_Run_AsAdmin_Sel = 1 (run as User)
          ; Obj_Run_AsAdmin_Sel = 2 (run as Admin)
          ; -------------------------------------------
          Obj_Run_AsAdmin_Sel := 1 ; (073_2)(Obj_Run_AsAdmin_Sel [0,1,2])
        }
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ;
        if !FileExist(Run_FilePathNameExt) ; (305_4)([run] Selected File [File Name] [File Ext] [File Path])
        {
          ; -------------------------------------------
          PassOK := 0
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (411_1)(Splash Error File: File Not Found)
          SplashImage, Off
          Splash_Image := A_ProgramFiles "\PopUpMenu_PUM\image\gui\(411)_" UserLang ".png" ; (365_2)(Current User language)
          SplashImage, %Splash_Image%, b
          Sleep, 1500
          SplashImage, Off
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (411_1)(Splash Error File: File Not Found)
        } ; End (305_4)([File Name] [File Ext] [File Path]) [Not Exist]
        else if !FileExist(Rwh_OpeningApp) ; (305_5)([rwh] Selected Opening Application [Full File Path])
        {
          ; -------------------------------------------
          PassOK := 0
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (421_1)(Splash Error File: Application to Open File Not Found)
          SplashImage, Off
          Splash_Image := A_ProgramFiles "\PopUpMenu_PUM\image\gui\(421)_" UserLang ".png" ; (365_2)(Current User language)
          SplashImage, %Splash_Image%, b
          Sleep, 1500
          SplashImage, Off
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (421_1)(Splash Error File: Application to Open File Not Found)
        } ; End (305_5)(Selected Opening Application [Full File Path]) [Not Exist]
        ; -------------------------------------------
      } ; (Script Type) (rwh)
      ; -------------------------------------------
      else if (Script_Type == "url") ; (Script Type)
      {
        ; -------------------------------------------
        ;
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (url)
        ; Script_Line_2 := "Browser Name from Title"  (307_11)(Url_BrowserTitle [Browser Name from Window Title])
        ; Script_Line_3 := "https://Site.com/"        (307_2)(Url_Address)
        ; Script_Line_4 :=                            *** EMPTY ***
        ; Script_Line_5 := 0/1                        (307_9)(Url_NewTab [Open URL Address in New Tab] [0/1])
        ; Script_Line_6 := "Web Page Title"           (307)(04)(Url_Title [Web Page Title])
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (url)
        ;
        ; -------------------------------------------
        Url_BrowserTitle       := Script_Line_2
        Url_Address            := Script_Line_3
        Url_NewTab             := Script_Line_5
        Url_Title              := Script_Line_6
        ; -------------------------------------------
        ;
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ; Url_NewTab, Default is (0)(Open in Same Tab)
        ; -------------------------------------------
        if (Url_NewTab != 1 && Url_NewTab != 2)
        {
          ; -------------------------------------------
          ; Url_NewTab = 0 (Open in Same Tab)
          ; Url_NewTab = 1 (Open in New Tab)
          ; -------------------------------------------
          Url_NewTab := 1 ; (307_9)(Url_NewTab [Open URL Address in New Tab] [0/1])
        } ; [End] if (Url_NewTab != 0 && Url_NewTab != 1)
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ;
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ; Remove ("/search") from (Url_Address)
        ; -------------------------------------------
        if (InStr(Url_Address, "/search" ,,, 1) > 0) ; (Url_Address) is a Search
        {
          Url_Pos := InStr(Url_Address, "/search" ,,, 1)
          Url_P1  := SubStr(Url_Address, 1, Url_Pos - 1)
          Url_P2  := SubStr(Url_Address, Url_Pos + 7)
          Url_Address := Url_P1 "`/" Url_P2
        } ; [End] if (InStr(Url_Address, "/search" ,,, 1) > 0) ; (Url_Address) is a Search
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ;
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ; Remove and (") from (Url_Address)
        Url_Address := StrReplace(Url_Address, """", "")
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ;
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ; Check Internet Connection
        ; -------------------------------------------
        flag=0x40
        HasInternet := DllCall("Wininet.dll\InternetGetConnectedState", "Str", flag,"Int",0) 
        ; -------------------------------------------
        if (HasInternet == 0) ; (427)(Splash Error Image File: No Internet Connection)
        {
          PassOK := 0
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (427)(Splash Error Image File: No Internet Connection)
          SplashImage, Off
          Splash_Image := A_ProgramFiles "\PopUpMenu_PUM\image\gui\(427)_" UserLang ".png"
          SplashImage, %Splash_Image%, b
          Sleep, 1500
          SplashImage, Off
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (427)(Splash Error Image File: No Internet Connection)
        } ; if (HasInternet == 0) ; (427)(Splash Error Image File: No Internet Connection)
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      } ; (Script Type) (url)
      ; -------------------------------------------
    } ; End [CHECK] Shortcut Errors
    ; ------------------------------------------
    if (PassOK == 1)
    {
      ; -------------------------------------------
      if (Script_Type == "cpl") ; (Script Type)
      {
        ; -------------------------------------------
        ;
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (cpl)
        ; Script_Line_2 := "Com_####"                 (300_8)(Cpl_ComNum [Com_#### Used for Icon and Link/ahk Name])
        ; Script_Line_3 := ""                         *** EMPTY ***
        ; Script_Line_4 := ""                         *** EMPTY ***
        ; Script_Line_5 := ""                         *** EMPTY ***
        ; Script_Line_6 := ""                         *** EMPTY ***
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (cpl)
        ;
        ; -------------------------------------------
        Run, %Cpl_ShortcutScript%
        ; -------------------------------------------
      } ; End (Script Type) (cpl)
      ; -------------------------------------------
      else if (Script_Type == "key") ; (Script Type)
      {
        ; -------------------------------------------
        ;
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (key)
        ; Script_Line_2 := 1/2                        (072_2)(Obj_KeyMnu_AppOnly_Sel [0,1,2])
        ; Script_Line_3 := ["[Key]", "~X~"]           (301_8)(Key_KeyArrayShortcut [Array])
        ; Script_Line_4 := "App Class"                (301_5)(KeyMnu_Class)
        ; Script_Line_5 := "App ProcessName"          (301_6)(KeyMnu_ProcessName)
        ; Script_Line_6 := ""                         *** EMPTY ***
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (key)
        ;
        ; -------------------------------------------
        for Index, ThisItem in Key_KeyArrayShortcut ; (301_8)([key] Key_KeyArrayShortcut [Array])
        {
          ; -------------------------------------------
          { ; [SET] KeyType (KEY -or- TEXT)
            CheckThis := SubStr(ThisItem, 1, 1)
            if (CheckThis == "[")
            {
              KeyType := "KEY"
            } ; End (CheckThis == "[")
            else if (CheckThis == "~")
            {
              KeyType := "TEXT"
            } ; End (CheckThis == "~")
            ThisKey := SubStr(ThisItem, 2, StrLen(ThisItem) - 2) 
            if (KeyType == "KEY")
            {
              Sleep, 1
              Send, {%ThisKey%}
            } ; End (KeyType == "KEY")
            else if (KeyType == "TEXT")
            {
              Sleep, 1
              Send, %ThisKey%
            } ; End (KeyType == "TEXT")
            ; -------------------------------------------
          } ; End [SET] KeyType (KEY -or- TEXT)
          ; -------------------------------------------
        } ; (301_8)([key] Key_KeyArrayShortcut [Array])
        ; -------------------------------------------
      } ; (Script Type) (key)
      ; ------------------------------------------
      else if (Script_Type == "mnu") ; (Script Type)
      {
        ; -------------------------------------------
        ;
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (mnu)
        ; Script_Line_2 := ["[Key]", "~X~"]           (119_1)(Mkb_KeyStroke)
        ; Script_Line_3 := "Com_####" or "Mkb_####"   (302_8)(Mnu_ComNum [Com_#### Used for Icon and Link/ahk Name])
        ; Script_Line_4 := "App Class"                (301_5)(KeyMnu_Class)
        ; Script_Line_5 := "App ProcessName"          (301_6)(KeyMnu_ProcessName)
        ; Script_Line_6 := "Lang"                     (365_2)(UserLang [Current User language])
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (mnu)
        ;
        if (InStr(Mnu_ComNum, "Mkb_") > 0)
        {
          for Index, ThisItem in Mkb_KeyStroke
          {
            ; -------------------------------------------
            StringLower, ThisItem, ThisItem
            ; -------------------------------------------
            CheckThis := SubStr(ThisItem, 1, 1)
            if (CheckThis == "[")
            {
              KeyType := "KEY"
            } ; End (CheckThis == "[")
            else if (CheckThis == "~")
            {
              KeyType := "TEXT"
            } ; End (CheckThis == "~")
            ; -------------------------------------------
            ThisKey := SubStr(ThisItem, 2, StrLen(ThisItem) - 2) 
            ; -------------------------------------------
            if (KeyType == "KEY")
            {
              Sleep, 1
              Send, {%ThisKey%}
            } ; End (KeyType == "KEY")
            else if (KeyType == "TEXT")
            {
              Sleep, 1
              Send, %ThisKey%
            } ; End (KeyType == "TEXT")
            ; -------------------------------------------
          } ; [End] for Index, ThisItem in Mkb_KeyStroke
          ; -------------------------------------------
        } ; [End] if (InStr(Mnu_ComNum, "Mkb_") > 0)
        else ; NOT a Mkb keystroke
        {
          ; -------------------------------------------
          Run, %Mnu_ShortcutScript%
          ; -------------------------------------------
        } ; [End] else ; NOT a Mkb keystroke
        ; -------------------------------------------
      } ; (Script Type) (mnu)
      ; -------------------------------------------
      else if (Script_Type == "ofl") ; (Script Type)
      {
        ; -------------------------------------------
        ;
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (ofl)
        ; Script_Line_2 := ""                         *** EMPTY ***
        ; Script_Line_3 := "x:\Folder"                (303_2)(ofl_FolderPathName [Folder Name With Path])
        ; Script_Line_4 := ""                         *** EMPTY ***
        ; Script_Line_5 := ""                         *** EMPTY ***
        ; Script_Line_6 := ""                         *** EMPTY ***
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (ofl)
        ;
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ; For Application File Select
        ; -------------------------------------------
        ThisActiveClass := ""
        WinGetClass, ThisActiveClass, A
        WinGetTitle, ThisActiveTitle, A
        StringLower, ThisActiveTitle, ThisActiveTitle
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ;
        ; -------------------------------------------
        if ((InStr(ThisActiveTitle, "open") > 0 or InStr(ThisActiveTitle, "save") > 0 or InStr(ThisActiveTitle, "load") > 0) && ThisActiveClass == "#32770" && InStr(ThisActiveTitle, "Internet Download Manager") == 0) ; Application File Select is Active
        {
          if (Script_Line_3 != "")
          {
            OldClip := Clipboard
            Sleep, 100
            Clipboard :=
            Sleep, 100
            Clipboard := Script_Line_3
            ClipWait, 1, 1
            Sleep, 50
            Send, {Ctrl Down}l{Ctrl Up}
            Sleep, 150
            Send, {Ctrl Down}v{Ctrl Up}
            Sleep, 50
            Send, {Enter}
            Sleep, 50
            Clipboard := OldClip
          }
        }
        else if WinExist("ahk_class CabinetWClass")
        {
          ; -------------------------------------------
          WinActivate, ahk_class CabinetWClass
          WinWaitActive, ahk_class CabinetWClass
          ; -------------------------------------------
          if (Script_Line_3 != "")
          {
            OldClip := Clipboard
            Sleep, 100
            Clipboard :=
            Sleep, 100
            Clipboard := Script_Line_3
            ClipWait, 1, 1
            Sleep, 50
            Send, {Ctrl Down}l{Ctrl Up}
            Sleep, 150
            Send, {Ctrl Down}v{Ctrl Up}
            Sleep, 50
            Send, {Enter}
            Sleep, 50
            Clipboard := OldClip
          }
        }
        else
        {
          WinExplorer := A_WinDir "\explorer.exe"
          RunThis := """" WinExplorer """ """ Script_Line_3 """"
          RunWait, %RunThis%
        }
        ; -------------------------------------------
      } ; End (Script_Type == "ofl")
      ; -------------------------------------------
      else if (Script_Type == "run") ; (Script Type)
      {
        ; -------------------------------------------
        ;
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (run)
        ; Script_Line_2 := 0/1/2                      (073_2)(Obj_Run_AsAdmin_Sel [0,1,2])
        ; Script_Line_3 := "x:\Executable.ext"        (305_11)(run_OutTarget [FullPath])
        ; Script_Line_4 := "run_Arguments"            (305_12)(run_Arguments [Executable Arguments])
        ; Script_Line_5 := 0/1                        (305_13)(run_UseLink [Selected OutTarget File Is a LNK] [0/1])
        ; Script_Line_6 := ""                         (Empty)
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (run)
        ;
        ; -------------------------------------------
        WinGetTitle, ActiveWindow_Title, A
        WinGetClass, ActiveWindow_Class, A
        ; -------------------------------------------
        SplitPath, run_OutTarget, Target_ExtName
        ; -------------------------------------------
        Var_Exist := WinExist("ahk_exe" . Target_ExtName)
        ; -------------------------------------------
        ;
        ; -------------------------------------------
        if (Target_ExtName == "chrome.exe" && ActiveWindow_Title != "temp") ; msedge Running in Background
        {
          Var_Exist := "0x0"
        } ; msedge Running in Background
        ; -------------------------------------------
        ;
        ; -------------------------------------------
        if (Target_ExtName == "msedge.exe" && Var_Exist != "0x0") ; msedge Running in Background
        {
          Check_Title := "Microsoft​ Edge"
          SetTitleMatchMode, 2
          if !WinExist(Check_Title)
          {
            Var_Exist := "0x0"
          }
        } ; msedge Running in Background
        ; -------------------------------------------
        ;
        ; -------------------------------------------
        ; "0x0" Means Not Exist
        if (Var_Exist != "0x0") ; NOT "0x0" Means Window (Exist), CHECK (Active)
        {
          ; -------------------------------------------
          Var_WinActive := WinActive("ahk_exe" . Target_ExtName)
          ; -------------------------------------------
          ; "0x0" Means Not Active
          if (Var_WinActive != "0x0") ; NOT "0x0" Means Window is (Active)
          {
            ; -------------------------------------------
            RegRead, UserPictureFolder, HKEY_CURRENT_USER, Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders, My Pictures
            ArrayIn := [run_OutTarget, "", "", UserLang, UserPictureFolder]
            FileError440 := Img_Error440(ArrayIn)
            ; -------------------------------------------
            ;
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ ; (440)(Splash Error Image File: Application is Active)
            SplashImage, Off
            SplashImage, %FileError440%, b
            Sleep, 1500
            SplashImage, Off
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ ; (440)(Splash Error Image File: Application is Active)
          } ; [End] if (Var_WinActive != "0x0") ; (Exist) (Active)
          else if (Var_WinActive == "0x0")  ; "0x0" Means Window is NOT (Active)
          {
            ; -------------------------------------------
            HasAdminRights := A_IsAdmin
            ; -------------------------------------------
            if (HasAdminRights == 1)
            {
              ; -------------------------------------------
              ScriptWinActivate := A_AppData "\PopUpMenu_PUM\temp\ScriptWinActivate.ahk"
              if FileExist(ScriptWinActivate)
              {
                FileDelete, %ScriptWinActivate%
              }
              ; -------------------------------------------
              Sleep, 100
              Line_1 := "`#NoEnv"
              Line_2 := "`#MaxHotkeysPerInterval 99000000"
              Line_3 := "`#HotkeyInterval 99000000"
              Line_4 := "`#KeyHistory 0"
              Line_5 := "ListLines Off"
              Line_6 := "Process, Priority, , A"
              Line_7 := "SetBatchLines, -1"
              Line_8 := "SetKeyDelay, -1, -1"
              Line_9 := "SetMouseDelay, -1"
              Line_10 := "SetDefaultMouseSpeed, 0"
              Line_11 := "SetWinDelay, -1"
              Line_12 := "SetControlDelay, -1"
              Line_13 := "SendMode Input"
              Line_14 := "WinActivate`, ahk_exe " Target_ExtName
              ; -------------------------------------------
              FileEncoding, UTF-8 ; UTF-8
              FileAppend, %Line_1%`n, %ScriptWinActivate% ; UTF-8
              FileAppend, %Line_2%`n, %ScriptWinActivate% ; UTF-8
              FileAppend, %Line_3%`n, %ScriptWinActivate% ; UTF-8
              FileAppend, %Line_4%`n, %ScriptWinActivate% ; UTF-8
              FileAppend, %Line_5%`n, %ScriptWinActivate% ; UTF-8
              FileAppend, %Line_6%`n, %ScriptWinActivate% ; UTF-8
              FileAppend, %Line_7%`n, %ScriptWinActivate% ; UTF-8
              FileAppend, %Line_8%`n, %ScriptWinActivate% ; UTF-8
              FileAppend, %Line_9%`n, %ScriptWinActivate% ; UTF-8
              FileAppend, %Line_10%`n, %ScriptWinActivate% ; UTF-8
              FileAppend, %Line_11%`n, %ScriptWinActivate% ; UTF-8
              FileAppend, %Line_12%`n, %ScriptWinActivate% ; UTF-8
              FileAppend, %Line_13%`n, %ScriptWinActivate% ; UTF-8
              FileAppend, %Line_14%`n, %ScriptWinActivate% ; UTF-8
              ; -------------------------------------------
              BreakTime := A_TickCount + 2000
              while !FileExist(ScriptWinActivate)
              {
                if (A_TickCount > BreakTime)
                {
                  break
                }
                Sleep, 100
              }
              ; -------------------------------------------
              if WinExist("ahk_exe" . Target_ExtName)
              {
                WinActivate
              }
              ; -------------------------------------------
              if FileExist(ScriptWinActivate)
              {
                FileDelete, %ScriptWinActivate%
              }
              ; -------------------------------------------
            } ; [End] if (HasAdminRights == 1)
            else ; User Does NOT Have Admin Rights
            {
              ; -------------------------------------------
              RegRead, UserPictureFolder, HKEY_CURRENT_USER, Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders, My Pictures
              ArrayIn := [run_OutTarget, "", "", UserLang, UserPictureFolder]
              FileError450 := Img_Error450(ArrayIn)
              ; -------------------------------------------
              ;
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ ; (440)(Splash Error Image File: Application is Open)
              SplashImage, Off
              SplashImage, %Error450%, b
              Sleep, 1500
              SplashImage, Off
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ ; (440)(Splash Error Image File: Application is Open)
            }
            ; -------------------------------------------
          } ; [End] else ; Window (Exist) (NOT Active)
          ; -------------------------------------------
        } ; [End] if (Var_Exist != "0x0") ; Window (Exist) CHECK (Active)
        ; -------------------------------------------
        else ; "0x0" Means Window Does (NOT Exist)
        {
          ; -------------------------------------------
          if (Obj_Run_AsAdmin_Sel == 2)
          {
            if (run_Arguments == "")
            {
              
              ShellRun(run_OutTarget, , , "RunAs") ; Application, Arguments, Working Directory, "RunAs"
            }
            else
            {
              ShellRun(run_OutTarget, run_Arguments, , "RunAs") ; Application, Arguments, Working Directory, "RunAs"
            }
          } ; End (Obj_Run_AsAdmin_Sel == 2)
          else ; (Obj_Run_AsAdmin_Sel != 2)
          {
            if (run_Arguments == "")
            {
              ShellRun(run_OutTarget) ; Application, Arguments, Working Directory, "RunAs"
            }
            else
            {
              ShellRun(run_OutTarget, run_Arguments) ; Application, Arguments, Working Directory, "RunAs"
            }
          } ; End (Obj_Run_AsAdmin_Sel != 2)
          ; -------------------------------------------
        } ; [End] else ; Window (NOT Exist)
        ; -------------------------------------------
      } ; (Script Type) (run)
      ; -------------------------------------------
      else if (Script_Type == "rwh") ; (Script Type)
      {
        ; -------------------------------------------
        ;
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (rwh)
        ; Script_Line_2 := 1/2                        (073_2)(Obj_Run_AsAdmin_Sel [0,1,2])
        ; Script_Line_3 := "x:\File.ext"              (305_4)(Run_FilePathNameExt [Selected File] [Path,Name,Ext])
        ; Script_Line_4 := "x:\Executable.ext"        (305_5)(Rwh_OpeningApp [Full File Path])
        ; Script_Line_5 := ""                         *** EMPTY ***
        ; Script_Line_6 := ""                         *** EMPTY ***
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (rwh)
        ;
        ; -------------------------------------------
        ; SplitPath, InputVar, OutFileName, OutDir, OutExtension, OutNameNoExt, OutDrive
        SplitPath,  Run_FilePathNameExt, Rwh_FileName,, Rwh_FileExt
        StringLower, Rwh_FileExt, Rwh_FileExt
        ; -------------------------------------------
        SetTitleMatchMode, 2
        if WinExist(Rwh_FileName) ; Rwh_FileName is Open in a Window
        {
          ; -------------------------------------------
          SplitPath, Rwh_FileName, , , Rwh_FileName_Extension
          if (Rwh_FileName_Extension == "ahk") ; This is a script
          {
            ; -------------------------------------------
            if (Obj_Run_AsAdmin_Sel == 2) ; (073_2)([run] As Admin: Select [0]Hide/[1]Nor/[2]Sel)
            {
              ; -------------------------------------------
              Rwh_OpeningApp := """" Rwh_OpeningApp """" ; (305_5)([rwh] Selected Opening Application [Full File Path])
              Run_FilePathNameExt := """" Run_FilePathNameExt """" ; (305_4)([run] Selected File [File Name] [File Ext] [File Path])
              ; -------------------------------------------
              ShellRun(Rwh_OpeningApp, Run_FilePathNameExt, , "RunAs") ; Application, Arguments, Working Directory, "RunAs"
              ; -------------------------------------------
            } ; (073_2)([run] As Admin: Select [0]Hide/[1]Nor/[2]Sel)
            else
            {
              ; -------------------------------------------
              Rwh_OpeningApp := """" Rwh_OpeningApp """" ; (305_5)([rwh] Selected Opening Application [Full File Path])
              Run_FilePathNameExt := """" Run_FilePathNameExt """" ; (305_4)([run] Selected File [File Name] [File Ext] [File Path])
              ; -------------------------------------------
              ShellRun(Rwh_OpeningApp, Run_FilePathNameExt) ; Application, Arguments, Working Directory, "RunAs"
              ; -------------------------------------------
            } ; End else
            ; -------------------------------------------
          } ; if (Rwh_FileName_Extension == "ahk")
          else
          {
            ; -------------------------------------------
            WinActivate, %Rwh_FileName%
            ; -------------------------------------------
          }
        } ; End Rwh_FileName is Open in a Window
        else ; Rwh_FileName IS NOT Open in a Windows
        {
          ; -------------------------------------------
          if (Obj_Run_AsAdmin_Sel == 2) ; (073_2)([run] As Admin: Select [0]Hide/[1]Nor/[2]Sel)
          {
            ; -------------------------------------------
            Rwh_OpeningApp := """" Rwh_OpeningApp """" ; (305_5)([rwh] Selected Opening Application [Full File Path])
            Run_FilePathNameExt := """" Run_FilePathNameExt """" ; (305_4)([run] Selected File [File Name] [File Ext] [File Path])
            ; -------------------------------------------
            ShellRun(Rwh_OpeningApp, Run_FilePathNameExt, , "RunAs") ; Application, Arguments, Working Directory, "RunAs"
            ; -------------------------------------------
          } ; (073_2)([run] As Admin: Select [0]Hide/[1]Nor/[2]Sel)
          else
          {
            ; -------------------------------------------
            Rwh_OpeningApp := """" Rwh_OpeningApp """" ; (305_5)([rwh] Selected Opening Application [Full File Path])
            Run_FilePathNameExt := """" Run_FilePathNameExt """" ; (305_4)([run] Selected File [File Name] [File Ext] [File Path])
            ; -------------------------------------------
            ShellRun(Rwh_OpeningApp, Run_FilePathNameExt) ; Application, Arguments, Working Directory, "RunAs"
            ; -------------------------------------------
          } ; End else
          ; -------------------------------------------
        } ; End Rwh_FileName IS NOT Open in a Windows
        ; -------------------------------------------
      } ; (Script Type) (rwh)
      ; -------------------------------------------
      else if (Script_Type == "url") ; (Script Type)
      {
        ; -------------------------------------------
        ;
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (url)
        ; Script_Line_2 := "Browser Name from Title"  (307_11)(Url_BrowserTitle [Browser Name from Window Title])
        ; Script_Line_3 := "https://Site.com/"        (307_2)(Url_Address)
        ; Script_Line_4 :=                            *** EMPTY ***
        ; Script_Line_5 := 0/1                        (307_9)(Url_NewTab [Open URL Address in New Tab] [0/1])
        ; Script_Line_6 := "Web Page Title"           (307)(04)(Url_Title [Web Page Title])
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (url)
        ;
        ; -------------------------------------------
        /*
        FROM ABOVE
        Url_BrowserTitle       := Script_Line_2
        Url_Address            := Script_Line_3
        Url_NewTab             := Script_Line_5
        Url_Title              := Script_Line_6
        */
        ; -------------------------------------------
        ;
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ; Currently Active Internet Browser -OR- Default Internet Browser
        ; -------------------------------------------
        ; Get Current Process Information
        ; -------------------------------------------
        WinGet,    Url_BrowserPathNameExt, ProcessPath , A
        SplitPath, Url_BrowserPathNameExt, Url_BrowserNameExt, Url_BrowserFolder, , Url_BrowserName
        WinGet,    Url_BrowserPID, PID , A
        ; -------------------------------------------
        StringLower, Url_BrowserName, Url_BrowserName
        Url_BrowserName := StrReplace(Url_BrowserName, A_Space, "")
        ; -------------------------------------------
        if (Url_BrowserName != "avantvw" && Url_BrowserName != "brave" && Url_BrowserName != "browser" && Url_BrowserName != "chrome" && Url_BrowserName != "cyberfox" && Url_BrowserName != "dragon" && Url_BrowserName != "firefox" && Url_BrowserName != "waterfox" && Url_BrowserName != "icedragon" && Url_BrowserName != "iexplore" && Url_BrowserName != "iridium" && Url_BrowserName != "kingpinprivatebrowser" && Url_BrowserName != "k-meleon" && Url_BrowserName != "safari" && Url_BrowserName != "seamonkey" && Url_BrowserName != "slimboat" && Url_BrowserName != "slimbrowser" && Url_BrowserName != "slimjet" && Url_BrowserName != "spark" && Url_BrowserName != "maxthon" && Url_BrowserName != "msedge" && Url_BrowserName != "opera" && Url_BrowserName != "palemoon" && Url_BrowserName != "ucbrowser" && Url_BrowserName != "vivaldi" && Url_BrowserName != "waterfox")
        {
          ; -------------------------------------------
          MsEdgeIsActive := 0
          ; -------------------------------------------
          ; [GET] Default Browser
          ; -------------------------------------------
          RegRead, BrowserKeyName, HKEY_CURRENT_USER, Software\Microsoft\Windows\CurrentVersion\Explorer\FileExts\.html\UserChoice, Progid
          RegRead, BrowserFullCommand, HKEY_CLASSES_ROOT, %BrowserKeyName%\shell\open\command
          StringGetPos, pos, BrowserFullCommand, ",,1
          pos := --pos
          StringMid, Url_BrowserPathNameExt, BrowserFullCommand, 2, %pos%
          ; -------------------------------------------
        }
        ; -------------------------------------------
        ; Currently Active Internet Browser -OR- Default Internet Browser
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ;
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ; Activate Browser
        ; -------------------------------------------
        if WinExist("ahk_exe " Url_BrowserNameExt)
        {
          ; -------------------------------------------
          if (Url_BrowserName == "msedge") ; msedge Set to Default Browser
          {
            ; -------------------------------------------
            WinGetClass, ThisBrowserClass, A
            ; -------------------------------------------
            if (ThisBrowserClass != "Chrome_WidgetWin_1")
            {
              ShellRun(Url_BrowserPathNameExt) ; Application, Arguments, Working Directory, "RunAs"
            }
          }
          ; -------------------------------------------
          SetTitleMatchMode, 2 ; 2 =  A window's title can contain WinTitle anywhere inside it to be a match
          WinWait, ahk_exe %Url_BrowserNameExt%
          ; -------------------------------------------
          ;
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          if (Url_NewTab == 2) ; Open Url in New Tab
          {
            Send, {Ctrl Down}t{Ctrl Up}
            Sleep, 750
          } ; End Open Url in New Tab
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          ;
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          if (Url_BrowserName == "Safari")
          {
            ; -------------------------------------------
            OldClip := Clipboard
            sleep, 100
            Clipboard := Url_Address
            Sleep, 100
            ; -------------------------------------------
            Send, {Ctrl Down}l{Ctrl Up}
            Sleep, 250
            Send, {Ctrl Down}v{Ctrl Up}
            Sleep, 100
            Send, {Enter}
            Clipboard := OldClip
            ; -------------------------------------------
          }
          ; -------------------------------------------
          else if (Url_BrowserName == "avant")
          {
            ; -------------------------------------------
            OldClip := Clipboard
            sleep, 100
            Clipboard := Url_Address
            Sleep, 100
            ; -------------------------------------------
            Send, {Alt Down}d{Alt Up}
            Sleep, 250
            Send, {Ctrl Down}v{Ctrl Up}
            Sleep, 100
            Send, {Enter}
            Clipboard := OldClip
            ; -------------------------------------------
          }
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          else if (Url_BrowserName == "kingpinprivatebrowser")
          {
            ; -------------------------------------------
            Send, {Ctrl Down}d{Ctrl Up}
            Sleep, 250
            Send, %Url_Address%
            Sleep, 100
            Send, {Enter}
            Clipboard := OldClip
            ; -------------------------------------------
          }
          else
          {
            ; -------------------------------------------
            OldClip := Clipboard
            sleep, 100
            Clipboard := Url_Address
            Sleep, 100
            ; -------------------------------------------
            Send, {Ctrl Down}l{Ctrl Up}
            Sleep, 250
            Send, {Ctrl Down}v{Ctrl Up}
            Sleep, 100
            Send, {Enter}
            Clipboard := OldClip
            ; -------------------------------------------
          }
          ; -------------------------------------------
        }
        ; -------------------------------------------
        else ; Run URL with Default Internet Browser
        {
          ; -------------------------------------------
          ShellRun(Url_BrowserPathNameExt, Url_Address) ; Application, Arguments, Working Directory, "RunAs"
          ; -------------------------------------------
          ;
          ; -------------------------------------------
          SetTitleMatchMode, 2 ; 2 =  A window's title can contain WinTitle anywhere inside it to be a match
          WinWait, ahk_exe %Url_BrowserNameExt%
          ; -------------------------------------------
          if (Url_BrowserTitle == "FlashPeak SlimBrowser")
          {
            ; -------------------------------------------
            ; "slimbrowser" May have a update window Active
            ; -------------------------------------------
            BreakTime := A_TickCount + 3000
            while (!WinActive(Ck_AhkExe) && A_TickCount < BreakTime)
            {
              Sleep, 250
            }
            if WinExist("Check Update" . "ahk_class MozillaDialogClass")
            {
              Send, {Esc}
            }
          } ; [End] if (Url_BrowserTitle == "FlashPeak SlimBrowser")
          ; -------------------------------------------
        } ; [End] Window Does Not Exist, run it
        ; -------------------------------------------
        ; Activate Browser
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      } ; (Script Type) (url)
      ; -------------------------------------------
    } ; End No Shortcut Error
    ; -------------------------------------------
  } ; End Does NOT Exist Gui File Select
  ; -------------------------------------------
  ;
  ; -------------------------------------------
  ExitApp
  ; -------------------------------------------
} ; (Script Type)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; END OF FILE
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
