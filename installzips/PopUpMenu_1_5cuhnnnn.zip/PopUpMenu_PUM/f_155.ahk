﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\Sys_EnableDisable.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_GuiControl.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Pum_DisplayImageTxt.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
f_155(DataArray) ; (155_1)(Obj_Pum_BgText)
{
  ; -------------------------------------------
  global PumLock
  if (PumLock == "")
  {
    ; -------------------------------------------
    global PumLock := 0
    ; -------------------------------------------
  }
  ; -------------------------------------------
  if (PumLock == 0)
  {
    ; -------------------------------------------
    global PumLock := 1
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    if (DataArray.155.2 == "" or DataArray.155.2 == 1) ; (155_2)(Obj_Pum_BgText_Sel [0,1,2,3])
    {
      ; -------------------------------------------
      Sys_EnableDisable("Disable") ; "Enable" or "Disable"
      ; -------------------------------------------
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      DataArray := Image_GuiControl("004", 3, 0, DataArray) ; (004_1)(Obj_ok)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Hide/Stop (Animate) Pum_Building_Construct
      global s_521 := 0 ; Hide
      SetTimer, l_521, Off ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
      global ShowAnimationChange := 0
      ;
      DataArray := Image_GuiControl("137", 0, 0, DataArray) ; (137_1)(Obj_MsgImg480x270)
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Hide/Stop (Animate) Pum_Building_Construct
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      { ; [START UP]  Vars
        ; -------------------------------------------
        { ; [GET] Vars
          ; -------------------------------------------
          ThisPumProcessFolder := DataArray.361.8 ; (361)(8)(ThisPumProcessFolder [Pum Folder Path])
          ; -------------------------------------------
          Mobile_OnOff := DataArray.362.24 ; (362_24)(Pum_MobileTextOnOff [1 = On, 0 Off])
          ; -------------------------------------------
          XmlBgType := DataArray.362.28 ; (362_28)(XmlBgType [BG Image 1 / BG Trans 2])
          ; -------------------------------------------
        } ; End [GET] Vars
        ; -------------------------------------------
        Temp_Selected_Img := DataArray.362.33 ; (362_33)(Temp_Selected_Img [FilePath])
        ; -------------------------------------------
        Temp_Display_Txt_Col := ThisPumProcessFolder "\image\Temp_Display_Txt_Col.png" ; (361)(8)(Pum [Specific Folder Path])
        Temp_Display_Txt_Img := ThisPumProcessFolder "\image\Temp_Display_Txt_Img.png" ; (361)(8)(Pum [Specific Folder Path])
        ; -------------------------------------------
      } ; End [START UP] Vars
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; -------------------------------------------
      DataArray.366.5 := "pum_pumSetting_pumBgText" ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
      ; -------------------------------------------
      DataArray := Image_GuiControl("154", 1, 1, DataArray) ; (154_1)(Obj_Pum_BgImage)
      DataArray := Image_GuiControl("155", 2, 1, DataArray) ; (155_1)(Obj_Pum_BgText)
      DataArray := Image_GuiControl("156", 1, 1, DataArray) ; (156_1)(Obj_Pum_BgDim)
      ; -------------------------------------------
      if !FileExist(Temp_Selected_Img)
      {
        if FileExist(bg_Selected_img)
        {
          FileCopy, %bg_Selected_img%, %Temp_Selected_Img%, 1
          Sleep, 10
        }
      }
      if !FileExist(Temp_Selected_Img)
      {
        XmlBgType := 2 ; (362_28) (BG with Color 2)
        DataArray.362.28 := 2 ; if !FileExist(Temp_Selected_Img) (362_28)(XmlBgType [BG Image 1 / BG Trans 2])
      }
      ; -------------------------------------------
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      { ; Hide
        ; -------------------------------------------
        ; Hide [pumBgImage]
        DataArray := Image_GuiControl("165", 0, 1, DataArray) ; (165_1)(Obj_Pum_BgImageSelect)
        DataArray := Image_GuiControl("167", 0, 1, DataArray) ; (167_1)(Obj_Pum_BgFitImage)
        DataArray := Image_GuiControl("182", 0, 0, DataArray) ; (182_1)(Obj_Pum_BgRotateLeft)
        DataArray := Image_GuiControl("183", 0, 0, DataArray) ; (183_1)(Obj_Pum_BgRotateRight)
        DataArray := Image_GuiControl("241", 0, 0, DataArray) ; (241_1)(Obj_Pum_CropLeft)
        DataArray := Image_GuiControl("242", 0, 0, DataArray) ; (242_1)(Obj_Pum_CropRight)
        DataArray := Image_GuiControl("243", 0, 0, DataArray) ; (243_1)(Obj_Pum_CropUp)
        DataArray := Image_GuiControl("244", 0, 0, DataArray) ; (244_1)(Obj_Pum_CropDown)
        DataArray := Image_GuiControl("245", 0, 0, DataArray) ; (245_1)(Obj_Pum_CropCenter)
        DataArray := Image_GuiControl("246", 0, 0, DataArray) ; (246_1)(Obj_Pum_ZoomIn)
        DataArray := Image_GuiControl("247", 0, 0, DataArray) ; (247_1)(Obj_Pum_ZoomOut)
        ; -------------------------------------------
        ; Hide [pumBgText]
        GuiControl, PopUpMenu:Hide, g_164 ; (164_1)(Obj_Pum_BgTxtImg)
        DataArray := Image_GuiControl("166", 0, 1, DataArray) ; (166_1)(Obj_Pum_BgColor)
        DataArray := Image_GuiControl("172", 0, 1, DataArray) ; (172_1)(Obj_Pum_MobileText)
        DataArray := Image_GuiControl("173", 0, 1, DataArray) ; (173_1)(Obj_Pum_MobileTxtColor)
        DataArray := Image_GuiControl("174", 0, 1, DataArray) ; (174_1)(Obj_Pum_MobileBgColor)
        ; -------------------------------------------
        ; Hide [pumBgText] Tranparency (177)-(181)
        DataArray := Image_GuiControl("177", 0, 1, DataArray) ; (177_1)(Obj_Pum_BgTrans)
        DataArray := Image_GuiControl("178", 0, 0, DataArray) ; (178_1)(Obj_Pum_BgOpacityUp)
        DataArray := Image_GuiControl("179", 0, 0, DataArray) ; (179_1)(Obj_Pum_BgOpacityDown)
        DataArray := Image_GuiControl("180", 0, 0, DataArray) ; (180_1)(Obj_Pum_DisplayText_Opacity)
        DataArray := Image_GuiControl("181", 0, 0, DataArray) ; (181_1)(Obj_Pum_Opacity)
        ; -------------------------------------------
        ; Hide [pumBgText] Color Picker (291) - (238)
        Num_Hide := 190
        Loop 48
        {
          Num_Hide := Num_Hide + 1
          DataArray := Image_GuiControl(Num_Hide, 0, 0, DataArray) ; (166_1)(GUI Object: [pum] [pumBgColor])
        }
        ; -------------------------------------------
        ; Hide (Message Image 8)
        DataArray := Image_GuiControl("254", 0, 1, DataArray) ; (254_1)(Obj_MsgImg300x300)
        ; -------------------------------------------
        ; Hide [pumDimension]
        DataArray := Image_GuiControl("260", 0, 1, DataArray) ; (260_1)(Obj_Pum_IconSize)
        DataArray := Image_GuiControl("261", 0, 0, DataArray) ; (261_1)(Obj_Pum_IconUp)
        DataArray := Image_GuiControl("262", 0, 0, DataArray) ; (262_1)(Obj_Pum_IconDown)
        DataArray := Image_GuiControl("263", 0, 1, DataArray) ; (263_1)(Obj_Pum_ImageText_IconSize)
        DataArray := Image_GuiControl("266", 0, 1, DataArray) ; (266_1)(Obj_Pum_PumRow)
        DataArray := Image_GuiControl("267", 0, 0, DataArray) ; (267_1)(Obj_Pum_PumRowUp)
        DataArray := Image_GuiControl("268", 0, 0, DataArray) ; (268_1)(Obj_Pum_PumRowDown)
        DataArray := Image_GuiControl("269", 0, 1, DataArray) ; (269_1)(Obj_Pum_DisplayText_Vertical)
        DataArray := Image_GuiControl("272", 0, 1, DataArray) ; (272_1)(Obj_Pum_PumColumn)
        DataArray := Image_GuiControl("273", 0, 0, DataArray) ; (273_1)(Obj_Pum_PumColumnUp)
        DataArray := Image_GuiControl("274", 0, 0, DataArray) ; (274_1)(Obj_Pum_PumColumnDown)
        DataArray := Image_GuiControl("275", 0, 1, DataArray) ; (275_1)(Obj_Pum_DisplayText_Horizontal)
        ; -------------------------------------------
      } ; End Hide
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      { ; Show
        ; -------------------------------------------
        DataArray := Image_GuiControl("166", 1, 1, DataArray) ; (166_1)(Obj_Pum_BgColor)
        ; -------------------------------------------
        if FileExist(Temp_Selected_Img) ; [Has a Background Image]
        {
          if (XmlBgType == "1") ; (362_28)([pum][XML Line 19] Background type [BG with Image 1 / BG with Color 2])
          {
            DataArray := Image_GuiControl("164", 2, 1, DataArray) ; (164_1)(Obj_Pum_BgTxtImg)
          }
          else
          {
            DataArray := Image_GuiControl("164", 1, 1, DataArray) ; (164_1)(Obj_Pum_BgTxtImg)
          }
        } ; End [Does Not Have Image for Background]
        else if !FileExist(Temp_Selected_Img) ; [Does Not Have Image for Background]
        {
          DataArray := Image_GuiControl("164", 3, 1, DataArray) ; (164_1)(Obj_Pum_BgTxtImg)
        } ; End [Does Not Have Image for Background]
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        if (Mobile_OnOff == "1" ) ; (362_24)([pum][XML Line 17] [Mobile Text] [1 On / 0 Off])
        {
          ; (362_24)([pum][XML Line 17] [Mobile Text] [1 On / 0 Off])
          DataArray := Image_GuiControl("172", 2, 1, DataArray) ; (172_1)(Obj_Pum_MobileText)
          DataArray := Image_GuiControl("173", 1, 1, DataArray) ; (173_1)(Obj_Pum_MobileTxtColor)
          DataArray := Image_GuiControl("174", 1, 1, DataArray) ; (174_1)(Obj_Pum_MobileBgColor)
        }
        else if (Mobile_OnOff == "0") ; (362_24)([pum][XML Line 17] [Mobile Text] [1 On / 0 Off])
        {
          ; (362_24)([pum][XML Line 17] [Mobile Text] [1 On / 0 Off])
          DataArray := Image_GuiControl("172", 1, 1, DataArray) ; (172_1)(Obj_Pum_MobileText)
          DataArray := Image_GuiControl("173", 0, 1, DataArray) ; (173_1)(Obj_Pum_MobileTxtColor)
          DataArray := Image_GuiControl("174", 0, 1, DataArray) ; (174_1)(Obj_Pum_MobileBgColor)
        }
        ; -------------------------------------------
      } ; End Show
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      if (XmlBgType == 1) ; (362_28) (BG with Image 1)
      {
        if !FileExist(Temp_Display_Txt_Img)
        {
          DataArray := Pum_DisplayImageTxt(DataArray) ; > DataArray
        }
        else ; bg_Temp_Txt [EXIST] (Display Temp_Display_Txt_Img.png)
        {
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          GuiControl, PopUpMenu:, g_254, %Temp_Display_Txt_Img% ; (254_1)(Obj_MsgImg300x300)
          GuiControl, PopUpMenu:Show, g_254 ; (254_1)(Obj_MsgImg300x300)
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          ;
        } ; End bg_Temp_Txt [EXIST] (Display Temp_Display_Txt_Img.png)
      } ; End (XmlBgType == 1) (362_28) (BG with Image 1)
      else if (XmlBgType == 2) ; (362_28) (BG with Color 2)
      {
        if !FileExist(Temp_Display_Txt_Col)
        {
          DataArray := Pum_DisplayImageTxt(DataArray) ; > DataArray
        }
        else ; bg_Temp_Txt [EXIST] (Display Temp_Display_Txt_Col.png)
        {
          ;
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          GuiControl, PopUpMenu:, g_254, %Temp_Display_Txt_Col% ; (254_1)(Obj_MsgImg300x300)
          GuiControl, PopUpMenu:Show, g_254 ; (254_1)(Obj_MsgImg300x300)
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          ;
        } ; End bg_Temp_Txt [EXIST] (Display Temp_Display_Txt_Col.png)
      } ; End (XmlBgType == 2) (362_28) (BG with Color 2)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      DataArray := Image_GuiControl("004", 1, 0, DataArray) ; (004_1)(Obj_ok)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; -------------------------------------------
      Sys_EnableDisable("Enable") ; "Enable" or "Disable"
      ; -------------------------------------------
    } ; End Button in Normal State
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    global PumLock := 0
    ; -------------------------------------------
  } ; End (PumLock == 0)
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
} ; End (155_1)(GUI Object: [pum] [pumBgText])
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
