﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\Email_Send.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_GuiControl.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Pum_Close.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Pum_Create.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Pum_Run.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Script_Close.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Shortcut_Config.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Sys_ResetDataArray.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
f_004(DataArray) ; (004_1)(Obj_ok)
{
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if (DataArray.4.2 == 1) ; (004_2)(Obj_ok_Sel [0,1,3])
  {
    ; -------------------------------------------
    DataArray := Image_GuiControl("004", 2, 0, DataArray) ; (004_1)(Obj_ok)
    ; -------------------------------------------
    KeyWait, LButton, L
    KeyWait, LButton
    Send, {LButton Up}
    Sleep, 100
    ; -------------------------------------------
    GuiControlGet, Obj_EditFeild_StatusBar_Val, PopUpMenu:, g_122 ; (122_1)(Obj_EditFeild_StatusBar)
    DataArray.122.3 := Obj_EditFeild_StatusBar_Val ; (122_3)(Obj_EditFeild_StatusBar_Val [Text Value])
    ; -------------------------------------------
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [DELETE] Shortcut]
    if (DataArray.133.2 == 2) ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])
    {
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ScriptPath := A_ProgramFiles "\PopUpMenu_PUM\Splash_519.ahk"
      Run, %ScriptPath%
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ;
      ; -------------------------------------------
      DataArray := Shortcut_Config(DataArray) ; > DataArray
      ; -------------------------------------------
      DataArray := Sys_ResetDataArray(DataArray) ; > DataArray
      ; -------------------------------------------
    }
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [DELETE] Shortcut]
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [NEW] Shortcut
    else if (DataArray.366.5 == "cpl" or DataArray.366.5 == "key" or DataArray.366.5 == "mnu" or DataArray.366.5 == "ofl" or DataArray.366.5 == "run" or DataArray.366.5 == "rwh" or DataArray.366.5 == "url") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
    {
      ; -------------------------------------------
      DataArray := Shortcut_Config(DataArray) ; > DataArray
      ; -------------------------------------------
      DataArray := Sys_ResetDataArray(DataArray) ; > DataArray
      ; -------------------------------------------
    } ; End OkEnable
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [NEW] Shortcut
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [NEW] pum Application
    else if (InStr(DataArray.366.5, "pumApplication") > 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
    {
      ; -------------------------------------------
      DataArray := Pum_Create(DataArray) ; > DataArray
      ; -------------------------------------------
      DataArray := Sys_ResetDataArray(DataArray) ; > DataArray
      ; -------------------------------------------
    } ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,pum,url])
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [NEW] pum Application
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [DELETE] pum
    else if (InStr(DataArray.366.5, "pumDelete") > 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
    {
      ; -------------------------------------------
      ThisPumProcessFolder := DataArray.361.8 ; (361)(8)(ThisPumProcessFolder [Pum Folder Path])
      ; -------------------------------------------
      DataArray := Pum_Close(DataArray) ; > Close Gui
      ; -------------------------------------------
      DataArray := Pum_Close(DataArray) ; > Close Pum
      ; -------------------------------------------
      ;
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      Splash_Script("Off", 0) ; (Just Before) (Run) PopUpMenu Working Gear
      Sleep, 100
      ScriptPath := A_ProgramFiles "\PopUpMenu_PUM\Splash_519.ahk"
      Run, %ScriptPath%
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ;
      ; -------------------------------------------
      FileRemoveDir, %ThisPumProcessFolder%, 1
      ; -------------------------------------------
      DataArray := Sys_ResetDataArray(DataArray) ; > DataArray
      ; -------------------------------------------
      ;
      ; -------------------------------------------
      ; Create Current Pum List
      ; -------------------------------------------
      PumPath := A_AppData "\PopUpMenu_PUM\pums"
      PumList := A_AppData "\PopUpMenu_PUM\system\PumList.txt"
      if FileExist(PumList)
      {
        FileDelete, %PumList%
      }
      Loop Files, %PumPath%\pum_*.exe, R
      {
        ThisPumPath := A_LoopFileFullPath
        SplitPath, ThisPumPath, ThisPum
        ; -------------------------------------------
        FileEncoding, UTF-8
        FileAppend, %ThisPum%`n, %PumList% ; UTF-8
        ; -------------------------------------------
      }
      ; -------------------------------------------
      DataArray := Pum_Run(DataArray) ; > Nothing
      ; -------------------------------------------
    } ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,pum,url])
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [DELETE] pum
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [SEND EMAIL]
    else if (InStr(DataArray.366.5, "pumContact") > 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
    {
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Show/Start (Animate) Send Email
      global n_187 := 1 ; Start Frame Number
      global s_187 := 1 ; Show
      ; -------------------------------------------
      SetTimer, l_187, 300 ; (187_1)(Obj_Pum_SendEmailAnimate)
      BreakTime := A_TickCount + 8000
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Show/Start (Animate) Send Email
      ;
      ; -------------------------------------------
      GuiControlGet, ContactName, PopUpMenu:, g_189 ; (189_1)(Obj_Pum_EditFeild_ContactName)
      GuiControlGet, ContactEmail, PopUpMenu:, g_188 ; (188_1)(Obj_Pum_EditFeild_EmailAddress)
      GuiControlGet, ContactBody, PopUpMenu:, g_190 ; (190_1)(Obj_Pum_EditFeild_EmailBody)
      ; -------------------------------------------
      File_ContactInfo := A_AppData "\PopUpMenu_PUM\system\Contact.txt"
      FileDelete, %File_ContactInfo%
      ; -------------------------------------------
      FileEncoding, UTF-8
      FileAppend, %ContactName%`n, %File_ContactInfo% ; UTF-8
      FileAppend, %ContactEmail%`n, %File_ContactInfo% ; UTF-8
      ; -------------------------------------------
      Sleep, 100
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      Email_Subject := "(Contact)"
      Email_Body := Email_Body "Email: " ContactEmail "`n"
      Email_Body := Email_Body "Name: " ContactName "`n`n"
      ;
      Email_Body := Email_Body ContactBody
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      Email_Send(Email_Subject, Email_Body)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      while (BreakTime > A_TickCount)
      {
      } ; [End] while (BreakTime > A_TickCount)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Hide/Stop (Animate) Send Email
      global s_187 := 0 ; Hide
      SetTimer, l_187, Off ; (187_1)(Obj_Pum_SendEmailAnimate)
      global ShowAnimationChange := 0
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Hide/Stop (Animate) Send Email
      ;
      ; -------------------------------------------
      DataArray := Pum_Close(DataArray) ; > Close Gui
      ; -------------------------------------------
      
    } ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,pum,url])
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [SEND EMAIL]
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [CHANGE] pum Image or Size
    else if (InStr(DataArray.366.5, "pum") > 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
    {
      ; -------------------------------------------
      DataArray := Shortcut_Config(DataArray) ; > DataArray
      ; -------------------------------------------
      DataArray := Sys_ResetDataArray(DataArray) ; > DataArray
      ; -------------------------------------------
    } ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,pum,url])
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [CHANGE] pum Image or Size
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    else if (InStr(DataArray.366.5, "CatPaw") > 0) ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
    {
      ; -------------------------------------------
      File_CatPaw      := A_Appdata "\PopUpMenu_PUM\system\CatPaw.txt"
      File_CatPawTime := A_Appdata "\PopUpMenu_PUM\system\CatPawTime.txt"
      ; -------------------------------------------
      if (DataArray.169.2 != DataArray.169.4) ; (169_2)(Obj_CatPawAutoStart_Sel [1,2])/(169_4)(Obj_CatPawPreviousAutoStart_Sel [1,2])
      {
        ; -------------------------------------------
        ; (169_2)(Obj_CatPawAutoStart_Sel [1,2])
        ; (169_2)(Obj_CatPawAutoStart_Sel [1,2])
        ; -------------------------------------------
        DataArray.169.4 := DataArray.169.2 ; (169_4)(Obj_CatPawPreviousAutoStart_Sel [1,2])/(169_2)(Obj_CatPawAutoStart_Sel [1,2])
        ; -------------------------------------------
        CatPawOnOff := DataArray.169.2 ; (169_2)(Obj_CatPawAutoStart_Sel [1,2])
        FileDelete, %File_CatPaw%
        Sleep, 500
        ; -------------------------------------------
        FileEncoding, UTF-8
        FileAppend, %CatPawOnOff%, %File_CatPaw% ; 20127 us-ascii US-ASCII (7-bit), UTF-8
        ; -------------------------------------------
      }
      if (DataArray.170.2 != DataArray.170.4) ; (170_2)(Obj_CatPawDropDown_Time [1,2,3,4,5])/(170_4)(Obj_CatPawPreviousDropDown_Time [1,2,3,4,5])
      {
        ; -------------------------------------------
        DataArray.170.4 := DataArray.170.2 ; (170_4)(Obj_CatPawPreviousDropDown_Time [1,2,3,4,5])/(170_2)(Obj_CatPawDropDown_Time [1,2,3,4,5])
        ; -------------------------------------------
        CatPawTime := DataArray.170.2 ; (170_2)(Obj_CatPawDropDown_Time [1,2,3,4,5])
        FileDelete, %File_CatPawTime%
        Sleep, 500
        ; -------------------------------------------
        FileEncoding, UTF-8
        FileAppend, %CatPawTime%, %File_CatPawTime% ; 20127 us-ascii US-ASCII (7-bit)
        ; -------------------------------------------
      }
      ; -------------------------------------------
      DataArray := Pum_Close(DataArray) ; > Close Gui
      ; -------------------------------------------
    } ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; -------------------------------------------
    ; Returns "Ok"/"Accept" to Normal State
    DataArray := Image_GuiControl("004", 1, 0, DataArray) ; (004_1)(Obj_ok)
    ; -------------------------------------------
  } ; [End] (004_2)(Obj_ok_Sel == [1])
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [CHANGE] pum Image or Size
  ;
  ; -------------------------------------------
  Sleep, 401
  ; -------------------------------------------
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ScriptPath := A_ProgramFiles "\PopUpMenu_PUM\Splash_519.ahk"
  ScriptRunning := Script_Running(ScriptPath)
  if (ScriptRunning > 0)
  {
    Script_Close(ScriptPath)
  }
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  return DataArray
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
