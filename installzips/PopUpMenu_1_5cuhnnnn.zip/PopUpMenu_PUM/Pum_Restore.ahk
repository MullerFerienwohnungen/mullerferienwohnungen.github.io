#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 163 [pumRestore]
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\Select_FileFolder.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Script_Close.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Pum_Restore(UserLang)
{
	; -------------------------------------------
	if (UserLang == "")
	{
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; Get Current UserLang
    ; -------------------------------------------
    File_UserLang := A_AppData "\PopUpMenu_PUM\system\File_UserLang.txt"
    ; -------------------------------------------
    FileReadLINE, UserLang, %File_UserLang%, 1
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	}
	; -------------------------------------------
	;
	; -------------------------------------------
	File_PumRestore := Pum_GetRestoreFile(UserLang) ; > File_PumRestore
	; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
