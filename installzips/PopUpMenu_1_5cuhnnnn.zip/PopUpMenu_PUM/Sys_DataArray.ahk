﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\Folder_WindowsUser.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Array_Add.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Default_Browser.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Sys_DataArray() ; > DataArray
{
  /* Info
  ; ------------------------------------------->>>>>
  (de)(German)
  (en)(English)
  (es)(Spanish)
  (fr)(French)
  (it)(Italian)
  (pl)(Polish)
  (pt)(Portuguese)
  (ru)(Russian)
  (sv)(Swedish)
  (tr)(Turkish)
  ; ------------------------------------------->>>>>
  Info
  Colors
  ("199524" ; Green), ("a30404" ; Red), ("000000" ; Black), ("921297" ; Purple)
  FontColor := "199524" ; Green)
  FontColor := "a30404" ; Red)
  FontColor := "000000" ; Black)
  FontColor := "921297" ; Purple)
 */ ; End Info
  ; -------------------------------------------
  { ; Create Blank DataArray
    ; -------------------------------------------
    Var_Num := 0
    While (Var_Num < 600)
    {
      ; -------------------------------------------
      Var_Num := Var_Num + 1
      Var_Item := []
      ; -------------------------------------------
      if (Var_Num < 10)
      {
        Var_Item := ["v_00" Var_Num "_1"]
      }
      else if (Var_Num < 100)
      {
        Var_Item := ["v_0" Var_Num  "_1"]
      }
      else ; Number is 100 or Greater
      {
        Var_Item := ["v_" Var_Num  "_1"]
      }
      ; -------------------------------------------
      DataArray := Array_Add(DataArray, Var_Item, "End")
      ; -------------------------------------------
    }
  } ; End Create Blank DataArray
  ; -------------------------------------------
  ;
  ; -------------------------------------------
  DataArray.305.17 := 0 ; (305_17)(Run_DefaultPum [0,1][Selected Shortcut is to the Default pum])
  DataArray.305.18 := 0 ; (305_18)(Run_CatPaw [0,1][Selected Shortcut is to the CatPaw])
  ; -------------------------------------------
  DataArray.299 := ["GuiVarEnd"] ; (299_1)(End GUI Object)
  DataArray.366.2 := "Arial" ; (366_2)(GuiFont [Set in DataArray_Set])
  ; -------------------------------------------
  ;
  ; -------------------------------------------
  { ; (Gui Color Picker)
    ; -------------------------------------------
    ; (191)(01)(GUI Object: [pum][A1] Color Table: Gui Grid [Letter][Number])
    ; (191)(04)([pum][A1] Color Table: Hex Number)
    ; (191)(05)([pum][A1] Color Table: Acesss Number)
    DataArray.191.4 := "A1" ; (191_4)(Obj_Pum_ColorA1_GridNum [Letter,Number])
    DataArray.191.5 := "0xff8080" ; (191_5)(Obj_Pum_ColorA1_HexNum [Hex Image Number])
    DataArray.191.6 := "8421631" ; (191_6)(Obj_Pum_ColorA1_AcesssNum [MS Access Number])
    DataArray.192.4 := "A2" ; (192_4)(Obj_Pum_ColorA2_GridNum [Letter,Number])
    DataArray.192.5 := "0xff0000" ; (192_5)(Obj_Pum_ColorA2_HexNum [Hex Image Number])
    DataArray.192.6 := "255" ; (192_6)(Obj_Pum_ColorA2_AcesssNum [MS Access Number])
    DataArray.193.4 := "A3" ; (193_4)(Obj_Pum_ColorA3_GridNum [Letter,Number])
    DataArray.193.5 := "0x804040" ; (193_5)(Obj_Pum_ColorA3_HexNum [Hex Image Number])
    DataArray.193.6 := "4210816" ; (193_6)(Obj_Pum_ColorA3_AcesssNum [MS Access Number])
    DataArray.194.4 := "A4" ; (194_4)(Obj_Pum_ColorA4_GridNum [Letter,Number])
    DataArray.194.5 := "0x800000" ; (194_5)(Obj_Pum_ColorA4_HexNum [Hex Image Number])
    DataArray.194.6 := "128" ; (194_6)(Obj_Pum_ColorA4_AcesssNum [MS Access Number])
    DataArray.195.4 := "A5" ; (195_4)(Obj_Pum_ColorA5_GridNum [Letter,Number])
    DataArray.195.5 := "0x400000" ; (195_5)(Obj_Pum_ColorA5_HexNum [Hex Image Number])
    DataArray.195.6 := "64" ; (195_6)(Obj_Pum_ColorA5_AcesssNum [MS Access Number])
    DataArray.196.4 := "A6" ; (196_4)(Obj_Pum_ColorA6_GridNum [Letter,Number])
    DataArray.196.5 := "0x000000" ; (196_5)(Obj_Pum_ColorA6_HexNum [Hex Image Number])
    DataArray.196.6 := "0" ; (196_6)(Obj_Pum_ColorA6_AcesssNum [MS Access Number])
    DataArray.197.4 := "B1" ; (197_4)(Obj_Pum_ColorB1_GridNum [Letter,Number])
    DataArray.197.5 := "0xffff80" ; (197_5)(Obj_Pum_ColorB1_HexNum [Hex Image Number])
    DataArray.197.6 := "8454143" ; (197_6)(Obj_Pum_ColorB1_AcesssNum [MS Access Number])
    DataArray.198.4 := "B2" ; (198_4)(Obj_Pum_ColorB2_GridNum [Letter,Number])
    DataArray.198.5 := "0xffff00" ; (198_5)(Obj_Pum_ColorB2_HexNum [Hex Image Number])
    DataArray.198.6 := "65535" ; (198_6)(Obj_Pum_ColorB2_AcesssNum [MS Access Number])
    DataArray.199.4 := "B3" ; (199_4)(Obj_Pum_ColorB3_GridNum [Letter,Number])
    DataArray.199.5 := "0xff8040" ; (199_5)(Obj_Pum_ColorB3_HexNum [Hex Image Number])
    DataArray.199.6 := "4227327" ; (199_6)(Obj_Pum_ColorB3_AcesssNum [MS Access Number])
    DataArray.200.4 := "B4" ; (200_4)(Obj_Pum_ColorB4_GridNum [Letter,Number])
    DataArray.200.5 := "0xff8000" ; (200_5)(Obj_Pum_ColorB4_HexNum [Hex Image Number])
    DataArray.200.6 := "33023" ; (200_6)(Obj_Pum_ColorB4_AcesssNum [MS Access Number])
    DataArray.201.4 := "B5" ; (201_4)(Obj_Pum_ColorB5_GridNum [Letter,Number])
    DataArray.201.5 := "0x804000" ; (201_5)(Obj_Pum_ColorB5_HexNum [Hex Image Number])
    DataArray.201.6 := "16512" ; (201_6)(Obj_Pum_ColorB5_AcesssNum [MS Access Number])
    DataArray.202.4 := "B6" ; (202_4)(Obj_Pum_ColorB6_GridNum [Letter,Number])
    DataArray.202.5 := "0x808000" ; (202_5)(Obj_Pum_ColorB6_HexNum [Hex Image Number])
    DataArray.202.6 := "32896" ; (202_6)(Obj_Pum_ColorB6_AcesssNum [MS Access Number])
    DataArray.203.4 := "C1" ; (203_4)(Obj_Pum_ColorC1_GridNum [Letter,Number])
    DataArray.203.5 := "0x80ff80" ; (203_5)(Obj_Pum_ColorC1_HexNum [Hex Image Number])
    DataArray.203.6 := "8454016" ; (203_6)(Obj_Pum_ColorC1_AcesssNum [MS Access Number])
    DataArray.204.4 := "C2" ; (204_4)(Obj_Pum_ColorC2_GridNum [Letter,Number])
    DataArray.204.5 := "0x80ff00" ; (204_5)(Obj_Pum_ColorC2_HexNum [Hex Image Number])
    DataArray.204.6 := "65408" ; (204_6)(Obj_Pum_ColorC2_AcesssNum [MS Access Number])
    DataArray.205.4 := "C3" ; (205_4)(Obj_Pum_ColorC3_GridNum [Letter,Number])
    DataArray.205.5 := "0x00ff00" ; (205_5)(Obj_Pum_ColorC3_HexNum [Hex Image Number])
    DataArray.205.6 := "65280" ; (205_6)(Obj_Pum_ColorC3_AcesssNum [MS Access Number])
    DataArray.206.4 := "C4" ; (206_4)(Obj_Pum_ColorC4_GridNum [Letter,Number])
    DataArray.206.5 := "0x008000" ; (206_5)(Obj_Pum_ColorC4_HexNum [Hex Image Number])
    DataArray.206.6 := "32768" ; (206_6)(Obj_Pum_ColorC4_AcesssNum [MS Access Number])
    DataArray.207.4 := "C5" ; (207_4)(Obj_Pum_ColorC5_GridNum [Letter,Number])
    DataArray.207.5 := "0x004000" ; (207_5)(Obj_Pum_ColorC5_HexNum [Hex Image Number])
    DataArray.207.6 := "16384" ; (207_6)(Obj_Pum_ColorC5_AcesssNum [MS Access Number])
    DataArray.208.4 := "C6" ; (208_4)(Obj_Pum_ColorC6_GridNum [Letter,Number])
    DataArray.208.5 := "0x808040" ; (208_5)(Obj_Pum_ColorC6_HexNum [Hex Image Number])
    DataArray.208.6 := "4227200" ; (208_6)(Obj_Pum_ColorC6_AcesssNum [MS Access Number])
    DataArray.209.4 := "D1" ; (209_4)(Obj_Pum_ColorD1_GridNum [Letter,Number])
    DataArray.209.5 := "0x00ff80" ; (209_5)(Obj_Pum_ColorD1_HexNum [Hex Image Number])
    DataArray.209.6 := "8453888" ; (209_6)(Obj_Pum_ColorD1_AcesssNum [MS Access Number])
    DataArray.210.4 := "D2" ; (210_4)(Obj_Pum_ColorD2_GridNum [Letter,Number])
    DataArray.210.5 := "0x00ff40" ; (210_5)(Obj_Pum_ColorD2_HexNum [Hex Image Number])
    DataArray.210.6 := "4259584" ; (210_6)(Obj_Pum_ColorD2_AcesssNum [MS Access Number])
    DataArray.211.4 := "D3" ; (211_4)(Obj_Pum_ColorD3_GridNum [Letter,Number])
    DataArray.211.5 := "0x008080" ; (211_5)(Obj_Pum_ColorD3_HexNum [Hex Image Number])
    DataArray.211.6 := "8421376" ; (211_6)(Obj_Pum_ColorD3_AcesssNum [MS Access Number])
    DataArray.212.4 := "D4" ; (212_4)(Obj_Pum_ColorD4_GridNum [Letter,Number])
    DataArray.212.5 := "0x008040" ; (212_5)(Obj_Pum_ColorD4_HexNum [Hex Image Number])
    DataArray.212.6 := "4227072" ; (212_6)(Obj_Pum_ColorD4_AcesssNum [MS Access Number])
    DataArray.213.4 := "D5" ; (213_4)(Obj_Pum_ColorD5_GridNum [Letter,Number])
    DataArray.213.5 := "0x004040" ; (213_5)(Obj_Pum_ColorD5_HexNum [Hex Image Number])
    DataArray.213.6 := "4210688" ; (213_6)(Obj_Pum_ColorD5_AcesssNum [MS Access Number])
    DataArray.214.4 := "D6" ; (214_4)(Obj_Pum_ColorD6_GridNum [Letter,Number])
    DataArray.214.5 := "0x808080" ; (214_5)(Obj_Pum_ColorD6_HexNum [Hex Image Number])
    DataArray.214.6 := "8421504" ; (214_6)(Obj_Pum_ColorD6_AcesssNum [MS Access Number])
    DataArray.215.4 := "E1" ; (215_4)(Obj_Pum_ColorE1_GridNum [Letter,Number])
    DataArray.215.5 := "0x80ffff" ; (215_5)(Obj_Pum_ColorE1_HexNum [Hex Image Number])
    DataArray.215.6 := "16777088" ; (215_6)(Obj_Pum_ColorE1_AcesssNum [MS Access Number])
    DataArray.216.4 := "E2" ; (216_4)(Obj_Pum_ColorE2_GridNum [Letter,Number])
    DataArray.216.5 := "0x00ffff" ; (216_5)(Obj_Pum_ColorE2_HexNum [Hex Image Number])
    DataArray.216.6 := "16776960" ; (216_6)(Obj_Pum_ColorE2_AcesssNum [MS Access Number])
    DataArray.217.4 := "E3" ; (217_4)(Obj_Pum_ColorE3_GridNum [Letter,Number])
    DataArray.217.5 := "0x004080" ; (217_5)(Obj_Pum_ColorE3_HexNum [Hex Image Number])
    DataArray.217.6 := "8404992" ; (217_6)(Obj_Pum_ColorE3_AcesssNum [MS Access Number])
    DataArray.218.4 := "E4" ; (218_4)(Obj_Pum_ColorE4_GridNum [Letter,Number])
    DataArray.218.5 := "0x0000ff" ; (218_5)(Obj_Pum_ColorE4_HexNum [Hex Image Number])
    DataArray.218.6 := "16711680" ; (218_6)(Obj_Pum_ColorE4_AcesssNum [MS Access Number])
    DataArray.219.4 := "E5" ; (219_4)(Obj_Pum_ColorE5_GridNum [Letter,Number])
    DataArray.219.5 := "0x000080" ; (219_5)(Obj_Pum_ColorE5_HexNum [Hex Image Number])
    DataArray.219.6 := "8388608" ; (219_6)(Obj_Pum_ColorE5_AcesssNum [MS Access Number])
    DataArray.220.4 := "E6" ; (220_4)(Obj_Pum_ColorE6_GridNum [Letter,Number])
    DataArray.220.5 := "0x408080" ; (220_5)(Obj_Pum_ColorE6_HexNum [Hex Image Number])
    DataArray.220.6 := "8421440" ; (220_6)(Obj_Pum_ColorE6_AcesssNum [MS Access Number])
    DataArray.221.4 := "F1" ; (221_4)(Obj_Pum_ColorF1_GridNum [Letter,Number])
    DataArray.221.5 := "0x0080ff" ; (221_5)(Obj_Pum_ColorF1_HexNum [Hex Image Number])
    DataArray.221.6 := "16744448" ; (221_6)(Obj_Pum_ColorF1_AcesssNum [MS Access Number])
    DataArray.222.4 := "F2" ; (222_4)(Obj_Pum_ColorF2_GridNum [Letter,Number])
    DataArray.222.5 := "0x0080c0" ; (222_5)(Obj_Pum_ColorF2_HexNum [Hex Image Number])
    DataArray.222.6 := "12615680" ; (222_6)(Obj_Pum_ColorF2_AcesssNum [MS Access Number])
    DataArray.223.4 := "F3" ; (223_4)(Obj_Pum_ColorF3_GridNum [Letter,Number])
    DataArray.223.5 := "0x8080ff" ; (223_5)(Obj_Pum_ColorF3_HexNum [Hex Image Number])
    DataArray.223.6 := "16744576" ; (223_6)(Obj_Pum_ColorF3_AcesssNum [MS Access Number])
    DataArray.224.4 := "F4" ; (224_4)(Obj_Pum_ColorF4_GridNum [Letter,Number])
    DataArray.224.5 := "0x0000a0" ; (224_5)(Obj_Pum_ColorF4_HexNum [Hex Image Number])
    DataArray.224.6 := "10485760" ; (224_6)(Obj_Pum_ColorF4_AcesssNum [MS Access Number])
    DataArray.225.4 := "F5" ; (225_4)(Obj_Pum_ColorF5_GridNum [Letter,Number])
    DataArray.225.5 := "0x000040" ; (225_5)(Obj_Pum_ColorF5_HexNum [Hex Image Number])
    DataArray.225.6 := "4194304" ; (225_6)(Obj_Pum_ColorF5_AcesssNum [MS Access Number])
    DataArray.226.4 := "F6" ; (226_4)(Obj_Pum_ColorF6_GridNum [Letter,Number])
    DataArray.226.5 := "0xc0c0c0" ; (226_5)(Obj_Pum_ColorF6_HexNum [Hex Image Number])
    DataArray.226.6 := "12632256" ; (226_6)(Obj_Pum_ColorF6_AcesssNum [MS Access Number])
    DataArray.227.4 := "G1" ; (227_4)(Obj_Pum_ColorG1_GridNum [Letter,Number])
    DataArray.227.5 := "0xff80c0" ; (227_5)(Obj_Pum_ColorG1_HexNum [Hex Image Number])
    DataArray.227.6 := "12615935" ; (227_6)(Obj_Pum_ColorG1_AcesssNum [MS Access Number])
    DataArray.228.4 := "G2" ; (228_4)(Obj_Pum_ColorG2_GridNum [Letter,Number])
    DataArray.228.5 := "0x8080c0" ; (228_5)(Obj_Pum_ColorG2_HexNum [Hex Image Number])
    DataArray.228.6 := "12615808" ; (228_6)(Obj_Pum_ColorG2_AcesssNum [MS Access Number])
    DataArray.229.4 := "G3" ; (229_4)(Obj_Pum_ColorG3_GridNum [Letter,Number])
    DataArray.229.5 := "0x800040" ; (229_5)(Obj_Pum_ColorG3_HexNum [Hex Image Number])
    DataArray.229.6 := "4194432" ; (229_6)(Obj_Pum_ColorG3_AcesssNum [MS Access Number])
    DataArray.230.4 := "G4" ; (230_4)(Obj_Pum_ColorG4_GridNum [Letter,Number])
    DataArray.230.5 := "0x800080" ; (230_5)(Obj_Pum_ColorG4_HexNum [Hex Image Number])
    DataArray.230.6 := "8388736" ; (230_6)(Obj_Pum_ColorG4_AcesssNum [MS Access Number])
    DataArray.231.4 := "G5" ; (231_4)(Obj_Pum_ColorG5_GridNum [Letter,Number])
    DataArray.231.5 := "0x400040" ; (231_5)(Obj_Pum_ColorG5_HexNum [Hex Image Number])
    DataArray.231.6 := "4194368" ; (231_6)(Obj_Pum_ColorG5_AcesssNum [MS Access Number])
    DataArray.232.4 := "G6" ; (232_4)(Obj_Pum_ColorG6_GridNum [Letter,Number])
    DataArray.232.5 := "0x404040" ; (232_5)(Obj_Pum_ColorG6_HexNum [Hex Image Number])
    DataArray.232.6 := "4210752" ; (232_6)(Obj_Pum_ColorG6_AcesssNum [MS Access Number])
    DataArray.233.4 := "H1" ; (233_4)(Obj_Pum_ColorH1_GridNum [Letter,Number])
    DataArray.233.5 := "0xff80ff" ; (233_5)(Obj_Pum_ColorH1_HexNum [Hex Image Number])
    DataArray.233.6 := "16744703" ; (233_6)(Obj_Pum_ColorH1_AcesssNum [MS Access Number])
    DataArray.234.4 := "H2" ; (234_4)(Obj_Pum_ColorH2_GridNum [Letter,Number])
    DataArray.234.5 := "0xff00ff" ; (234_5)(Obj_Pum_ColorH2_HexNum [Hex Image Number])
    DataArray.234.6 := "16711935" ; (234_6)(Obj_Pum_ColorH2_AcesssNum [MS Access Number])
    DataArray.235.4 := "H3" ; (235_4)(Obj_Pum_ColorH3_GridNum [Letter,Number])
    DataArray.235.5 := "0xff0080" ; (235_5)(Obj_Pum_ColorH3_HexNum [Hex Image Number])
    DataArray.235.6 := "8388863" ; (235_6)(Obj_Pum_ColorH3_AcesssNum [MS Access Number])
    DataArray.236.4 := "H4" ; (236_4)(Obj_Pum_ColorH4_GridNum [Letter,Number])
    DataArray.236.5 := "0x8000ff" ; (236_5)(Obj_Pum_ColorH4_HexNum [Hex Image Number])
    DataArray.236.6 := "16711808" ; (236_6)(Obj_Pum_ColorH4_AcesssNum [MS Access Number])
    DataArray.237.4 := "H5" ; (237_4)(Obj_Pum_ColorH5_GridNum [Letter,Number])
    DataArray.237.5 := "0x400080" ; (237_5)(Obj_Pum_ColorH5_HexNum [Hex Image Number])
    DataArray.237.6 := "8388672" ; (237_6)(Obj_Pum_ColorH5_AcesssNum [MS Access Number])
    DataArray.238.4 := "H6" ; (238_4)(Obj_Pum_ColorH6_GridNum [Letter,Number])
    DataArray.238.5 := "0xffffff" ; (238_5)(Obj_Pum_ColorH6_HexNum [Hex Image Number])
    DataArray.238.6 := "16777215" ; (238_6)(Obj_Pum_ColorH6_AcesssNum [MS Access Number])
    ; -------------------------------------------
  } ; End (Gui Color Picker)
  ; -------------------------------------------
  { ; (Url_DefaultBrowser)
    ; -------------------------------------------
    Url_DefaultBrowser := Default_Browser() ; (307_6)(Url_DefaultBrowser [Full File Path])
    ; -------------------------------------------
    DataArray.307.6 := Url_DefaultBrowser ; (307_6)(Url_DefaultBrowser [Full File Path])
    ; -------------------------------------------
  }  ; End (Url_DefaultBrowser)
  ; -------------------------------------------
  { ; UserLanguage
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; User Language [GET] (UserLang) [SET] DataArray
    ; -------------------------------------------
    File_UserLang := A_AppData "\PopUpMenu_PUM\system\File_UserLang.txt"
    ; -------------------------------------------
    if FileExist(File_UserLang)
    {
      FileReadLINE, UserLang, %File_UserLang%, 1
    }
    if (UserLang == "")
    {
      ; -------------------------------------------
      if FileExist(File_UserLang)
      {
        FileDelete, %File_UserLang%
        Sleep, 100
      } ; [End] if FileExist(File_UserLang)
      ; -------------------------------------------
      if (A_Language == "0407" or A_Language == "0807" or A_Language == "0c07" or A_Language == "1007" or A_Language == "1407")
      {
        ; -------------------------------------------
        UserLang := "de"
        ; -------------------------------------------
      } ; [End] German (de)
      ; -------------------------------------------
      else if (A_Language == "0409" or A_Language == "0809" or A_Language == "0c09" or A_Language == "1009" or A_Language == "1409" or A_Language == "1809" or A_Language == "1c09" or A_Language == "2009" or A_Language == "2409" or A_Language == "2809" or A_Language == "2c09" or A_Language == "3009" or A_Language == "3409")
      {
        ; -------------------------------------------
        UserLang := "en"
        ; -------------------------------------------
      } ; [End] English (en)
      ; -------------------------------------------
      else if (A_Language == "040a" or A_Language == "080a" or A_Language == "0c0a" or A_Language == "100a" or A_Language == "140a" or A_Language == "180a" or A_Language == "1c0a" or A_Language == "200a" or A_Language == "240a" or A_Language == "280a" or A_Language == "2c0a" or A_Language == "300a" or A_Language == "340a" or A_Language == "380a" or A_Language == "3c0a" or A_Language == "400a" or A_Language == "440a" or A_Language == "480a" or A_Language == "4c0a" or A_Language == "500a")
      {
        ; -------------------------------------------
        UserLang := "es"
        ; -------------------------------------------
      } ; [End] Spanish (es)
      ; -------------------------------------------
      else if (A_Language == "040c" or A_Language == "080c" or A_Language == "0c0c" or A_Language == "100c" or A_Language == "140c" or A_Language == "180c")
      {
        ; -------------------------------------------
        UserLang := "fr"
        ; -------------------------------------------
      } ; [End] French (fr)
      ; -------------------------------------------
      else if (A_Language == "0410" or A_Language == "0810")
      {
        ; -------------------------------------------
        UserLang := "it"
        ; -------------------------------------------
      } ; [End] Italian (it)
      ; -------------------------------------------
      else if (A_Language == "0415")
      {
        ; -------------------------------------------
        UserLang := "pl"
        ; -------------------------------------------
      } ; [End] Polish (pl)
      ; -------------------------------------------
      else if (A_Language == "0416" or A_Language == "0816")
      {
        ; -------------------------------------------
        UserLang := "pt"
        ; -------------------------------------------
      } ; [End] Portuguese (pt)
      ; -------------------------------------------
      else if (A_Language == "0419")
      {
        ; -------------------------------------------
        UserLang := "ru"
        ; -------------------------------------------
      } ; [End] Russian (ru)
      ; -------------------------------------------
      else if (A_Language == "041d" or A_Language == "081d")
      {
        ; -------------------------------------------
        UserLang := "sv"
        ; -------------------------------------------
      } ; [End] Swedish (sv)
      ; -------------------------------------------
      else if (A_Language == "041f")
      {
        ; -------------------------------------------
        UserLang := "tr"
        ; -------------------------------------------
      } ; [End] Turkish (tr)
      ; -------------------------------------------
      else ; English (en)
      {
        ; -------------------------------------------
        UserLang := "en"
        ; -------------------------------------------
      } ; [End] else ; English (en)
      ; -------------------------------------------
      FileEncoding, UTF-8 ; UTF-8
      FileAppend, %UserLang%`n, %File_UserLang% ; UTF-8
      ; -------------------------------------------
    } ; [End] if (UserLang == "")
    ; -------------------------------------------
    DataArray.365.2 := UserLang ; (365_2)(UserLang [Current User language])
    ; -------------------------------------------
    ; User Language [GET] (UserLang) [SET] DataArray
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [SET] Obj_DropDownListLang_ListBox
    ; -------------------------------------------
    Lang_de := "Deutsch"
    Lang_en := "English"
    Lang_es := "Español"
    Lang_fr := "Français"
    Lang_it := "Italiano"
    Lang_pl := "Polskie"
    Lang_pt := "Português"
    Lang_ru := "Pусский"
    Lang_sv := "Svenska"
    Lang_tr := "Türk"
    DataArray.124.3 := "|" Lang_de "|" Lang_en "|" Lang_es "|" Lang_fr "|" Lang_it "|" Lang_pl "|" Lang_pt "|" Lang_ru "|" Lang_sv "|" Lang_tr ; (124_3)(Obj_DropDownListLang_ListBox [List Box])
    ; -------------------------------------------
    ; [SET] Obj_DropDownListLang_ListBox
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [SET] LangListArray
    ; -------------------------------------------
    DataArray.365.4 := ["de", "en", "es", "fr", "it", "pl", "pt", "ru", "sv", "tr"] ; (365_4)(LangListArray [Language List] [Array])
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  } ; [End] UserLanguage
  ; -------------------------------------------
  ; Folder, Public [0=ThisUser/1=AllUsers] > FoundFolder
  RegRead, UserPictureFolder, HKEY_CURRENT_USER, Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders, My Pictures
  DataArray.363.12 := UserPictureFolder ; (363_12)(ThisUserPictureFolder)
  DataArray.363.13 := UserPictureFolder ; (363_13)(AllUsersPictureFolder)
  DataArray.363.14 := Folder_WindowsUser("Start Menu", 0) ; (363_14)(ThisUserStartMenuFolder)
  DataArray.363.15 := Folder_WindowsUser("Start Menu", 1) ; (363_15)(AllUsersStartMenuFolder)
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; END OF FILE
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
