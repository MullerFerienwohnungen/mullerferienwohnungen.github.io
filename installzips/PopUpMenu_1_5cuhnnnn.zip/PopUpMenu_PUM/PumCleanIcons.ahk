#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
#SingleInstance, force
#NoTrayIcon
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\Array_FromFile.ahk ; Array_FromFile(FilePath) ; > Array
#Include %A_ProgramFiles%\PopUpMenu_PUM\Array_Add.ahk ; Array_Add(ThisArray, AddThis, ThisPos) ; > ThisArray
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
PumPath := A_AppData "\PopUpMenu_PUM\pums"
; -------------------------------------------
Loop, Files, %PumPath%\*.xml, R
{
	; -------------------------------------------
	File_Xml := A_LoopFileFullPath
	Array_Xml := Array_FromFile(File_Xml) ; > Array
	; -------------------------------------------
	for Index, Line_Xml in Array_Xml
	{
		if (InStr(Line_Xml, "<icon name=") > 0)
		{
			ThisIconName := Line_Xml
			ThisIconName := StrReplace(ThisIconName, "      <icon name=""pumiconcache\", "")
			ThisIconName := StrReplace(ThisIconName, """ index=""0"" />", "")
			Array_Ico := Array_Add(Array_Ico, ThisIconName, ThisPos) ; > ThisArray
		}
	}
}
; -------------------------------------------
Loop, Files, %PumPath%\*.ico, R
{
	; -------------------------------------------
	ThisIcon_FullPath := A_LoopFileFullPath
	SplitPath, ThisIcon_FullPath, ThisIcon_NameExt,
	; -------------------------------------------
	if (InStr(ThisIcon_FullPath, "\pumiconcache") == 0)
	{
		DeleteThis := 0
	}
	else if (InStr(ThisIcon_FullPath, "\pumiconcache") > 0)
	{
		; -------------------------------------------
		DeleteThis := 1
		; -------------------------------------------
		for Index, ExistIcon_NameExt in Array_Ico
		{
			; -------------------------------------------
			if (ExistIcon_NameExt == ThisIcon_NameExt)
			{
				DeleteThis := 0
				break
			}
		}
	}
	; -------------------------------------------
	if (DeleteThis == 1)
	{
		; -------------------------------------------
		FileDelete, %ThisIcon_FullPath%
		; -------------------------------------------
	}
	; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; END OF FILE
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

