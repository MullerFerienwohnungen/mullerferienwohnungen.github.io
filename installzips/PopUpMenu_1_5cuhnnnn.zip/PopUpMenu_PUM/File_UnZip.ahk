﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
File_UnZip(ZipFile, UnZipDir)
{
  ; -------------------------------------------
  Support_7zip := A_ProgramFiles "\PopUpMenu_PUM\support\7-Zip\7z.exe"
  RunThis := Support_7zip " x -aoa -o""" UnZipDir """ """ ZipFile """"
  RunWait, %RunThis%, , Hide
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
