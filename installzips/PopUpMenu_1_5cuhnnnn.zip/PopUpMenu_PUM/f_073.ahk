﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_GuiControl.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Gui_AdjustTextWidth.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
f_073(DataArray) ; (073_1)(Obj_Run_AsAdmin)
{
  ; -------------------------------------------
  v_365_2 := DataArray.365.2 ; (365_2)(UserLang [Current User language])
  v_366_2 := DataArray.366.2 ; (366_2)(GuiFont [Set in DataArray_Set])
  v_073_2 := DataArray.73.2 ; (073_2)(Obj_Run_AsAdmin_Sel [0,1,2])
  ; -------------------------------------------
  if (v_073_2 == 1) ; (073_2)(Obj_Run_AsAdmin_Sel [0,1,2])
  {
    ; -------------------------------------------
    v_073_2 := 2 ; (073_2)(Obj_Run_AsAdmin_Sel [0,1,2])
    DataArray := Image_GuiControl("073", 2, 1, DataArray) ; (073_1)(Obj_Run_AsAdmin)
    ; -------------------------------------------
    if (DataArray.366.6 != 0) ; (366_6)(ScriptError [Integer])
    {
      FontColor := "a30404" ; (Red) Error Color
    }
    else
    {
      FontColor := "040e47" ; (Dark Blue) As Admin Color
    }
    ; -------------------------------------------
  } ; End (073_2)([run][rwh] As Admin: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis) (= 1)
  else if (v_073_2 == 2) ; (073_2)(Obj_Run_AsAdmin_Sel [0,1,2])
  {
    ; -------------------------------------------
    v_073_2 := 1 ; (073_2)(Obj_Run_AsAdmin_Sel [0,1,2])
    DataArray := Image_GuiControl("073", 1, 1, DataArray) ; (073_1)(Obj_Run_AsAdmin)
    ; -------------------------------------------
    if (DataArray.366.6 != 0) ; (366_6)(ScriptError [Integer])
    {
      FontColor := "a30404" ; (Red) Error Color
    }
    else
    {
      FontColor := "199524" ; (Green) Normal Color
    }
    ; -------------------------------------------
  } ; End (073_2)([run][rwh] As Admin: Select [0]Hide/[1]Nor/[2]Sel/[3]Dis) (= 2)
  ; -------------------------------------------
  { ; Language for (114_3)(<Displayed Text> Title 1: Value)
    ; -------------------------------------------
    if (v_365_2 == "en") ; (365_2)(UserLang [Current User language])
    {
      if (v_073_2 == 2) ; (073_2)(Obj_Run_AsAdmin_Sel [0,1,2])
      {
        v_114_3 := "Run As Administrator" ; (114_3)(Obj_DisplayText_Title1_Val [Text Value])
      }
      else
      {
        v_114_3 := "Run" ; (114_3)(Obj_DisplayText_Title1_Val [Text Value])
      }
    } ; End (en English)
    ; -------------------------------------------
    else if (v_365_2 == "fr") ; (365_2)(UserLang [Current User language])
    {
      if (v_073_2 == 2) ; (073_2)(Obj_Run_AsAdmin_Sel [0,1,2])
      {
        v_114_3 := "Exécuter en tant qu'administrateur" ; (114_3)(Obj_DisplayText_Title1_Val [Text Value])
      }
      else
      {
        v_114_3 := "Fonctionner" ; (114_3)(Obj_DisplayText_Title1_Val [Text Value])
      }
    } ; End (fr French)
    ; -------------------------------------------
    else if (v_365_2 == "de") ; (365_2)(UserLang [Current User language])
    {
      if (v_073_2 == 2) ; (073_2)(Obj_Run_AsAdmin_Sel [0,1,2])
      {
        v_114_3 := "Ausführen als Administrator" ; (114_3)(Obj_DisplayText_Title1_Val [Text Value])
      }
      else
      {
        v_114_3 := "Betreiben" ; (114_3)(Obj_DisplayText_Title1_Val [Text Value])
      }
    } ; End (de German)
    ; -------------------------------------------
    else if (v_365_2 == "it") ; (365_2)(UserLang [Current User language])
    {
      if (v_073_2 == 2) ; (073_2)(Obj_Run_AsAdmin_Sel [0,1,2])
      {
        v_114_3 := "Esegui come Amministratore" ; (114_3)(Obj_DisplayText_Title1_Val [Text Value])
      }
      else
      {
          v_114_3 := "Funzionare" ; (114_3)(Obj_DisplayText_Title1_Val [Text Value])
        }
    } ; End (it Italian)
    ; -------------------------------------------
    else if (v_365_2 == "pl") ; (365_2)(UserLang [Current User language])
    {
      if (v_073_2 == 2) ; (073_2)(Obj_Run_AsAdmin_Sel [0,1,2])
      {
        v_114_3 := "Uruchom jako Administrator" ; (114_3)(Obj_DisplayText_Title1_Val [Text Value])
      }
      else
      {
        v_114_3 := "Uruchomić" ; (114_3)(Obj_DisplayText_Title1_Val [Text Value])
      }
    } ; End (pl Polish)
    ; -------------------------------------------
    else if (v_365_2 == "pt") ; (365_2)(UserLang [Current User language])
    {
      if (v_073_2 == 2) ; (073_2)(Obj_Run_AsAdmin_Sel [0,1,2])
      {
        v_114_3 := "Executado como Administrador" ; (114_3)(Obj_DisplayText_Title1_Val [Text Value])
      }
      else
      {
        v_114_3 := "Executar" ; (114_3)(Obj_DisplayText_Title1_Val [Text Value])
      }
    } ; End (pt Portuguese)
    ; -------------------------------------------
    else if (v_365_2 == "ru") ; (365_2)(UserLang [Current User language])
    {
      if (v_073_2 == 2) ; (073_2)(Obj_Run_AsAdmin_Sel [0,1,2])
      {
        v_114_3 := "Выполнить в качестве администратора" ; (114_3)(Obj_DisplayText_Title1_Val [Text Value])
      }
      else
      {
        v_114_3 := "Запустить" ; (114_3)(Obj_DisplayText_Title1_Val [Text Value])
      }
    } ; End (ru Russian)
    ; -------------------------------------------
    else if (v_365_2 == "es") ; (365_2)(UserLang [Current User language])
    {
      if (v_073_2 == 2) ; (073_2)(Obj_Run_AsAdmin_Sel [0,1,2])
      {
        v_114_3 := "Ejecutar como administrador" ; (114_3)(Obj_DisplayText_Title1_Val [Text Value])
      }
      else
      {
        v_114_3 := "Ejecutar" ; (114_3)(Obj_DisplayText_Title1_Val [Text Value])
      }
    } ; End (es Spanish)
    ; -------------------------------------------
    else if (v_365_2 == "sv") ; (365_2)(UserLang [Current User language])
    {
      if (v_073_2 == 2) ; (073_2)(Obj_Run_AsAdmin_Sel [0,1,2])
      {
        v_114_3 := "Kör som Administratör" ; (114_3)(Obj_DisplayText_Title1_Val [Text Value])
      }
      else
      {
        v_114_3 := "Köra" ; (114_3)(Obj_DisplayText_Title1_Val [Text Value])
      }
    } ; End (sv Swedish)
    ; -------------------------------------------
    else if (v_365_2 == "tr") ; (365_2)(UserLang [Current User language])
    {
      if (v_073_2 == 2) ; (073_2)(Obj_Run_AsAdmin_Sel [0,1,2])
      {
        v_114_3 := "Yönetici Olarak Çalıştır" ; (114_3)(Obj_DisplayText_Title1_Val [Text Value])
      }
      else
      {
        v_114_3 := "Çalıştırmak" ; (114_3)(Obj_DisplayText_Title1_Val [Text Value])
      }
    } ; End (tr Turkish)
    ; -------------------------------------------
  } ; End Language for (114_3)(<Displayed Text> Title 1: Value)        
  ; -------------------------------------------
  DataArray.73.2 := v_073_2 ; (073_2)(Obj_Run_AsAdmin_Sel [0,1,2])
  DataArray.114.3 := v_114_3 ; (114_3)(Obj_DisplayText_Title1_Val [Text Value])
  FontSize := 14
  Gui_AdjustTextWidth("g_114", v_114_3, v_366_2, FontSize, FontColor, 158) ; (114_3)(Obj_DisplayText_Title1_Val [Text Value])/(366_2)(GuiFont [Set in DataArray_Set])/(114_1)(Obj_DisplayText_Title1)
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
