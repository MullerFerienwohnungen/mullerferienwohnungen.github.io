﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Image_ResizeImg(Resize_W, Resize_H, ImageIn, ImageOut) ; Resize_W, Resize_H, Image_In, Image_Out > Image_Out
{
  ; -------------------------------------------
  if FileExist(ImageIn)
  {
    ; -------------------------------------------
    Support_magick := A_ProgramFiles "\PopUpMenu_PUM\support\magick\magick.exe"
    ; -------------------------------------------
    RunThis := Support_magick " convert """ ImageIn """ -resize " Resize_W "x" Resize_H "! """ ImageOut """"
    Run, %A_ProgramFiles%\PopUpMenu_PUM\PriorityProcess_ImageMagic.ahk
    RunWait, %RunThis%, , Hide
    ; -------------------------------------------
  }
  ; -------------------------------------------
  return ImageOut
  ; -------------------------------------------
} ; End Image_ResizeImg(Resize_W, Resize_H, Image_In) ; > Image_Out
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; END OF FILE
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>