#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
#SingleInstance, force
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
SetWindowPosition(WindowId, ThisX, ThisY, ThisW, ThisH)
{
	; -------------------------------------------
	Scr_W := A_ScreenWidth
  Scr_H := A_ScreenHeight
	WinGetPos, , , , TaskBar_H, ahk_class Shell_TrayWnd
  Scr_H := Scr_H - TaskBar_H
	; -------------------------------------------
	if (ThisX == 0)
	{
		SetX := 0
	}
	else if (ThisX == 33)
	{
		SetX := Floor(Scr_W / 3)
	}
	else if (ThisX == 50)
	{
		SetX := Floor(Scr_W / 2)
	}
	else if (ThisX == 66)
	{
		SetX := Floor((Scr_W / 3) * 2)
	}
	; -------------------------------------------
	if (ThisY == 0)
	{
		SetY := 0
	}
	else if (ThisY == 33)
	{
		SetY := Floor(Scr_H / 3)
	}
	else if (ThisY == 50)
	{
		SetY := Floor(Scr_H / 2)
	}
	else if (ThisY == 66)
	{
		SetY := Floor((Scr_H / 3) * 2)
	}
	; -------------------------------------------
	if (ThisW == 100)
	{
		SetW := Floor(Scr_W)
	}
	else if (ThisW == 33)
	{
		SetW := Floor(Scr_W / 3)
	}
	else if (ThisW == 50)
	{
		SetW := Floor(Scr_W / 2)
	}
	else if (ThisW == 66)
	{
		SetW := Floor((Scr_W / 3) * 2)
	}
	; -------------------------------------------
	if (ThisH == 100)
	{
		SetH := Floor(Scr_H)
	}
	else if (ThisH == 33)
	{
		SetH := Floor(Scr_H / 3)
	}
	else if (ThisH == 50)
	{
		SetH := Floor(Scr_H / 2)
	}
	else if (ThisH == 66)
	{
		SetH := Floor((Scr_H / 3) * 2)
	}
	; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	if (SetX > 0)
	{
	  SetX := Floor(SetX - 5)
	}
	else
	{
	  SetX := 0
	}	
	SetY := Floor(SetY)
	SetW := Floor(SetW + 10)
	SetH := Floor(SetH + 5)
	; -------------------------------------------
	Sleep, 10
	; -------------------------------------------
	if WinActive("ahk_exe explorer.exe") ; Windows Explorer
	{
		; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ;ahk_class CabinetWClass
    ;ahk_exe explorer.exe
  	; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
		;
		; -------------------------------------------
		Send, {LWin Down}{Right}{LWin Up}
	  Sleep, 250
		; -------------------------------------------
	}
	; -------------------------------------------
	WinMove, ahk_id %WindowId%, , %SetX%, %SetY%, %SetW%, %SetH%
	Sleep, 250
	; -------------------------------------------
	if WinActive("ahk_exe explorer.exe")
	{
		; -------------------------------------------
	  Send, {Esc}
	  Sleep, 100
		Send, {Esc}
		Sleep, 100
		; -------------------------------------------
	  WinGetPos, OutX, OutY, OutW, OutH, ahk_id %WindowId%
		; -------------------------------------------
		BreakTime := A_TickCount + 2000
	  while (OutX != SetX or OutY != SetY or OutW != SetW or OutH != SetH)
	  {
			; -------------------------------------------
			if (A_TickCount > BreakTime)
			{
				break
			}
			; -------------------------------------------
  		WinMove, ahk_id %WindowId%, , %SetX%, %SetY%, %SetW%, %SetH%
	    Sleep, 250
			; -------------------------------------------
	    Send, {Esc}
	    Sleep, 100
		  Send, {Esc}
		  Sleep, 100
		  ; -------------------------------------------
	  }
		; -------------------------------------------
		if (OutX != SetX or OutY != SetY or OutW != SetW or OutH != SetH)
		{
		  ; -------------------------------------------
		  BreakTime := A_TickCount + 2000
	    while (OutX != SetX or OutY != SetY or OutW != SetW or OutH != SetH)
	    {
  			; -------------------------------------------
			  if (A_TickCount > BreakTime)
			  {
  				break
			  }
			  ; -------------------------------------------
  		  WinMove, ahk_id %WindowId%, , %SetX%, %SetY%, %SetW%, %SetH%
	      Sleep, 250
			  ; -------------------------------------------
	      Send, {Esc}
	      Sleep, 100
		    Send, {Esc}
		    Sleep, 100
		    ; -------------------------------------------
	    }
		  ; -------------------------------------------
		}
		; -------------------------------------------
		; -------------------------------------------
		if (OutX != SetX or OutY != SetY or OutW != SetW or OutH != SetH)
		{
		  ; -------------------------------------------
		  BreakTime := A_TickCount + 2000
	    while (OutX != SetX or OutY != SetY or OutW != SetW or OutH != SetH)
	    {
  			; -------------------------------------------
			  if (A_TickCount > BreakTime)
			  {
  				break
			  }
			  ; -------------------------------------------
  		  WinMove, ahk_id %WindowId%, , %SetX%, %SetY%, %SetW%, %SetH%
	      Sleep, 250
			  ; -------------------------------------------
	      Send, {Esc}
	      Sleep, 100
		    Send, {Esc}
		    Sleep, 100
		    ; -------------------------------------------
	    }
		  ; -------------------------------------------
		}
		; -------------------------------------------
		; -------------------------------------------
		if (OutX != SetX or OutY != SetY or OutW != SetW or OutH != SetH)
		{
		  ; -------------------------------------------
		  BreakTime := A_TickCount + 2000
	    while (OutX != SetX or OutY != SetY or OutW != SetW or OutH != SetH)
	    {
  			; -------------------------------------------
			  if (A_TickCount > BreakTime)
			  {
  				break
			  }
			  ; -------------------------------------------
  		  WinMove, ahk_id %WindowId%, , %SetX%, %SetY%, %SetW%, %SetH%
	      Sleep, 250
			  ; -------------------------------------------
	      Send, {Esc}
	      Sleep, 100
		    Send, {Esc}
		    Sleep, 100
		    ; -------------------------------------------
	    }
		  ; -------------------------------------------
		}
		; -------------------------------------------
		; -------------------------------------------
		if (OutX != SetX or OutY != SetY or OutW != SetW or OutH != SetH)
		{
		  ; -------------------------------------------
		  BreakTime := A_TickCount + 2000
	    while (OutX != SetX or OutY != SetY or OutW != SetW or OutH != SetH)
	    {
  			; -------------------------------------------
			  if (A_TickCount > BreakTime)
			  {
  				break
			  }
			  ; -------------------------------------------
  		  WinMove, ahk_id %WindowId%, , %SetX%, %SetY%, %SetW%, %SetH%
	      Sleep, 250
			  ; -------------------------------------------
	      Send, {Esc}
	      Sleep, 100
		    Send, {Esc}
		    Sleep, 100
		    ; -------------------------------------------
	    }
		  ; -------------------------------------------
		}
		; -------------------------------------------
		; -------------------------------------------
		if (OutX != SetX or OutY != SetY or OutW != SetW or OutH != SetH)
		{
		  ; -------------------------------------------
		  BreakTime := A_TickCount + 2000
	    while (OutX != SetX or OutY != SetY or OutW != SetW or OutH != SetH)
	    {
  			; -------------------------------------------
			  if (A_TickCount > BreakTime)
			  {
  				break
			  }
			  ; -------------------------------------------
  		  WinMove, ahk_id %WindowId%, , %SetX%, %SetY%, %SetW%, %SetH%
	      Sleep, 250
			  ; -------------------------------------------
	      Send, {Esc}
	      Sleep, 100
		    Send, {Esc}
		    Sleep, 100
		    ; -------------------------------------------
	    }
		  ; -------------------------------------------
		}
		; -------------------------------------------
	}
	; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; END OF FILE
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
