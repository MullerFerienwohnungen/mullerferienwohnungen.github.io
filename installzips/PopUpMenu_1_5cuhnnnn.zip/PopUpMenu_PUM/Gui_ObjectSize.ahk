﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\MenuSize.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Gui_ObjectSize(ThisGuiVar, DataArray) ; > Nothing
{
  if (ThisGuiVar == "001")
  {
    MoveHD_W := 40
    MoveHD_H := 40
  }
  else if (ThisGuiVar == "002")
  {
    MoveHD_W := 40
    MoveHD_H := 40
  }
  else if (ThisGuiVar == "003")
  {
    MoveHD_W := 40
    MoveHD_H := 40
  }
  else if (ThisGuiVar == "004")
  {
    MoveHD_W := 100
    MoveHD_H := 35
  }
  else if (ThisGuiVar == "005")  ; (005_1)(Text,List,Var) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  {
    MoveHD_W := ""
    MoveHD_H := ""
  }
  else if (ThisGuiVar == "006")
  {
    MoveHD_W := 300
    MoveHD_H := 70
  }
  else if (ThisGuiVar == "007")
  {
    MoveHD_W := 40
    MoveHD_H := 40
  }
  else if (ThisGuiVar == "008")
  {
    MoveHD_W := 56
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "009")
  {
    MoveHD_W := 23
    MoveHD_H := 23
  }
  else if (ThisGuiVar == "010")
  {
    MoveHD_W := 23
    MoveHD_H := 23
  }
  else if (ThisGuiVar == "011")
  {
    MoveHD_W := 23
    MoveHD_H := 23
  }
  else if (ThisGuiVar == "012")
  {
    MoveHD_W := 23
    MoveHD_H := 23
  }
  else if (ThisGuiVar == "013")
  {
    MoveHD_W := 56
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "014")
  {
    MoveHD_W := 23
    MoveHD_H := 23
  }
  else if (ThisGuiVar == "015")
  {
    MoveHD_W := 23
    MoveHD_H := 23
  }
  else if (ThisGuiVar == "016")
  {
    MoveHD_W := 23
    MoveHD_H := 23
  }
  else if (ThisGuiVar == "017")
  {
    MoveHD_W := 23
    MoveHD_H := 23
  }
  else if (ThisGuiVar == "018")
  {
    MoveHD_W := 56
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "019")
  {
    MoveHD_W := 56
    MoveHD_H := 23
  }
  else if (ThisGuiVar == "020")
  {
    MoveHD_W := 56
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "021")
  {
    MoveHD_W := 56
    MoveHD_H := 23
  }
  else if (ThisGuiVar == "022")
  {
    MoveHD_W := 36
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "023")
  {
    MoveHD_W := 36
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "024")
  {
    MoveHD_W := 36
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "025")
  {
    MoveHD_W := 36
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "026")
  {
    MoveHD_W := 36
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "027")
  {
    MoveHD_W := 36
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "028")
  {
    MoveHD_W := 36
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "029")
  {
    MoveHD_W := 36
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "030")
  {
    MoveHD_W := 36
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "031")
  {
    MoveHD_W := 36
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "032")
  {
    MoveHD_W := 36
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "033")
  {
    MoveHD_W := 36
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "034")
  {
    MoveHD_W := 44
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "035")
  {
    MoveHD_W := 44
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "036")
  {
    MoveHD_W := 44
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "037")
  {
    MoveHD_W := 44
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "038")
  {
    MoveHD_W := 44
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "039")
  {
    MoveHD_W := 44
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "040")
  {
    MoveHD_W := 44
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "041")
  {
    MoveHD_W := 44
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "042")
  {
    MoveHD_W := 44
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "043")
  {
    MoveHD_W := 44
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "044")
  {
    MoveHD_W := 75
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "045")
  {
    MoveHD_W := 75
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "046")
  {
    MoveHD_W := 75
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "047")
  {
    MoveHD_W := 75
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "048")
  {
    MoveHD_W := 75
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "049")
  {
    MoveHD_W := 75
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "050")
  {
    MoveHD_W := 56
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "051")
  {
    MoveHD_W := 23
    MoveHD_H := 23
  }
  else if (ThisGuiVar == "052")
  {
    MoveHD_W := 23
    MoveHD_H := 23
  }
  else if (ThisGuiVar == "053")
  {
    MoveHD_W := 23
    MoveHD_H := 23
  }
  else if (ThisGuiVar == "054")
  {
    MoveHD_W := 23
    MoveHD_H := 23
  }
  else if (ThisGuiVar == "055")
  {
    MoveHD_W := 56
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "056")
  {
    MoveHD_W := 56
    MoveHD_H := 23
  }
  else if (ThisGuiVar == "057")
  {
    MoveHD_W := 56
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "058")
  {
    MoveHD_W := 23
    MoveHD_H := 23
  }
  else if (ThisGuiVar == "059")
  {
    MoveHD_W := 23
    MoveHD_H := 23
  }
  else if (ThisGuiVar == "060")
  {
    MoveHD_W := 23
    MoveHD_H := 23
  }
  else if (ThisGuiVar == "061")
  {
    MoveHD_W := 23
    MoveHD_H := 23
  }
  else if (ThisGuiVar == "062")
  {
    MoveHD_W := 100
    MoveHD_H := 35
  }
  else if (ThisGuiVar == "063")
  {
    MoveHD_W := 160
    MoveHD_H := 35
  }
  else if (ThisGuiVar == "064") ; (064_1)(Text,List,Var) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  {
    MoveHD_W := ""
    MoveHD_H := ""
  }
  else if (ThisGuiVar == "065")
  {
    MoveHD_W := 185
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "066")
  {
    MoveHD_W := 185
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "067")
  {
    MoveHD_W := 185
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "068")
  {
    MoveHD_W := 280
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "069")
  {
    MoveHD_W := 150
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "070")
  {
    MoveHD_W := 130
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "071")
  {
    MoveHD_W := 130
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "072")
  {
    MoveHD_W := 100
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "073")
  {
    MoveHD_W := 100
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "074")
  {
    MoveHD_W := 56
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "075")
  {
    MoveHD_W := 75
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "076")
  {
    MoveHD_W := 75
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "077")
  {
    MoveHD_W := 75
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "078")
  {
    MoveHD_W := 75
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "079")
  {
    MoveHD_W := 75
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "080")
  {
    MoveHD_W := 75
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "081")
  {
    MoveHD_W := 130
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "082")
  {
    MoveHD_W := 130
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "083")
  {
    MoveHD_W := 159
    MoveHD_H := 35
  }
  else if (ThisGuiVar == "084")
  {
    MoveHD_W := 159
    MoveHD_H := 35
  }
  else if (ThisGuiVar == "085")
  {
    MoveHD_W := 130
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "086")
  {
    MoveHD_W := 159
    MoveHD_H := 35
  }
  else if (ThisGuiVar == "087")
  {
    MoveHD_W := 130
    MoveHD_H := 25
  }
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (Obj_Mnu_AppMenu)
  else if (ThisGuiVar == "088") > 0 or InStr(ThisGuiVar, "089") > 0 or InStr(ThisGuiVar, "090") > 0 or InStr(ThisGuiVar, "091") > 0 or InStr(ThisGuiVar, "092") > 0 or InStr(ThisGuiVar, "093") > 0 or InStr(ThisGuiVar, "094") > 0 or InStr(ThisGuiVar, "095") > 0 or InStr(ThisGuiVar, "096") > 0 or InStr(ThisGuiVar, "097") > 0 or InStr(ThisGuiVar, "098")
  {
    ; -------------------------------------------
    ThisMenuSize := MenuSize(DataArray) ; > MenuSize
    SizeArray := GetMenuSize(ThisMenuSize) ; > [Item_W, Item_H]
    MoveHD_W := SizeArray.1
    MoveHD_H := SizeArray.2
  }
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ (Obj_Mnu_AppMenu)
  else if (ThisGuiVar == "099")
  {
    MoveHD_W := 480
    MoveHD_H := 20
  }
  else if (ThisGuiVar == "100") ; (Text,List,Var) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  {
    MoveHD_W := ""
    MoveHD_H := ""
  }
  else if (ThisGuiVar == "101")
  {
    MoveHD_W := 94
    MoveHD_H := 23
  }
  else if (ThisGuiVar == "102")
  {
    MoveHD_W := 80
    MoveHD_H := 80
  }
  else if (ThisGuiVar == "103")
  {
    MoveHD_W := 30
    MoveHD_H := 30
  }
  else if (ThisGuiVar == "104") ; (Text,List,Var) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  {
    MoveHD_W := ""
    MoveHD_H := ""
  }
  else if (ThisGuiVar == "105") ; (Text,List,Var) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  {
    MoveHD_W := ""
    MoveHD_H := ""
  }
  else if (ThisGuiVar == "106") ; (Text,List,Var) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  {
    MoveHD_W := ""
    MoveHD_H := ""
  }
  else if (ThisGuiVar == "107") ; (Text,List,Var) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  {
    MoveHD_W := ""
    MoveHD_H := ""
  }
  else if (ThisGuiVar == "108")
  {
    MoveHD_W := 100
    MoveHD_H := 41
  }
  else if (ThisGuiVar == "109")
  {
    MoveHD_W := 167
    MoveHD_H := 70
  }
  else if (ThisGuiVar == "110") ; (Text,List,Var) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  {
    MoveHD_W := ""
    MoveHD_H := ""
  }
  else if (ThisGuiVar == "111") ; (Text,List,Var) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  {
    MoveHD_W := ""
    MoveHD_H := ""
  }
  else if (ThisGuiVar == "112") ; (Text,List,Var) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  {
    MoveHD_W := ""
    MoveHD_H := ""
  }
  else if (ThisGuiVar == "113") ; (Text,List,Var) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  {
    MoveHD_W := ""
    MoveHD_H := ""
  }
  else if (ThisGuiVar == "114") ; (Text,List,Var) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  {
    MoveHD_W := ""
    MoveHD_H := ""
  }
  else if (ThisGuiVar == "115") ; (Text,List,Var) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  {
    MoveHD_W := ""
    MoveHD_H := ""
  }
  else if (ThisGuiVar == "116") ; (Text,List,Var) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  {
    MoveHD_W := ""
    MoveHD_H := ""
  }
  else if (ThisGuiVar == "117") ; (Text,List,Var) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  {
    MoveHD_W := ""
    MoveHD_H := ""
  }
  else if (ThisGuiVar == "118") ; (Text,List,Var) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  {
    MoveHD_W := ""
    MoveHD_H := ""
  }
  else if (ThisGuiVar == "119") ; (Text,List,Var) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  {
    MoveHD_W := ""
    MoveHD_H := ""
  }
  else if (ThisGuiVar == "120") ; (Text,List,Var) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  {
    MoveHD_W := ""
    MoveHD_H := ""
  }
  else if (ThisGuiVar == "121") ; (Text,List,Var) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  {
    MoveHD_W := ""
    MoveHD_H := ""
  }
  else if (ThisGuiVar == "122")
  {
    MoveHD_W := 285
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "123")
  {
    MoveHD_W := 285
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "124") ; (Text,List,Var) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  {
    MoveHD_W := ""
    MoveHD_H := ""
  }
  else if (ThisGuiVar == "125")
  {
    MoveHD_W := 58
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "126")
  {
    MoveHD_W := 58
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "127")
  {
    MoveHD_W := 58
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "128")
  {
    MoveHD_W := 58
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "129")
  {
    MoveHD_W := 58
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "130")
  {
    MoveHD_W := 58
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "131") ; (Text,List,Var) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  {
    MoveHD_W := ""
    MoveHD_H := ""
  }
  else if (ThisGuiVar == "132") ; (Empty) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  {
    MoveHD_W := ""
    MoveHD_H := ""
  }
  else if (ThisGuiVar == "133")
  {
    MoveHD_W := 100
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "134")
  {
    MoveHD_W := 130
    MoveHD_H := 100
  }
  else if (ThisGuiVar == "135")
  {
    MoveHD_W := 130
    MoveHD_H := 100
  }
  else if (ThisGuiVar == "136")
  {
    MoveHD_W := 130
    MoveHD_H := 100
  }
  else if (ThisGuiVar == "137")
  {
    MoveHD_W := 480
    MoveHD_H := 270
  }
  else if (ThisGuiVar == "138")
  {
    MoveHD_W := 58
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "139")
  {
    MoveHD_W := 58
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "140")
  {
    MoveHD_W := 100
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "141") ; (Text,List,Var) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  {
    MoveHD_W := ""
    MoveHD_H := ""
  }
  else if (ThisGuiVar == "142") ; (Empty) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  {
    MoveHD_W := ""
    MoveHD_H := ""
  }
  else if (ThisGuiVar == "143") ; (Empty) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  {
    MoveHD_W := ""
    MoveHD_H := ""
  }
  else if (ThisGuiVar == "144") ; (Empty) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  {
    MoveHD_W := ""
    MoveHD_H := ""
  }
  else if (ThisGuiVar == "145") ; (Empty) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  {
    MoveHD_W := ""
    MoveHD_H := ""
  }
  else if (ThisGuiVar == "146") ; (Empty) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  {
    MoveHD_W := ""
    MoveHD_H := ""
  }
  else if (ThisGuiVar == "147") ; (Empty) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  {
    MoveHD_W := ""
    MoveHD_H := ""
  }
  else if (ThisGuiVar == "148") ; (Empty) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  {
    MoveHD_W := ""
    MoveHD_H := ""
  }
  else if (ThisGuiVar == "149") ; (Empty) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  {
    MoveHD_W := ""
    MoveHD_H := ""
  }
  else if (ThisGuiVar == "150") ; (Empty) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  {
    MoveHD_W := ""
    MoveHD_H := ""
  }
  else if (ThisGuiVar == "151") ; (Empty) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  {
    MoveHD_W := ""
    MoveHD_H := ""
  }
  else if (ThisGuiVar == "152") ; (Empty) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  {
    MoveHD_W := ""
    MoveHD_H := ""
  }
  else if (ThisGuiVar == "153") ; (Empty) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  {
    MoveHD_W := ""
    MoveHD_H := ""
  }
  else if (ThisGuiVar == "154")
  {
    MoveHD_W := 158
    MoveHD_H := 75
  }
  else if (ThisGuiVar == "155")
  {
    MoveHD_W := 158
    MoveHD_H := 75
  }
  else if (ThisGuiVar == "156")
  {
    MoveHD_W := 158
    MoveHD_H := 75
  }
  else if (ThisGuiVar == "157")
  {
    MoveHD_W := 130
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "158") ; (Empty) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  {
    MoveHD_W := ""
    MoveHD_H := ""
  }
  else if (ThisGuiVar == "159")
  {
    MoveHD_W := 130
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "160")
  {
    MoveHD_W := 130
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "161")
  {
    MoveHD_W := 130
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "162") ; (Empty) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  {
    MoveHD_W := ""
    MoveHD_H := ""
  }
  else if (ThisGuiVar == "163") ; (Empty) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  {
    MoveHD_W := ""
    MoveHD_H := ""
  }
  else if (ThisGuiVar == "164")
  {
    MoveHD_W := 100
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "165")
  {
    MoveHD_W := 100
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "166")
  {
    MoveHD_W := 100
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "167")
  {
    MoveHD_W := 100
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "168") ; (Empty) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  {
    MoveHD_W := ""
    MoveHD_H := ""
  }
  else if (ThisGuiVar == "169")
  {
    MoveHD_W := 120
    MoveHD_H := 30
  }
  else if (ThisGuiVar == "170") ; (Text,List,Var) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  {
    MoveHD_W := ""
    MoveHD_H := ""
  }
  else if (ThisGuiVar == "171") ; (Empty) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  {
    MoveHD_W := ""
    MoveHD_H := ""
  }
  else if (ThisGuiVar == "172")
  {
    MoveHD_W := 100
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "173")
  {
    MoveHD_W := 100
    MoveHD_H := 50
  }
  else if (ThisGuiVar == "174")
  {
    MoveHD_W := 100
    MoveHD_H := 50
  }
  else if (ThisGuiVar == "175") ; (Empty) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  {
    MoveHD_W := ""
    MoveHD_H := ""
  }
  else if (ThisGuiVar == "176") ; (Empty) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  {
    MoveHD_W := ""
    MoveHD_H := ""
  }
  else if (ThisGuiVar == "177")
  {
    MoveHD_W := 150
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "178")
  {
    MoveHD_W := 55
    MoveHD_H := 60
  }
  else if (ThisGuiVar == "179")
  {
    MoveHD_W := 55
    MoveHD_H := 60
  }
  else if (ThisGuiVar == "180") ; (180_1)(Obj_Pum_DisplayText_Opacity)
  {
    MoveHD_W := ""
    MoveHD_H := ""
  }
  else if (ThisGuiVar == "181")
  {
    MoveHD_W := 70
    MoveHD_H := 80
  }
  else if (ThisGuiVar == "182")
  {
    MoveHD_W := 45
    MoveHD_H := 45
  }
  else if (ThisGuiVar == "183")
  {
    MoveHD_W := 45
    MoveHD_H := 45
  }
  else if (ThisGuiVar == "184")
  {
    MoveHD_W := 160
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "185")
  {
    MoveHD_W := 160
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "186")
  {
    MoveHD_W := 270
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "187")
  {
    MoveHD_W := 138
    MoveHD_H := 192
  }
  else if (ThisGuiVar == "188")
  {
    MoveHD_W := 315
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "189")
  {
    MoveHD_W := 315
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "190")
  {
    MoveHD_W := 332
    MoveHD_H := 243
  }
  else if (ThisGuiVar == "191")
  {
    MoveHD_W := 30
    MoveHD_H := 35
  }
  else if (ThisGuiVar == "192")
  {
    MoveHD_W := 30
    MoveHD_H := 35
  }
  else if (ThisGuiVar == "193")
  {
    MoveHD_W := 30
    MoveHD_H := 35
  }
  else if (ThisGuiVar == "194")
  {
    MoveHD_W := 30
    MoveHD_H := 35
  }
  else if (ThisGuiVar == "195")
  {
    MoveHD_W := 30
    MoveHD_H := 35
  }
  else if (ThisGuiVar == "196")
  {
    MoveHD_W := 30
    MoveHD_H := 35
  }
  else if (ThisGuiVar == "197")
  {
    MoveHD_W := 30
    MoveHD_H := 35
  }
  else if (ThisGuiVar == "198")
  {
    MoveHD_W := 30
    MoveHD_H := 35
  }
  else if (ThisGuiVar == "199")
  {
    MoveHD_W := 30
    MoveHD_H := 35
  }
  else if (ThisGuiVar == "200")
  {
    MoveHD_W := 30
    MoveHD_H := 35
  }
  else if (ThisGuiVar == "201")
  {
    MoveHD_W := 30
    MoveHD_H := 35
  }
  else if (ThisGuiVar == "202")
  {
    MoveHD_W := 30
    MoveHD_H := 35
  }
  else if (ThisGuiVar == "203")
  {
    MoveHD_W := 30
    MoveHD_H := 35
  }
  else if (ThisGuiVar == "204")
  {
    MoveHD_W := 30
    MoveHD_H := 35
  }
  else if (ThisGuiVar == "205")
  {
    MoveHD_W := 30
    MoveHD_H := 35
  }
  else if (ThisGuiVar == "206")
  {
    MoveHD_W := 30
    MoveHD_H := 35
  }
  else if (ThisGuiVar == "207")
  {
    MoveHD_W := 30
    MoveHD_H := 35
  }
  else if (ThisGuiVar == "208")
  {
    MoveHD_W := 30
    MoveHD_H := 35
  }
  else if (ThisGuiVar == "209")
  {
    MoveHD_W := 30
    MoveHD_H := 35
  }
  else if (ThisGuiVar == "210")
  {
    MoveHD_W := 30
    MoveHD_H := 35
  }
  else if (ThisGuiVar == "211")
  {
    MoveHD_W := 30
    MoveHD_H := 35
  }
  else if (ThisGuiVar == "212")
  {
    MoveHD_W := 30
    MoveHD_H := 35
  }
  else if (ThisGuiVar == "213")
  {
    MoveHD_W := 30
    MoveHD_H := 35
  }
  else if (ThisGuiVar == "214")
  {
    MoveHD_W := 30
    MoveHD_H := 35
  }
  else if (ThisGuiVar == "215")
  {
    MoveHD_W := 30
    MoveHD_H := 35
  }
  else if (ThisGuiVar == "216")
  {
    MoveHD_W := 30
    MoveHD_H := 35
  }
  else if (ThisGuiVar == "217")
  {
    MoveHD_W := 30
    MoveHD_H := 35
  }
  else if (ThisGuiVar == "218")
  {
    MoveHD_W := 30
    MoveHD_H := 35
  }
  else if (ThisGuiVar == "219")
  {
    MoveHD_W := 30
    MoveHD_H := 35
  }
  else if (ThisGuiVar == "220")
  {
    MoveHD_W := 30
    MoveHD_H := 35
  }
  else if (ThisGuiVar == "221")
  {
    MoveHD_W := 30
    MoveHD_H := 35
  }
  else if (ThisGuiVar == "222")
  {
    MoveHD_W := 30
    MoveHD_H := 35
  }
  else if (ThisGuiVar == "223")
  {
    MoveHD_W := 30
    MoveHD_H := 35
  }
  else if (ThisGuiVar == "224")
  {
    MoveHD_W := 30
    MoveHD_H := 35
  }
  else if (ThisGuiVar == "225")
  {
    MoveHD_W := 30
    MoveHD_H := 35
  }
  else if (ThisGuiVar == "226")
  {
    MoveHD_W := 30
    MoveHD_H := 35
  }
  else if (ThisGuiVar == "227")
  {
    MoveHD_W := 30
    MoveHD_H := 35
  }
  else if (ThisGuiVar == "228")
  {
    MoveHD_W := 30
    MoveHD_H := 35
  }
  else if (ThisGuiVar == "229")
  {
    MoveHD_W := 30
    MoveHD_H := 35
  }
  else if (ThisGuiVar == "230")
  {
    MoveHD_W := 30
    MoveHD_H := 35
  }
  else if (ThisGuiVar == "231")
  {
    MoveHD_W := 30
    MoveHD_H := 35
  }
  else if (ThisGuiVar == "232")
  {
    MoveHD_W := 30
    MoveHD_H := 35
  }
  else if (ThisGuiVar == "233")
  {
    MoveHD_W := 30
    MoveHD_H := 35
  }
  else if (ThisGuiVar == "234")
  {
    MoveHD_W := 30
    MoveHD_H := 35
  }
  else if (ThisGuiVar == "235")
  {
    MoveHD_W := 30
    MoveHD_H := 35
  }
  else if (ThisGuiVar == "236")
  {
    MoveHD_W := 30
    MoveHD_H := 35
  }
  else if (ThisGuiVar == "237")
  {
    MoveHD_W := 30
    MoveHD_H := 35
  }
  else if (ThisGuiVar == "238")
  {
    MoveHD_W := 30
    MoveHD_H := 35
  }
  else if (ThisGuiVar == "239") ; (Empty) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  {
    MoveHD_W := ""
    MoveHD_H := ""
  }
  else if (ThisGuiVar == "240") ; (Empty) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  {
    MoveHD_W := ""
    MoveHD_H := ""
  }
  else if (ThisGuiVar == "241")
  {
    MoveHD_W := 45
    MoveHD_H := 45
  }
  else if (ThisGuiVar == "242")
  {
    MoveHD_W := 45
    MoveHD_H := 45
  }
  else if (ThisGuiVar == "243")
  {
    MoveHD_W := 45
    MoveHD_H := 45
  }
  else if (ThisGuiVar == "244")
  {
    MoveHD_W := 45
    MoveHD_H := 45
  }
  else if (ThisGuiVar == "245")
  {
    MoveHD_W := 45
    MoveHD_H := 45
  }
  else if (ThisGuiVar == "246")
  {
    MoveHD_W := 45
    MoveHD_H := 45
  }
  else if (ThisGuiVar == "247")
  {
    MoveHD_W := 45
    MoveHD_H := 45
  }
  else if (ThisGuiVar == "248")
  {
    MoveHD_W := 40
    MoveHD_H := 40
  }
  else if (ThisGuiVar == "249")
  {
    MoveHD_W := 40
    MoveHD_H := 40
  }
  else if (ThisGuiVar == "250")
  {
    MoveHD_W := 40
    MoveHD_H := 40
  }
  else if (ThisGuiVar == "251") ; (Text,List,Var) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  {
    MoveHD_W := ""
    MoveHD_H := ""
  }
  else if (ThisGuiVar == "252")
  {
    MoveHD_W := 40
    MoveHD_H := 40
  }
  else if (ThisGuiVar == "253") ; (Empty) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  {
    MoveHD_W := ""
    MoveHD_H := ""
  }
  else if (ThisGuiVar == "254")
  {
    MoveHD_W := 300
    MoveHD_H := 300
  }
  else if (ThisGuiVar == "255") ; (Empty) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  {
    MoveHD_W := ""
    MoveHD_H := ""
  }
  else if (ThisGuiVar == "256") ; (Empty) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  {
    MoveHD_W := ""
    MoveHD_H := ""
  }
  else if (ThisGuiVar == "257") ; (Empty) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  {
    MoveHD_W := ""
    MoveHD_H := ""
  }
  else if (ThisGuiVar == "258") ; (Empty) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  {
    MoveHD_W := ""
    MoveHD_H := ""
  }
  else if (ThisGuiVar == "259") ; (Empty) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  {
    MoveHD_W := ""
    MoveHD_H := ""
  }
  else if (ThisGuiVar == "260")
  {
    MoveHD_W := 64
    MoveHD_H := 64
  }
  else if (ThisGuiVar == "261")
  {
    MoveHD_W := 33
    MoveHD_H := 33
  }
  else if (ThisGuiVar == "262")
  {
    MoveHD_W := 33
    MoveHD_H := 33
  }
  else if (ThisGuiVar == "263")
  {
    MoveHD_W := 100
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "264") ; (Empty) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  {
    MoveHD_W := ""
    MoveHD_H := ""
  }
  else if (ThisGuiVar == "265") ; (Empty) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  {
    MoveHD_W := ""
    MoveHD_H := ""
  }
  else if (ThisGuiVar == "266")
  {
    MoveHD_W := 31
    MoveHD_H := 20
  }
  else if (ThisGuiVar == "267")
  {
    MoveHD_W := 33
    MoveHD_H := 33
  }
  else if (ThisGuiVar == "268")
  {
    MoveHD_W := 33
    MoveHD_H := 33
  }
  else if (ThisGuiVar == "269")
  {
    MoveHD_W := 100
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "270") ; (Empty) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  {
    MoveHD_W := ""
    MoveHD_H := ""
  }
  else if (ThisGuiVar == "271") ; (Empty) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  {
    MoveHD_W := ""
    MoveHD_H := ""
  }
  else if (ThisGuiVar == "272")
  {
    MoveHD_W := 31
    MoveHD_H := 20
  }
  else if (ThisGuiVar == "273")
  {
    MoveHD_W := 33
    MoveHD_H := 33
  }
  else if (ThisGuiVar == "274")
  {
    MoveHD_W := 33
    MoveHD_H := 33
  }
  else if (ThisGuiVar == "275")
  {
    MoveHD_W := 100
    MoveHD_H := 25
  }
  else if (ThisGuiVar == "276") ; (Empty) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  {
    MoveHD_W := ""
    MoveHD_H := ""
  }
  else if (ThisGuiVar == "277")
  {
    MoveHD_W := 131
    MoveHD_H := 44
  }
  ; -------------------------------------------
  if (MoveHD_W != "" && MoveHD_H != "")
  {
    GuiControl, PopUpMenu:Move, g_%ThisGuiVar%, w%MoveHD_W% h%MoveHD_H%
  }
  ; -------------------------------------------
} ; [End] Gui_ObjectSize(ThisGuiVar, DataArray) ; > Nothing
; -------------------------------------------
GetMenuSize(MenuSize) ; > [Item_W, Item_H]
{
  ; -------------------------------------------
  Item_H := 25
  ; -------------------------------------------
  if (MenuSize == 2)
  {
    Item_W := 238
  } ; [End] if (MenuSize == 2)
  else if (MenuSize == 3)
  {
    Item_W := 158
  } ; [End] else if (MenuSize == 3)
  else if (MenuSize == 4)
  {
    Item_W := 118
  } ; [End] else if (MenuSize == 4)
  else if (MenuSize == 5)
  {
    Item_W := 94
  } ; [End] else if (MenuSize == 5)
  else if (MenuSize == 6)
  {
    Item_W := 78
  } ; [End] else if (MenuSize == 6)
  else if (MenuSize == 7)
  {
    Item_W := 67
  } ; [End] else if (MenuSize == 7)
  else if (MenuSize == 8)
  {
    Item_W := 58
  } ; [End] else if (MenuSize == 8)
  else if (MenuSize == 9)
  {
    Item_W := 51
  } ; [End] else if (MenuSize == 9)
  else if (MenuSize == 10)
  {
    Item_W := 46
  } ; [End] else if (MenuSize == 10)
  else if (MenuSize == 11)
  {
    Item_W := 42
  } ; [End] else if (MenuSize == 11)
  ; -------------------------------------------
  R_Array := [Item_W, Item_H]
  return R_Array
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
