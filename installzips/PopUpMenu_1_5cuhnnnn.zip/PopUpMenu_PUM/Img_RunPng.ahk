﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\Folder_WindowsUser.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_ImgToIco.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_PathFolderOrName.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_ResizePng.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Run_GetLink.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_Convert.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Img_RunPng(ArrayIn) ; > FileRunPng
{
/*
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; -------------------------------------------
ArrayIn := [DataArray.367.5, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
FileRunPng := Img_RunPng(ArrayIn)
; -------------------------------------------
ArrayIn := [AppProcessPathNameExt, AppProcessName, UseCommonBrowser, UserLang, UserPictureFolder]
FileRunPng := Img_RunPng(ArrayIn)
; -------------------------------------------
ArrayIn := [run_OutTarget, "", "", UserLang, UserPictureFolder]
FileRunPng := Img_RunPng(ArrayIn)
; -------------------------------------------
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
AppProcessPathNameExt := ArrayIn.1 ; (DataArray.367.5)(AppProcessPathNameExt [Path,Name,Ext])
AppProcessName        := ArrayIn.2 ; (DataArray.367.1)(AppProcessName [Name][LowerCase][NoSpace])
UseCommonBrowser      := ArrayIn.3 ; (DataArray.290.2 = 2 [UseCommonBrowser = 2][Each Browser Different pum])(DataArray.290.2 = 1 [UseCommonBrowser = 1][All Browsers Same Pum])
UserLang              := ArrayIn.4 ; (DataArray.365.2)(UserLang [Current User language])
UserPictureFolder     := ArrayIn.5 ; (UserPictureFolder)(ThisUserPictureFolder)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
return FileRunPng
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
*/
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; StartUp Vars
  ; -------------------------------------------
  AppProcessPathNameExt := ArrayIn.1 ; (AppProcessPathNameExt)(AppProcessPathNameExt [Path,Name,Ext])
  AppProcessName        := ArrayIn.2 ; (AppProcessName)(AppProcessName [Name][LowerCase][NoSpace])
  UseCommonBrowser      := ArrayIn.3 ; (UseCommonBrowser = 1 [UseCommonBrowser = 2][Each Browser Different pum])(UseCommonBrowser = 0 [UseCommonBrowser = 1][All Browsers Same Pum])
  UserLang              := ArrayIn.4 ; (UserLang)(UserLang [Current User language])
  UserPictureFolder     := ArrayIn.5  ; (UserPictureFolder)(ThisUserPictureFolder)
  ; -------------------------------------------
  ; StartUp Vars
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; if This Value is Blank
  ; -------------------------------------------
  if (UseCommonBrowser == "")
  {
    UseCommonBrowser := 0
  }
  ; -------------------------------------------
  if (UserPictureFolder == "")
  {
    ; -------------------------------------------
    RegRead, UserPictureFolder, HKEY_CURRENT_USER, Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders, My Pictures
    ; -------------------------------------------
  }
  ; -------------------------------------------
  if (AppProcessName == "")
  {
    if (AppProcessPathNameExt != "")
    {
      SplitPath, AppProcessPathNameExt, , , , AppProcessName
    }
  }
  ; -------------------------------------------
  ; if This Value is Blank
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  if FileExist(AppProcessPathNameExt) ;  Application Path Exist
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ArrayIn          := [AppProcessPathNameExt, AppProcessName, UseCommonBrowser, "FileRunPng", UserLang, UserPictureFolder]
    ArrayOut         := Image_PathFolderOrName(ArrayIn)
    FileRunPng       := ArrayOut.1
    AppProcessName   := ArrayOut.2
    AppProcessExt    := ArrayOut.3
    AppProcessFolder := ArrayOut.4
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [CHECK] [CREATE]
    ; [UserPictureFolder "\(_PopUpMenu_)\(_Application_)\Png\" AppProcessName "_(" AppProcessFolder ").png"]
    ; -------------------------------------------
    if !FileExist(FileRunPng)
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; [CHECK] Gui Active
      ; -------------------------------------------
      GuiActive := WinExist("Shortcut_Pop_Up_Menu" . "ahk_class AutoHotkeyGUI")
      ; -------------------------------------------
      if (GuiActive == "0x0") ; Gui is NOT Active
      {
        GuiActive := 0
      } ; [End] Gui is NOT Active
      else ; Gui is Active
      {
        GuiActive := 1
      } ; [End] Gui is Active
      ; -------------------------------------------
      ; [CHECK] Gui Active
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; (AppProcessExt == "lnk") [CREATE] [UserPictureFolder "\(_PopUpMenu_)\(_Application_)\Png\" AppProcessName "_(" AppProcessFolder ").png"]
      ; -------------------------------------------
      if (AppProcessExt == "lnk") ; AppProcessPathNameExt is a Link
      {
        ; -------------------------------------------
        GetLink_Array := Run_GetLink(AppProcessPathNameExt, "") ; ThisLink, StringLink["Link","String"] > [Target, Arguments, LinkUse, LinkIcon, LinkName]
        Target    := GetLink_Array.1
        Arguments := GetLink_Array.2
        LinkUse   := GetLink_Array.3
        LinkIcon  := GetLink_Array.4
        LinkName  := GetLink_Array.5
        ; -------------------------------------------
        SplitPath, LinkIcon, , , LinkIcon_Ext
        StringLower, LinkIcon_Ext, LinkIcon_Ext
        ; -------------------------------------------
        if (LinkIcon_Ext == "exe") ; AppProcessPathNameExt is a Link to a Exicutible
        {
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          ; Extract (.png) from LinkIcon
          ; [UserPictureFolder "\(_PopUpMenu_)\(_Application_)\Png\" AppProcessName "_(" AppProcessFolder ").png"]
          ; -------------------------------------------
          Support_PumIconExtract := A_ProgramFiles "\PopUpMenu_PUM\support\PopUpMenu_IconExtract.exe"
          RunThis := Support_PumIconExtract " ""-res=" LinkIcon "`,0"" ""-icon=" FileRunPng """ -formats=180 -pngc" ; (383_1)([Icon Extract] PopUpMenu_IconExtract.exe [Support Program File Path])
          Run, %A_ProgramFiles%\PopUpMenu_PUM\PriorityProcess_IconExtract.ahk
          RunWait, %RunThis%, , Hide
          ; -------------------------------------------
        } ; [End] if (LinkIcon_Ext == "exe") ; AppProcessPathNameExt is a Exicutible
        ; -------------------------------------------
        if (LinkIcon_Ext == "ico") ; AppProcessPathNameExt is a Link to a (Icon.ico)
        {
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ; Image_ResizePng Will Convert the Icon (.ico) to a .png) with  No Error
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ;
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Convert (.ico) to (.png)
          ; [UserPictureFolder "\(_PopUpMenu_)\(_Application_)\Png\" AppProcessName "_(" AppProcessFolder ").png"]
          Image_ResizePng(180, 180, LinkIcon, FileRunPng) ; [RESIZE]_W, Resize_H, ImageIn, ImageOut > 1 / 0
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Convert (.ico) to (.png)
        } ; [End] if (LinkIcon_Ext == "ico") ; AppProcessPathNameExt is a Link
        ; -------------------------------------------
      } ; [End] if (AppProcessExt == "lnk")
      ; -------------------------------------------
      ; (AppProcessExt == "lnk") [CREATE] [UserPictureFolder "\(_PopUpMenu_)\(_Application_)\Png\" AppProcessName "_(" AppProcessFolder ").png"]
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; (AppProcessExt == "exe") [EXTRACT] [UserPictureFolder "\(_PopUpMenu_)\(_Application_)\Png\" AppProcessName "_(" AppProcessFolder ").png"]
      ; -------------------------------------------
      if (AppProcessExt == "exe") ; AppProcessPathNameExt is a Exicutible
      {
        
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ; Extract (.png) from LinkIcon
        ; [UserPictureFolder "\(_PopUpMenu_)\(_Application_)\Png\" AppProcessName "_(" AppProcessFolder ").png"]
        ; -------------------------------------------
        Support_PumIconExtract := A_ProgramFiles "\PopUpMenu_PUM\support\PopUpMenu_IconExtract.exe"
        RunThis := Support_PumIconExtract " ""-res=" AppProcessPathNameExt "`,0"" ""-icon=" FileRunPng """ -formats=180 -pngc" ; (383_1)([Icon Extract] PopUpMenu_IconExtract.exe [Support Program File Path])
        Run, %A_ProgramFiles%\PopUpMenu_PUM\PriorityProcess_IconExtract.ahk
        RunWait, %RunThis%, , Hide
        ; -------------------------------------------
        ; Extract (.png) from LinkIcon
        ; [UserPictureFolder "\(_PopUpMenu_)\(_Application_)\Png\" AppProcessName "_(" AppProcessFolder ").png"]
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ;
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ ; (_16_Apr_2023_)(_14_26_59_)
        ; Extracts Too many Icons using ResourceHacker
        ;
        ;~ ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ;~ ; Extract (_ProcessPng_).png from AppProcessPathNameExt
        ;~ ; [UserPictureFolder "\(_PopUpMenu_)\(_Application_)\Png\" AppProcessName "_(" AppProcessFolder ").png"]
        ;~ ; -------------------------------------------
        ;~ Support_ResourceHacker := A_ProgramFiles "\PopUpMenu_PUM\support\resourcehacker\PopUpMenu_ResourceHacker.exe"
        ;~ ; ------------------------------------------
        ;~ IconTempFolder := A_AppData "\PopUpMenu_PUM\temp\exeicon"
        ;~ if !FileExist(IconTempFolder)
        ;~ {
          ;~ FileCreateDir, %IconTempFolder%
          ;~ Sleep, 100
        ;~ }
        ;~ ; -------------------------------------------
        ;~ AnyIconFile := IconTempFolder "\*.ico"
        ;~ if FileExist(AnyIconFile)
        ;~ {
          ;~ FileDelete, %AnyIconFile%
          ;~ Sleep, 100
        ;~ }
        ;~ ; -------------------------------------------
        ;~ RunThis := Support_ResourceHacker " -open """ AppProcessPathNameExt """ -save """ IconTempFolder """ -action extract -mask ICONGROUP`,`, -log CON"
        ;~ Run, %A_ProgramFiles%\PopUpMenu_PUM\PriorityProcess_ResourceHacker.ahk
        ;~ RunWait, %RunThis%, , Hide
        ;~ ; -------------------------------------------
        ;~ Sleep, 100
        ;~ Loop Files, %IconTempFolder%\*.ico, R
        ;~ {
          ;~ ; -------------------------------------------
          ;~ FileExeIco := A_LoopFileFullPath
          ;~ ; -------------------------------------------
        ;~ }
        ;~ ; -------------------------------------------
        ;~ if FileExist(FileToRename)
        ;~ {
          ;~ FileRunPng := Image_Convert(FileExeIco, FileRunPng) ; Image_In, Image_Out > Image_Out
        ;~ }
        ;~ ; -------------------------------------------
        ;~ AnyIconFile := IconTempFolder "\*.ico"
        ;~ if FileExist(AnyIconFile)
        ;~ {
          ;~ FileDelete, %AnyIconFile%
          ;~ Sleep, 100
        ;~ }
        ;~ ; -------------------------------------------
        ;~ ; Extract (_ProcessPng_).png from AppProcessPathNameExt
        ;~ ; [UserPictureFolder "\(_PopUpMenu_)\(_Application_)\Png\" AppProcessName "_(" AppProcessFolder ").png"]
        ;~ ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;~ } ; [End] if (AppProcessExt == "exe")
      ;~ ; -------------------------------------------
      ;~ ; (AppProcessExt == "exe") [EXTRACT] [UserPictureFolder "\(_PopUpMenu_)\(_Application_)\Png\" AppProcessName "_(" AppProcessFolder ").png"]
      ;~ ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ ; (_16_Apr_2023_)(_14_26_59_)
      ;
      } ; if (AppProcessExt == "exe") ; AppProcessPathNameExt is a Exicutible
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; No Image in AppProcessPathNameExt
      ; -------------------------------------------
      if !FileExist(FileRunPng) ; No Image in AppProcessPathNameExt
      {
        ; -------------------------------------------
        if (AppProcessExt == "bat" or AppProcessExt == "cmd" or AppProcessExt == "com" or AppProcessExt == "exe")
        {
          ; -------------------------------------------
          Default_FileRunPng   := A_ProgramFiles "\PopUpMenu_PUM\image\ico\default\" AppProcessExt "\FileRunPng.png" ; w180 h180
          Default_FileRunIco   := A_ProgramFiles "\PopUpMenu_PUM\image\ico\default\" AppProcessExt "\FileRunIco.ico" ; w80 h80
          Default_FileRwhIco   := A_ProgramFiles "\PopUpMenu_PUM\image\ico\default\" AppProcessExt "\FileRwhIco.ico" ; w80 h80
          Default_FileOflIco   := A_ProgramFiles "\PopUpMenu_PUM\image\ico\default\" AppProcessExt "\FileOflIco.ico" ; w80 h80
          ;
          Default_FileMnu134 := A_ProgramFiles "\PopUpMenu_PUM\image\ico\default\" AppProcessExt "\FileMnu134.png" ; 130w 100h
          Default_FileMnu137 := A_ProgramFiles "\PopUpMenu_PUM\image\ico\default\" AppProcessExt "\FileMnu137.png" ; 480w 270h
          ;
          Default_FileError440_de := A_ProgramFiles "\PopUpMenu_PUM\image\ico\default\" AppProcessExt "\FileError440_de.png" ; 230w 90h
          Default_FileError440_en := A_ProgramFiles "\PopUpMenu_PUM\image\ico\default\" AppProcessExt "\FileError440_en.png" ; 230w 90h
          Default_FileError440_es := A_ProgramFiles "\PopUpMenu_PUM\image\ico\default\" AppProcessExt "\FileError440_es.png" ; 230w 90h
          Default_FileError440_fr := A_ProgramFiles "\PopUpMenu_PUM\image\ico\default\" AppProcessExt "\FileError440_fr.png" ; 230w 90h
          Default_FileError440_it := A_ProgramFiles "\PopUpMenu_PUM\image\ico\default\" AppProcessExt "\FileError440_it.png" ; 230w 90h
          Default_FileError440_pl := A_ProgramFiles "\PopUpMenu_PUM\image\ico\default\" AppProcessExt "\FileError440_pl.png" ; 230w 90h
          Default_FileError440_pt := A_ProgramFiles "\PopUpMenu_PUM\image\ico\default\" AppProcessExt "\FileError440_pt.png" ; 230w 90h
          Default_FileError440_ru := A_ProgramFiles "\PopUpMenu_PUM\image\ico\default\" AppProcessExt "\FileError440_ru.png" ; 230w 90h
          Default_FileError440_sv := A_ProgramFiles "\PopUpMenu_PUM\image\ico\default\" AppProcessExt "\FileError440_sv.png" ; 230w 90h
          Default_FileError440_tr := A_ProgramFiles "\PopUpMenu_PUM\image\ico\default\" AppProcessExt "\FileError440_tr.png" ; 230w 90h
          ;
          Default_FileError450_de := A_ProgramFiles "\PopUpMenu_PUM\image\ico\default\" AppProcessExt "\FileError450_de.png" ; 230w 90h
          Default_FileError450_en := A_ProgramFiles "\PopUpMenu_PUM\image\ico\default\" AppProcessExt "\FileError450_en.png" ; 230w 90h
          Default_FileError450_es := A_ProgramFiles "\PopUpMenu_PUM\image\ico\default\" AppProcessExt "\FileError450_es.png" ; 230w 90h
          Default_FileError450_fr := A_ProgramFiles "\PopUpMenu_PUM\image\ico\default\" AppProcessExt "\FileError450_fr.png" ; 230w 90h
          Default_FileError450_it := A_ProgramFiles "\PopUpMenu_PUM\image\ico\default\" AppProcessExt "\FileError450_it.png" ; 230w 90h
          Default_FileError450_pl := A_ProgramFiles "\PopUpMenu_PUM\image\ico\default\" AppProcessExt "\FileError450_pl.png" ; 230w 90h
          Default_FileError450_pt := A_ProgramFiles "\PopUpMenu_PUM\image\ico\default\" AppProcessExt "\FileError450_pt.png" ; 230w 90h
          Default_FileError450_ru := A_ProgramFiles "\PopUpMenu_PUM\image\ico\default\" AppProcessExt "\FileError450_ru.png" ; 230w 90h
          Default_FileError450_sv := A_ProgramFiles "\PopUpMenu_PUM\image\ico\default\" AppProcessExt "\FileError450_sv.png" ; 230w 90h
          Default_FileError450_tr := A_ProgramFiles "\PopUpMenu_PUM\image\ico\default\" AppProcessExt "\FileError450_tr.png" ; 230w 90h
          ;
          Default_FileNew254_de := A_ProgramFiles "\PopUpMenu_PUM\image\ico\default\" AppProcessExt "\FileNew254_de.png" ; 300w 300h
          Default_FileNew254_en := A_ProgramFiles "\PopUpMenu_PUM\image\ico\default\" AppProcessExt "\FileNew254_en.png" ; 300w 300h
          Default_FileNew254_es := A_ProgramFiles "\PopUpMenu_PUM\image\ico\default\" AppProcessExt "\FileNew254_es.png" ; 300w 300h
          Default_FileNew254_fr := A_ProgramFiles "\PopUpMenu_PUM\image\ico\default\" AppProcessExt "\FileNew254_fr.png" ; 300w 300h
          Default_FileNew254_it := A_ProgramFiles "\PopUpMenu_PUM\image\ico\default\" AppProcessExt "\FileNew254_it.png" ; 300w 300h
          Default_FileNew254_pl := A_ProgramFiles "\PopUpMenu_PUM\image\ico\default\" AppProcessExt "\FileNew254_pl.png" ; 300w 300h
          Default_FileNew254_pt := A_ProgramFiles "\PopUpMenu_PUM\image\ico\default\" AppProcessExt "\FileNew254_pt.png" ; 300w 300h
          Default_FileNew254_ru := A_ProgramFiles "\PopUpMenu_PUM\image\ico\default\" AppProcessExt "\FileNew254_ru.png" ; 300w 300h
          Default_FileNew254_sv := A_ProgramFiles "\PopUpMenu_PUM\image\ico\default\" AppProcessExt "\FileNew254_sv.png" ; 300w 300h
          Default_FileNew254_tr := A_ProgramFiles "\PopUpMenu_PUM\image\ico\default\" AppProcessExt "\FileNew254_tr.png" ; 300w 300h
          ;
          Default_FileDel254_de := A_ProgramFiles "\PopUpMenu_PUM\image\ico\default\" AppProcessExt "\FileDel254_de.png" ; 300w 300h
          Default_FileDel254_en := A_ProgramFiles "\PopUpMenu_PUM\image\ico\default\" AppProcessExt "\FileDel254_en.png" ; 300w 300h
          Default_FileDel254_es := A_ProgramFiles "\PopUpMenu_PUM\image\ico\default\" AppProcessExt "\FileDel254_es.png" ; 300w 300h
          Default_FileDel254_fr := A_ProgramFiles "\PopUpMenu_PUM\image\ico\default\" AppProcessExt "\FileDel254_fr.png" ; 300w 300h
          Default_FileDel254_it := A_ProgramFiles "\PopUpMenu_PUM\image\ico\default\" AppProcessExt "\FileDel254_it.png" ; 300w 300h
          Default_FileDel254_pl := A_ProgramFiles "\PopUpMenu_PUM\image\ico\default\" AppProcessExt "\FileDel254_pl.png" ; 300w 300h
          Default_FileDel254_pt := A_ProgramFiles "\PopUpMenu_PUM\image\ico\default\" AppProcessExt "\FileDel254_pt.png" ; 300w 300h
          Default_FileDel254_ru := A_ProgramFiles "\PopUpMenu_PUM\image\ico\default\" AppProcessExt "\FileDel254_ru.png" ; 300w 300h
          Default_FileDel254_sv := A_ProgramFiles "\PopUpMenu_PUM\image\ico\default\" AppProcessExt "\FileDel254_sv.png" ; 300w 300h
          Default_FileDel254_tr := A_ProgramFiles "\PopUpMenu_PUM\image\ico\default\" AppProcessExt "\FileDel254_tr.png" ; 300w 300h
          ; -------------------------------------------
          FileRunPng      := UserPictureFolder "\(_PopUpMenu_)\(_Application_)\Png\" AppProcessName "_(" AppProcessFolder ").png"
          FileRunIco      := UserPictureFolder "\(_PopUpMenu_)\(_Application_)\Ico\" AppProcessName "_(" AppProcessFolder ").ico"
          FileRwhIco      := UserPictureFolder "\(_PopUpMenu_)\(_Application_)\(_Item_)\" AppProcessName "_(" AppProcessFolder ").ico"
          FileOflIco      := UserPictureFolder "\(_PopUpMenu_)\(_Folder_)(_App_)\" AppProcessName "_(" AppProcessFolder ").ico"
          ;
          FileMnu134      := UserPictureFolder "\(_PopUpMenu_)\System\Mnu134\" AppProcessName "_(" AppProcessFolder ").png"
          FileMnu137      := UserPictureFolder "\(_PopUpMenu_)\System\Mnu137\" AppProcessName "_(" AppProcessFolder ").png"
          ;
          FileError440_de := UserPictureFolder "\(_PopUpMenu_)\System\Error440\de_" AppProcessName "_(" AppProcessFolder ").png"
          FileError440_en := UserPictureFolder "\(_PopUpMenu_)\System\Error440\en_" AppProcessName "_(" AppProcessFolder ").png"
          FileError440_es := UserPictureFolder "\(_PopUpMenu_)\System\Error440\es_" AppProcessName "_(" AppProcessFolder ").png"
          FileError440_fr := UserPictureFolder "\(_PopUpMenu_)\System\Error440\fr_" AppProcessName "_(" AppProcessFolder ").png"
          FileError440_it := UserPictureFolder "\(_PopUpMenu_)\System\Error440\it_" AppProcessName "_(" AppProcessFolder ").png"
          FileError440_pl := UserPictureFolder "\(_PopUpMenu_)\System\Error440\pl_" AppProcessName "_(" AppProcessFolder ").png"
          FileError440_pt := UserPictureFolder "\(_PopUpMenu_)\System\Error440\pt_" AppProcessName "_(" AppProcessFolder ").png"
          FileError440_ru := UserPictureFolder "\(_PopUpMenu_)\System\Error440\ru_" AppProcessName "_(" AppProcessFolder ").png"
          FileError440_sv := UserPictureFolder "\(_PopUpMenu_)\System\Error440\sv_" AppProcessName "_(" AppProcessFolder ").png"
          FileError440_tr := UserPictureFolder "\(_PopUpMenu_)\System\Error440\tr_" AppProcessName "_(" AppProcessFolder ").png"
          ;
          FileError450_de := UserPictureFolder "\(_PopUpMenu_)\System\Error450\de_" AppProcessName "_(" AppProcessFolder ").png"
          FileError450_en := UserPictureFolder "\(_PopUpMenu_)\System\Error450\en_" AppProcessName "_(" AppProcessFolder ").png"
          FileError450_es := UserPictureFolder "\(_PopUpMenu_)\System\Error450\es_" AppProcessName "_(" AppProcessFolder ").png"
          FileError450_fr := UserPictureFolder "\(_PopUpMenu_)\System\Error450\fr_" AppProcessName "_(" AppProcessFolder ").png"
          FileError450_it := UserPictureFolder "\(_PopUpMenu_)\System\Error450\it_" AppProcessName "_(" AppProcessFolder ").png"
          FileError450_pl := UserPictureFolder "\(_PopUpMenu_)\System\Error450\pl_" AppProcessName "_(" AppProcessFolder ").png"
          FileError450_pt := UserPictureFolder "\(_PopUpMenu_)\System\Error450\pt_" AppProcessName "_(" AppProcessFolder ").png"
          FileError450_ru := UserPictureFolder "\(_PopUpMenu_)\System\Error450\ru_" AppProcessName "_(" AppProcessFolder ").png"
          FileError450_sv := UserPictureFolder "\(_PopUpMenu_)\System\Error450\sv_" AppProcessName "_(" AppProcessFolder ").png"
          FileError450_tr := UserPictureFolder "\(_PopUpMenu_)\System\Error450\tr_" AppProcessName "_(" AppProcessFolder ").png"
          ;
          FileNew254_de   := UserPictureFolder "\(_PopUpMenu_)\System\New254\de_" AppProcessName "_(" AppProcessFolder ").png"
          FileNew254_en   := UserPictureFolder "\(_PopUpMenu_)\System\New254\en_" AppProcessName "_(" AppProcessFolder ").png"
          FileNew254_es   := UserPictureFolder "\(_PopUpMenu_)\System\New254\es_" AppProcessName "_(" AppProcessFolder ").png"
          FileNew254_fr   := UserPictureFolder "\(_PopUpMenu_)\System\New254\fr_" AppProcessName "_(" AppProcessFolder ").png"
          FileNew254_it   := UserPictureFolder "\(_PopUpMenu_)\System\New254\it_" AppProcessName "_(" AppProcessFolder ").png"
          FileNew254_pl   := UserPictureFolder "\(_PopUpMenu_)\System\New254\pl_" AppProcessName "_(" AppProcessFolder ").png"
          FileNew254_pt   := UserPictureFolder "\(_PopUpMenu_)\System\New254\pt_" AppProcessName "_(" AppProcessFolder ").png"
          FileNew254_ru   := UserPictureFolder "\(_PopUpMenu_)\System\New254\ru_" AppProcessName "_(" AppProcessFolder ").png"
          FileNew254_sv   := UserPictureFolder "\(_PopUpMenu_)\System\New254\sv_" AppProcessName "_(" AppProcessFolder ").png"
          FileNew254_tr   := UserPictureFolder "\(_PopUpMenu_)\System\New254\tr_" AppProcessName "_(" AppProcessFolder ").png"
          ;
          FileDel254_de   := UserPictureFolder "\(_PopUpMenu_)\System\Del254\de_" AppProcessName "_(" AppProcessFolder ").png"
          FileDel254_en   := UserPictureFolder "\(_PopUpMenu_)\System\Del254\en_" AppProcessName "_(" AppProcessFolder ").png"
          FileDel254_es   := UserPictureFolder "\(_PopUpMenu_)\System\Del254\es_" AppProcessName "_(" AppProcessFolder ").png"
          FileDel254_fr   := UserPictureFolder "\(_PopUpMenu_)\System\Del254\fr_" AppProcessName "_(" AppProcessFolder ").png"
          FileDel254_it   := UserPictureFolder "\(_PopUpMenu_)\System\Del254\it_" AppProcessName "_(" AppProcessFolder ").png"
          FileDel254_pl   := UserPictureFolder "\(_PopUpMenu_)\System\Del254\pl_" AppProcessName "_(" AppProcessFolder ").png"
          FileDel254_pt   := UserPictureFolder "\(_PopUpMenu_)\System\Del254\pt_" AppProcessName "_(" AppProcessFolder ").png"
          FileDel254_ru   := UserPictureFolder "\(_PopUpMenu_)\System\Del254\ru_" AppProcessName "_(" AppProcessFolder ").png"
          FileDel254_sv   := UserPictureFolder "\(_PopUpMenu_)\System\Del254\sv_" AppProcessName "_(" AppProcessFolder ").png"
          FileDel254_tr   := UserPictureFolder "\(_PopUpMenu_)\System\Del254\tr_" AppProcessName "_(" AppProcessFolder ").png"
          ;
          ; -------------------------------------------
          FileCopy, %Default_FileRunPng%, %FileRunPng%, 1
          FileCopy, %Default_FileRunIco%, %FileRunIco%, 1
          FileCopy, %Default_FileRwhIco%, %FileRwhIco%, 1
          FileCopy, %Default_FileOflIco%, %FileOflIco%, 1
          ;
          FileCopy, %Default_FileMnu134%, %FileMnu134%, 1
          FileCopy, %Default_FileMnu137%, %FileMnu137%, 1
          ;
          FileCopy, %Default_FileError440_de%, %FileError440_de%, 1
          FileCopy, %Default_FileError440_en%, %FileError440_en%, 1
          FileCopy, %Default_FileError440_es%, %FileError440_es%, 1
          FileCopy, %Default_FileError440_fr%, %FileError440_fr%, 1
          FileCopy, %Default_FileError440_it%, %FileError440_it%, 1
          FileCopy, %Default_FileError440_pl%, %FileError440_pl%, 1
          FileCopy, %Default_FileError440_pt%, %FileError440_pt%, 1
          FileCopy, %Default_FileError440_ru%, %FileError440_ru%, 1
          FileCopy, %Default_FileError440_sv%, %FileError440_sv%, 1
          FileCopy, %Default_FileError440_tr%, %FileError440_tr%, 1
          ;
          FileCopy, %Default_FileError450_de%, %FileError450_de%, 1
          FileCopy, %Default_FileError450_en%, %FileError450_en%, 1
          FileCopy, %Default_FileError450_es%, %FileError450_es%, 1
          FileCopy, %Default_FileError450_fr%, %FileError450_fr%, 1
          FileCopy, %Default_FileError450_it%, %FileError450_it%, 1
          FileCopy, %Default_FileError450_pl%, %FileError450_pl%, 1
          FileCopy, %Default_FileError450_pt%, %FileError450_pt%, 1
          FileCopy, %Default_FileError450_ru%, %FileError450_ru%, 1
          FileCopy, %Default_FileError450_sv%, %FileError450_sv%, 1
          FileCopy, %Default_FileError450_tr%, %FileError450_tr%, 1
          ;
          FileCopy, %Default_FileNew254_de%, %FileNew254_de%, 1
          FileCopy, %Default_FileNew254_en%, %FileNew254_en%, 1
          FileCopy, %Default_FileNew254_es%, %FileNew254_es%, 1
          FileCopy, %Default_FileNew254_fr%, %FileNew254_fr%, 1
          FileCopy, %Default_FileNew254_it%, %FileNew254_it%, 1
          FileCopy, %Default_FileNew254_pl%, %FileNew254_pl%, 1
          FileCopy, %Default_FileNew254_pt%, %FileNew254_pt%, 1
          FileCopy, %Default_FileNew254_ru%, %FileNew254_ru%, 1
          FileCopy, %Default_FileNew254_sv%, %FileNew254_sv%, 1
          FileCopy, %Default_FileNew254_tr%, %FileNew254_tr%, 1
          ;
          FileCopy, %Default_FileDel254_de%, %FileDel254_de%, 1
          FileCopy, %Default_FileDel254_en%, %FileDel254_en%, 1
          FileCopy, %Default_FileDel254_es%, %FileDel254_es%, 1
          FileCopy, %Default_FileDel254_fr%, %FileDel254_fr%, 1
          FileCopy, %Default_FileDel254_it%, %FileDel254_it%, 1
          FileCopy, %Default_FileDel254_pl%, %FileDel254_pl%, 1
          FileCopy, %Default_FileDel254_pt%, %FileDel254_pt%, 1
          FileCopy, %Default_FileDel254_ru%, %FileDel254_ru%, 1
          FileCopy, %Default_FileDel254_sv%, %FileDel254_sv%, 1
          FileCopy, %Default_FileDel254_tr%, %FileDel254_tr%, 1
          ;
          ; -------------------------------------------
        } ; [End] if (AppProcessExt == "bat" or AppProcessExt == "cmd" or AppProcessExt == "com" or AppProcessExt == "exe")
        ; -------------------------------------------
      } ; [End] if !FileExist(FileRunPng)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    } ; [End] if !FileExist(FileRunPng)
    ; -------------------------------------------
    ; [CHECK] [CREATE]
    ; [UserPictureFolder "\(_PopUpMenu_)\(_Application_)\Png\" AppProcessName "_(" AppProcessFolder ").png"]
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; -------------------------------------------
    return FileRunPng
    ; -------------------------------------------
  } ; [End] if FileExist(AppProcessPathNameExt) ;  Application Path Exist
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
