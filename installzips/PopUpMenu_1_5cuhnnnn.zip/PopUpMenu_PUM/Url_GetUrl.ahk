; -------------------------------------------
#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
; (_17_Aug_2023_)(_10_49_17_)
; Line 1204
; Very Long Wait for Url
; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
/*
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\Url_GetUrl.ahk
if (IsInternetBrowser(DataArray.367.1, DataArray.367.3, DataArray.367.4) == 1) ; All Supported Internet Browsers
if (IsInternetBrowser(DataArray.367.1, DataArray.367.3, DataArray.367.4) == 0) ; All Supported Internet Browsers
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
avantvw.exe ; Avant Browser (Alt + d)
Spark.exe ; Baidu Browser (Ctrl + L)
brave.exe ; Brave (Ctrl + L)
dragon.exe ; Comodo Dragon (Ctrl + L)
icedragon.exe ; Comodo IceDragon (Ctrl + L)
chrome.exe ; Coowon Browser (Ctrl + L)
Cyberfox.exe ; Cyberfox (Ctrl + L)
SlimBoat.exe ; FlashPeak SlimBoat (Ctrl + L)
slimbrowser.exe ; FlashPeak SlimBrowser (Ctrl + L)
slimjet.exe ; FlashPeak Slimjet (Ctrl + L)
chrome.exe ; Google Chrome (Ctrl + L)
iexplore.exe ; Internet Explorer (Ctrl + L)
iridium.exe ; Iridium (Ctrl + L)
Kingpin Private Browser.exe ; Kingpin Web Browser (Ctrl + D)
k-meleon.exe ; KMeleon Browser Window (Ctrl + L)
ahk_exe Maxthon.exe ; Maxthon (Ctrl + L)
ahk_exe msedge.exe ; Microsoft Edge (Ctrl + L)
firefox.exe ; Mozilla Firefox (Ctrl + L)
waterfox.exe ; Waterfox (Ctrl + L)
opera.exe ; Opera Browser (Ctrl + L)
chrome.exe ; Orbitum (Ctrl + L)
palemoon.exe ; Pale Moon (Ctrl + L)
Safari.exe ; Safari (Ctrl + L)
seamonkey.exe ; SeaMonkey (Ctrl + L)
chrome.exe ; SRWare Iron (Ctrl + L)
firefox.exe ; Tor Browser (Ctrl + L)
UCBrowser.exe ; UC Browser (Ctrl + L)
vivaldi.exe ; Vivaldi (Ctrl + L)
waterfox.exe ; Waterfox Classic (Ctrl + L)
browser.exe ; Yandex (Ctrl + L)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
avantvw.exe; 
brave.exe; 
browser.exe;
chrome.exe; 
Cyberfox.exe; 
dragon.exe; 
firefox.exe; 
waterfox.exe;
icedragon.exe; 
iexplore.exe; 
iridium.exe; 
Kingpin Private Browser.exe; 
k-meleon.exe; 
Safari.exe; 
seamonkey.exe; 
SlimBoat.exe; 
slimbrowser.exe; 
slimjet.exe;
Spark.exe; 
Maxthon.exe; 
msedge.exe; 
opera.exe; 
palemoon.exe; 
UCBrowser.exe; 
vivaldi.exe; 
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
SelectedItems_OutTarget_ExtName != "avantvw.exe" && 
SelectedItems_OutTarget_ExtName != "brave.exe" && 
SelectedItems_OutTarget_ExtName != "browser.exe" && 
SelectedItems_OutTarget_ExtName != "chrome.exe" && 
SelectedItems_OutTarget_ExtName != "cyberfox.exe" && 
SelectedItems_OutTarget_ExtName != "dragon.exe" && 
SelectedItems_OutTarget_ExtName != "firefox.exe" && 
SelectedItems_OutTarget_ExtName != "waterfox.exe" && 
SelectedItems_OutTarget_ExtName != "icedragon.exe" && 
SelectedItems_OutTarget_ExtName != "iexplore.exe" && 
SelectedItems_OutTarget_ExtName != "iridium.exe" && 
SelectedItems_OutTarget_ExtName != "kingpinprivatebrowser.exe" && 
SelectedItems_OutTarget_ExtName != "k-meleon.exe" && 
SelectedItems_OutTarget_ExtName != "safari.exe" && 
SelectedItems_OutTarget_ExtName != "seamonkey.exe" && 
SelectedItems_OutTarget_ExtName != "slimboat.exe" && 
SelectedItems_OutTarget_ExtName != "slimbrowser.exe" && 
SelectedItems_OutTarget_ExtName != "slimjet.exe" && 
SelectedItems_OutTarget_ExtName != "spark.exe" && 
SelectedItems_OutTarget_ExtName != "maxthon.exe" && 
SelectedItems_OutTarget_ExtName != "msedge.exe" && 
SelectedItems_OutTarget_ExtName != "opera.exe" && 
SelectedItems_OutTarget_ExtName != "palemoon.exe" && 
SelectedItems_OutTarget_ExtName != "ucbrowser.exe" && 
SelectedItems_OutTarget_ExtName != "vivaldi.exe" && 
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Avant Browser
; ------------------------------------------- 0
PageTitle - Avant Browser
ahk_class TAFfrmClient.UnicodeClass
ahk_exe avantvw.exe

(Failed) GetBrowserURL_ACC 
(Failed) GetBrowserURL_DDE
(Failed) Url_GetUrl_1

Alt + d
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Baidu Browser
; ------------------------------------------- 0
PageTitle - Baidu Browser
ahk_class {7597C4B1-F62C-4e83-A35F-8B69C8779DC1}
ahk_exe Spark.exe

(Failed) GetBrowserURL_ACC
(Failed) GetBrowserURL_DDE
(Failed) Url_GetUrl_1

Ctrl + L
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Brave
; ------------------------------------------- 1-3
PageTitle - Brave
ahk_class Chrome_WidgetWin_1
ahk_exe brave.exe

(OK) GetBrowserURL_ACC
(Failed) GetBrowserURL_DDE
(OK) Url_GetUrl_1

Ctrl + L
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Comodo Dragon
; ------------------------------------------- 1-3
PageTitle - Comodo Dragon
ahk_class Chrome_WidgetWin_1
ahk_exe dragon.exe

(OK) GetBrowserURL_ACC
(Failed) GetBrowserURL_DDE
(OK) Url_GetUrl_1

Ctrl + L
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Comodo IceDragon
; ------------------------------------------- 0
PageTitle - Comodo IceDragon
ahk_class MozillaWindowClass
ahk_exe icedragon.exe

(Failed) GetBrowserURL_ACC
(Failed) GetBrowserURL_DDE
(Failed) Url_GetUrl_1

Ctrl + L
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Coowon Browser
; -------------------------------------------  1-3
PageTitle - Coowon Browser
ahk_class Chrome_WidgetWin_1
ahk_exe chrome.exe

(OK) GetBrowserURL_ACC
(Failed) GetBrowserURL_DDE
(OK) Url_GetUrl_1

Ctrl + L
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Cyberfox
; ------------------------------------------- 0
PageTitle - Cyberfox
ahk_class MozillaWindowClass
ahk_exe Cyberfox.exe

(Failed) GetBrowserURL_ACC
(Failed) GetBrowserURL_DDE
(Failed) Url_GetUrl_1

Ctrl + L
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
FlashPeak SlimBoat
; ------------------------------------------- 0
PageTitle - SlimBoat
ahk_class QWidget
ahk_exe SlimBoat.exe

(Failed) GetBrowserURL_ACC
(Failed) GetBrowserURL_DDE
(Failed) Url_GetUrl_1

Ctrl + L
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
FlashPeak SlimBrowser
; ------------------------------------------- 1
PageTitle — FlashPeak Slimbrowser
ahk_class FlashPeakWindowClass
ahk_exe slimbrowser.exe

(OK) GetBrowserURL_ACC
(Failed) GetBrowserURL_DDE
(Failed) Url_GetUrl_1

Ctrl + L
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
FlashPeak Slimjet
; -------------------------------------------  1-3
PageTitle - Slimjet
ahk_class Slimjet64_WidgetWin_1
ahk_exe slimjet.exe

(OK) GetBrowserURL_ACC
(Failed) GetBrowserURL_DDE
(OK) Url_GetUrl_1

Ctrl + L
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Google Chrome
; -------------------------------------------  1-3
PageTitle - Google Chrome
ahk_class Chrome_WidgetWin_1
ahk_exe chrome.exe

(OK) GetBrowserURL_ACC
(Failed) GetBrowserURL_DDE
(OK) Url_GetUrl_1

Ctrl + L
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 1-2
Internet Explorer
; -------------------------------------------
PageTitle - Internet Explorer
ahk_class IEFrame
ahk_exe iexplore.exe

(OK) GetBrowserURL_ACC
(OK) GetBrowserURL_DDE
(Failed) Url_GetUrl_1

Ctrl + L
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Iridium
; -------------------------------------------  1-3
PageTitle - Iridium
ahk_class Chrome_WidgetWin_1
ahk_exe iridium.exe

(OK) GetBrowserURL_ACC
(Failed) GetBrowserURL_DDE
(OK) Url_GetUrl_1

Ctrl + L
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Kingpin
; ------------------------------------------- 0
Kingpin Web Browser
ahk_class Chrome_WidgetWin_1
ahk_exe Kingpin Private Browser.exe

(Failed) GetBrowserURL_ACC
(Failed) GetBrowserURL_DDE
(Failed) Url_GetUrl_1

Ctrl + D
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
K-Meleon
; ------------------------------------------- 1
PageTitle - K-Meleon
ahk_class KMeleon Browser Window
ahk_exe k-meleon.exe

(OK) GetBrowserURL_ACC
(Failed) GetBrowserURL_DDE
(Failed) Url_GetUrl_1

Ctrl + L
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Maxthon
; -------------------------------------------  1-3
PageTitle - Maxthon
ahk_class Chrome_WidgetWin_1
ahk_exe Maxthon.exe

(OK) GetBrowserURL_ACC
(Failed) GetBrowserURL_DDE
(OK) Url_GetUrl_1

Ctrl + L
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Microsoft Edge
; -------------------------------------------  1-3
PageTitle - Personal - Microsoft​ Edge
ahk_class Chrome_WidgetWin_1
ahk_exe msedge.exe

(OK) GetBrowserURL_ACC
(Failed) GetBrowserURL_DDE
(OK) Url_GetUrl_1

Ctrl + L
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Mozilla Firefox
; ------------------------------------------- 1
PageTitle — Mozilla Firefox
ahk_class MozillaWindowClass
ahk_exe firefox.exe

(OK) GetBrowserURL_ACC
(Failed) GetBrowserURL_DDE
(Failed) Url_GetUrl_1

Ctrl + L
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Waterfox
; ------------------------------------------- 1
PageTitle — Waterfox
ahk_class MozillaWindowClass
ahk_exe waterfox.exe

(OK) GetBrowserURL_ACC
(Failed) GetBrowserURL_DDE
(Failed) Url_GetUrl_1

Ctrl + L
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Opera Browser
; -------------------------------------------
PageTitle - Opera
ahk_class Chrome_WidgetWin_1
ahk_exe opera.exe

(OK) GetBrowserURL_ACC
(Failed) GetBrowserURL_DDE
(Failed) Url_GetUrl_1

Ctrl + L
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Orbitum
; -------------------------------------------  1-3
PageTitle - Orbitum
ahk_class Chrome_WidgetWin_1
ahk_exe chrome.exe

(OK) GetBrowserURL_ACC
(Failed) GetBrowserURL_DDE
(OK) Url_GetUrl_1

Ctrl + L
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Pale Moon
; ------------------------------------------- 0
PageTitle - Pale Moon
ahk_class MozillaWindowClass
ahk_exe palemoon.exe

(Failed) GetBrowserURL_ACC
(Failed) GetBrowserURL_DDE
(Failed) Url_GetUrl_1

Ctrl + L
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Safari
; ------------------------------------------- 1
PageTitle
ahk_class {1C03B488-D53B-4a81-97F8-754559640193}
ahk_exe Safari.exe

(OK) GetBrowserURL_ACC
(Failed) GetBrowserURL_DDE
(Failed) Url_GetUrl_1

Ctrl + L
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
SeaMonkey
; ------------------------------------------- 1-2
PageTitle - SeaMonkey
ahk_class MozillaWindowClass
ahk_exe seamonkey.exe

(OK) GetBrowserURL_ACC
(OK) GetBrowserURL_DDE
(Failed) Url_GetUrl_1

Ctrl + L
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
SRWare Iron
; ------------------------------------------- 1-3
PageTitle - Iron
ahk_class Chrome_WidgetWin_1
ahk_exe chrome.exe

(OK) GetBrowserURL_ACC
(Failed) GetBrowserURL_DDE
(OK) Url_GetUrl_1

Ctrl + L
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Tor Browser
; ------------------------------------------- 1
PageTitle — Tor Browser
ahk_class MozillaWindowClass
ahk_exe firefox.exe

(OK) GetBrowserURL_ACC
(Failed) GetBrowserURL_DDE
(Failed) Url_GetUrl_1

Ctrl + L
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
UC Browser
; ------------------------------------------- 0
PageTitle - UC Browser
ahk_class Chrome_WidgetWin_1
ahk_exe UCBrowser.exe

(Failed) GetBrowserURL_ACC
(Failed) GetBrowserURL_DDE
(Failed) Url_GetUrl_1

Ctrl + L
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Vivaldi
; ------------------------------------------- 0
PageTitle - Vivaldi
ahk_class Chrome_WidgetWin_1
ahk_exe vivaldi.exe

(Failed) GetBrowserURL_ACC
(Failed) GetBrowserURL_DDE
(Failed) Url_GetUrl_1

Ctrl + L
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Waterfox Classic
; ------------------------------------------- 1
PageTitle - Waterfox Classic
ahk_class MozillaWindowClass
ahk_exe waterfox.exe

(OK) GetBrowserURL_ACC
(Failed) GetBrowserURL_DDE
(Failed) Url_GetUrl_1

Ctrl + L
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Yandex
; -------------------------------------------  1-3
1: PageTitle — Yandex Browser
ahk_class YandexBrowser_WidgetWin_1
ahk_exe browser.exe

(OK) GetBrowserURL_ACC
(Failed) GetBrowserURL_DDE
(OK) Url_GetUrl_1

Ctrl + L
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
*/
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Url_GetUrl_A(AppProcessClass) ; AppProcessClass > URL_Address
{
	; -------------------------------------------
	URL_Address :=  ""
	; -------------------------------------------
	global nWindow := ""
  global accAddressBar := ""
  ; -------------------------------------------
	URL_Address := GetBrowserURL_ACC(AppProcessClass)
	; -------------------------------------------
	;
	; -------------------------------------------
	return URL_Address
	; -------------------------------------------
}
; -------------------------------------------
GetBrowserURL_DDE(sClass)
{
	; -------------------------------------------
	WinGet, sServer, ProcessName, % "ahk_class " sClass
	StringTrimRight, sServer, sServer, 4
	iCodePage := A_IsUnicode ? 0x04B0 : 0x03EC ; 0x04B0 = CP_WINUNICODE, 0x03EC = CP_WINANSI
	DllCall("DdeInitialize", "UPtrP", idInst, "Uint", 0, "Uint", 0, "Uint", 0)
	hServer := DllCall("DdeCreateStringHandle", "UPtr", idInst, "Str", sServer, "int", iCodePage)
	hTopic := DllCall("DdeCreateStringHandle", "UPtr", idInst, "Str", "WWW_GetWindowInfo", "int", iCodePage)
	hItem := DllCall("DdeCreateStringHandle", "UPtr", idInst, "Str", "0xFFFFFFFF", "int", iCodePage)
	hConv := DllCall("DdeConnect", "UPtr", idInst, "UPtr", hServer, "UPtr", hTopic, "Uint", 0)
	hData := DllCall("DdeClientTransaction", "Uint", 0, "Uint", 0, "UPtr", hConv, "UPtr", hItem, "UInt", 1, "Uint", 0x20B0, "Uint", 10000, "UPtrP", nResult) ; 0x20B0 = XTYP_REQUEST, 10000 = 10s timeout
	sData := DllCall("DdeAccessData", "Uint", hData, "Uint", 0, "Str")
	DllCall("DdeFreeStringHandle", "UPtr", idInst, "UPtr", hServer)
	DllCall("DdeFreeStringHandle", "UPtr", idInst, "UPtr", hTopic)
	DllCall("DdeFreeStringHandle", "UPtr", idInst, "UPtr", hItem)
	DllCall("DdeUnaccessData", "UPtr", hData)
	DllCall("DdeFreeDataHandle", "UPtr", hData)
	DllCall("DdeDisconnect", "UPtr", hConv)
	DllCall("DdeUninitialize", "UPtr", idInst)
	csvWindowInfo := StrGet(&sData, "CP0")
	StringSplit, sWindowInfo, csvWindowInfo, `" ;"; comment to avoid a syntax highlighting issue in autohotkey.com/boards
	Return sWindowInfo2
	; -------------------------------------------
} ; [End] GetBrowserURL_DDE(sClass)
; -------------------------------------------
GetBrowserURL_ACC(sClass)
{
	; -------------------------------------------
	global nWindow, accAddressBar
	; -------------------------------------------
	if (nWindow != WinExist("ahk_class " sClass)) ; reuses accAddressBar if it's the same window
	{
		nWindow := WinExist("ahk_class " sClass)
		global accAddressBar := GetAddressBar(Acc_ObjectFromWindow(nWindow))
	}
	; -------------------------------------------
	Try sURL := accAddressBar.accValue(0)
	; -------------------------------------------
	if (sURL == "")
	{
		; -------------------------------------------
		WinGet, nWindows, List, % "ahk_class " sClass ; In case of a nested browser window as in the old CoolNovo (TO DO: check if still needed)
		if (nWindows > 1)
		{
			global accAddressBar := GetAddressBar(Acc_ObjectFromWindow(nWindows2))
			Try sURL := accAddressBar.accValue(0)
		}
		; -------------------------------------------
	}
	; -------------------------------------------
	if ((sURL != "") and (SubStr(sURL, 1, 4) != "http")) ; Modern browsers omit "h t t p : / /"
	{
		sURL := "http://" sURL
	}
	; -------------------------------------------
	if (sURL == "")
	{
		nWindow := -1 ; Don't remember the window if there is no URL
	}
	; -------------------------------------------
	Return sURL
	; -------------------------------------------
} ; [End] GetBrowserURL_ACC(sClass)
; -------------------------------------------
GetAddressBar(accObj)
{
	; -------------------------------------------
	Try if ((accObj.accRole(0) == 42) and IsURL(accObj.accValue(0)))
	{
		Return accObj
	}
	; -------------------------------------------
	Try if ((accObj.accRole(0) == 42) and IsURL("http://" accObj.accValue(0))) ; Modern browsers omit " h t t p : / / "
	{
		Return accObj
	}
	; -------------------------------------------
	For nChild, accChild in Acc_Children(accObj)
	{
		if IsObject(accAddressBar1 := GetAddressBar(accChild))
		{
			Return accAddressBar1
		}
	}
	; -------------------------------------------
} ; [End] GetAddressBar(accObj)
; -------------------------------------------
IsURL(sURL)
{
	Return RegExMatch(sURL, "^(?<Protocol>https?|ftp)://(?<Domain>(?:[\w-]+\.)+\w\w+)(?::(?<Port>\d+))?/?(?<Path>(?:[^:/?# ]*/?)+)(?:\?(?<Query>[^#]+)?)?(?:\#(?<Hash>.+)?)?$")
} ; [End] IsURL(sURL)
; -------------------------------------------
Acc_Init()
{
	; -------------------------------------------
	static h
	if Not h
	{
		h:=DllCall("LoadLibrary","Str","oleacc","Ptr")
	}
	; -------------------------------------------
} ; [End] Acc_Init()
; -------------------------------------------
Acc_ObjectFromWindow(hWnd, idObject = 0)
{
	; -------------------------------------------
	Acc_Init()
	if DllCall("oleacc\AccessibleObjectFromWindow", "Ptr", hWnd, "UInt", idObject&=0xFFFFFFFF, "Ptr", -VarSetCapacity(IID,16)+NumPut(idObject==0xFFFFFFF0?0x46000000000000C0:0x719B3800AA000C81,NumPut(idObject==0xFFFFFFF0?0x0000000000020400:0x11CF3C3D618736E0,IID,"Int64"),"Int64"), "Ptr*", pacc)=0
	{
	  Return ComObjEnwrap(9,pacc,1)
	}
	; -------------------------------------------
} ; [End] Acc_ObjectFromWindow(hWnd, idObject = 0)
; -------------------------------------------
Acc_Query(Acc)
{
	; -------------------------------------------
	Try Return ComObj(9, ComObjQuery(Acc,"{618736e0-3c3d-11cf-810c-00aa00389b71}"), 1)
	; -------------------------------------------
} ; [End] Acc_Query(Acc)
; -------------------------------------------
Acc_Children(Acc)
{
	; -------------------------------------------
	if ComObjType(Acc,"Name") != "IAccessible"
	{
		ErrorLevel := "Invalid IAccessible Object"
	}
	else
	{
		; -------------------------------------------
		PassFail := 1
		; -------------------------------------------
		try  ; Attempts to execute code.
    {
      Acc_Init(), cChildren:=Acc.accChildCount, Children:=[]
		}
		catch
		{
			PassFail := 0
		}
		; -------------------------------------------
		if (PassFail == 1)
		{
			; -------------------------------------------
		  if DllCall("oleacc\AccessibleChildren", "Ptr",ComObjValue(Acc), "Int",0, "Int",cChildren, "Ptr",VarSetCapacity(varChildren,cChildren*(8+2*A_PtrSize),0)*0+&varChildren, "Int*",cChildren)=0
		  {
  			Loop %cChildren%
			  {
  				i:=(A_Index-1)*(A_PtrSize*2+8)+8, child:=NumGet(varChildren,i), Children.Insert(NumGet(varChildren,i-8)=9?Acc_Query(child):child), NumGet(varChildren,i-8)=9?ObjRelease(child):
			  }
			  Return Children.MaxIndex()?Children:
		  }
		  else
		  {
  			ErrorLevel := "AccessibleChildren DllCall Failed"
		  }
		}
	}
	; -------------------------------------------
} ; [End] Acc_Children(Acc)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Url_GetUrl_B(AppProcessTitle) ; AppProcessTitle > URL_Address
{
	; -------------------------------------------
	ErrorLevel := 0
	if !(wId := WinExist(AppProcessTitle))
	{
		ErrorLevel := 1
		return
	}
	; -------------------------------------------
	IUIAutomation := ComObjCreate(CLSID_CUIAutomation := "{ff48dba4-60ef-4201-aa87-54103eef594e}", IID_IUIAutomation := "{30cbe57d-d9d0-452a-ab13-7ac5ac4825ee}")
	DllCall(NumGet(NumGet(IUIAutomation+0)+6*A_PtrSize), "ptr", IUIAutomation, "ptr", wId, "ptr*", elementMain)   ; IUIAutomation::ElementFromHandle
	NumPut(addressbarStrPtr := DllCall("oleaut32\SysAllocString", "wstr", "Address and search bar", "ptr"),(VarSetCapacity(addressbar,8+2*A_PtrSize)+NumPut(8,addressbar,0,"short"))*0+&addressbar,8,"ptr")
	DllCall("oleaut32\SysFreeString", "ptr", addressbarStrPtr)
	; -------------------------------------------
	if (A_PtrSize = 4)
	{
		DllCall(NumGet(NumGet(IUIAutomation+0)+23*A_PtrSize), "ptr", IUIAutomation, "int", 30005, "int64", NumGet(addressbar, 0, "int64"), "int64", NumGet(addressbar, 8, "int64"), "ptr*", addressbarCondition)   ; IUIAutomation::CreatePropertyCondition
	}
	else
	{
		DllCall(NumGet(NumGet(IUIAutomation+0)+23*A_PtrSize), "ptr", IUIAutomation, "int", 30005, "ptr", &addressbar, "ptr*", addressbarCondition)   ; IUIAutomation::CreatePropertyCondition
	}
	; -------------------------------------------
	DllCall(NumGet(NumGet(elementMain+0)+5*A_PtrSize), "ptr", elementMain, "int", TreeScope_Descendants := 0x4, "ptr", addressbarCondition, "ptr*", currentURLElement) ; IUIAutomationElement::FindFirst
	DllCall(NumGet(NumGet(currentURLElement+0)+10*A_PtrSize),"ptr",currentURLElement,"uint",30045,"ptr",(VarSetCapacity(currentURL,8+2*A_PtrSize)+NumPut(0,currentURL,0,"short")+NumPut(0,currentURL,8,"ptr"))*0+&currentURL) ;IUIAutomationElement::GetCurrentPropertyValue
	ObjRelease(currentURLElement)
	ObjRelease(elementMain)
	ObjRelease(IUIAutomation)
	return StrGet(NumGet(currentURL,8,"ptr"),"utf-16")
	; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Url_GetUrl_C(AppProcessName, AppProcessClass) ; AppProcessClass, AppProcessName > URL_Address
{
	; -------------------------------------------
	; AppProcessName ALWAYS Loser Case
	; -------------------------------------------
	StringLower, AppProcessClass, AppProcessClass
	AppProcessClass := StrReplace(AppProcessClass, A_Space, "")
	; -------------------------------------------
	StringLower, AppProcessName, AppProcessName
	AppProcessName := StrReplace(AppProcessName, A_Space, "")
	AppProcessName := StrReplace(AppProcessName, ".exe", "")
	; -------------------------------------------
	if (AppProcessName == "avantvw" && AppProcessClass == "taffrmclient.unicodeclass")
	{
		; Alt + D
		Url_Address := SendKeyStroke("AD") ; "CD" "CL" "AD" > Url_Address
	}
	else if (AppProcessName == "spark" && AppProcessClass == "{7597c4b1-f62c-4e83-a35f-8b69c8779dc1}")
	{
		; Ctrl + L
		Url_Address := SendKeyStroke("CL") ; "CD" "CL" "AD" > Url_Address
	}
	else if (AppProcessName == "brave" && AppProcessClass == "chrome_widgetwin_1")
	{
		; Ctrl + L
		Url_Address := SendKeyStroke("CL") ; "CD" "CL" "AD" > Url_Address
	}
	else if (AppProcessName == "dragon" && AppProcessClass == "chrome_widgetwin_1")
	{
		; Ctrl + L
		Url_Address := SendKeyStroke("CL") ; "CD" "CL" "AD" > Url_Address
	}
	else if (AppProcessName == "icedragon" && AppProcessClass == "mozillawindowclass")
	{
		; Ctrl + L
		Url_Address := SendKeyStroke("CL") ; "CD" "CL" "AD" > Url_Address
	}
	else if (AppProcessName == "chrome" && AppProcessClass == "chrome_widgetwin_1") ; (Google Chrome) (Coowon Browser) (Orbitum) (SRWare Iron)
	{
		; Ctrl + L
		Url_Address := SendKeyStroke("CL") ; "CD" "CL" "AD" > Url_Address
	}
	else if (AppProcessName == "cyberfox" && AppProcessClass == "mozillawindowclass")
	{
		; Ctrl + L
		Url_Address := SendKeyStroke("CL") ; "CD" "CL" "AD" > Url_Address
	}
	else if (AppProcessName == "slimboat" && AppProcessClass == "qwidget")
	{
		; Ctrl + L
		Url_Address := SendKeyStroke("CL") ; "CD" "CL" "AD" > Url_Address
	}
	else if (AppProcessName == "slimbrowser" && AppProcessClass == "flashpeakwindowclass")
	{
		; Ctrl + L
		Url_Address := SendKeyStroke("CL") ; "CD" "CL" "AD" > Url_Address
	}
	else if (AppProcessName == "slimjet") ; AppProcessClass == Slimjet64_WidgetWin_1 (Could also be 32)
	{
		; Ctrl + L
		Url_Address := SendKeyStroke("CL") ; "CD" "CL" "AD" > Url_Address
	}
	else if (AppProcessName == "iexplore" && AppProcessClass == "ieframe")
	{
		; Ctrl + L
		Url_Address := SendKeyStroke("CL") ; "CD" "CL" "AD" > Url_Address
	}
	else if (AppProcessName == "iridium" && AppProcessClass == "chrome_widgetwin_1")
	{
		; Ctrl + L
		Url_Address := SendKeyStroke("CL") ; "CD" "CL" "AD" > Url_Address
	}
	else if (AppProcessName == "kingpinprivatebrowser" && AppProcessClass == "chrome_widgetwin_1")
	{
		; Ctrl + D
		Url_Address := SendKeyStroke("CD") ; "CD" "CL" "AD" > Url_Address
	}
	else if (AppProcessName == "k-meleon" && AppProcessClass == "kmeleonbrowserwindow")
	{
		; Ctrl + L
		Url_Address := SendKeyStroke("CL") ; "CD" "CL" "AD" > Url_Address
	}
	else if (AppProcessName == "maxthon" && AppProcessClass == "chrome_widgetwin_1")
	{
		; Ctrl + L
		Url_Address := SendKeyStroke("CL") ; "CD" "CL" "AD" > Url_Address
	}
	else if (AppProcessName == "msedge" && AppProcessClass == "chrome_widgetwin_1")
	{
		; Ctrl + L
		Url_Address := SendKeyStroke("CL") ; "CD" "CL" "AD" > Url_Address
	}
	else if (AppProcessName == "firefox" && AppProcessClass == "mozillawindowclass") ; (Mozilla Firefox) (Tor Browser)
	{
		; Ctrl + L
		Url_Address := SendKeyStroke("CL") ; "CD" "CL" "AD" > Url_Address
	}
	else if (AppProcessName == "waterfox" && AppProcessClass == "mozillawindowclass")
	{
		; Ctrl + L
		Url_Address := SendKeyStroke("CL") ; "CD" "CL" "AD" > Url_Address
	}
	else if (AppProcessName == "" && AppProcessClass == "")
	{
		; Ctrl + L
		Url_Address := SendKeyStroke("CL") ; "CD" "CL" "AD" > Url_Address
	}
	else if (AppProcessName == "opera" && AppProcessClass == "chrome_widgetwin_1")
	{
		; Ctrl + L
		Url_Address := SendKeyStroke("CL") ; "CD" "CL" "AD" > Url_Address
	}
	else if (AppProcessName == "palemoon" && AppProcessClass == "mozillawindowclass")
	{
		; Ctrl + L
		Url_Address := SendKeyStroke("CL") ; "CD" "CL" "AD" > Url_Address
	}
	else if (AppProcessName == "safari" && AppProcessClass == "{1c03b488-d53b-4a81-97f8-754559640193}")
	{
		; Ctrl + L
		Url_Address := SendKeyStroke("CL") ; "CD" "CL" "AD" > Url_Address
	}
	else if (AppProcessName == "seamonkey" && AppProcessClass == "mozillawindowclass")
	{
		; Ctrl + L
		Url_Address := SendKeyStroke("CL") ; "CD" "CL" "AD" > Url_Address
	}
	else if (AppProcessName == "ucbrowser" && AppProcessClass == "chrome_widgetwin_1")
	{
		; Ctrl + L
		Url_Address := SendKeyStroke("CL") ; "CD" "CL" "AD" > Url_Address
	}
	else if (AppProcessName == "vivaldi" && AppProcessClass == "chrome_widgetwin_1")
	{
		; Ctrl + L
		Url_Address := SendKeyStroke("CL") ; "CD" "CL" "AD" > Url_Address
	}
	else if (AppProcessName == "browser" && AppProcessClass == "yandexbrowser_widgetwin_1")
	{
		; Ctrl + L
		Url_Address := SendKeyStroke("CL") ; "CD" "CL" "AD" > Url_Address
	}
	; -------------------------------------------
	;
	; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	; (_17_Aug_2023_)(_11_09_30_)
  Send, {Esc 2}
	; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	;
	; -------------------------------------------
	return URL_Address
	; -------------------------------------------
} ; Url_GetUrl_C(AppProcessClass, AppProcessName) ; AppProcessClass, AppProcessName > URL Address
; -------------------------------------------
SendKeyStroke(SendThis) ; "CD" "CL" "AD" > Url_Address
{
	; -------------------------------------------
	if (Clipboard == "")
	{
		OldClip := ""
	}
	else
	{
	  OldClip := Clipboard
	  Clipboard := 
		Sleep, 100
	}
  ; -------------------------------------------
	if (SendThis == "CD")
	{
		; -------------------------------------------
		Send, {Ctrl Down}d{Ctrl Up}
		; -------------------------------------------
	} ; if (SendThis == "CD")
	else if (SendThis == "CL")
	{
		; -------------------------------------------
		Send, {Ctrl Down}l{Ctrl Up}
		; -------------------------------------------
	} ; else if (SendThis == "CL")
	else if (SendThis == "AD")
	{
		; -------------------------------------------
		Send, {Alt Down}d{Alt Up}
		; -------------------------------------------
	} ; else if (SendThis == "AD")
	; -------------------------------------------
	Sleep, 100
	Send, {Ctrl Down}c{Ctrl Up}
	Sleep, 100
	Url_Address := Clipboard
	; -------------------------------------------
	if (OldClip != "")
	{
	  Clipboard := OldClip
		Sleep, 100
	}
	; -------------------------------------------
	return Url_Address
	; -------------------------------------------
} ; FromCtrl(SendThis)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Url_GetTitle(AppProcessName, AppProcessClass, AppProcessTitle) ; > [Browser_Name, Url_Title]
{
	; -------------------------------------------
	Browser_Name := ""
	; -------------------------------------------
	StringLower, AppProcessClass, AppProcessClass
	AppProcessClass := StrReplace(AppProcessClass, A_Space, "")
	; -------------------------------------------
	StringLower, AppProcessName, AppProcessName
	AppProcessName := StrReplace(AppProcessName, A_Space, "")
	AppProcessName := StrReplace(AppProcessName, ".exe", "")
	; -------------------------------------------
	;
  ; -------------------------------------------
	Url_Title := AppProcessTitle
	; -------------------------------------------
	;
	; -------------------------------------------
  if (AppProcessName == "avantvw" && AppProcessClass == "taffrmclient.unicodeclass" && InStr(Url_Title, "Avant") > 0)
	{
		; -------------------------------------------
		Url_Title := StrReplace(Url_Title, " — Avant Browser", "")
		Url_Title := StrReplace(Url_Title, " - Avant Browser", "")
		Browser_Name := "Avant Browser"
		; -------------------------------------------
	}
	else if (AppProcessName == "spark" && AppProcessClass == "{7597c4b1-f62c-4e83-a35f-8b69c8779dc1}" && InStr(Url_Title, "Baidu") > 0)
	{
		; -------------------------------------------
		Url_Title := StrReplace(Url_Title, " — Baidu Browser", "")
		Url_Title := StrReplace(Url_Title, " - Baidu Browser", "")
		Browser_Name := "Baidu Browser"
		; -------------------------------------------
	}
	else if (AppProcessName == "brave" && AppProcessClass == "chrome_widgetwin_1" && InStr(Url_Title, "Brave") > 0)
	{
		; -------------------------------------------
		Url_Title := StrReplace(Url_Title, " — Brave", "")
		Url_Title := StrReplace(Url_Title, " - Brave", "")
		Browser_Name := "Brave"
		; -------------------------------------------
	}
	else if (AppProcessName == "dragon" && AppProcessClass == "chrome_widgetwin_1" && InStr(Url_Title, "Comodo Dragon") > 0)
	{
		; -------------------------------------------
		Url_Title := StrReplace(Url_Title, " — Comodo Dragon", "")
		Url_Title := StrReplace(Url_Title, " - Comodo Dragon", "")
		Browser_Name := "Comodo Dragon"
		; -------------------------------------------
	}
	else if (AppProcessName == "icedragon" && AppProcessClass == "mozillawindowclass" && InStr(Url_Title, "Comodo IceDragon") > 0)
	{
		; -------------------------------------------
		Url_Title := StrReplace(Url_Title, " — Comodo IceDragon", "")
		Url_Title := StrReplace(Url_Title, " - Comodo IceDragon", "")
		Browser_Name := "Comodo IceDragon"
		; -------------------------------------------
	}
	else if (AppProcessName == "chrome" && AppProcessClass == "chrome_widgetwin_1" && InStr(Url_Title, "Coowon") > 0)
	{
		; -------------------------------------------
		Url_Title := StrReplace(Url_Title, " — Coowon Browser", "")
		Url_Title := StrReplace(Url_Title, " - Coowon Browser", "")
		Browser_Name := "Coowon Browser"
		; -------------------------------------------
	}
	else if (AppProcessName == "cyberfox" && AppProcessClass == "mozillawindowclass" && InStr(Url_Title, "Cyberfox") > 0)
	{
		; -------------------------------------------
		Url_Title := StrReplace(Url_Title, " — Cyberfox", "")
		Url_Title := StrReplace(Url_Title, " - Cyberfox", "")
		Browser_Name := "Cyberfox"
		; -------------------------------------------
	}
	else if (AppProcessName == "slimboat" && AppProcessClass == "qwidget" && InStr(Url_Title, "SlimBoat") > 0)
	{
		; -------------------------------------------
		Url_Title := StrReplace(Url_Title, " — SlimBoat", "")
		Url_Title := StrReplace(Url_Title, " - SlimBoat", "")
		Browser_Name := "SlimBoat"
		; -------------------------------------------
	}
	else if (AppProcessName == "slimbrowser" && AppProcessClass == "flashpeakwindowclass" && InStr(Url_Title, "Slimbrowser") > 0)
	{
		; -------------------------------------------
		Url_Title := StrReplace(Url_Title, " — FlashPeak Slimbrowser", "")
		Url_Title := StrReplace(Url_Title, " - FlashPeak Slimbrowser", "")
		Browser_Name := "FlashPeak Slimbrowser"
		; -------------------------------------------
	}
	else if (AppProcessName == "slimjet" && InStr(Url_Title, "Slimjet") > 0) ; AppProcessClass == Slimjet64_WidgetWin_1 (Could also be 32)
	{
		; -------------------------------------------
		Url_Title := StrReplace(Url_Title, " — Slimjet", "")
		Url_Title := StrReplace(Url_Title, " - Slimjet", "")
		Browser_Name := "Slimjet"
		; -------------------------------------------
	}
	else if (AppProcessName == "chrome" && AppProcessClass == "chrome_widgetwin_1" && InStr(Url_Title, "Chrome") > 0)
	{
		; -------------------------------------------
		Url_Title := StrReplace(Url_Title, " — Google Chrome", "")
		Url_Title := StrReplace(Url_Title, " - Google Chrome", "")
		Browser_Name := "Google Chrome"
		; -------------------------------------------
	}
	else if (AppProcessName == "iexplore" && AppProcessClass == "ieframe" && InStr(Url_Title, "Internet Explorer") > 0)
	{
		; -------------------------------------------
		Url_Title := StrReplace(Url_Title, " — Internet Explorer", "")
		Url_Title := StrReplace(Url_Title, " - Internet Explorer", "")
		Browser_Name := "Internet Explorer"
		; -------------------------------------------
	}
	else if (AppProcessName == "iridium" && AppProcessClass == "chrome_widgetwin_1" && InStr(Url_Title, "Iridium") > 0)
	{
		; -------------------------------------------
		Url_Title := StrReplace(Url_Title, " — Iridium", "")
		Url_Title := StrReplace(Url_Title, " - Iridium", "")
		Browser_Name := "Iridium"
		; -------------------------------------------
	}
	else if (AppProcessName == "kingpinprivatebrowser" && AppProcessClass == "chrome_widgetwin_1" && InStr(Url_Title, "Kingpin Web Browser") > 0)
	{
		; -------------------------------------------
		Url_Title := StrReplace(Url_Title, "Kingpin Web Browser", "")
		Browser_Name := "Kingpin Web Browser"
		; -------------------------------------------
	}
	else if (AppProcessName == "k-meleon" && AppProcessClass == "kmeleonbrowserwindow" && InStr(Url_Title, "K-Meleon") > 0)
	{
		; -------------------------------------------
		Url_Title := StrReplace(Url_Title, " — K-Meleon", "")
		Url_Title := StrReplace(Url_Title, " - K-Meleon", "")
		Browser_Name := "K-Meleon"
		; -------------------------------------------
	}
	else if (AppProcessName == "maxthon" && AppProcessClass == "chrome_widgetwin_1" && InStr(Url_Title, "Maxthon") > 0)
	{
		; -------------------------------------------
		Url_Title := StrReplace(Url_Title, " — Maxthon", "")
		Url_Title := StrReplace(Url_Title, " - Maxthon", "")
		Browser_Name := "Maxthon"
		; -------------------------------------------
	}
	else if (AppProcessName == "msedge" && AppProcessClass == "chrome_widgetwin_1" && InStr(Url_Title, "Microsoft​ Edge") > 0)
	{
		; -------------------------------------------
		Url_Title := StrReplace(Url_Title, " — Personal - Microsoft​ Edge", "")
		Url_Title := StrReplace(Url_Title, " — Personal — Microsoft​ Edge", "")
		Url_Title := StrReplace(Url_Title, " - Personal - Microsoft​ Edge", "")
		Url_Title := StrReplace(Url_Title, " — Microsoft​ Edge", "")
		Url_Title := StrReplace(Url_Title, " - Microsoft​ Edge", "")
		Browser_Name := "Microsoft​ Edge"
		; -------------------------------------------
	}
	else if (AppProcessName == "firefox" && AppProcessClass == "mozillawindowclass" && InStr(Url_Title, "Firefox") > 0)
	{
		; -------------------------------------------
	  Url_Title := StrReplace(Url_Title, " — Mozilla Firefox", "")
	  Url_Title := StrReplace(Url_Title, " - Mozilla Firefox", "")
		Browser_Name := "Mozilla Firefox"
		; -------------------------------------------
	}
	else if (AppProcessName == "waterfox" && AppProcessClass == "mozillawindowclass" && InStr(Url_Title, "Waterfox") > 0)
	{
		; -------------------------------------------
	  Url_Title := StrReplace(Url_Title, " — Waterfox", "")
	  Url_Title := StrReplace(Url_Title, " - Waterfox", "")
		Browser_Name := "Waterfox"
		; -------------------------------------------
	}
	else if (AppProcessName == "opera" && AppProcessClass == "chrome_widgetwin_1" && InStr(Url_Title, "Opera") > 0)
	{
		; -------------------------------------------
		Url_Title := StrReplace(Url_Title, " — Opera", "")
		Url_Title := StrReplace(Url_Title, " - Opera", "")
		Browser_Name := "Opera"
		; -------------------------------------------
	}
	else if (AppProcessName == "chrome" && AppProcessClass == "chrome_widgetwin_1" && InStr(Url_Title, "Orbitum") > 0) ; (Google Chrome) (Coowon Browser) (Orbitum) (SRWare Iron)
	{
		; -------------------------------------------
		Url_Title := StrReplace(Url_Title, " — Orbitum", "")
		Url_Title := StrReplace(Url_Title, " - Orbitum", "")
		Browser_Name := "Orbitum"
		; -------------------------------------------
	}
	else if (AppProcessName == "palemoon" && AppProcessClass == "mozillawindowclass" && InStr(Url_Title, "Pale Moon") > 0)
	{
		; -------------------------------------------
		Url_Title := StrReplace(Url_Title, " — Pale Moon", "")
		Url_Title := StrReplace(Url_Title, " - Pale Moon", "")
		Browser_Name := "Pale Moon"
		; -------------------------------------------
	}
	else if (AppProcessName == "safari" && AppProcessClass == "{1c03b488-d53b-4a81-97f8-754559640193}") ; Safari NOT in Url_Title
	{
		; -------------------------------------------
		Url_Title := AppProcessTitle ; Safari NOT in Url_Title
		Browser_Name := "Safari"
		; -------------------------------------------
	}
	else if (AppProcessName == "seamonkey" && AppProcessClass == "mozillawindowclass" && InStr(Url_Title, "SeaMonkey") > 0)
	{
		; -------------------------------------------
		Url_Title := StrReplace(Url_Title, " — SeaMonkey", "")
		Url_Title := StrReplace(Url_Title, " - SeaMonkey", "")
		Browser_Name := "SeaMonkey"
		; -------------------------------------------
	}
	else if (AppProcessName == "chrome" && AppProcessClass == "chrome_widgetwin_1" && InStr(Url_Title, "Iron") > 0) ; (Google Chrome) (Coowon Browser) (Orbitum) (SRWare Iron)
	{
		; -------------------------------------------
		Url_Title := StrReplace(Url_Title, " — Iron", "")
		Url_Title := StrReplace(Url_Title, " - Iron", "")
		Browser_Name := "Iron"
		; -------------------------------------------
	}
	else if (AppProcessName == "firefox" && AppProcessClass == "mozillawindowclass" && InStr(Url_Title, "Tor Browser") > 0) ; (Mozilla Firefox) (Tor Browser)
	{
		; -------------------------------------------
		Url_Title := StrReplace(Url_Title, " — Tor Browser", "")
		Url_Title := StrReplace(Url_Title, " - Tor Browser", "")
		Browser_Name := "Tor Browser"
		; -------------------------------------------
	}
	else if (AppProcessName == "ucbrowser" && AppProcessClass == "chrome_widgetwin_1" && InStr(Url_Title, "UC Browser") > 0)
	{
		; -------------------------------------------
		Url_Title := StrReplace(Url_Title, " — UC Browser", "")
		Url_Title := StrReplace(Url_Title, " - UC Browser", "")
		Browser_Name := "UC Browser"
		; -------------------------------------------
	}
	else if (AppProcessName == "vivaldi" && AppProcessClass == "chrome_widgetwin_1" && InStr(Url_Title, "Vivaldi") > 0)
	{
		; -------------------------------------------
		Url_Title := StrReplace(Url_Title, " — Vivaldi", "")
		Url_Title := StrReplace(Url_Title, " - Vivaldi", "")
		Browser_Name := "Vivaldi"
		; -------------------------------------------
	}
	else if (AppProcessName == "waterfox" && AppProcessClass == "mozillawindowclass" && InStr(Url_Title, "Waterfox Classic") > 0)
	{
		; -------------------------------------------
		Url_Title := StrReplace(Url_Title, " — Waterfox Classic", "")
		Url_Title := StrReplace(Url_Title, " - Waterfox Classic", "")
		Browser_Name := "Waterfox Classic"
		; -------------------------------------------
	}
	else if (AppProcessName == "browser" && AppProcessClass == "yandexbrowser_widgetwin_1" && InStr(Url_Title, "Yandex Browser") > 0)
	{
		; -------------------------------------------
		Url_Title := StrReplace(Url_Title, " — Yandex Browser", "")
		Url_Title := StrReplace(Url_Title, " - Yandex Browser", "")
		Browser_Name := "Yandex Browser"
		; -------------------------------------------
	}
	; -------------------------------------------
	ReturnArray := [Browser_Name, Url_Title]
	; -------------------------------------------
	return ReturnArray
	; -------------------------------------------
} ; Url_GetTitle(AppProcessName, AppProcessClass, AppProcessTitle) ; > [Browser_Name, Url_Title]
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Url_GetUrl(AppProcessName, AppProcessClass, AppProcessTitle) ; > [URL_Address, Url_Title, Browser_Name]
{
	; -------------------------------------------
	URL_Address := ""
	; -------------------------------------------
	Url_Array := Url_GetTitle(AppProcessName, AppProcessClass, AppProcessTitle) ; > [Browser_Name, Url_Title]
	Browser_Name := Url_Array.1
	Url_Title := Url_Array.2
  ; -------------------------------------------
	if (IsStartPage(AppProcessName, AppProcessClass, AppProcessTitle) == 0) ; is Not a (New Tab) or (Start page)
	{
		; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
		; Was Remarked Out (From Here) (To Here)
		; (_17_Aug_2023_)(_10_49_17_)
		; Very Long Wait for Url
		; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ;~ URL_Address := Url_GetUrl_C(AppProcessName, AppProcessClass) ; AppProcessClass, AppProcessName > URL_Address
		;
		; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
		; (_26_Aug_2023_)(_09_35_37_)
		; Put Back Anne had Error Where when she clicked het Hot key "LWin" the pum woulf come up
		; but would goto to the "lock screen Switch User"
		; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
		;
		; Was Remarked Out (From Here)
	  ; -------------------------------------------
	  URL_Address := ""
	  ; -------------------------------------------
	  URL_Address := Url_GetUrl_A(AppProcessClass) ; AppProcessClass > URL_Address
		; -------------------------------------------
	  if (URL_Address == "")
	  {
  		URL_Address := Url_GetUrl_B(AppProcessTitle) ; AppProcessTitle > URL_Address
		  if (URL_Address == "")
	    {
  			URL_Address := Url_GetUrl_C(AppProcessName, AppProcessClass) ; AppProcessClass, AppProcessName > URL_Address
		  }
	  }
	  ; -------------------------------------------
		; Was Remarked Out (To Here)
		; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	}
	; -------------------------------------------
	ReturnArray := [URL_Address, Url_Title, Browser_Name]
	; -------------------------------------------
	return ReturnArray
	; -------------------------------------------
}
; -------------------------------------------
IsInternetBrowser(AppProcessName, AppProcessClass, AppProcessTitle) ; > ThisAppIsBrowser (0 or 1)
{
	; -------------------------------------------
	StringLower, AppProcessClass, AppProcessClass
	AppProcessClass := StrReplace(AppProcessClass, A_Space, "")
	; -------------------------------------------
	StringLower, AppProcessName, AppProcessName
	AppProcessName := StrReplace(AppProcessName, A_Space, "")
	AppProcessName := StrReplace(AppProcessName, ".exe", "")
	; -------------------------------------------
  ;
  ; -------------------------------------------
	ThisAppIsBrowser := 0
	; -------------------------------------------
	;
	; -------------------------------------------
  if (AppProcessName == "avantvw" && AppProcessClass == "taffrmclient.unicodeclass" && InStr(AppProcessTitle, "Avant") > 0)
	{
		ThisAppIsBrowser := 1
	}
	else if (AppProcessName == "spark" && AppProcessClass == "{7597c4b1-f62c-4e83-a35f-8b69c8779dc1}" && InStr(AppProcessTitle, "Baidu") > 0)
	{
		ThisAppIsBrowser := 1
	}
	else if (AppProcessName == "brave" && AppProcessClass == "chrome_widgetwin_1" && InStr(AppProcessTitle, "Brave") > 0)
	{
		ThisAppIsBrowser := 1
	}
	else if (AppProcessName == "dragon" && AppProcessClass == "chrome_widgetwin_1" && InStr(AppProcessTitle, "Comodo Dragon") > 0)
	{
		ThisAppIsBrowser := 1
	}
	else if (AppProcessName == "icedragon" && AppProcessClass == "mozillawindowclass" && InStr(AppProcessTitle, "Comodo IceDragon") > 0)
	{
		ThisAppIsBrowser := 1
	}
	else if (AppProcessName == "chrome" && AppProcessClass == "chrome_widgetwin_1" && InStr(AppProcessTitle, "Coowon") > 0)
	{
		ThisAppIsBrowser := 1
	}
	else if (AppProcessName == "cyberfox" && AppProcessClass == "mozillawindowclass" && InStr(AppProcessTitle, "Cyberfox") > 0)
	{
		ThisAppIsBrowser := 1
	}
	else if (AppProcessName == "slimboat" && AppProcessClass == "qwidget" && InStr(AppProcessTitle, "SlimBoat") > 0)
	{
		ThisAppIsBrowser := 1
	}
	else if (AppProcessName == "slimbrowser" && AppProcessClass == "flashpeakwindowclass" && InStr(AppProcessTitle, "Slimbrowser") > 0)
	{
		ThisAppIsBrowser := 1
	}
	else if (AppProcessName == "slimjet" && InStr(AppProcessTitle, "Slimjet") > 0) ; AppProcessClass == Slimjet64_WidgetWin_1 (Could also be 32)
	{
		ThisAppIsBrowser := 1
	}
	else if (AppProcessName == "chrome" && AppProcessClass == "chrome_widgetwin_1" && InStr(AppProcessTitle, "Chrome") > 0)
	{
		ThisAppIsBrowser := 1
	}
	else if (AppProcessName == "iexplore" && AppProcessClass == "ieframe" && InStr(AppProcessTitle, "Internet Explorer") > 0)
	{
		ThisAppIsBrowser := 1
	}
	else if (AppProcessName == "iridium" && AppProcessClass == "chrome_widgetwin_1" && InStr(AppProcessTitle, "Iridium") > 0)
	{
		ThisAppIsBrowser := 1
	}
	else if (AppProcessName == "kingpinprivatebrowser" && AppProcessClass == "chrome_widgetwin_1" && InStr(AppProcessTitle, "Kingpin Web Browser") > 0)
	{
		ThisAppIsBrowser := 1
	}
	else if (AppProcessName == "k-meleon" && AppProcessClass == "kmeleonbrowserwindow" && InStr(AppProcessTitle, "K-Meleon") > 0)
	{
		ThisAppIsBrowser := 1
	}
	else if (AppProcessName == "maxthon" && AppProcessClass == "chrome_widgetwin_1" && InStr(AppProcessTitle, "Maxthon") > 0)
	{
		ThisAppIsBrowser := 1
	}
	else if (AppProcessName == "msedge" && AppProcessClass == "chrome_widgetwin_1" && InStr(AppProcessTitle, "Edge") > 0)
	{
		ThisAppIsBrowser := 1
	}
	else if (AppProcessName == "firefox" && AppProcessClass == "mozillawindowclass" && InStr(AppProcessTitle, "Firefox") > 0)
	{
	  ThisAppIsBrowser := 1
	}
	else if (AppProcessName == "waterfox" && AppProcessClass == "mozillawindowclass" && InStr(AppProcessTitle, "Waterfox") > 0)
	{
	  ThisAppIsBrowser := 1
	}
	else if (AppProcessName == "opera" && AppProcessClass == "chrome_widgetwin_1" && InStr(AppProcessTitle, "Opera") > 0)
	{
		ThisAppIsBrowser := 1
	}
	else if (AppProcessName == "chrome" && AppProcessClass == "chrome_widgetwin_1" && InStr(AppProcessTitle, "Orbitum") > 0) ; (Google Chrome) (Coowon Browser) (Orbitum) (SRWare Iron)
	{
		ThisAppIsBrowser := 1
	}
	else if (AppProcessName == "palemoon" && AppProcessClass == "mozillawindowclass" && InStr(AppProcessTitle, "Pale Moon") > 0)
	{
		ThisAppIsBrowser := 1
	}
	else if (AppProcessName == "safari" && AppProcessClass == "{1c03b488-d53b-4a81-97f8-754559640193}") ; Safari NOT in AppProcessTitle
	{
		ThisAppIsBrowser := 1
	}
	else if (AppProcessName == "seamonkey" && AppProcessClass == "mozillawindowclass" && InStr(AppProcessTitle, "SeaMonkey") > 0)
	{
    ThisAppIsBrowser := 1
	}
	else if (AppProcessName == "chrome" && AppProcessClass == "chrome_widgetwin_1" && InStr(AppProcessTitle, "Iron") > 0) ; (Google Chrome) (Coowon Browser) (Orbitum) (SRWare Iron)
	{
		ThisAppIsBrowser := 1
	}
	else if (AppProcessName == "torbrowser" && AppProcessClass == "mozillawindowclass" && InStr(AppProcessTitle, "Tor Browser") > 0) ; (Mozilla Firefox) (Tor Browser)
	{
		ThisAppIsBrowser := 1
	}
	else if (AppProcessName == "ucbrowser" && AppProcessClass == "chrome_widgetwin_1" && InStr(AppProcessTitle, "UC Browser") > 0)
	{
		ThisAppIsBrowser := 1
	}
	else if (AppProcessName == "vivaldi" && AppProcessClass == "chrome_widgetwin_1" && InStr(AppProcessTitle, "Vivaldi") > 0)
	{
		ThisAppIsBrowser := 1
	}
	else if (AppProcessName == "waterfox" && AppProcessClass == "mozillawindowclass" && InStr(AppProcessTitle, "Waterfox Classic") > 0)
	{
		ThisAppIsBrowser := 1
	}
	else if (AppProcessName == "browser" && AppProcessClass == "yandexbrowser_widgetwin_1" && InStr(AppProcessTitle, "Yandex") > 0)
	{
		ThisAppIsBrowser := 1
	}
	; -------------------------------------------
	return ThisAppIsBrowser
	; -------------------------------------------
} ; IsInternetBrowser(AppProcessName, AppProcessClass, AppProcessTitle) ; > ThisAppIsBrowser (0 or 1)
; -------------------------------------------
IsStartPage(AppProcessName, AppProcessClass, AppProcessTitle) ; > StartPage (0 or 1)
{
	; -------------------------------------------
	StringLower, AppProcessClass, AppProcessClass
	AppProcessClass := StrReplace(AppProcessClass, A_Space, "")
	; -------------------------------------------
	StringLower, AppProcessName, AppProcessName
	AppProcessName := StrReplace(AppProcessName, A_Space, "")
	AppProcessName := StrReplace(AppProcessName, ".exe", "")
	; -------------------------------------------
  ;
  ; -------------------------------------------
	StartPage := 0
	; -------------------------------------------
	; NO (NEW TAB) or (START PAGE)
	; -----------
	; Avant Browser
	; Coowon
	; Kingpin Web Browser
	; Safari
	; -------------------------------------------
	if (AppProcessName == "spark" && AppProcessClass == "{7597c4b1-f62c-4e83-a35f-8b69c8779dc1}" && InStr(AppProcessTitle, "Baidu") > 0)
	{
		if (InStr(AppProcessTitle, "New Tab") > 0)
		{
			StartPage := 1
		}
	}
	else if (AppProcessName == "brave" && AppProcessClass == "chrome_widgetwin_1" && InStr(AppProcessTitle, "Brave") > 0)
	{
		if (InStr(AppProcessTitle, "New Tab") > 0)
		{
			StartPage := 1
		}
	}
	else if (AppProcessName == "dragon" && AppProcessClass == "chrome_widgetwin_1" && InStr(AppProcessTitle, "Comodo Dragon") > 0)
	{
		if (InStr(AppProcessTitle, "New Tab") > 0)
		{
			StartPage := 1
		}
	}
	else if (AppProcessName == "icedragon" && AppProcessClass == "mozillawindowclass" && InStr(AppProcessTitle, "Comodo IceDragon") > 0)
	{
		if (AppProcessTitle == "Comodo IceDragon")
		{
			StartPage := 1
		}
	}
	else if (AppProcessName == "cyberfox" && AppProcessClass == "mozillawindowclass" && InStr(AppProcessTitle, "Cyberfox") > 0)
	{
		if (InStr(AppProcessTitle, "Start Page") > 0)
		{
			StartPage := 1
		}
	}
	else if (AppProcessName == "slimboat" && AppProcessClass == "qwidget" && InStr(AppProcessTitle, "SlimBoat") > 0)
	{
		if (InStr(AppProcessTitle, "New Tab") > 0)
		{
			StartPage := 1
		}
	}
	else if (AppProcessName == "slimbrowser" && AppProcessClass == "flashpeakwindowclass" && InStr(AppProcessTitle, "Slimbrowser") > 0)
	{
		if (AppProcessTitle == "FlashPeak Slimbrowser")
		{
			StartPage := 1
		}
	}
	else if (AppProcessName == "slimjet" && InStr(AppProcessTitle, "Slimjet") > 0) ; AppProcessClass == Slimjet64_WidgetWin_1 (Could also be 32)
	{
		if (InStr(AppProcessTitle, "New Tab") > 0)
		{
			StartPage := 1
		}
	}
	else if (AppProcessName == "chrome" && AppProcessClass == "chrome_widgetwin_1" && InStr(AppProcessTitle, "Chrome") > 0)
	{
		if (InStr(AppProcessTitle, "New Tab") > 0)
		{
			StartPage := 1
		}
	}
	else if (AppProcessName == "iexplore" && AppProcessClass == "ieframe" && InStr(AppProcessTitle, "Internet Explorer") > 0)
	{
		if (InStr(AppProcessTitle, "New Tab") > 0)
		{
			StartPage := 1
		}
	}
	else if (AppProcessName == "iridium" && AppProcessClass == "chrome_widgetwin_1" && InStr(AppProcessTitle, "Iridium") > 0)
	{
		if (InStr(AppProcessTitle, "New Tab") > 0)
		{
			StartPage := 1
		}
	}
	else if (AppProcessName == "k-meleon" && AppProcessClass == "kmeleonbrowserwindow" && InStr(AppProcessTitle, "K-Meleon") > 0)
	{
		if (InStr(AppProcessTitle, "Start Page") > 0)
		{
			StartPage := 1
		}
	}
	else if (AppProcessName == "maxthon" && AppProcessClass == "chrome_widgetwin_1" && InStr(AppProcessTitle, "Maxthon") > 0)
	{
		if (InStr(AppProcessTitle, "Start Page") > 0)
		{
			StartPage := 1
		}
	}
	else if (AppProcessName == "msedge" && AppProcessClass == "chrome_widgetwin_1" && InStr(AppProcessTitle, "Microsoft​ Edge") > 0)
	{
		if (InStr(AppProcessTitle, "New tab") > 0)
		{
			StartPage := 1
		}
	}
	else if (AppProcessName == "firefox" && AppProcessClass == "mozillawindowclass" && InStr(AppProcessTitle, "Firefox") > 0)
	{
		if (AppProcessTitle == "Mozilla Firefox")
		{
			StartPage := 1
		}
	}
	else if (AppProcessName == "waterfox" && AppProcessClass == "mozillawindowclass" && InStr(AppProcessTitle, "Waterfox") > 0)
	{
		if (AppProcessTitle == "Waterfox")
		{
			StartPage := 1
		}
	}
	else if (AppProcessName == "opera" && AppProcessClass == "chrome_widgetwin_1" && InStr(AppProcessTitle, "Opera") > 0)
	{
		if (InStr(AppProcessTitle, "Speed Dial") > 0)
		{
			StartPage := 1
		}
	}
	else if (AppProcessName == "chrome" && AppProcessClass == "chrome_widgetwin_1" && InStr(AppProcessTitle, "Orbitum") > 0) ; (Google Chrome) (Coowon Browser) (Orbitum) (SRWare Iron)
	{
		if (InStr(AppProcessTitle, "Popular websites") > 0)
		{
			StartPage := 1
		}
	}
	else if (AppProcessName == "palemoon" && AppProcessClass == "mozillawindowclass" && InStr(AppProcessTitle, "Pale Moon") > 0)
	{
		if (InStr(AppProcessTitle, "start.me") > 0)
		{
			StartPage := 1
		}
	}
	else if (AppProcessName == "seamonkey" && AppProcessClass == "mozillawindowclass" && InStr(AppProcessTitle, "SeaMonkey") > 0)
	{
		if (InStr(AppProcessTitle, "Welcome to SeaMonkey") > 0)
		{
			StartPage := 1
		}
	}
	else if (AppProcessName == "chrome" && AppProcessClass == "chrome_widgetwin_1" && InStr(AppProcessTitle, "Iron") > 0) ; (Google Chrome) (Coowon Browser) (Orbitum) (SRWare Iron)
	{
		if (InStr(AppProcessTitle, "New Tab") > 0)
		{
			StartPage := 1
		}
	}
	else if (AppProcessName == "firefox" && AppProcessClass == "mozillawindowclass" && InStr(AppProcessTitle, "Tor Browser") > 0) ; (Mozilla Firefox) (Tor Browser)
	{
		if (InStr(AppProcessTitle, "About Tor") > 0)
		{
			StartPage := 1
		}
	}
	else if (AppProcessName == "ucbrowser" && AppProcessClass == "chrome_widgetwin_1" && InStr(AppProcessTitle, "UC Browser") > 0)
	{
		if (InStr(AppProcessTitle, "Start your online journey from here") > 0)
		{
			StartPage := 1
		}
	}
	else if (AppProcessName == "vivaldi" && AppProcessClass == "chrome_widgetwin_1" && InStr(AppProcessTitle, "Vivaldi") > 0)
	{
		if (InStr(AppProcessTitle, "Start Page") > 0)
		{
			StartPage := 1
		}
	}
	else if (AppProcessName == "waterfox" && AppProcessClass == "mozillawindowclass" && InStr(AppProcessTitle, "Waterfox Classic") > 0)
	{
		if (InStr(AppProcessTitle, "Start Page") > 0)
		{
			StartPage := 1
		}
	}
	else if (AppProcessName == "browser" && AppProcessClass == "yandexbrowser_widgetwin_1" && InStr(AppProcessTitle, "Yandex Browser") > 0)
	{
		if (InStr(AppProcessTitle, "Yandex — Yandex Browser") > 0)
		{
			StartPage := 1
		}
	}
	; -------------------------------------------
	return StartPage
	; -------------------------------------------
} ; IsStartPage(AppProcessName, AppProcessClass, AppProcessTitle) ; > StartPage (0 or 1)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; END OF FILE
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

