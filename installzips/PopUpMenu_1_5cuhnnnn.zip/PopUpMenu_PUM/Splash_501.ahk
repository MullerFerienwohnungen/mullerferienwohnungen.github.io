﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
#NoTrayIcon
#SingleInstance, Force
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; (501)(Splash Anamated: PopUpMenu Updating)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
if !WinExist("PopUpMenuUpdate501" . "ahk_class AutoHotkeyGUI") ; (Update Splash is NOT Running)
{
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; [StartUp] PreLoad Image
  ; -------------------------------------------
  ; *Note* Splash_Script("Off", 0) is Ran (SysTray.ahk)
  ; Max 90 Seconds to ExitApp
  ; -------------------------------------------
  Breaktime := A_TickCount + 90000
  ImagePath := A_ProgramFiles "\PopUpMenu_PUM\image\gui"
  ; -------------------------------------------
  LangArray := ["de", "en", "es", "fr", "it", "pl", "pt", "ru", "sv", "tr"]
  for Index, ThisLang in LangArray
  {
  	; -------------------------------------------
  	ThisImage := ImagePath "\(501)_1_" ThisLang ".png"
  	LoadPicture(ThisImage)
	  ThisImage := ImagePath "\(501)_2_" ThisLang ".png"
	  LoadPicture(ThisImage)
	  ; -------------------------------------------
  }
  ; -------------------------------------------
  GuiUpdateNum := 1
  ; -------------------------------------------
  ; [StartUp] Vars / PreLoad Image
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  { ; User Language [GET] (UserLang)
    ; -------------------------------------------
    File_UserLang := A_AppData "\PopUpMenu_PUM\system\File_UserLang.txt"
    ; -------------------------------------------
    if FileExist(File_UserLang)
    {
      FileReadLINE, UserLang, %File_UserLang%, 1
    }
    if (UserLang == "")
    {
      ; -------------------------------------------
      if FileExist(File_UserLang)
      {
        FileDelete, %File_UserLang%
        Sleep, 100
      } ; [End] if FileExist(File_UserLang)
      ; -------------------------------------------
      if (A_Language == "0407" or A_Language == "0807" or A_Language == "0c07" or A_Language == "1007" or A_Language == "1407")
      {
        ; -------------------------------------------
        UserLang := "de"
        ; -------------------------------------------
      } ; [End] German (de)
      ; -------------------------------------------
      else if (A_Language == "0409" or A_Language == "0809" or A_Language == "0c09" or A_Language == "1009" or A_Language == "1409" or A_Language == "1809" or A_Language == "1c09" or A_Language == "2009" or A_Language == "2409" or A_Language == "2809" or A_Language == "2c09" or A_Language == "3009" or A_Language == "3409")
      {
        ; -------------------------------------------
        UserLang := "en"
        ; -------------------------------------------
      } ; [End] English (en)
      ; -------------------------------------------
      else if (A_Language == "040a" or A_Language == "080a" or A_Language == "0c0a" or A_Language == "100a" or A_Language == "140a" or A_Language == "180a" or A_Language == "1c0a" or A_Language == "200a" or A_Language == "240a" or A_Language == "280a" or A_Language == "2c0a" or A_Language == "300a" or A_Language == "340a" or A_Language == "380a" or A_Language == "3c0a" or A_Language == "400a" or A_Language == "440a" or A_Language == "480a" or A_Language == "4c0a" or A_Language == "500a")
      {
        ; -------------------------------------------
        UserLang := "es"
        ; -------------------------------------------
      } ; [End] Spanish (es)
      ; -------------------------------------------
      else if (A_Language == "040c" or A_Language == "080c" or A_Language == "0c0c" or A_Language == "100c" or A_Language == "140c" or A_Language == "180c")
      {
        ; -------------------------------------------
        UserLang := "fr"
        ; -------------------------------------------
      } ; [End] French (fr)
      ; -------------------------------------------
      else if (A_Language == "0410" or A_Language == "0810")
      {
        ; -------------------------------------------
        UserLang := "it"
        ; -------------------------------------------
      } ; [End] Italian (it)
      ; -------------------------------------------
      else if (A_Language == "0415")
      {
        ; -------------------------------------------
        UserLang := "pl"
        ; -------------------------------------------
      } ; [End] Polish (pl)
      ; -------------------------------------------
      else if (A_Language == "0416" or A_Language == "0816")
      {
        ; -------------------------------------------
        UserLang := "pt"
        ; -------------------------------------------
      } ; [End] Portuguese (pt)
      ; -------------------------------------------
      else if (A_Language == "0419")
      {
        ; -------------------------------------------
        UserLang := "ru"
        ; -------------------------------------------
      } ; [End] Russian (ru)
      ; -------------------------------------------
      else if (A_Language == "041d" or A_Language == "081d")
      {
        ; -------------------------------------------
        UserLang := "sv"
        ; -------------------------------------------
      } ; [End] Swedish (sv)
      ; -------------------------------------------
      else if (A_Language == "041f")
      {
        ; -------------------------------------------
        UserLang := "tr"
        ; -------------------------------------------
      } ; [End] Turkish (tr)
      ; -------------------------------------------
      else ; English (en)
      {
        ; -------------------------------------------
        UserLang := "en"
        ; -------------------------------------------
      } ; [End] else ; English (en)
      ; -------------------------------------------
      FileEncoding, UTF-8 ; UTF-8
      FileAppend, %UserLang%`n, %File_UserLang% ; UTF-8
      ; -------------------------------------------
    } ; [End] if (UserLang == "")
    ; -------------------------------------------
  } ; User Language [GET] (UserLang)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; Gui
  ; -------------------------------------------
  Gui, PopUpMenu501:Add, Picture, x0  y0   w200 h250 vG_GuiUpdate, 
  ; -------------------------------------------
  Gui, PopUpMenu501:+LastFound -Caption +AlwaysOnTop +ToolWindow -Border ; Gui Start (AlwaysOnTop)
  Gui, PopUpMenu501:Color, 562958
  WinSet, TransColor, 562958
  ; -------------------------------------------
  Gui, PopUpMenu501:Show, , PopUpMenuUpdate501
  ; -------------------------------------------
  SetTimer, PopUpMenuLabel501, 270
  ; -------------------------------------------
  ;
  ; -------------------------------------------
  return
  ; -------------------------------------------
  ; Gui
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; Labels
  ; -------------------------------------------
  PopUpMenuLabel501:
  {
    ; -------------------------------------------
    if (A_TickCount > Breaktime)
    {
      ; -------------------------------------------
      SetTimer, PopUpMenuLabel501, Off
      ExitApp
      ; -------------------------------------------
    }
    ; -------------------------------------------
    ;
    ; -------------------------------------------
    if (GuiUpdateNum == 1)
    {
      ; -------------------------------------------
      ThisImage := ImagePath "\(501)_" GuiUpdateNum "_" UserLang ".png"
      GuiControl, PopUpMenu501:, G_GuiUpdate, %ThisImage%
      ; -------------------------------------------
      GuiUpdateNum := 2
      ; -------------------------------------------
    }
    else if (GuiUpdateNum == 2)
    {
      ; -------------------------------------------
      ThisImage := ImagePath "\(501)_" GuiUpdateNum "_" UserLang ".png"
      GuiControl, PopUpMenu501:, G_GuiUpdate, %ThisImage%
      ; -------------------------------------------
      GuiUpdateNum := 1
      ; -------------------------------------------
    }
    ; -------------------------------------------
  }
  return
  ; -------------------------------------------
  ; Labels
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>