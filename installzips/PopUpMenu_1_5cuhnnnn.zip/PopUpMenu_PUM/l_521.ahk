﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\Gui_ObjectSize.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
l_521: ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
{
  ; -------------------------------------------
  ; Building_Construct
  ; -------------------------------------------
  DataArray.187.2 := 0 ; (187_2)(Obj_Pum_SendEmailAnimate_Sel [0,1,2])
  DataArray.187.3 := "" ; (187_3)(Obj_Pum_SendEmailAnimate_Img [Image Path])
  GuiControl, PopUpMenu:Hide, g_187 ; (187_1)(Obj_Pum_SendEmailAnimate)
  GuiControl, PopUpMenu:, g_187, ; (187_1)(Obj_Pum_SendEmailAnimate)
  ; -------------------------------------------
  ;
  ; (_w480 x h270_)
  ; This Animation will NOT Repeat
  ; Anamation Continues from Last Frame Shown
  ; 
  ; (Animation Start/Stop In)
  ; (083_1)(Obj_Tom_Pum)
  ; (157_1)(Obj_Pum_Setting)
  ; (160_1)(Obj_Pum_App))
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Start/Stop (Animate) Pum_Building_Construct
  ; if (n_521 == 170)
  ; {
  ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
  ;   global s_521 := 0 ; Hide
  ; } ; [End] if (n_521 == 170)
  ; else
  ; {
  ;   global s_521 := 1 ; Show
  ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
  ; } ; [End] else
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Start/Stop (Animate) Pum_Building_Construct
  ;
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Start/Stop (Pum_Building_Construct)
  ;
  ; (Animation Hide/Stop In)
  ; (084_1)(Obj_Tom_FileUrlFolder)
  ; (086_1)(Obj_Tom_MenuControlKey)
  ; (087_1)(Obj_Mnu_Menu)
  ; (154_1)(Obj_Pum_BgImage)
  ; (155_1)(Obj_Pum_BgText)
  ; (156_1)(Obj_Pum_BgDim)
  ; (159_1)(Obj_Pum_Contact)
  ; (160_1)(Obj_Pum_App))
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Stop/Hide (Pum_Building_Construct)
  ; global s_521 := 0 ; Hide
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ [ANIMATE] Stop/Hide (Pum_Building_Construct)
  ;
  ; -------------------------------------------
  if (ShowAnimationChange == "")
  {
    global ShowAnimationChange := 0
  }
  ; -------------------------------------------
  Total_Images := 169
  ; -------------------------------------------
  if (n_521 == "")
  {
    global n_521 := 1
  }
  ; -------------------------------------------
  if (s_521 == 1) ; [START] [ANMIMATE]
  {
    ; -------------------------------------------
    if (n_521 <= Total_Images)
    {
      ; -------------------------------------------
      GuiControl, PopUpMenu:, g_137, %A_ProgramFiles%\PopUpMenu_PUM\image\gui\(521)_%n_521%.png ; (137_1)(Obj_MsgImg480x270)
      ; -------------------------------------------
      Gui_ObjectSize("137", DataArray) ; > Nothing
      ; -------------------------------------------
      if (ShowAnimationChange == 0)
      {
        GuiControl, PopUpMenu:Show, g_137 ; (137_1)(Obj_MsgImg480x270)
        global ShowAnimationChange := 1
      }
      ; -------------------------------------------
      global n_521 := n_521 + 1
      ; -------------------------------------------
    }
  } ; [End] [START] [ANMIMATE]
  else ; [STOP] [ANMIMATE]
  {
    ; -------------------------------------------
    global ShowAnimationChange := 0
    ; -------------------------------------------
    SetTimer, l_521, Off ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
    ; -------------------------------------------
  } ; [End] [STOP] [ANMIMATE]
  ; -------------------------------------------
} ; [End] (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
