﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Url_GetTitleWindow(ThisBrowser) ; > [Url_Title, Browser_Title]
{
  ; -------------------------------------------
  ThisBrowser := StrReplace(ThisBrowser, ".exe", "")
  ThisBrowser := StrReplace(ThisBrowser, A_Space, "")
  StringLower, ThisBrowser, ThisBrowser
  ; -------------------------------------------
  ;
  ; -------------------------------------------
  if (ThisBrowser == "brave")
  {
    ; -------------------------------------------
    ; Brave
    ; (Window Title) "Page Title" (Only)
    ; (ahk_class Chrome_WidgetWin_1)
    ; (ahk_exe Brave.exe) 
    ; -------------------------------------------
    WinGetTitle, Url_Title, ahk_exe Brave.exe
    Browser_Title := "brave"
    ; -------------------------------------------
  }
  ; -------------------------------------------
  else if (ThisBrowser == "chrome")
  {
    ; -------------------------------------------
    ; Chrome
    ; (Window Title) "Page Title" + " - Google Chrome"
    ; (ahk_class Chrome_WidgetWin_1)
    ; (ahk_exe chrome.exe)
    ; -------------------------------------------
    SetTitleMatchMode, 2
    WinGet, Browser_Id, ID , Google Chrome ahk_class Chrome_WidgetWin_1
    WinGetTitle, Url_Title, ahk_id %Browser_Id%
    ; -------------------------------------------
    BrowserNamePos := InStr(Url_Title, "Google Chrome")
    Browser_Title := "Google Chrome"
    ; -------------------------------------------
  }
  ; -------------------------------------------
  else if (ThisBrowser == "coowon")
  {
    ; -------------------------------------------
    ; Coowon
    ; (ahk_class Chrome_WidgetWin_1)
    ; (ahk_exe chrome.exe)
    ; (Window Title) "Page Title" + " - Coowon Browser"
    ; -------------------------------------------
    SetTitleMatchMode, 2
    WinGet, Browser_Id, ID , Coowon Browser ahk_class Chrome_WidgetWin_1
    WinGetTitle, Url_Title, ahk_id %Browser_Id%
    ; -------------------------------------------
    BrowserNamePos := InStr(Url_Title, "Coowon Browser")
    Browser_Title := "Coowon Browser"
    ; -------------------------------------------
  }
  ; -------------------------------------------
  else if (ThisBrowser == "firefox")
  {
    ; -------------------------------------------
    ; Firefox
    ; (Window Title) "Page Title" + " - Mozilla Firefox"
    ; (ahk_class MozillaWindowClass)
    ; (ahk_exe firefox.exe) 
    ; -------------------------------------------
    SetTitleMatchMode, 2
    WinGet, Browser_Id, ID , Mozilla Firefox ahk_class MozillaWindowClass
    WinGetTitle, Url_Title, ahk_id %Browser_Id%
    ; -------------------------------------------
    BrowserNamePos := InStr(Url_Title, "Mozilla Firefox")
    Browser_Title := "Mozilla Firefox"
    ; -------------------------------------------
  }
  else if (ThisBrowser == "waterfox")
  {
    ; -------------------------------------------
    ; Waterfox
    ; (Window Title) "Waterfox"
    ; (ahk_class MozillaWindowClass)
    ; (ahk_exe waterfox.exe) 
    ; -------------------------------------------
    SetTitleMatchMode, 2
    WinGet, Browser_Id, ID , Waterfox ahk_class MozillaWindowClass
    WinGetTitle, Url_Title, ahk_id %Browser_Id%
    ; -------------------------------------------
    BrowserNamePos := InStr(Url_Title, "Waterfox")
    Browser_Title := "Waterfox"
    ; -------------------------------------------
  }
  ; -------------------------------------------
  else if (ThisBrowser == "iexplore")
  {
    ; -------------------------------------------
    ; Internet Explorer
    ; (Window Title) "Page Title" + " - Internet Explorer"
    ; (ahk_class IEFrame)
    ; (ahk_exe iexplore.exe) 
    ; -------------------------------------------
    SetTitleMatchMode, 2
    WinGet, Browser_Id, ID , Internet Explorer ahk_class IEFrame
    WinGetTitle, Url_Title, ahk_id %Browser_Id%
    ; -------------------------------------------
    BrowserNamePos := InStr(Url_Title, "Internet Explorer")
    Browser_Title := "Internet Explorer"
    ; -------------------------------------------
  }
  ; -------------------------------------------
  else if (ThisBrowser == "iridium")
  {
    ; -------------------------------------------
    ; Iridium
    ; (Window Title) "Page Title" + " - Iridium"
    ; (ahk_class Chrome_WidgetWin_1)
    ; (ahk_exe iridium.exe) 
    ; -------------------------------------------
    SetTitleMatchMode, 2
    WinGet, Browser_Id, ID , Iridium ahk_class Chrome_WidgetWin_1
    WinGetTitle, Url_Title, ahk_id %Browser_Id%
    ; -------------------------------------------
    BrowserNamePos := InStr(Url_Title, "Iridium")
    Browser_Title := "Iridium"
    ; -------------------------------------------
  }
  ; -------------------------------------------
  else if (ThisBrowser == "kingpinprivatebrowser")
  {
    ; -------------------------------------------
    ; Kingpin
    ; (Window Title) "Kingpin Web Browser" + (Only)
    ; (ahk_class Chrome_WidgetWin_1)
    ; (ahk_exe Kingpin Private Browser.exe) 
    ; -------------------------------------------
    SetTitleMatchMode, 2
    WinGet, Browser_Id, ID, Kingpin Web Browser ahk_class Chrome_WidgetWin_1
    WinGetTitle, Url_Title, ahk_id %Browser_Id%
    ; -------------------------------------------
    BrowserNamePos := InStr(Url_Title, "Kingpin Web Browser")
    Browser_Title := "Kingpin Web Browser"
    ; -------------------------------------------
  }
  ; -------------------------------------------
  else if (ThisBrowser == "msedge")
  {
    ; -------------------------------------------
    ; Microsoftedge
    ; (Window Title) "Page Title" + " - Personal - Microsoft Edge"
    ; (ahk_class Chrome_WidgetWin_1)
    ; (ahk_exe msedge.exe) 
    ; -------------------------------------------
    SetTitleMatchMode, 2
    WinGet, Browser_Id, ID, Microsoft ahk_class Chrome_WidgetWin_1
    WinGetTitle, Url_Title, ahk_id %Browser_Id%
    ; -------------------------------------------
    BrowserNamePos := InStr(Url_Title, "Personal - Microsoft")
    ; -------------------------------------------
    if (BrowserNamePos == 0)
    {
      BrowserNamePos := InStr(Url_Title, "Microsoft")
      Browser_Title := "Microsoft"
    }
    else
    {
      Browser_Title := "Personal - Microsoft"
    }
    ; -------------------------------------------
  }
  ; -------------------------------------------
  else if (ThisBrowser == "opera")
  {
    ; -------------------------------------------
    ; Opera
    ; (Window Title) "Page Title" + " - Opera"
    ; (ahk_class Chrome_WidgetWin_1)
    ; (ahk_exe opera.exe) 
    ; -------------------------------------------
    SetTitleMatchMode, 2
    WinGet, Browser_Id, ID, Opera ahk_class Chrome_WidgetWin_1
    WinGetTitle, Url_Title, ahk_id %Browser_Id%
    ; -------------------------------------------
    BrowserNamePos := InStr(Url_Title, "Opera")
    Browser_Title := "Opera"
    ; -------------------------------------------
  }
  ; -------------------------------------------
  else if (ThisBrowser == "slimbrowser")
  {
    ; -------------------------------------------
    ; SlimBrowser
    ; (Window Title) "Page Title" + " - FlashPeak SlimBrowser"
    ; (ahk_class FlashPeakWindowClass)
    ; (ahk_exe slimbrowser.exe) 
    ; -------------------------------------------
    SetTitleMatchMode, 2
    WinGet, Browser_Id, ID, FlashPeak SlimBrowser ahk_class FlashPeakWindowClass
    WinGetTitle, Url_Title, ahk_id %Browser_Id%
    ; -------------------------------------------
    BrowserNamePos := InStr(Url_Title, "FlashPeak SlimBrowser")
    Browser_Title := "FlashPeak SlimBrowser"
    ; -------------------------------------------
  }
  ; -------------------------------------------
  else if (ThisBrowser == "slimjet")
  {
    ; -------------------------------------------
    ; Slimjet
    ; (Window Title) "Page Title" + " - Slimjet"
    ; (ahk_class Slimjet_WidgetWin_1)
    ; (ahk_exe slimjet.exe) 
    ; -------------------------------------------
    SetTitleMatchMode, 2
    WinGet, Browser_Id, ID, Slimjet ahk_class Slimjet_WidgetWin_1
    WinGetTitle, Url_Title, ahk_id %Browser_Id%
    ; -------------------------------------------
    BrowserNamePos := InStr(Url_Title, "Slimjet")
    Browser_Title := "Slimjet"
    ; -------------------------------------------
  }
  ; -------------------------------------------
  else if (ThisBrowser == "torbrowser")
  {
    ; -------------------------------------------
    ; Tor
    ; (Window Title) "Page Title" + " - Tor Browser"
    ; ahk_class MozillaWindowClass
    ; ahk_exe firefox.exe 
    ; -------------------------------------------
    SetTitleMatchMode, 2
    WinGet, Browser_Id, ID, Tor Browser ahk_class MozillaWindowClass
    WinGetTitle, Url_Title, ahk_id %Browser_Id%
    ; -------------------------------------------
    BrowserNamePos := InStr(Url_Title, "Tor Browser")
    Browser_Title := "Tor Browser"
    ; -------------------------------------------
  }
  ; -------------------------------------------
  ;
  ; -------------------------------------------
  if (BrowserNamePos > 0)
  {
    BrowserNamePos := BrowserNamePos - 4
    Url_Title := SubStr(Url_Title, 1, BrowserNamePos)
  }
  ; -------------------------------------------
  return ReturnArray := [Url_Title, Browser_Title]
  return ReturnArray
  ; -------------------------------------------
} ; [End] Url_GetTitleWindow() ; > [Url_Title, Browser_Title]
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
