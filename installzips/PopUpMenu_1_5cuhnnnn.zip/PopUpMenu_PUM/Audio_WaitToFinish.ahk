#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
#SingleInstance, force
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %ProgramFiles%\PopUpMenu_PUM\Audio_Functions.ahk
;#Include %ProgramFiles%\PopUpMenu_PUM\Audio_WaitToFinish.ahk ; Audio_WaitToFinish(WaitForSound) ; WaitForSound > SoundHeard <0,1>
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; This will Wait for Sound to start from (WaitForSound) 1000 = 1 Second
; Will Wait until no more Sound is Heard
; will Return (SoundHeard) 1 = Sound was Heard, 0 = NO Sound was Heard
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Audio_WaitToFinish(WaitForSound) ; WaitForSound > SoundHeard <0,1>
{
	; -------------------------------------------
	audioMeter := VA_GetAudioMeter()
  VA_IAudioMeterInformation_GetMeteringChannelCount(audioMeter, channelCount)
  VA_GetDevicePeriod("capture", devicePeriod)
	; -------------------------------------------
	Waittime := WaitForSound + A_TickCount
	; -------------------------------------------
	if (peakValue == "")
	{
		peakValue := 0
	}
	; -------------------------------------------
	PeakLevel := 0.003
	BreakTime := 1500
	; -------------------------------------------
	SoundHeard := 0
	Sleep, 500
	; -------------------------------------------
	while (Waittime > A_TickCount)
	{
	}
	; -------------------------------------------
	while (peakValue > PeakLevel)
	{
		; -------------------------------------------
		if (SoundHeard == 0 && peakValue > PeakLevel)
		{
			SoundHeard := 1
		}
		; -------------------------------------------
		VA_IAudioMeterInformation_GetPeakValue(audioMeter, peakValue)
		; -------------------------------------------
		Sleep, %BreakTime%
		VA_IAudioMeterInformation_GetPeakValue(audioMeter, peakValue)
		; -------------------------------------------
	}
	; -------------------------------------------
	return SoundHeard
	; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; END OF FILE
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
