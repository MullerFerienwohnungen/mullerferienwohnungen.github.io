﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\Array_Add.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Array_ItemExist.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Array_FromFile.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Array_Subtract.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Url_Download.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_Convert.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_ResizeImg.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\String_Reverse.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Url_GetRoot.ahk
; -------------------------------------------
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_ResizePng.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Image_ImgToIco.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Url_GetIcon(Url_Address) ; > Url_Icon
{
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; [DELETE] Files in (A_AppData "\PopUpMenu_PUM\url_cache\url_cache\") Folder
  ; -------------------------------------------
  Delete_Img_1 := A_AppData "\PopUpMenu_PUM\url_cache\Url_Icon*.*"
  FileDelete, %Delete_Img_1%
  Sleep, 10
  ; -------------------------------------------
  Delete_Img_2 := A_AppData "\PopUpMenu_PUM\url_cache\Url_SizeIcon.*"
  FileDelete, %Delete_Img_2%
  Sleep, 10
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; (Common) Get Root Address
  ; -------------------------------------------
  Url_Root := Url_GetRoot(Url_Address) ; > Url_Root (http://somename.xxx) or (http://xxx.somename.xxx)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  { ; [favicon.ico]
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if !FileExist(Url_Icon)
    {
      Url_Link := Url_Root "/favicon.ico"
      Url_Icon := A_AppData "\PopUpMenu_PUM\url_cache\Url_Icon.ico"
      Url_Download(Url_Link, Url_Icon) ; (ThisUrl, ThisFile) > ThisFile
    } ; [End] if FileExist(Url_Icon)
    ; -------------------------------------------
    ; Download Url_Root/favicon.ico
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; Test if favicon.ico is a Image
    ; -------------------------------------------
    if FileExist(Url_Icon)
    {
      ; -------------------------------------------
      TestArray := Array_FromFile(Url_Icon)
      ; -------------------------------------------
      for Index, ThisLine in TestArray
      {
        ; -------------------------------------------
        StringLower, ThisLine, ThisLine
        ; -------------------------------------------
        if (InStr(ThisLine, "html") > 0 or InStr(ThisLine, "rgb") > 0 or InStr(ThisLine, "png") > 0 or InStr(ThisLine, "ihdr") > 0)
        {
          ; -------------------------------------------
          ; NOT a Image
          ; -------------------------------------------
          FileDelete, %Url_Icon%
          Sleep, 10
          break
          ; -------------------------------------------
        } ; [End] if (InStr(ThisLine, "html") > 0 or InStr(ThisLine, "rgb") > 0 or InStr(ThisLine, "png") > 0 or InStr(ThisLine, "ihdr") > 0)
      } ; [End] for Index, ThisLine in TestArray
    } ; [End] if FileExist(Url_Icon)
    ; -------------------------------------------
    ; Test if favicon.ico is a Image
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [SiZE CHECK]
    if FileExist(Url_Icon)
    {
      ; -------------------------------------------
      ThisSize_1 := Url_SizeCheck(Url_Icon) ; > Image_Width [CREATE] (Url_SizeIcon.png)
      ; -------------------------------------------
      if (ThisSize_1 < 80)
      {
        ; -------------------------------------------
        Url_IconSize_1 := A_AppData "\PopUpMenu_PUM\url_cache\Url_IconSize_1.ico"
        FileCopy, %Url_Icon%, %Url_IconSize_1%, 1
        Sleep, 10
        FileDelete, %Url_Icon%
        Sleep, 10
        ; -------------------------------------------
      } ; [End] if (ThisSize < 80)
      ; -------------------------------------------
    } ; [End] if FileExist(Url_Icon)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [SiZE CHECK]
  } ; [favicon.ico]
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  { ; [URL_SourceFile.txt]
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [Download] [URL_SourceFile.txt]
    ; [GET Links
    ; [SET] Url_Icon
    ; -------------------------------------------
    if !FileExist(Url_Icon)
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; Download(Url_Address) as (A_AppData "\PopUpMenu_PUM\url_cache\URL_SourceFile.txt")
      ; -------------------------------------------
      if FileExist(URL_SourceFile)
      {
        FileDelete, %URL_SourceFile%
      }
      ; -------------------------------------------
      URL_SourceFile := A_AppData "\PopUpMenu_PUM\url_cache\URL_SourceFile.txt"
      Url_Download(Url_Address, URL_SourceFile) ; (ThisUrl, ThisFile) > ThisFile
      Sleep, 10
      ; -------------------------------------------
      ; Download(Url_Address) as (A_AppData "\PopUpMenu_PUM\url_cache\URL_SourceFile.txt")
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; Create Icon_LinkArray from URL_SourceFile.txt
      ; -------------------------------------------
      ; Get everything in <head>...</head> Only
      Icon_LinkArray := Url_LinkArray(URL_SourceFile) ; > Array
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Array_Len (Icon_LinkArray)
      Icon_LinkArray_Len := Icon_LinkArray.MaxIndex() ; Highest Length
      ; -------------------------------------------
      if (Icon_LinkArray_Len > 0) ; Array is Not Empty
      {
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ; Get Download Link from "<Link >"
        ; -------------------------------------------
        for Index, ThisLink in Icon_LinkArray
        {
          ; -------------------------------------------
          ThisPos := InStr(ThisLink, "href")
          ; -------------------------------------------
          ; Remove Everything Before (href=)
          ; -------------------------------------------
          URL_Source_Icon_Link := SubStr(ThisLink, ThisPos + 5) ; "//www.y2mate.com/themes/images/logo.png"
          ; -------------------------------------------
          ;
          ; -------------------------------------------
          ; Remove (A_Space) and (A_Tab)
          ; -------------------------------------------
          URL_Source_Icon_Link := StrReplace(URL_Source_Icon_Link, A_Space, "")
          URL_Source_Icon_Link := StrReplace(URL_Source_Icon_Link, A_Tab, "")
          ; -------------------------------------------
          ;
          ; -------------------------------------------
          ; Remove Everything After Second (")
          ; -------------------------------------------
          ThisPos := InStr(URL_Source_Icon_Link, """", , , 2)
          TotalStrLen := StrLen(URL_Source_Icon_Link)
          ThisStrLen := ThisPos - 1
          URL_Source_Icon_Link := SubStr(URL_Source_Icon_Link, 1, ThisStrLen)
          ; -------------------------------------------
          ;
          ; -------------------------------------------
          ; Remove All (")
          ; -------------------------------------------
          URL_Source_Icon_Link := StrReplace(URL_Source_Icon_Link, """", "")
          ; -------------------------------------------
          ;
          ; -------------------------------------------
          ; Remove (http://) and (https://)
          URL_Source_Icon_Link := StrReplace(URL_Source_Icon_Link, "http://", "")
          URL_Source_Icon_Link := StrReplace(URL_Source_Icon_Link, "https://", "")
          ; -------------------------------------------
          ;
          ; -------------------------------------------
          ; Remove (//) (/) (./) from Beginning 
          ; -------------------------------------------
          if (SubStr(URL_Source_Icon_Link, 1, 2) == "//")
          {
            URL_Source_Icon_Link := SubStr(URL_Source_Icon_Link, 3)
          }
          else if (SubStr(URL_Source_Icon_Link, 1, 1) == "/")
          {
            URL_Source_Icon_Link := SubStr(URL_Source_Icon_Link, 2)
          }
          else if (SubStr(URL_Source_Icon_Link, 1, 2) == "./")
          {
            URL_Source_Icon_Link := SubStr(URL_Source_Icon_Link, 3)
          }
          ; -------------------------------------------
          ;
          ; -------------------------------------------
          ThisSlash := InStr(URL_Source_Icon_Link, "/", , , 1)
          if (ThisSlash > 0)
          {
            ThisDot := InStr(URL_Source_Icon_Link, ".", , , 1)
            if (ThisDot > 0)
            {
              if (ThisSlash > ThisDot)
              {
                URL_Source_Icon_Link := "http://" URL_Source_Icon_Link
              }
              else
              {
                URL_Source_Icon_Link := Url_Root "/" URL_Source_Icon_Link
              }
            } ; [End] if (ThisDot > 0)
            else
            {
              URL_Source_Icon_Link := Url_Root "/" URL_Source_Icon_Link
            }
          }
          else
          {
            ThisDot := InStr(URL_Source_Icon_Link, ".", , , 1)
            if (ThisDot > 0)
            {
              URL_Source_Icon_Link := "http://" URL_Source_Icon_Link
            } ; [End] if (ThisDot > 0)
            else
            {
              URL_Source_Icon_Link := Url_Root "/" URL_Source_Icon_Link
            }
          }
          ; -------------------------------------------
          ItemExist := Array_ItemExist(DownloadArray, URL_Source_Icon_Link) ; ThisArray, CheckThis > Number of times in Array
          if (ItemExist == 0)
          {
            DownloadArray := Array_Add(DownloadArray, URL_Source_Icon_Link, "End") ; ThisArray, AddThis, ThisPos > ThisArray
          }
          ; -------------------------------------------
        } ; [End] for Index, ThisLink in Icon_LinkArray
        ; -------------------------------------------
        ; Get Download Link from "<Link >"
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ;
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Array_Len (DownloadArray)
        ; Download All Links
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        DownloadArray_Len := DownloadArray.MaxIndex() ; Highest Length
        ; -------------------------------------------
        if (DownloadArray_Len > 0)
        {
          ; ------------------------------------------
          Num := 0
          ; -------------------------------------------
          for Index, DownloadLink in DownloadArray
          {
            ; -------------------------------------------
            Num := Num + 1
            ; -------------------------------------------
            ExtPos := InStr(DownloadLink, ".apng")
            if (ExtPos > 0)
            {
              ImageExt := "apng"
            }
            else
            {
              ExtPos := InStr(DownloadLink, ".avif")
              if (ExtPos > 0)
              {
                ImageExt := "avif"
              }
              else
              {
                ExtPos := InStr(DownloadLink, ".bmp")
                if (ExtPos > 0)
                {
                  ImageExt := "bmp"
                }
                else
                {
                  ExtPos := InStr(DownloadLink, ".gif")
                  if (ExtPos > 0)
                  {
                    ImageExt := "gif"
                  }
                  else
                  {
                    ExtPos := InStr(DownloadLink, ".ico")
                    if (ExtPos > 0)
                    {
                      ImageExt := "ico"
                    }
                    else
                    {
                      ExtPos := InStr(DownloadLink, ".jfif")
                      if (ExtPos > 0)
                      {
                        ImageExt := "jfif"
                      }
                      else
                      {
                        ExtPos := InStr(DownloadLink, ".jpeg")
                        if (ExtPos > 0)
                        {
                          ImageExt := "jpeg"
                        }
                        else
                        {
                          ExtPos := InStr(DownloadLink, ".jpg")
                          if (ExtPos > 0)
                          {
                            ImageExt := "jpg"
                          }
                          else
                          {
                            ExtPos := InStr(DownloadLink, ".png")
                            if (ExtPos > 0)
                            {
                              ImageExt := "png"
                            }
                            else
                            {
                              ExtPos := InStr(DownloadLink, ".svg")
                              if (ExtPos > 0)
                              {
                                ImageExt := "svg"
                              }
                              else
                              {
                                ExtPos := InStr(DownloadLink, ".tiff")
                                if (ExtPos > 0)
                                {
                                  ImageExt := "tiff"
                                }
                                else
                                {
                                  ExtPos := InStr(DownloadLink, ".tif")
                                  if (ExtPos > 0)
                                  {
                                    ImageExt := "tif"
                                  }
                                  else
                                  {
                                    ExtPos := InStr(DownloadLink, ".webp")
                                    if (ExtPos > 0)
                                    {
                                      ImageExt := "webp"
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
            ; -------------------------------------------
            if (DownloadArray_Len == 1)
            {
              Url_Icon := A_AppData "\PopUpMenu_PUM\url_cache\Url_Icon." ImageExt
            }
            else
            {
              Url_Icon := A_AppData "\PopUpMenu_PUM\url_cache\Url_Icon_" Num "." ImageExt
            }
            ; -------------------------------------------
            FileEncoding, UTF-8
            URLDownloadToFile, %DownloadLink%, %Url_Icon%
            ; -------------------------------------------
            ThisFileArray := Array_FromFile(Url_Icon)
            ; -------------------------------------------
            ;
            ; -------------------------------------------
            ; 404 Check
            ;
            for Index, ThisLine in ThisFileArray
            {
              ; -------------------------------------------
              StringLower, ThisLine, ThisLine
              ; -------------------------------------------
              if (InStr(ThisLine, "html") > 0)
              {
                FileDelete, %Url_Icon%
                Sleep, 10
                break
              } ; [End] if (InStr(ThisLine, "html")
              ; -------------------------------------------
            } ; [End] for Index ThisLine in ThisFileArray
            ;
            ; 404 Check
            ; -------------------------------------------
          } ; [End] for Index, DownloadLink in DownloadArray
          ; -------------------------------------------
          ; Download All Links
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          ;
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          ; Check Image for (.png) if Not Convert to png
          ; This is done to check size
          ; -------------------------------------------
          if (DownloadArray_Len > 1)
          {
            ; -------------------------------------------
            FilePath := A_AppData "\PopUpMenu_PUM\url_cache\Url_Icon_*.*"
            ; -------------------------------------------
            ; Convert All inages to (.png)
            ; -------------------------------------------
            Loop Files, %FilePath%
            {
              ; -------------------------------------------
              Image_In := A_LoopFileFullPath
              ; -------------------------------------------
              SplitPath, Image_In, , , OutExtension
              StringLower, OutExtension, OutExtension
              ; -------------------------------------------
              if (OutExtension != "png")
              {
                ; -------------------------------------------
                OldExt := "." OutExtension
                Image_Out := StrReplace(Image_In, OldExt, ".png")
                Image_Out := Image_Convert(Image_In, Image_Out) ; Image_In, Image_Out > Image_Out
                FileDelete, %Image_In%
                Sleep, 10
                ; -------------------------------------------
              } ; [End] if (OutExtension != "png")
            } ; [End] Loop Files, %FilePath%
            ; -------------------------------------------
            ; Get Largest Inage Size
            ; -------------------------------------------
            LargestWidth := 0
            Loop Files, %FilePath%
            {
              ; -------------------------------------------
              ThisImage := A_LoopFileFullPath
              ; -------------------------------------------
              Gui, ImageSize:Add, Picture, hwndJustForSize, %ThisImage%
              ControlGetPos, , , ThisWidth, ThisHeight, , ahk_id %JustForSize%
              ; -------------------------------------------
              if (ThisWidth > LargestWidth)
              {
                LargestWidth := ThisWidth
                LargestImage := ThisImage
              }
            } ; [End] Loop Files, %FilePath%
            ; -------------------------------------------
            ; Delete All Smaller Images
            ; -------------------------------------------
            LargestWidth := 0
            Loop Files, %FilePath%
            {
              ; -------------------------------------------
              ThisImage := A_LoopFileFullPath
              ; -------------------------------------------
              if (ThisImage != LargestImage)
              {
                FileDelete, %ThisImage%
                Sleep, 10
              }
            } ; [End] Loop Files, %FilePath%
            ; -------------------------------------------
            ; Convert LargestImage to an (.ico)
            ; -------------------------------------------
            Url_Icon := A_AppData "\PopUpMenu_PUM\url_cache\Url_Icon.ico"
            Url_Icon := Image_ImgToIco(LargestImage, Url_Icon) ; (ImageIn, ImageOut, RunAnimate) > ImageOut
            FileDelete, %LargestImage%
            Sleep, 10
            ; -------------------------------------------
          } ; [End] if (Array_Len > 1)
          else if (DownloadArray_Len == 1)
          {
            ; -------------------------------------------
            ; Url_Icon := A_AppData "\PopUpMenu_PUM\url_cache\Url_Icon." ImageExt
            ; -------------------------------------------
            if (ImageExt != "ico")
            {
              ; -------------------------------------------
              ImageIn  := Url_Icon
              Url_Icon := A_AppData "\PopUpMenu_PUM\url_cache\Url_Icon.ico"
              ; -------------------------------------------
              Url_Icon := Image_ImgToIco(ImageIn, Url_Icon) ; (ImageIn, ImageOut, RunAnimate) > ImageOut
              ; -------------------------------------------
              FileDelete, %ImageIn%
              Sleep, 10
              ; -------------------------------------------
            } ; [End] if (ImageExt != "ico")
            ; -------------------------------------------
          } ; [End] else if (Array_Len == 1)
          ; -------------------------------------------
        } ; [End] if (Array_Len > 0)
        ; -------------------------------------------
        ; Download All Links
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Array_Len (DownloadArray)
      } ; [End] if (Array_Len > 0)
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Array_Len (Icon_LinkArray)
    } ; [End] if !FileExist(Url_Icon)
    ; -------------------------------------------
    ; Download URL_SourceFile.txt
    ; Check URL_SourceFile.txt for favicon Links
    ; [SET] Url_Icon
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [Download] [URL_SourceFile.txt]
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [SiZE CHECK]
    if FileExist(Url_Icon)
    {
      ; -------------------------------------------
      ThisSize_2 := Url_SizeCheck(Url_Icon) ; > Image_Width [CREATE] (Url_SizeIcon.png)
      ; -------------------------------------------
      if (ThisSize_2 < 80)
      {
        ; -------------------------------------------
        Url_IconSize_2 := A_AppData "\PopUpMenu_PUM\url_cache\Url_IconSize_2.ico"
        FileCopy, %Url_Icon%, %Url_IconSize_2%, 1
        Sleep, 10
        FileDelete, %Url_Icon%
        Sleep, 10
        ; -------------------------------------------
      } ; [End] if (ThisSize < 80)
      ; -------------------------------------------
    } ; [End] if FileExist(Url_Icon)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> [SiZE CHECK]
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    Url_Icon := A_AppData "\PopUpMenu_PUM\url_cache\Url_Icon.ico"
    Url_IconSize_1 := A_AppData "\PopUpMenu_PUM\url_cache\Url_IconSize_1.ico"
    Url_IconSize_2 := A_AppData "\PopUpMenu_PUM\url_cache\Url_IconSize_2.ico"
    ; -------------------------------------------
    if !FileExist(Url_Icon)
    {
      This_IconSize := 0
      if (FileExist(Url_IconSize_1) && FileExist(Url_IconSize_2))
      {
        if (ThisSize_1 > ThisSize_2)
        {
          FileCopy, %Url_IconSize_1%, %Url_Icon%, 1
          Sleep, 10
          This_IconSize := Url_IconSize_1
        } ; [End] if (ThisSize_1 > ThisSize_2)
        else if (ThisSize_1 < ThisSize_2)
        {
          FileCopy, %Url_IconSize_2%, %Url_Icon%, 1
          Sleep, 10
          This_IconSize := Url_IconSize_2
        } ; [End] else if (ThisSize_1 < ThisSize_2)
        else if (ThisSize_1 == ThisSize_2)
        {
          FileCopy, %Url_IconSize_1%, %Url_Icon%, 1
          Sleep, 10
          This_IconSize := Url_IconSize_1
        } ; [End] else if (ThisSize_1 == ThisSize_2)
      } ; [End] if (FileExist(Url_IconSize_1) && FileExist(Url_IconSize_2)
      else if FileExist(Url_IconSize_1)
      {
        FileCopy, %Url_IconSize_1%, %Url_Icon%, 1
        Sleep, 10
        This_IconSize := Url_IconSize_1
      } ; [End] else if FileExist(Url_IconSize_1)
      else if FileExist(Url_IconSize_2)
      {
        FileCopy, %Url_IconSize_2%, %Url_Icon%, 1
        Sleep, 10
        This_IconSize := Url_IconSize_2
      } ; [End] else if FileExist(Url_IconSize_2)
      ; -------------------------------------------
      if FileExist(Url_Icon)
      {
        ; -------------------------------------------
        if (This_IconSize < 80)
        {
          ; -------------------------------------------
          Url_IconPng := A_AppData "\PopUpMenu_PUM\url_cache\Url_Icon.png"
          Image_Convert(Url_Icon, Url_IconPng) ; Image_In, Image_Out > Image_Out
          FileDelete, %Url_Icon%
          Sleep, 10
          Image_ResizePng(80, 80, Url_IconPng, Url_IconPng) ; Resize_W, Resize_H, Image_In, Image_Out > 1 / 0
          Url_Icon := Image_ImgToIco(Url_IconPng, Url_Icon) ; (ImageIn, ImageOut) > ImageOut
          FileDelete, %Url_IconPng%
          Sleep, 10
          ; -------------------------------------------
        } ; [End] if (This_IconSize < 80)
      } ; [End] if FileExist(Url_Icon)
    } ; [End] if !FileExist(Url_Icon)
    ; -------------------------------------------
    if FileExist(Url_IconSize_1)
    {
      FileDelete, %Url_IconSize_1%
      Sleep, 10
    }
    if FileExist(Url_IconSize_2)
    {
      FileDelete, %Url_IconSize_2%
      Sleep, 10
    }
    ; -------------------------------------------
  } ; [URL_SourceFile.txt]
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Final Convert Icon
  if FileExist(Url_Icon)
  {
    ; -------------------------------------------
    Url_IconConvert :=  A_AppData "\PopUpMenu_PUM\url_cache\Url_IconConvert.png"
    Url_Icon := A_AppData "\PopUpMenu_PUM\url_cache\Url_Icon.ico"
    ; -------------------------------------------
    Image_Convert(Url_Icon, Url_IconConvert) ; Image_In, Image_Out > Image_Out
    FileDelete, %Url_Icon%
    Sleep, 10
    Image_ImgToIco(Url_IconConvert, Url_Icon) ; (ImageIn, ImageOut) > ImageOut
    FileDelete, %Url_IconConvert%
    Sleep, 10
    ; -------------------------------------------
  } ; [End] if FileExist(Url_Icon)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Final Convert Icon
  ;
  ; -------------------------------------------
  return Url_Icon
  ; -------------------------------------------
} ; [End] Url_GetIcon(Url_Address) ; > Url_Icon
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Url_LinkArray(URL_SourceFile) ; > Array
{
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  ; Returns an Array of Only favicon Links
  ; <link ... >
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  ; -------------------------------------------
  HeadStartFound := 0
  ReturnArray := []
  ThisLine := ""
  FileEncoding, UTF-8
  Loop, Read, %URL_SourceFile%
  {
    ; -------------------------------------------
    ThisLine := A_LoopReadLine
    ; -------------------------------------------
    if (InStr(ThisLine, "<head") > 0)
    {
      StringLower, StringLower_ThisLine, ThisLine
      HeadStart := InStr(StringLower_ThisLine, "<head")
      ThisLine := Substr(ThisLine, HeadStart)
      HeadStartFound := 1
    }
    ; -------------------------------------------
    if (HeadStartFound == 1)
    {
      ; -------------------------------------------
      OneLine := OneLine ThisLine
      ; -------------------------------------------
      StringLower, CheckThisLine, ThisLine ; StringLower, OutputVar, InputVar
      ; -------------------------------------------
      if (InStr(CheckThisLine, "/head") > 0)
      {
        break
      } ; [End] if (InStr(CheckThisLine, "/head") > 0)
    } ; [End] if (HeadStartFound == 1)
  } ; [End] Loop, Read, %FilePath%
  ; -------------------------------------------
  OneLine := StrReplace(OneLine, ">", ">`n")
  ; -------------------------------------------
  SourceFile_Array := StrSplit(OneLine, "`n", "`n")
  ; -------------------------------------------
  for Index, ThisItem in SourceFile_Array
  {
    ; -------------------------------------------
    while (SubStr(ThisItem, 1, 1) == A_Space)
    {
      ThisItem := SubStr(ThisItem, 2)
    }
    ; -------------------------------------------
    while (SubStr(ThisItem, 1, 1) == A_Tab)
    {
      ThisItem := SubStr(ThisItem, 2)
    }
    ; -------------------------------------------
    StringCaseSense, Off
    CheckLink_1 := InStr(ThisItem, "rel=""icon""")
    CheckLink_2 := InStr(ThisItem, "rel=""shortcut icon""")
    ; -------------------------------------------
    CheckLink_3 := InStr(ThisItem, "favicon")
    ; -------------------------------------------
    if (CheckLink_1 > 0 or CheckLink_2 > 0) ; (rel="icon", rel="shortcut icon")
    {
      ReturnArray.Push(ThisItem)
    } ; [End] if (CheckLink_1 > 0 && (CheckLink_2 > 0 or CheckLink_3 > 0))
  } ; [End] for Index, ThisItem in SourceFile_Array
  ; -------------------------------------------
  ;
  ; -------------------------------------------
  return ReturnArray
  ; -------------------------------------------
} ; [End] Url_LinkArray(FilePath) ; > Array
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Url_SizeCheck(Url_SizeImg) ; > Image_Width
{
  ; -------------------------------------------
  if FileExist(Url_SizeImg)
  {
    ; -------------------------------------------
    Url_SizePng := A_AppData "\PopUpMenu_PUM\url_cache\Url_SizeIcon.png"
    if FileExist(Url_SizePng)
    {
      FileDelete, %Url_SizePng%
      Sleep, 10
    }
    ; -------------------------------------------
    SplitPath, Url_SizeImg, , , Url_SizeExt
    StringLower, Url_SizeExt, Url_SizeExt
    ; -------------------------------------------
    if (Url_SizeExt == "ico")
    {
      Url_SizePng := Image_Convert(Url_SizeImg, Url_SizePng) ; Image_In, Image_Out > Image_Out
    }
    else
    {
      FileCopy, %Url_SizeImg%, %Url_SizePng%, 1
      Sleep, 10
    }
    ; -------------------------------------------
    Gui, ImageSize:Add, Picture, hwndJustForSize, %Url_SizePng%
    ControlGetPos, , , Image_Width, Image_Height, , ahk_id %JustForSize%
    ; -------------------------------------------
    FileDelete, %Url_SizePng%
    Sleep, 10
    ; -------------------------------------------
  } ; [End] if FileExist(ThisImage)
  else
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; ThisImage [NOT EXIST]
    Image_Width := 0
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  }
  ; -------------------------------------------
  return Image_Width
  ; -------------------------------------------
} ; [End] Url_SizeCheck(ThisImage) ; > Image_Width
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
