﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\l_187.ahk ; (187_1)(Obj_Pum_SendEmailAnimate)
#Include %A_ProgramFiles%\PopUpMenu_PUM\l_520.ahk ; (520_1)(_Msg 4_)(_w480 x h270_)_URL)
#Include %A_ProgramFiles%\PopUpMenu_PUM\l_521.ahk ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
#Include %A_ProgramFiles%\PopUpMenu_PUM\l_522.ahk ; (522_1)(_Msg 4_)(_w480 x h270_)_Nailing_Man)
#Include %A_ProgramFiles%\PopUpMenu_PUM\l_523.ahk ; (523_1)(_Msg 4_)(_w480 x h270_)_Jackhammer)
#Include %A_ProgramFiles%\PopUpMenu_PUM\l_524.ahk ; (524_1)(_Msg 4_)(_w480 x h270_)_Writing Request)
#Include %A_ProgramFiles%\PopUpMenu_PUM\l_541.ahk ; (541_1)(_Msg 8_)(_w300 x h300_)_Rotate_Left)
#Include %A_ProgramFiles%\PopUpMenu_PUM\l_542.ahk ; (542_1)(_Msg 8_)(_w300 x h300_)_Rotate_Right)
#Include %A_ProgramFiles%\PopUpMenu_PUM\l_543.ahk ; (543_1)(_Msg 8_)(_w300 x h300_)_Sanding_Man)
#Include %A_ProgramFiles%\PopUpMenu_PUM\l_544.ahk ; (544_1)(_Msg 8_)(_w300 x h300_)_Messure_Man)
#Include %A_ProgramFiles%\PopUpMenu_PUM\l_545_L.ahk ; (545_1)(Display Icon (w80_x_80) Rotate Icon)
#Include %A_ProgramFiles%\PopUpMenu_PUM\l_545_R.ahk ; (545_1)(Display Icon (w80_x_80) Rotate Icon)
#Include %A_ProgramFiles%\PopUpMenu_PUM\l_546.ahk ; (546_1)(002_003)(_w40 x h40_)(Process Rotate)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Sys_ResetDataArray(DataArray) ; > DataArray
{
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; Close Support Processes
  ; -------------------------------------------
  ThisProcess := "magick.exe"
  Process, Exist, %ThisProcess%
  while (ErrorLevel != 0)
  {
    Process, Close, %ThisProcess%
  }
  ; -------------------------------------------
  ThisProcess := "PopUpMenu_MailSend.exe"
  Process, Exist, %ThisProcess%
  while (ErrorLevel != 0)
  {
    Process, Close, %ThisProcess%
  }
  ; -------------------------------------------
  ThisProcess := "PopUpMenu_ResourceHacker.exe"
  Process, Exist, %ThisProcess%
  while (ErrorLevel != 0)
  {
    Process, Close, %ThisProcess%
  }
  ; -------------------------------------------
  ; Close Support Processes
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> All Gui Object Images
  ThisVar := 0
  Loop 299 
  {
    ; -------------------------------------------
    ThisVar := ThisVar + 1
    ; -------------------------------------------
    DataArray[ThisVar][3] := ""
    ; -------------------------------------------
  } ; [End] Loop 300
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> All Gui Object Images
  ;
  ; -------------------------------------------
  DataArray.305.17 := 0 ; (305_17)(Run_DefaultPum [0,1][Selected Shortcut is to the Default pum])
  DataArray.305.18 := 0 ; (305_18)(Run_CatPaw [0,1][Selected Shortcut is to the CatPaw])
  ; -------------------------------------------
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> ScriptType [cpl,mnu,pum,url]
  DataArray.72.2 := 0 ; (072_2)(Obj_Key_AppOnly_Sel [0,1,2])
  ;
  DataArray.300.2 := 0 ; (300_2)(Cpl_Number_x000 [#_X_X_X])
  DataArray.300.3 := 0 ; (300_3)(Cpl_Number_0x00 [X_#_X_X])
  DataArray.300.4 := 0 ; (300_4)(Cpl_Number_00x0 [X_X_#_X])
  ;
  DataArray.301.2 := "" ; (301_2)(Key_ArrayNumbers [Array])
  DataArray.301.3 := "" ; (301_3)(Key_ArrayValid [1,3])
  DataArray.301.4 := "" ; (301_4)(Key_InKeyArray [0,1,2])
  DataArray.301.5 := "" ; (301_5)(KeyMnu_Class)
  DataArray.301.6 := "" ; (301_6)(keyMnu_ProcessName)
  DataArray.301.7 := "" ; (301_7)(Key_KeyArrayDisplay [String] [by Lang])
  DataArray.301.8 := "" ; (301_8)(Key_KeyArrayShortcut [Array])
  DataArray.301.9 := "" ; (301_9)(KeyMnu_ProcessExtName)
  ;
  DataArray.302.2 := 0 ; (302_2)(Mnu_Number_x000 [#_X_X_X])
  DataArray.302.3 := 0 ; (302_3)(Mnu_Number_0x00 [X_#_X_X])
  DataArray.302.4 := 0 ; (302_4)(Mnu_Number_00x0 [X_X_#_X])
  DataArray.302.5 := 0 ; (302_5)(Mnu_Number_000x [X_X_X_#])
  DataArray.302.6 := 0 ; (302_6)(Mnu_MenuSize [#])
  ;
  DataArray.307.3 := "" ; (307_3)(Url_Downloaded [0/1])
  DataArray.307.6 := "" ; (307_6)(Url_DefaultBrowser [Full File Path])
  DataArray.307.9 := "" ; (307_9)(Url_NewTab [Open URL Address in New Tab] [0/1])
  ;
  DataArray.362.34 := "" ; (362_34)(Img_W)
  DataArray.362.35 := "" ; (362_35)(Img_H)
  DataArray.362.36 := "" ; (362_36)(Pum_W)
  DataArray.362.37 := "" ; (362_37)(Pum_H)
  DataArray.362.38 := "" ; (362_38)(Bg_Image_Type [C=Crop,F=Fit])
  DataArray.362.39 := "" ; (362_39)(Img_Gui_W)
  DataArray.362.40 := "" ; (362_40)(Img_Gui_H)
  DataArray.362.41 := "" ; (362_41)(Img_Gui_X)
  DataArray.362.42 := "" ; (362_42)(Img_Gui_Y)
  DataArray.362.44 := "" ; (362_44)(Pum_Gui_W)
  DataArray.362.45 := "" ; (362_45)(Pum_Gui_H)
  DataArray.362.46 := "" ; (362_46)(Pum_Gui_X)
  DataArray.362.47 := "" ; (362_47)(Pum_Gui_Y)
  DataArray.362.48 := "" ; (362_48)(Pum_Gui_Max_W)
  DataArray.362.49 := "" ; (362_49)(Pum_Gui_Max_H)
  DataArray.362.50 := "" ; (362_50)(Pum_Gui_Min_W)
  DataArray.362.51 := "" ; (362_51)(Pum_Gui_Min_H)
  ;
  DataArray.366.5  := "" ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
  ;
  DataArray.370.8  := "" ; (370_8)(XmlScriptPath [Full File Path])
  DataArray.370.9  := "" ; (370_9)(XmlOldScriptPath [Full File Path])
  DataArray.370.10 := "" ; (370_10)(TbXml_ShortcutLine8_IconPath [Full File Path])
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> ScriptType [cpl,mnu,pum,url,]
  ;
  DataArray.362.58 := "" ; (362_58)(Array_ShortcutGrid [C##R##, C##R##, C##R##] of Existing Shortcuts)
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Delete All Files in A_AppData "\PopUpMenu_PUM\temp\*.*"
  PopUpMenu_Temp := A_AppData "\PopUpMenu_PUM\temp\*.*"
  FileDelete, %PopUpMenu_Temp%
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Delete All Files in A_AppData "\PopUpMenu_PUM\temp\*.*"
  ;
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Stop Animate
  ;
  ; -------------------------------------------
  global ShowAnimationChange := 0
  ; -------------------------------------------
  global s_187 := 0 ; Hide
  global n_187 := 1
  SetTimer, l_187, Off ; (187_1)(Obj_Pum_SendEmailAnimate)
  ; -------------------------------------------
  global s_520 := 0 ; Hide
  global n_520 := 1
  SetTimer, l_520, Off ; (520_1)(_Msg 4_)(_w480 x h270_)_URL)
  ; -------------------------------------------
  global s_521 := 0 ; Hide
  global n_521 := 1
  SetTimer, l_521, Off ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
  ; -------------------------------------------
  global s_522 := 0 ; Hide
  global n_522 := 1
  SetTimer, l_522, Off ; (522_1)(_Msg 4_)(_w480 x h270_)_Nailing_Man)
  ; -------------------------------------------
  global s_523 := 0 ; Hide
  global n_523 := 1
  SetTimer, l_523, Off ; (523_1)(_Msg 4_)(_w480 x h270_)_Jackhammer)
  ; -------------------------------------------
  global s_524 := 0 ; Hide
  global n_524 := 1
  SetTimer, l_524, Off ; (524_1)(_Msg 4_)(_w480 x h270_)_Writing Request)
  ; -------------------------------------------
  global s_541 := 0 ; Hide
  global n_541 := 1
  SetTimer, l_541, Off ; (541_1)(_Msg 8_)(_w300 x h300_)_Rotate_Left)
  ; -------------------------------------------
  global s_542 := 0 ; Hide
  global n_542 := 1
  SetTimer, l_542, Off ; (542_1)(_Msg 8_)(_w300 x h300_)_Rotate_Right)
  ; -------------------------------------------
  global s_543 := 0 ; Hide
  global n_543 := 1
  SetTimer, l_543, Off ; (543_1)(_Msg 8_)(_w300 x h300_)_Sanding_Man)
  ; -------------------------------------------
  global s_544 := 0 ; Hide
  global n_544 := 1
  SetTimer, l_544, Off ; (544_1)(_Msg 8_)(_w300 x h300_)_Messure_Man)
  ; -------------------------------------------
  global s_545_L := 0 ; Hide
  global n_545_L := 1
  SetTimer, l_545_L, Off ; (545_1)(Display Icon (w80_x_80) Rotate Icon)
  ; -------------------------------------------
  global s_545_R := 0 ; Hide
  global n_545_R := 1
  SetTimer, l_545_R, Off ; (545_1)(Display Icon (w80_x_80) Rotate Icon)
  ; -------------------------------------------
  global s_546 := 0 ; Hide
  global n_546 := 1
  SetTimer, l_546, Off ; (546_1)(002_003)(_w40 x h40_)(Process Rotate)
  ; -------------------------------------------
  ;
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Stop Animate
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Pum Images
  Delete_1  := ThisPumProcessFolder "\image\Temp_Display_Img.png"
  Delete_2  := ThisPumProcessFolder "\image\Temp_Display_Txt_Col.png"
  Delete_3  := ThisPumProcessFolder "\image\Temp_Display_Txt_Img.png"
  Delete_4  := ThisPumProcessFolder "\image\Temp_Selected_Fit.png"
  Delete_5  := ThisPumProcessFolder "\Image\Temp_Selected_Gui.png"
  Delete_6  := ThisPumProcessFolder "\Image\Temp_Selected_Gui-*.png"
  Delete_7  := ThisPumProcessFolder "\Image\Temp_Selected_Img.*"
  Delete_8  := ThisPumProcessFolder "\Image\ImageIn_Temp.*"
  Delete_9  := ThisPumProcessFolder "\image\File_Pum_Gui.png"
  Delete_10  := ThisPumProcessFolder "\image\File_TxT_Gui_C.png"
  Delete_11 := ThisPumProcessFolder "\image\DisplayPumDim.png"
  Delete_12 := ThisPumProcessFolder "\image\ImageTemp*.**"
  Delete_13 := ThisPumProcessFolder "\image\File_Image.png"
  Delete_14 := ThisPumProcessFolder "\image\bg_Display_Txt_Col.png"
  Delete_15 := A_AppData "\PopUpMenu_PUM\temp\*.*"
  Delete_16 := A_AppData "\PopUpMenu_PUM\url_cache\*.*"
  Delete_17 := A_AppData "\PopUpMenu_PUM\temp\Temp_MonitorTop.png"
  Delete_18 := A_AppData "\PopUpMenu_PUM\system\DisplayMonitor.png"
  Delete_Array := [Delete_1, Delete_2, Delete_3, Delete_4, Delete_5, Delete_6, Delete_7, Delete_8, Delete_9, Delete_10, Delete_11, Delete_12, Delete_13, Delete_14, Delete_15, Delete_16, Delete_17, Delete_18]
  for Index, DeleteThis in Delete_Array
  {
    FileDelete, %DeleteThis%
  }
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Pum Images
  ;
  ; -------------------------------------------
  global LockKeys := 0
  DataArray.133.2 := 1 ; (133_2)(Obj_DeleteShortcut_Sel [0,1,2])
  DataArray.161.2 := 1 ; (161_2)(Obj_Pum_Del_Sel [0,1,2,3])
  ; -------------------------------------------
  ;
  return DataArray
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
