﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\Pum_Close.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Application_Request.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\_S1_C.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\_S2_H.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\_S3_S.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\Array_FromFile.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
f_137(DataArray) ; (137_1)(Obj_MsgImg480x270)
{
  ; -------------------------------------------
  v_366_6 := DataArray.366.6 ; (366_6)(ScriptError [Integer])
  ; -------------------------------------------
  ;
  ; -------------------------------------------
  ; [(366_6) ScriptError == 5] (Addon Not Installed)(Addon is Available)
  ; -------------------------------------------
  if (v_366_6 == 5) ; (366_6)(ScriptError [Integer])
  {
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; [(366_6) ScriptError == 5] (Addon Not Installed)(Addon is Available)
    ; -------------------------------------------
    ; User Clicked Download Addon
    ; Go to WebSite Addon Page
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; Check if There ia a Internet Connection
    ; -------------------------------------------
    flag=0x40
    HasConnection := DllCall("Wininet.dll\InternetGetConnectedState", "Str", flag,"Int",0)
    ; -------------------------------------------
    ; Check if There ia a Internet Connection
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (HasConnection == 1) ; Internet Connection OK
    {
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ; Get Current PopUpMenu Web Site
      ; -------------------------------------------
      File_PopupmenuSiteDomain := A_ProgramFiles "\PopUpMenu_PUM\update\domain_popupmenusite.txt"
      if FileExist(File_PopupmenuSiteDomain)
      {
        FileReadLine, PopupmenuSiteDomain, %File_PopupmenuSiteDomain%, 1
      } ; [End] if FileExist(File_PopupmenuSiteDomain)
      ; -------------------------------------------
      ; Get Current PopUpMenu Web Site
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      ;
      ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      if (PopupmenuSiteDomain != "") ; (PopupmenuSiteDomain) is NOT Empty
      {
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        UserLang := DataArray.365.2 ; (365_2)(UserLang [Current User language])
        AppName := DataArray.367.1 ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
        ; -------------------------------------------
        ProcessAddon := AppName "_" UserLang ; (365_2)(UserLang [Current User language])
        ; -------------------------------------------
        ;
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ; Url Buy Download Page for this AddOn
        ; -------------------------------------------
        ThisUrl := PopupmenuSiteDomain "/" AppName "_" UserLang ".html"
        Run, %ThisUrl%,,, Priority_PopUpMenuWebSite
        Process, Priority, %Priority_PopUpMenuWebSite%, High
        ; -------------------------------------------
        ; Url Buy Download Page for this AddOn
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ;
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ; Close GUI
        ; -------------------------------------------
        if (WinExist("Shortcut_Pop_Up_Menu" . "ahk_class AutoHotkeyGUI") or WinExist("HotKey PopUpMenu" . "ahk_class AutoHotkeyGUI"))
        {
          Pum_Close(DataArray) ; > Nothing
        }
        ; -------------------------------------------
        ; Close GUI
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ;
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        ; Close pum Process
        ; -------------------------------------------
        WinGet, ThisPumProcessExe, ProcessName, ahk_class TfrmToolbox
        if (InStr(ThisPumProcessExe, "pum_") != 0) ; pum Exist
        {
          ; -------------------------------------------
          Process, Close, %ThisPumProcessExe%
          ; -------------------------------------------
          Pum_FileDelete(ThisPumProcessExe)
          ; -------------------------------------------
          DataArray.367.1 := "" ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
          DataArray.367.2 := "" ; (367_2)(AppProcessExtName [Name,Ext])
          DataArray.367.3 := "" ; (367_3)(AppProcessClass)
          DataArray.367.4 := "" ; (367_4)(AppProcessTitle)
          DataArray.367.5 := "" ; (367_5)(AppProcessPathNameExt [Path,Name,Ext])
          DataArray.367.6 := "" ; (367_6)(AppProcesssVersion)
          DataArray.367.7 := "" ; (367_7)(AppProcesssPID)
          ; -------------------------------------------
        } ; [End] if (InStr(ThisPumProcessExe, "pum_") != 0) ; pum Exist
        ; -------------------------------------------
        ; Close pum Process
        ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      } ; [End] if (PopupmenuSiteDomain != "") ; (PopupmenuSiteDomain) is NOT Empty
      ; -------------------------------------------
    } ; [End] if (HasConnection == 1) ; Internet Connection OK
    ; -------------------------------------------
  } ; (366_6)(This Script Error [Integer])
  ; -------------------------------------------
  ;
  ; -------------------------------------------
  ; [ScriptError == 17] (mnu)(Addon Not Installed)(Addon Not Available)(Addon Not Been Requested)
  ; -------------------------------------------
  else if (v_366_6 == 17) ; (366_6)(ScriptError [Integer])
  {
    ; -------------------------------------------
    ; [ScriptError == 17] (mnu)(Addon Not Installed)(Addon Not Available)(Addon Not Been Requested)
    ; -------------------------------------------
    DataArray := Application_Request(DataArray)
    ; -------------------------------------------
    DataArray := _S1_C(DataArray)
    DataArray := _S2_H(DataArray)
    DataArray := _S3_S(DataArray)
    ; -------------------------------------------
  } ; (366_6)(This Script Error [Integer])
  ; -------------------------------------------
  ;
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
