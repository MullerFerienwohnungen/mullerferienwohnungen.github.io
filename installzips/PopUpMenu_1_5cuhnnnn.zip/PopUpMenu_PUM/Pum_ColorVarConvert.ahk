﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Pum_ColorVarConvert(VarType, Value, DataArray) ; VarType = ("VarNum"(123),"ColorGrid"(A1),"HexColor"(FFFFFF),"MsColor"(1234546)) > [VarNum, ColorGrid, HexColor, MsColor]
{
  ; -------------------------------------------
  ; Pum_ColorVarConvert(VarType, Value, DataArray)
  ;
  ; (if) VarType = "VarNum",    (Then) Value = "123" (Gui Color Picker DataArray Var Number)
  ; (if) VarType = "ColorGrid", (Then) Value = "A1"
  ; (if) VarType = "HexColor",  (Then) Value = "FFFFFF"
  ; (if) VarType = "MsColor",   (Then) Value = "123456789"
  ;
  ; Return These Values
  ; ReturnArray := [VarNum, ColorGrid, HexColor, MsColor]
  ; -------------------------------------------
  if (VarType == "VarNum")
  {
    VarNum := Value
    ColorGrid := DataArray[VarNum][4]
    HexColor  := DataArray[VarNum][5]
    MsColor   := DataArray[VarNum][6]
  }
  else
  {
    ; Loop through All 48 Colors Looking for a Match
    VarNum := 190
    Loop 48
    {
      VarNum := VarNum + 1
      if (VarType == "ColorGrid") ; (Color Grid [Letter][Number])
      {
        ThisValue := DataArray[VarNum][4]
        if (ThisValue == Value)
        {
          ColorGrid := DataArray[VarNum][4]
          HexColor  := DataArray[VarNum][5]
          MsColor   := DataArray[VarNum][6]
          break
        } ; End (ThisValue == Value)
      } ; End (VarType == "ColorGrid")
      else if (VarType == "HexColor") ; (Hex Color Number)
      {
        ThisValue := DataArray[VarNum][5]
        if (ThisValue == Value)
        {
          ColorGrid := DataArray[VarNum][4]
          HexColor  := DataArray[VarNum][5]
          MsColor   := DataArray[VarNum][6]
          break
        } ; End (ThisValue == Value)
      } ; End (VarType == "HexColor")
      else if (VarType == "MsColor") ; (MS Access Color Number)
      {
        ThisValue := DataArray[VarNum][6]
        if (ThisValue == Value)
        {
          ColorGrid := DataArray[VarNum][4]
          HexColor  := DataArray[VarNum][5]
          MsColor   := DataArray[VarNum][6]
          break
        } ; End (ThisValue == Value)
      } ; End (VarType == "MsColor")
    } ; End Loop 48
  } ; End else
  ; -------------------------------------------
  ReturnArray := [VarNum, ColorGrid, HexColor, MsColor]
  return ReturnArray
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
