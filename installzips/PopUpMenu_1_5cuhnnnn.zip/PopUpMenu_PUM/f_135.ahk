﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\f_070.ahk ; (070_1)(Obj_Cpl_WinControl)
#Include %A_ProgramFiles%\PopUpMenu_PUM\f_071.ahk ; (071_1)(Obj_URL)
#Include %A_ProgramFiles%\PopUpMenu_PUM\f_160.ahk ; (160)(Obj_Pum_App))
#Include %A_ProgramFiles%\PopUpMenu_PUM\f_161.ahk ; (161)(Obj_Pum_Del)
; -------------------------------------------
#Include %A_ProgramFiles%\PopUpMenu_PUM\Url_GetUrl.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
f_135(DataArray) ; (135_1)(Obj_ImageSelect2)
{
  ; -------------------------------------------
  if (DataArray.366.5 == "mnu_cpl_key") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
  {
    DataArray := f_070(DataArray) ; (070_1)(Obj_Cpl_WinControl)
  }
  else if (DataArray.366.5 == "run_rwh_url_ofl") ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
  {
    DataArray := f_071(DataArray) ; (071_1)(Obj_URL)
  }
  else if (InStr(DataArray.366.5, "pum") > 0) ; [InStr(ScriptType, ""pum"")]
  {
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ; [InStr(ScriptType, ""pum"")]
    ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    ;
    if (InStr(DataArray.361.9, "\pumdefault\") > 0) ; [Default pum Active]
    {
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ; [InStr(ScriptType, ""pum"")]
      ;
      ; [Default pum Active]
      ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
      ;
      if (IsInternetBrowser(DataArray.367.1, DataArray.367.3, DataArray.367.4) == 1) ; All Supported Internet Browsers
      {
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        ; [InStr(ScriptType, ""pum"")]
        ; [Default pum Active]
        ;
        ; [Internet Browser Application Active]
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        ;
        ; -------------------------------------------
        if (DataArray.290.2 == 1) ; [UseCommonBrowser = 1][All Browsers Same Pum]
        {
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ; [InStr(ScriptType, ""pum"")]
          ; [Default pum Active]
          ; [Internet Browser Application Active]
          ;
          ; [UseCommonBrowser = 1][All Browsers Same Pum]
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ;
          ; -------------------------------------------
          ThisPum := A_AppData "\PopUpMenu_PUM\pums\pumcommonbrowser\pum_pumcommonbrowser.exe"
          ; -------------------------------------------
          if FileExist(ThisPum) ; [Common Browser pum Exist]
          {
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ; [InStr(ScriptType, ""pum"")]
            ; [Default pum Active]
            ; [Internet Browser Application Active]
            ; [UseCommonBrowser = 1][All Browsers Same Pum]
            ;
            ; [Common Browser pum Exist [RUN] (f_161)(Obj_Pum_Del)]
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ;
            ; -------------------------------------------
            DataArray := f_161(DataArray) ; (161)(Obj_Pum_Del)
            ; -------------------------------------------
          } ; [Common Browser pum Exist]
          else ; [Common Browser pum does NOT Exist]
          {
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ; [InStr(ScriptType, ""pum"")]
            ; [Default pum Active]
            ; [Internet Browser Application Active]
            ; [UseCommonBrowser = 1][All Browsers Same Pum]
            ;
            ; [Common Browser pum does NOT Exist [RUN] (f_160)(Obj_Pum_App)]
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ;
            ; -------------------------------------------
            DataArray := f_160(DataArray) ; (160)(Obj_Pum_App)
            ; -------------------------------------------
          } ; [Common Browser pum does NOT Exist]
        } ; [UseCommonBrowser = 1][All Browsers Same Pum]
        ; -------------------------------------------
        else if (DataArray.290.2 == 2) ; [UseCommonBrowser = 2][Each Browser Different pum]
        {
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ; [InStr(ScriptType, ""pum"")]
          ; [Default pum Active]
          ; [Internet Browser Application Active]
          ; [UseCommonBrowser = 2][Each Browser Different pum]
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ;
          ; -------------------------------------------
          AppProcessName := DataArray.367.1 ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
          ThisPum := A_AppData "\PopUpMenu_PUM\pums\" AppProcessName "\pum_" AppProcessName ".exe"
          ; -------------------------------------------
          if FileExist(ThisPum) ; [pum Exist]
          {
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ; [InStr(ScriptType, ""pum"")]
            ; [Default pum Active]
            ; [Internet Browser Application Active]
            ; [UseCommonBrowser = 1][All Browsers Same Pum]
            ;
            ; [pum Exist [RUN] (f_161)(Obj_Pum_Del)]
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ;
            ; -------------------------------------------
            DataArray := f_161(DataArray) ; (161)(Obj_Pum_Del)
            ; -------------------------------------------
          } ; [pum Exist]
          else ; [pum does NOT Exist]
          {
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ; [InStr(ScriptType, ""pum"")]
            ; [Default pum Active]
            ; [Internet Browser Application Active]
            ; [UseCommonBrowser = 1][All Browsers Same Pum]
            ;
            ; [pum does NOT Exist [RUN] (f_160)(Obj_Pum_App)]
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ;
            ; -------------------------------------------
            DataArray := f_160(DataArray) ; (160)(Obj_Pum_App)
            ; -------------------------------------------
          } ; [pum does NOT Exist]
          ; -------------------------------------------
        } ; [UseCommonBrowser = 2][Each Browser Different pum]
        ; -------------------------------------------
      } ; [Internet Browser Application Active]
      ; -------------------------------------------
      DataArray := f_160(DataArray) ; (160)(Obj_Pum_App))
      ; -------------------------------------------
    } ; [Default pum Active]
    else ; [Default pum is NOT Active]
    {
      if (IsInternetBrowser(DataArray.367.1, DataArray.367.3, DataArray.367.4) == 1) ; All Supported Internet Browsers
      {
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        ; [InStr(ScriptType, ""pum"")]
        ; [Default pum is NOT Active]
        ;
        ; [Internet Browser Application Active]
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        ;
        ; -------------------------------------------
        if (DataArray.290.2 == 1) ; [UseCommonBrowser = 1][All Browsers Same Pum]
        {
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ; [InStr(ScriptType, ""pum"")]
          ; [Default pum is NOT Active]
          ; [Internet Browser Application Active]
          ;
          ; [UseCommonBrowser = 1][All Browsers Same Pum]
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ;
          ; -------------------------------------------
          ThisPum := A_AppData "\PopUpMenu_PUM\pums\pumcommonbrowser\pum_pumcommonbrowser.exe"
          ; -------------------------------------------
          if FileExist(ThisPum) ; [Common Browser pum Exist]
          {
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ; [InStr(ScriptType, ""pum"")]
            ; [Default pum is NOT Active]
            ; [Internet Browser Application Active]
            ; [UseCommonBrowser = 1][All Browsers Same Pum]
            ;
            ; [Common Browser pum Exist]
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ;
            ; -------------------------------------------
            if (DataArray.161.2 == "") ; (161_2)(Obj_Pum_Del_Sel [0,1,2,3])
            {
              DataArray.161.2 := 1 ; Set Here, is the case value was blank
            }
            ; -------------------------------------------
            ;
            ; -------------------------------------------
            if (DataArray.161.2 == 1)
            {
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ; [InStr(ScriptType, ""pum"")]
              ; [Default pum is NOT Active]
              ; [Internet Browser Application Active]
              ; [UseCommonBrowser = 1][All Browsers Same Pum]
              ; [Common Browser pum Exist]
              ;
              ; (Delete Pum) [RUN] (f_161)(Obj_Pum_Del)
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ;
              ; -------------------------------------------
              DataArray := f_161(DataArray) ; (161)(Obj_Pum_Del)
              ; -------------------------------------------
            }
            ; -------------------------------------------
						else if (DataArray.161.2 == 2) ; [UnSelect] Delete Pum
            {
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ; [InStr(ScriptType, ""pum"")]
              ; [Default pum is NOT Active]
              ; [Internet Browser Application Active]
              ; [UseCommonBrowser = 1][All Browsers Same Pum]
              ; [Common Browser pum Exist]
              ;
              ; [UnSelect] Delete Pum
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ;
              ; -------------------------------------------
              DataArray.366.5 := "pumtom" ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
              ; -------------------------------------------
              DataArray := Image_GuiControl("134", "pum", 0, DataArray) ; (134_1)(Obj_ImageSelect1)
              ; -------------------------------------------
							;
              ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
              Sys_EnableDisable("Enable") ; "Enable" or "Disable"
              ; -------------------------------------------
              Gui, PopUpMenu:Color, e7d8fe ; Purple
              ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
              ;
              ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
              if (Url_ConnectCheck(flag=0x40) == 1)
              {
                DataArray := Image_GuiControl("136", "pum", 0, DataArray) ; (136_1)(Obj_ImageSelect3)
              }
              ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
							;
              ; -------------------------------------------
              ThisAppPath := A_ProgramFiles "\PopUpMenu_PUM\image\ico\pumcommonbrowser.txt"
              ArrayIn := [ThisAppPath, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
              Img135 := Img_Del135(ArrayIn)
              DataArray := Image_GuiControl("Image_135", Img135, 0, DataArray)
              ; -------------------------------------------
              ;
              ; -------------------------------------------
              DataArray := Image_GuiControl("137", 0, 0, DataArray) ; (137_1)(Obj_MsgImg480x270)
              DataArray := Image_GuiControl("157", 1, 1, DataArray) ; (157_1)(Obj_Pum_Setting)
              ; -------------------------------------------
              DataArray := Image_GuiControl("160", 0, 1, DataArray) ; (160)(Obj_Pum_App))
              DataArray := Image_GuiControl("161", 1, 1, DataArray) ; (161)(Obj_Pum_Del)
              ; -------------------------------------------
              ;
              ; -------------------------------------------
              DataArray := Image_GuiControl("254", 0, 1, DataArray) ; (254_1)(Obj_MsgImg300x300)
              ; -------------------------------------------
              ;
              Sleep, 500
              ;
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Start/Stop (Animate) Pum_Building_Construct
              if (n_521 == 170)
              {
                ; -------------------------------------------
                DataArray := Image_GuiControl("521_137", 169, 0, DataArray) ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
                global s_521 := 0 ; Hide
                SetTimer, l_521, Off ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
                global ShowAnimationChange := 0
                ; -------------------------------------------
              }
              else
              {
                global s_521 := 1 ; Show
                SetTimer, l_521, 350 ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
              }
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Start/Stop (Animate) Pum_Building_Construct
            } ; [UnSelect] Delete Pum
						; -------------------------------------------
          } ; [Common Browser pum Exist]
          else ; [Common Browser pum does NOT Exist]
          {
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ; [InStr(ScriptType, ""pum"")]
            ; [Default pum is NOT Active]
            ; [Internet Browser Application Active]
            ; [UseCommonBrowser = 1][All Browsers Same Pum]
            ;
            ; [Common Browser pum does NOT Exist [RUN] (f_160)(Obj_Pum_App)]
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ;
            ; -------------------------------------------
            DataArray := f_160(DataArray) ; (160)(Obj_Pum_App)
            ; -------------------------------------------
          } ; [Common Browser pum does NOT Exist]
        } ; [UseCommonBrowser = 1][All Browsers Same Pum]
        else if (DataArray.290.2 == 2) ; [UseCommonBrowser = 2][Each Browser Different pum]
        {
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ; [InStr(ScriptType, ""pum"")]
          ; [Default pum is NOT Active]
          ; [Internet Browser Application Active]
          ;
          ; [UseCommonBrowser = 2][Each Browser Different pum]
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ;
          ; -------------------------------------------
          AppProcessName := DataArray.367.1 ; (367_1)(AppProcessName [Name][LowerCase][NoSpace])
          ThisPum := A_AppData "\PopUpMenu_PUM\pums\" AppProcessName "\pum_" AppProcessName ".exe"
          ; -------------------------------------------
          if FileExist(ThisPum) ; [Internet Browser Application pum Exist]
          {
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ; [InStr(ScriptType, ""pum"")]
            ; [Default pum Active]
            ; [Internet Browser Application Active]
            ; [UseCommonBrowser = 2][Each Browser Different pum]
            ;
            ; [Internet Browser Application pum Exist]
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ;
						; -------------------------------------------
            if (DataArray.161.2 == 1)
            {
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ; [InStr(ScriptType, ""pum"")]
              ; [Default pum Active]
              ; [Internet Browser Application Active]
              ; [UseCommonBrowser = 2][Each Browser Different pum]
              ; [Internet Browser Application pum Exist]
							;
							; (Delete Pum) f_161(DataArray)
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ;
              ; -------------------------------------------
              DataArray := f_161(DataArray) ; (161)(Obj_Pum_Del)
              ; -------------------------------------------
            }
            ; -------------------------------------------
						else if (DataArray.161.2 == 2) ; [UnSelect] Delete Pum
            {
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ; [InStr(ScriptType, ""pum"")]
              ; [Default pum Active]
              ; [Internet Browser Application Active]
              ; [UseCommonBrowser = 2][Each Browser Different pum]
              ; [Internet Browser Application pum Exist]
							;
							; [UnSelect] Delete Pum
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
              ;
              ; -------------------------------------------
              DataArray.366.5 := "pumtom" ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
              ; -------------------------------------------
              DataArray := Image_GuiControl("134", "pum", 0, DataArray) ; (134_1)(Obj_ImageSelect1)
              ; -------------------------------------------
							;
              ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
              Sys_EnableDisable("Enable") ; "Enable" or "Disable"
              ; -------------------------------------------
              Gui, PopUpMenu:Color, e7d8fe ; Purple
              ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
              ;
              ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
              if (Url_ConnectCheck(flag=0x40) == 1)
              {
                DataArray := Image_GuiControl("136", "pum", 0, DataArray) ; (136_1)(Obj_ImageSelect3)
              }
              ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
							;
              ; -------------------------------------------
              ThisAppPath := DataArray.367.5
              ArrayIn := [ThisAppPath, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
              Img135 := Img_Del135(ArrayIn)
              DataArray := Image_GuiControl("Image_135", Img135, 0, DataArray)
							; -------------------------------------------
              ;
              ; -------------------------------------------
              DataArray := Image_GuiControl("137", 0, 0, DataArray) ; (137_1)(Obj_MsgImg480x270)
              DataArray := Image_GuiControl("157", 1, 1, DataArray) ; (157_1)(Obj_Pum_Setting)
              ; -------------------------------------------
              DataArray := Image_GuiControl("160", 0, 1, DataArray) ; (160)(Obj_Pum_App))
              DataArray := Image_GuiControl("161", 1, 1, DataArray) ; (161)(Obj_Pum_Del)
              ; -------------------------------------------
              ;
              ; -------------------------------------------
              DataArray := Image_GuiControl("254", 0, 1, DataArray) ; (254_1)(Obj_MsgImg300x300)
              ; -------------------------------------------
              ;
              Sleep, 500
              ;
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Start/Stop (Animate) Pum_Building_Construct
              if (n_521 == 170)
              {
                ; -------------------------------------------
                DataArray := Image_GuiControl("521_137", 169, 0, DataArray) ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
                global s_521 := 0 ; Hide
                SetTimer, l_521, Off ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
                global ShowAnimationChange := 0
                ; -------------------------------------------
              }
              else
              {
                global s_521 := 1 ; Show
                SetTimer, l_521, 350 ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
              }
              ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Start/Stop (Animate) Pum_Building_Construct
            } ; [UnSelect] Delete Pum
						; -------------------------------------------            
          } ; [Internet Browser Application pum Exist]
          else ; [Internet Browser Application pum NOT Exist]
          {
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ; [InStr(ScriptType, ""pum"")]
            ; [Default pum Active]
            ; [Internet Browser Application Active]
            ; [UseCommonBrowser = 2][Each Browser Different pum]
            ;
            ; [Internet Browser Application pum NOT Exist]
            ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            ;
            ; -------------------------------------------
            DataArray := f_160(DataArray) ; (160)(Obj_Pum_App))
            ; -------------------------------------------
          } ; [Internet Browser Application pum NOT Exist]
          ; -------------------------------------------
        } ; [UseCommonBrowser = 2][Each Browser Different pum]
        ; -------------------------------------------
      } ; [Internet Browser Application Active]
      else ; [Any Other Application (Non-Internet Browser) Active]
      {
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        ; [InStr(ScriptType, ""pum"")]
        ; [Default pum is NOT Active]
        ;
        ; [Any Other Application (Non-Internet Browser) Active]
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        ;
        if (DataArray.161.2 == 1)
        {
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ; [InStr(ScriptType, ""pum"")]
          ; [Default pum is NOT Active]
          ; [Any Other Application (Non-Internet Browser) Active]
          ;
          ; (Delete Pum) f_161(DataArray)
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ;
          ; -------------------------------------------
          DataArray := f_161(DataArray) ; (161)(Obj_Pum_Del)
          ; -------------------------------------------
        }
        ; -------------------------------------------
        else if (DataArray.161.2 == 2) ; [UnSelect] Delete Pum
        {
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ; [InStr(ScriptType, ""pum"")]
          ; [Default pum is NOT Active]
          ; [Any Other Application (Non-Internet Browser) Active]
          ;
          ; [UnSelect] Delete Pum
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
          ;
          ; -------------------------------------------
          DataArray.366.5 := "pumtom" ; (366_5)(ScriptType [cpl,key,mnu,ofl,pum,run,rwh,url])
          ; -------------------------------------------
          DataArray := Image_GuiControl("134", "pum", 0, DataArray) ; (134_1)(Obj_ImageSelect1)
          ; -------------------------------------------
          ;
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          Sys_EnableDisable("Enable") ; "Enable" or "Disable"
          ; -------------------------------------------
          Gui, PopUpMenu:Color, e7d8fe ; Purple
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          ;
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          if (Url_ConnectCheck(flag=0x40) == 1)
          {
            DataArray := Image_GuiControl("136", "pum", 0, DataArray) ; (136_1)(Obj_ImageSelect3)
          }
          ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
          ;
          ; -------------------------------------------
          ThisAppPath := DataArray.367.5
          ArrayIn := [ThisAppPath, DataArray.367.1, DataArray.290.2, DataArray.365.2, DataArray.363.12]
          Img135 := Img_Del135(ArrayIn)
          DataArray := Image_GuiControl("Image_135", Img135, 0, DataArray)
          ; -------------------------------------------
          ;
          ; -------------------------------------------
          DataArray := Image_GuiControl("137", 0, 0, DataArray) ; (137_1)(Obj_MsgImg480x270)
          DataArray := Image_GuiControl("157", 1, 1, DataArray) ; (157_1)(Obj_Pum_Setting)
          ; -------------------------------------------
          DataArray := Image_GuiControl("160", 0, 1, DataArray) ; (160)(Obj_Pum_App))
          DataArray := Image_GuiControl("161", 1, 1, DataArray) ; (161)(Obj_Pum_Del)
          ; -------------------------------------------
          ;
          ; -------------------------------------------
          DataArray := Image_GuiControl("254", 0, 1, DataArray) ; (254_1)(Obj_MsgImg300x300)
          ; -------------------------------------------
          ;
          Sleep, 500
          ;
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Start/Stop (Animate) Pum_Building_Construct
          if (n_521 == 170)
          {
            ; -------------------------------------------
            DataArray := Image_GuiControl("521_137", 169, 0, DataArray) ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
            global s_521 := 0 ; Hide
            SetTimer, l_521, Off ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
            global ShowAnimationChange := 0
            ; -------------------------------------------
          }
          else
          {
            global s_521 := 1 ; Show
            SetTimer, l_521, 350 ; (521_1)(_Msg 4_)(_w480 x h270_)_Pum_Building_Construct)
          }
          ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Start/Stop (Animate) Pum_Building_Construct
        } ; [UnSelect] Delete Pum
        ; -------------------------------------------
      } ; [Any Other Application (Non-Internet Browser) Active]
      ; -------------------------------------------
    } ; [Default pum is NOT Active]
  }
  ; -------------------------------------------
  return DataArray
  ; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
