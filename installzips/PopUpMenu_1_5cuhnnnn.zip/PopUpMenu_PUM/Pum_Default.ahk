﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\Array_FromFile.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\XmlVal.ahk
#Include %A_ProgramFiles%\PopUpMenu_PUM\XmlWrite.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Pum_Default() ; > Nothing
{
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; User Language [GET] (UserLang)
  ; -------------------------------------------
  File_UserLang := A_AppData "\PopUpMenu_PUM\system\File_UserLang.txt"
  ; -------------------------------------------
  if FileExist(File_UserLang)
  {
    FileReadLINE, UserLang, %File_UserLang%, 1
  }
  if (UserLang == "")
  {
    ; -------------------------------------------
    if FileExist(File_UserLang)
    {
      FileDelete, %File_UserLang%
      Sleep, 100
    } ; [End] if FileExist(File_UserLang)
    ; -------------------------------------------
    if (A_Language == "0407" or A_Language == "0807" or A_Language == "0c07" or A_Language == "1007" or A_Language == "1407")
    {
      ; -------------------------------------------
      UserLang := "de"
      ; -------------------------------------------
    } ; [End] German (de)
    ; -------------------------------------------
    else if (A_Language == "0409" or A_Language == "0809" or A_Language == "0c09" or A_Language == "1009" or A_Language == "1409" or A_Language == "1809" or A_Language == "1c09" or A_Language == "2009" or A_Language == "2409" or A_Language == "2809" or A_Language == "2c09" or A_Language == "3009" or A_Language == "3409")
    {
      ; -------------------------------------------
      UserLang := "en"
      ; -------------------------------------------
    } ; [End] English (en)
    ; -------------------------------------------
    else if (A_Language == "040a" or A_Language == "080a" or A_Language == "0c0a" or A_Language == "100a" or A_Language == "140a" or A_Language == "180a" or A_Language == "1c0a" or A_Language == "200a" or A_Language == "240a" or A_Language == "280a" or A_Language == "2c0a" or A_Language == "300a" or A_Language == "340a" or A_Language == "380a" or A_Language == "3c0a" or A_Language == "400a" or A_Language == "440a" or A_Language == "480a" or A_Language == "4c0a" or A_Language == "500a")
    {
      ; -------------------------------------------
      UserLang := "es"
      ; -------------------------------------------
    } ; [End] Spanish (es)
    ; -------------------------------------------
    else if (A_Language == "040c" or A_Language == "080c" or A_Language == "0c0c" or A_Language == "100c" or A_Language == "140c" or A_Language == "180c")
    {
      ; -------------------------------------------
      UserLang := "fr"
      ; -------------------------------------------
    } ; [End] French (fr)
    ; -------------------------------------------
    else if (A_Language == "0410" or A_Language == "0810")
    {
      ; -------------------------------------------
      UserLang := "it"
      ; -------------------------------------------
    } ; [End] Italian (it)
    ; -------------------------------------------
    else if (A_Language == "0415")
    {
      ; -------------------------------------------
      UserLang := "pl"
      ; -------------------------------------------
    } ; [End] Polish (pl)
    ; -------------------------------------------
    else if (A_Language == "0416" or A_Language == "0816")
    {
      ; -------------------------------------------
      UserLang := "pt"
      ; -------------------------------------------
    } ; [End] Portuguese (pt)
    ; -------------------------------------------
    else if (A_Language == "0419")
    {
      ; -------------------------------------------
      UserLang := "ru"
      ; -------------------------------------------
    } ; [End] Russian (ru)
    ; -------------------------------------------
    else if (A_Language == "041d" or A_Language == "081d")
    {
      ; -------------------------------------------
      UserLang := "sv"
      ; -------------------------------------------
    } ; [End] Swedish (sv)
    ; -------------------------------------------
    else if (A_Language == "041f")
    {
      ; -------------------------------------------
      UserLang := "tr"
      ; -------------------------------------------
    } ; [End] Turkish (tr)
    ; -------------------------------------------
    else ; English (en)
    {
      ; -------------------------------------------
      UserLang := "en"
      ; -------------------------------------------
    } ; [End] else ; English (en)
    ; -------------------------------------------
    FileEncoding, UTF-8
    FileAppend, %UserLang%`n, %File_UserLang% ; UTF-8
    ; -------------------------------------------
  } ; [End] if (UserLang == "")
  ; -------------------------------------------
  ; User Language [GET] (UserLang)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;  [CHECK] [CREATE] [FOLDER] ThisPumProcessFolder
  ; -------------------------------------------
  ThisPumProcessFolder := A_AppData "\PopUpMenu_PUM\pums\pumdefault"
  ; -------------------------------------------
  if !FileExist(ThisPumProcessFolder) ; A_AppData "\PopUpMenu_PUM\pums\" AppProcessName 
  {
    FileCreateDir, %ThisPumProcessFolder%
    Sleep, 10
  } ; [End] if !FileExist(ThisPumProcessFolder) ; A_AppData "\PopUpMenu_PUM\pums\" AppProcessName
  ; -------------------------------------------
  ;  [CHECK] [CREATE] [FOLDER] ThisPumProcessFolder
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; [COPY] Pum Model Folder
  ; -------------------------------------------
  PumModelFolder := A_ProgramFiles "\PopUpMenu_PUM\pum_default"
  FileCopyDir, %PumModelFolder%, %ThisPumProcessFolder%, 1
  Sleep, 10
  ; -------------------------------------------
  ; [COPY] Pum Model Folder
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; [COPY] Language Spicific Script (pum_ahk_default) to ThisPumProcessFolder
  ; -------------------------------------------
	Path_PumAhkTemp := A_ProgramFiles "\PopUpMenu_PUM\pum_ahk_default\" UserLang
	; -------------------------------------------
  Pum_Ahk_Temp0 := Path_PumAhkTemp "\cpl-00000000000000.ahk"
  Pum_Ahk_Lang0 := ThisPumProcessFolder "\ahk\cpl-00000000000000.ahk"
	; -------------------------------------------
	Pum_Ahk_Temp1 := Path_PumAhkTemp "\key-00000000000001.ahk"
  Pum_Ahk_Lang1 := ThisPumProcessFolder "\ahk\key-00000000000001.ahk"
	; -------------------------------------------
	Pum_Ahk_Temp2 := Path_PumAhkTemp "\key-00000000000002.ahk"
  Pum_Ahk_Lang2 := ThisPumProcessFolder "\ahk\key-00000000000002.ahk"
	; -------------------------------------------
	Pum_Ahk_Temp3 := Path_PumAhkTemp "\key-00000000000003.ahk"
  Pum_Ahk_Lang3 := ThisPumProcessFolder "\ahk\key-00000000000003.ahk"
	; -------------------------------------------
	Pum_Ahk_Temp4 := Path_PumAhkTemp "\key-00000000000004.ahk"
  Pum_Ahk_Lang4 := ThisPumProcessFolder "\ahk\key-00000000000004.ahk"
	; -------------------------------------------
	Pum_Ahk_Temp5 := Path_PumAhkTemp "\key-00000000000005.ahk"
  Pum_Ahk_Lang5 := ThisPumProcessFolder "\ahk\key-00000000000005.ahk"
	; -------------------------------------------
	Pum_Ahk_Temp6 := Path_PumAhkTemp "\key-00000000000006.ahk"
  Pum_Ahk_Lang6 := ThisPumProcessFolder "\ahk\key-00000000000006.ahk"
	; -------------------------------------------
	Pum_Ahk_Temp7 := Path_PumAhkTemp "\key-00000000000007.ahk"
  Pum_Ahk_Lang7 := ThisPumProcessFolder "\ahk\key-00000000000007.ahk"
	; -------------------------------------------
  FileCopy, %Pum_Ahk_Temp0%, %Pum_Ahk_Lang0%, 1
  FileCopy, %Pum_Ahk_Temp1%, %Pum_Ahk_Lang1%, 1
  FileCopy, %Pum_Ahk_Temp2%, %Pum_Ahk_Lang2%, 1
  FileCopy, %Pum_Ahk_Temp3%, %Pum_Ahk_Lang3%, 1
  FileCopy, %Pum_Ahk_Temp4%, %Pum_Ahk_Lang4%, 1
  FileCopy, %Pum_Ahk_Temp5%, %Pum_Ahk_Lang5%, 1
  FileCopy, %Pum_Ahk_Temp6%, %Pum_Ahk_Lang6%, 1
  FileCopy, %Pum_Ahk_Temp7%, %Pum_Ahk_Lang7%, 1
  ; -------------------------------------------
	BreakTime := 1000
	while !FileExist(Pum_Ahk_Lang0)
	{
		if (A_TickCount > Breaktime)
		{
			break
		}
	}
	; -------------------------------------------
	BreakTime := 1000
	while !FileExist(Pum_Ahk_Lang1)
	{
		if (A_TickCount > Breaktime)
		{
			break
		}
	}
	; -------------------------------------------
	BreakTime := 1000
	while !FileExist(Pum_Ahk_Lang2)
	{
		if (A_TickCount > Breaktime)
		{
			break
		}
	}
	; -------------------------------------------
	BreakTime := 1000
	while !FileExist(Pum_Ahk_Lang3)
	{
		if (A_TickCount > Breaktime)
		{
			break
		}
	}
	; -------------------------------------------
	BreakTime := 1000
	while !FileExist(Pum_Ahk_Lang4)
	{
		if (A_TickCount > Breaktime)
		{
			break
		}
	}
	; -------------------------------------------
	BreakTime := 1000
	while !FileExist(Pum_Ahk_Lang5)
	{
		if (A_TickCount > Breaktime)
		{
			break
		}
	}
	; -------------------------------------------
	BreakTime := 1000
	while !FileExist(Pum_Ahk_Lang6)
	{
		if (A_TickCount > Breaktime)
		{
			break
		}
	}
	; -------------------------------------------
	BreakTime := 1000
	while !FileExist(Pum_Ahk_Lang7)
	{
		if (A_TickCount > Breaktime)
		{
			break
		}
	}
	; -------------------------------------------
  ; [COPY] Language Spicific Script (ahk) to ThisPumProcessFolder
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; [SET] ThisPumProcessXml
  ; -------------------------------------------
  ; Pum Xml to Array (ThisPumProcessArray)
  ; -------------------------------------------
  ThisPumProcessXml := A_AppData "\PopUpMenu_PUM\pums\pumdefault\settings\toolbox0.xml"
  ; -------------------------------------------
  ThisPumProcessArray := Array_FromFile(ThisPumProcessXml) ; > Array
  ; -------------------------------------------
  ; [SET] ThisPumProcessXml
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; XML Line Strings from (ThisPumProcessArray)
  ; -------------------------------------------
  XmlLine3  := ThisPumProcessArray.3
  XmlLine9  := ThisPumProcessArray.9
  ; -------------------------------------------
  ; XML Line Strings from (ThisPumProcessArray)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; (PumTotalRY)
  ; -------------------------------------------
  FindItem := "rows"
  XmlString := XmlLine3 ; <toolbox name="" rows="19" columns="25" left="38" top="36" stayontop="-1" >
  ; -------------------------------------------
  ItemPos := InStr(XmlString, FindItem)
  ValStringTemp := SubStr(XmlString, ItemPos)
  ValStartPos := InStr(ValStringTemp, """",,, 1)
  ValStartPos := ValStartPos + 1
  ValEndPos := InStr(ValStringTemp, """",,, 2)
  ValLen := ValEndPos - ValStartPos
  ThisVar  := SubStr(ValStringTemp, ValStartPos, ValLen)
  ; -------------------------------------------
  PumTotalRY := ThisVar
  ; -------------------------------------------
  ; (PumTotalRY)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; (PumTotalCX)
  ; -------------------------------------------
  FindItem := "columns"
  XmlString := XmlLine3 ; <toolbox name="" rows="19" columns="25" left="38" top="36" stayontop="-1" >
  ; -------------------------------------------
  ItemPos := InStr(XmlString, FindItem)
  ValStringTemp := SubStr(XmlString, ItemPos)
  ValStartPos := InStr(ValStringTemp, """",,, 1)
  ValStartPos := ValStartPos + 1
  ValEndPos := InStr(ValStringTemp, """",,, 2)
  ValLen := ValEndPos - ValStartPos
  ThisVar  := SubStr(ValStringTemp, ValStartPos, ValLen)
  ; -------------------------------------------
  PumTotalCX := ThisVar
  ; -------------------------------------------
  ; (PumTotalCX)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; (XmlIconSize)
  ; -------------------------------------------
  FindItem := "iconsize"
  XmlString := XmlLine9 ; <displaymode type="0" iconsize="48" />
  ; -------------------------------------------
  ItemPos := InStr(XmlString, FindItem)
  ValStringTemp := SubStr(XmlString, ItemPos)
  ValStartPos := InStr(ValStringTemp, """",,, 1)
  ValStartPos := ValStartPos + 1
  ValEndPos := InStr(ValStringTemp, """",,, 2)
  ValLen := ValEndPos - ValStartPos
  ThisVar  := SubStr(ValStringTemp, ValStartPos, ValLen)
  ; -------------------------------------------
  XmlIconSize := ThisVar
  ; -------------------------------------------
  ; (XmlIconSize)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; Center Pum on Screen
  ; Set (PumWindowsPosX)(PumWindowsPosY)
  ; -------------------------------------------
  PumTotalW  := PumTotalCX * XmlIconSize
  PumTotalH := PumTotalRY * XmlIconSize
  ; -------------------------------------------
  PumWindowsPosX := Round((A_ScreenWidth - PumTotalW) / 2)
  PumWindowsPosY := Round((A_ScreenHeight - PumTotalH) / 2)
  ; -------------------------------------------
  ; Center Pum on Screen
  ; Set (PumWindowsPosX)(PumWindowsPosY)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; Update (ThisPumProcessArray)
  ; -------------------------------------------
  XML_Line_3 := "<toolbox name="""" rows=""" PumTotalRY """ columns=""" PumTotalCX """ left=""" PumWindowsPosX  """ top=""" PumWindowsPosY  """ stayontop=""-1"" >"
  ; -------------------------------------------
  ThisPumProcessArray.RemoveAt(3)
  ThisPumProcessArray.InsertAt(3, XML_Line_3)
  ; -------------------------------------------
  ; Update (ThisPumProcessArray)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; [UPDATE] (ThisPumProcessArray)
  ; -------------------------------------------
  bg_Selected_Bmp := A_AppData "\PopUpMenu_PUM\pums\pumdefault\image\bg_Selected_Bmp.bmp"
  XmlBgColor   := 0
  XmlBgType    := 1
  XmlBgOpacity := 100
  ; -------------------------------------------
  XML_Line_19 := "  <background color=""" XmlBgColor """ type=""" XmlBgType """ effect=""0"" opacity=""" XmlBgOpacity """ >"
  XML_Line_20 := "    <filename>" bg_Selected_Bmp "</filename>"
  ; -------------------------------------------
  ThisPumProcessArray.RemoveAt(19)
  ThisPumProcessArray.InsertAt(19, XML_Line_19)
  ; -------------------------------------------
  ThisPumProcessArray.RemoveAt(20)
  ThisPumProcessArray.InsertAt(20, XML_Line_20)
  ; -------------------------------------------
  ; [UPDATE] (ThisPumProcessArray)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; [CHECK] for ERRORS / [WRITE] (ThisPumProcessXml)
  ; -------------------------------------------
  ;	Writes a (File_TempXml)
	; then Checks that (Temp Xml file) Againest the (Array_ThisXml)
	; if the Written (Temp Xml file) matches the Oranganal (Array_ThisXml)
	;  > Will Copy and Overwrite (File_ThisXml)
  ; -------------------------------------------
  XmlPassed := XmlWrite(ThisPumProcessArray, ThisPumProcessXml) ; Array_ThisXml, File_ThisXml > 1 = Ok , 0 Xml Has Error
  ; -------------------------------------------
  ; [CHECK] for ERRORS / [WRITE] (ThisPumProcessXml)
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
} ; [End] Pum_Default() ; > Nothing
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
