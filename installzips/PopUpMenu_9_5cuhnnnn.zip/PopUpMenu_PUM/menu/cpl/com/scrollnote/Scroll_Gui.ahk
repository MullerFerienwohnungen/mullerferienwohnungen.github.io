#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#NoTrayIcon
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
;(1)  Scroll_DataArray.1  ; Scroll_PosX            ; [#]
;(2)  Scroll_DataArray.2  ; Scroll_PosY            ; [#]
;(3)  Scroll_DataArray.3  ; Scroll_State           ; ["Closed","Open"]
;(4)  Scroll_DataArray.4  ; Scroll_AlarmOnOff      ; [0,1]
;(5)  Scroll_DataArray.5  ; Scroll_AlarmTime       ; [YYYYMMDDhhmm]
;(6)  Scroll_DataArray.6  ; Scroll_AlarmSoundOnOff ; [0,1]
;(7)  Scroll_DataArray.7  ; Scroll_WasMoved        ; [0,1]
;(8)  Scroll_DataArray.8  ; Scroll_AlarmSettings   ; [0,1]
;(9)  Scroll_DataArray.9  ; Alarm_Activated        ; [0,1]
;(10) Scroll_DataArray.10 ; Alarm_Activated_PosX   ; [#]
;(11) Scroll_DataArray.11 ; Alarm_Activated_PosY   ; [#]
; -------------------------------------------
; MUST BE THE LAST in the Array
;(12) Scroll_DataArray.12 Scroll_Entry             ; [String]
; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %A_ProgramFiles%\PopUpMenu_PUM\Array_FromFile.ahk
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; StartUp Vars
; -------------------------------------------
SplitPath, A_ScriptFullPath, , , , ThisScrollNote
TextFile_ThisScrollNote := A_ScriptDir "\" ThisScrollNote ".txt"
; -------------------------------------------
if FileExist(TextFile_ThisScrollNote) ; (This a Existing Scroll Note with is a New Login)
{
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  ;(1)  Scroll_DataArray.1  ; Scroll_PosX            ; [#]
  ;(2)  Scroll_DataArray.2  ; Scroll_PosY            ; [#]
  ;(3)  Scroll_DataArray.3  ; Scroll_State           ; ["Closed","Open"]
  ;(4)  Scroll_DataArray.4  ; Scroll_AlarmOnOff      ; [0,1]
  ;(5)  Scroll_DataArray.5  ; Scroll_AlarmTime       ; [YYYYMMDDhhmm]
  ;(6)  Scroll_DataArray.6  ; Scroll_AlarmSoundOnOff ; [0,1]
  ;(7)  Scroll_DataArray.7  ; Scroll_WasMoved        ; [0,1]
  ;(8)  Scroll_DataArray.8  ; Scroll_AlarmSettings   ; [0,1]
  ;(9)  Scroll_DataArray.9  ; Alarm_Activated        ; [0,1]
  ;(10) Scroll_DataArray.10 ; Alarm_Activated_PosX   ; [#]
  ;(11) Scroll_DataArray.11 ; Alarm_Activated_PosY   ; [#]
  ; -------------------------------------------
  ; MUST BE THE LAST in the Array
  ;(12) Scroll_DataArray.12 Scroll_Entry             ; [String]
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  ;
	; -------------------------------------------
	FirstTimeLoad := 2 ; File Exist (This a Existing Scroll Note with is a New Login)
	; -------------------------------------------
	;
	; -------------------------------------------
	Scroll_FileArray := Array_FromFile(TextFile_ThisScrollNote)
	; -------------------------------------------
	Scroll_PosX            := Scroll_FileArray.1
	Scroll_PosY            := Scroll_FileArray.2
	Scroll_State           := Scroll_FileArray.3
	Scroll_AlarmOnOff      := Scroll_FileArray.4
	Scroll_AlarmTime       := Scroll_FileArray.5
	Scroll_AlarmSoundOnOff := Scroll_FileArray.6
	Scroll_WasMoved        := 0  ; Line/Array 7
	Scroll_AlarmSettings   := 0  ; Line/Array 8
	Alarm_Activated        := 0  ; Array 9
	Alarm_Activated_PosX   := 0  ; Array 10
	Alarm_Activated_PosY   := 0  ; Array 11
	; -------------------------------------------
	Scroll_Entry           := "" ; Line/Array 12
	; -------------------------------------------
	for Index, ThisEntry in Scroll_FileArray
	{
		; -------------------------------------------
		if (Index > 11)
		{
			; -------------------------------------------
			Scroll_Entry := Scroll_Entry ThisEntry "`n"
			; -------------------------------------------
		} ; if (Index > 8)
	} ; for Index, ThisEntry in Scroll_FileArray
	; -------------------------------------------
	Scroll_DataArray := [Scroll_PosX, Scroll_PosY, Scroll_State, Scroll_AlarmOnOff, Scroll_AlarmTime, Scroll_AlarmSoundOnOff, Scroll_WasMoved, Scroll_AlarmSettings, Alarm_Activated, Alarm_Activated_PosX, Alarm_Activated_PosY, Scroll_Entry]
	; -------------------------------------------
	Alarm_Year   := SubStr(Scroll_AlarmTime, 1, 4)
	Alarm_Month  := SubStr(Scroll_AlarmTime, 5, 2)
	Alarm_Day    := SubStr(Scroll_AlarmTime, 7, 2)
	Alarm_Hour   := SubStr(Scroll_AlarmTime, 9, 2)
	Alarm_Minute := SubStr(Scroll_AlarmTime, 11, 2)
	; -------------------------------------------
} ; if FileExist(TextFile_ThisScrollNote)
else ; (TextFile_ThisScrollNote) Does NOT Exist (This a New Scroll Note)
{
	; -------------------------------------------
	FirstTimeLoad := 1 ; This a New Scroll Note
	; -------------------------------------------
	;
  ; -------------------------------------------
	FormatTime, TimeRightNow , , yyyyMMddHHmm
	Current_Year := SubStr(TimeRightNow, 1, 4)
	Current_Month := SubStr(TimeRightNow, 5, 2)
	Current_Day := SubStr(TimeRightNow, 7, 2)
	Current_Hour := SubStr(TimeRightNow, 9, 2)
	Current_Minute := SubStr(TimeRightNow, 11, 2)
	; -------------------------------------------
	Alarm_Year   := Current_Year
	Alarm_Month  := Current_Month
	Alarm_Day    := Current_Day
	Alarm_Hour   := Current_Hour
  Alarm_Minute := Current_Minute
  ; -------------------------------------------
	Scroll_AlarmTime := Alarm_Year Alarm_Month Alarm_Day Alarm_Hour Alarm_Minute
	; -------------------------------------------
	;
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  ;(1)  Scroll_DataArray.1  ; Scroll_PosX            ; [#]
  ;(2)  Scroll_DataArray.2  ; Scroll_PosY            ; [#]
  ;(3)  Scroll_DataArray.3  ; Scroll_State           ; ["Closed","Open"]
  ;(4)  Scroll_DataArray.4  ; Scroll_AlarmOnOff      ; [0,1]
  ;(5)  Scroll_DataArray.5  ; Scroll_AlarmTime       ; [YYYYMMDDhhmm]
  ;(6)  Scroll_DataArray.6  ; Scroll_AlarmSoundOnOff ; [0,1]
  ;(7)  Scroll_DataArray.7  ; Scroll_WasMoved        ; [0,1]
  ;(8)  Scroll_DataArray.8  ; Scroll_AlarmSettings   ; [0,1]
  ;(9)  Scroll_DataArray.9  ; Alarm_Activated        ; [0,1]
  ;(10) Scroll_DataArray.10 ; Alarm_Activated_PosX   ; [#]
  ;(11) Scroll_DataArray.11 ; Alarm_Activated_PosY   ; [#]
  ; -------------------------------------------
  ; MUST BE THE LAST in the Array
  ;(12) Scroll_DataArray.12 Scroll_Entry             ; [String]
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  ;
	Scroll_PosX := Round((A_ScreenWidth / 2) - 101)
	Scroll_PosY := Round((A_ScreenHeight / 2) - 125)
	Scroll_State := "Closed"
	Scroll_AlarmOnOff := 0
	Scroll_AlarmTime := 0
	Scroll_AlarmSoundOnOff := 0  ; 6
	Scroll_WasMoved        := 0  ; 7
	Scroll_AlarmSettings   := 0  ; 8
		; -------------------------------------------
	Alarm_Activated        := 0  ; 9
	Alarm_Activated_PosX   := 0  ; 10
	Alarm_Activated_PosY   := 0  ; 11
	; -------------------------------------------
	Scroll_Entry           := "" ; 12
	Scroll_DataArray := [Scroll_PosX, Scroll_PosY, Scroll_State, Scroll_AlarmOnOff, Scroll_AlarmTime, Scroll_AlarmSoundOnOff, Scroll_WasMoved, Scroll_AlarmSettings, Alarm_Activated, Alarm_Activated_PosX, Alarm_Activated_PosY, Scroll_Entry]
	; -------------------------------------------
	F_Scroll_UpdateText(Scroll_DataArray) ; > Nothing
	; -------------------------------------------
} ; else ; (TextFile_ThisScrollNote) Does NOT Exist
; -------------------------------------------
; StartUp Vars
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
F_Scroll_UpdateText(Scroll_DataArray) ; > Nothing
{
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  ;(1)  Scroll_DataArray.1  ; Scroll_PosX            ; [#]
  ;(2)  Scroll_DataArray.2  ; Scroll_PosY            ; [#]
  ;(3)  Scroll_DataArray.3  ; Scroll_State           ; ["Closed","Open"]
  ;(4)  Scroll_DataArray.4  ; Scroll_AlarmOnOff      ; [0,1]
  ;(5)  Scroll_DataArray.5  ; Scroll_AlarmTime       ; [YYYYMMDDhhmm]
  ;(6)  Scroll_DataArray.6  ; Scroll_AlarmSoundOnOff ; [0,1]
  ;(7)  Scroll_DataArray.7  ; Scroll_WasMoved        ; [0,1]
  ;(8)  Scroll_DataArray.8  ; Scroll_AlarmSettings   ; [0,1]
  ;(9)  Scroll_DataArray.9  ; Alarm_Activated        ; [0,1]
  ;(10) Scroll_DataArray.10 ; Alarm_Activated_PosX   ; [#]
  ;(11) Scroll_DataArray.11 ; Alarm_Activated_PosY   ; [#]
  ; -------------------------------------------
  ; MUST BE THE LAST in the Array
  ;(12) Scroll_DataArray.12 Scroll_Entry             ; [String]
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	;
	; -------------------------------------------
	;Scroll_DataArray := [Scroll_PosX, Scroll_PosY, Scroll_State, Scroll_AlarmOnOff, Scroll_AlarmTime, Scroll_AlarmSoundOnOff, Scroll_WasMoved, Scroll_AlarmSettings, Alarm_Activated, Alarm_Activated_PosX, Alarm_Activated_PosY, Scroll_Entry]
	; -------------------------------------------
	Scroll_PosX            := Scroll_DataArray.1
	Scroll_PosY            := Scroll_DataArray.2
	Scroll_State           := Scroll_DataArray.3
	Scroll_AlarmOnOff      := Scroll_DataArray.4
	Scroll_AlarmTime       := Scroll_DataArray.5
	Scroll_AlarmSoundOnOff := Scroll_DataArray.6
	Scroll_WasMoved        := Scroll_DataArray.7
	Scroll_AlarmSettings   := Scroll_DataArray.8
	Alarm_Activated        := Scroll_DataArray.9
	Alarm_Activated_PosX   := Scroll_DataArray.10
	Alarm_Activated_PosY   := Scroll_DataArray.11
	; -------------------------------------------
	GuiControlGet, Scroll_Entry,  , G_ScrollEdit,   Value ; 12
	Array_ScrollEntry := StrSplit(Scroll_Entry, "`n", "`n")
	; -------------------------------------------
	;
	; -------------------------------------------
	SplitPath, A_ScriptFullPath, , , , ThisScrollNote
	TextFile_ThisScrollNote := A_ScriptDir "\" ThisScrollNote ".txt"
	; -------------------------------------------
	if FileExist(TextFile_ThisScrollNote)
	{
    FileDelete, %TextFile_ThisScrollNote%
	}
	; -------------------------------------------
	BreakTime := A_TickCount + 1000
	while FileExist(TextFile_ThisScrollNote) ; Wait until File is Deleted
	{
		if (A_TickCount > BreakTime)
		{
			break
		}
	}
	; -------------------------------------------
	;
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  ;(1)  Scroll_DataArray.1  ; Scroll_PosX            ; [#]
  ;(2)  Scroll_DataArray.2  ; Scroll_PosY            ; [#]
  ;(3)  Scroll_DataArray.3  ; Scroll_State           ; ["Closed","Open"]
  ;(4)  Scroll_DataArray.4  ; Scroll_AlarmOnOff      ; [0,1]
  ;(5)  Scroll_DataArray.5  ; Scroll_AlarmTime       ; [YYYYMMDDhhmm]
  ;(6)  Scroll_DataArray.6  ; Scroll_AlarmSoundOnOff ; [0,1]
  ;(7)  Scroll_DataArray.7  ; Scroll_WasMoved        ; [0,1]
  ;(8)  Scroll_DataArray.8  ; Scroll_AlarmSettings   ; [0,1]
  ;(9)  Scroll_DataArray.9  ; Alarm_Activated        ; [0,1]
  ;(10) Scroll_DataArray.10 ; Alarm_Activated_PosX   ; [#]
  ;(11) Scroll_DataArray.11 ; Alarm_Activated_PosY   ; [#]
  ; -------------------------------------------
  ; MUST BE THE LAST in the Array
  ;(12) Scroll_DataArray.12 Scroll_Entry             ; [String]
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	;
	; -------------------------------------------
	FileAppend, %Scroll_PosX%`n, %TextFile_ThisScrollNote%, UTF-8            ;(1)  Scroll_PosX            [#]
	FileAppend, %Scroll_PosY%`n, %TextFile_ThisScrollNote%, UTF-8            ;(2)  Scroll_PosY            [#]
	FileAppend, %Scroll_State%`n, %TextFile_ThisScrollNote%, UTF-8           ;(3)  Scroll_State           ["Closed","Open"]
	FileAppend, %Scroll_AlarmOnOff%`n, %TextFile_ThisScrollNote%, UTF-8      ;(4)  Scroll_AlarmOnOff      [0,1]
	FileAppend, %Scroll_AlarmTime%`n, %TextFile_ThisScrollNote%, UTF-8       ;(5)  Scroll_AlarmTime       [YYYYMMDDhhmm]
	FileAppend, %Scroll_AlarmSoundOnOff%`n, %TextFile_ThisScrollNote%, UTF-8 ;(6)  Scroll_AlarmSoundOnOff [0,1]
	FileAppend, %Scroll_WasMoved%`n, %TextFile_ThisScrollNote%, UTF-8        ;(7)  Scroll_WasMoved        [0,1]
	FileAppend, %Scroll_AlarmSettings%`n, %TextFile_ThisScrollNote%, UTF-8   ;(8)  Scroll_AlarmSettings   [0,1]
	FileAppend, %Alarm_Activated%`n, %TextFile_ThisScrollNote%, UTF-8        ;(9)  Alarm_Activated        [0,1]
	FileAppend, %Alarm_Activated_PosX%`n, %TextFile_ThisScrollNote%, UTF-8   ;(10) Alarm_Activated_PosX   [#]
	FileAppend, %Alarm_Activated_PosY%`n, %TextFile_ThisScrollNote%, UTF-8   ;(11) Alarm_Activated_PosY   [#]
	; -------------------------------------------
	for Index, ThisEntry in Array_ScrollEntry
	{
		FileAppend, %ThisEntry%`n, %TextFile_ThisScrollNote% ; Scroll_Entry [Edit Text Entry]
	}
	; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
F_CheckTime(ShowHide) ; > AlarmTime
{
	; -------------------------------------------
	if (ShowHide == "R") ; Reset
	{	
		; -------------------------------------------
		GuiControl, ScrollGUIOfNote:Hide, G_Edit_Minute
		GuiControl, ScrollGUIOfNote:Hide, G_Edit_Hour
		GuiControl, ScrollGUIOfNote:Hide, G_Edit_Day
		GuiControl, ScrollGUIOfNote:Hide, G_Edit_Month
		GuiControl, ScrollGUIOfNote:Hide, G_Text_Year
		; -------------------------------------------
		GuiControl, ScrollGUIOfNote:Hide, G_IMG_Min
		GuiControl, ScrollGUIOfNote:Hide, G_IMG_Hour
		GuiControl, ScrollGUIOfNote:Hide, G_IMG_Day
		GuiControl, ScrollGUIOfNote:Hide, G_IMG_Month
		; -------------------------------------------
		GuiControl, ScrollGUIOfNote:Hide, G_Alarm_Accept
		; -------------------------------------------
		GuiControl, ScrollGUIOfNote:Hide, G_Alarm_Sound
		; -------------------------------------------
		GuiControl, ScrollGUIOfNote:Hide, G_Alarm_Cancel
		; -------------------------------------------
		GuiControl, ScrollGUIOfNote:Hide, G_Alarm_BG
		; -------------------------------------------
    GuiControl, ScrollGUIOfNote:Hide, G_AlarmTime
    ; -------------------------------------------
		;
		; -------------------------------------------
	  FormatTime, TimeRightNow , , yyyyMMddHHmm
	  Current_Year   := SubStr(TimeRightNow, 1, 4)
	  Current_Month  := SubStr(TimeRightNow, 5, 2)
	  Current_Day    := SubStr(TimeRightNow, 7, 2)
	  Current_Hour   := SubStr(TimeRightNow, 9, 2)
	  Current_Minute := SubStr(TimeRightNow, 11, 2)
	  ; -------------------------------------------
	  GuiControl, ScrollGUIOfNote:, G_Text_Year, %Current_Year%
	  GuiControl, ScrollGUIOfNote:, G_Edit_Month, %Current_Month%
	  GuiControl, ScrollGUIOfNote:, G_Edit_Day, %Current_Day%
	  GuiControl, ScrollGUIOfNote:, G_Edit_Hour, %Current_Hour%
	  GuiControl, ScrollGUIOfNote:, G_Edit_Minute, %Current_Minute%
	  ; -------------------------------------------
    ; -------------------------------------------
	  GuiControl, ScrollGUIOfNote:, G_Alarm_Sound, %A_ProgramFiles%\PopUpMenu_PUM\menu\cpl\com\scrollnote\support\AlarmSound_Off.png
	  ; -------------------------------------------
	  GuiControl, ScrollGUIOfNote:, G_AlarmSet, %A_ProgramFiles%\PopUpMenu_PUM\menu\cpl\com\scrollnote\support\Alarm_Off.png
	  ; -------------------------------------------
		;
		; -------------------------------------------
		GuiControl, ScrollGUIOfNote:Show, G_AlarmSet
		; -------------------------------------------
		GuiControl, ScrollGUIOfNote:Show, G_ScrollEdit
		; -------------------------------------------
	}
	else ; Not (ShowHide != "R") ; Reset
	{
	  ; -------------------------------------------
	  TimeChanged := 0
	  ; -------------------------------------------
	  ;
    ; -------------------------------------------
	  FormatTime, TimeRightNow , , yyyyMMddHHmm
	  Current_Year := SubStr(TimeRightNow, 1, 4)
	  Current_Month := SubStr(TimeRightNow, 5, 2)
	  Current_Day := SubStr(TimeRightNow, 7, 2)
	  Current_Hour := SubStr(TimeRightNow, 9, 2)
	  Current_Minute := SubStr(TimeRightNow, 11, 2)
	  ; -------------------------------------------
	  ;
    ; -------------------------------------------
	  if (ShowHide == "H")
	  {
  		; -------------------------------------------
		  GuiControl, ScrollGUIOfNote:Hide, G_Edit_Minute
		  GuiControl, ScrollGUIOfNote:Hide, G_Edit_Hour
		  GuiControl, ScrollGUIOfNote:Hide, G_Edit_Day
		  GuiControl, ScrollGUIOfNote:Hide, G_Edit_Month
		  GuiControl, ScrollGUIOfNote:Hide, G_Text_Year
		  ; -------------------------------------------
		  GuiControl, ScrollGUIOfNote:Hide, G_IMG_Min
		  GuiControl, ScrollGUIOfNote:Hide, G_IMG_Hour
	    GuiControl, ScrollGUIOfNote:Hide, G_IMG_Day
	    GuiControl, ScrollGUIOfNote:Hide, G_IMG_Month
	    ; -------------------------------------------
	    GuiControl, ScrollGUIOfNote:Hide, G_Alarm_Accept
	    ; -------------------------------------------
	    GuiControl, ScrollGUIOfNote:Hide, G_Alarm_Sound
	    ; -------------------------------------------
	    GuiControl, ScrollGUIOfNote:Hide, G_Alarm_Cancel
	    ; -------------------------------------------
	    GuiControl, ScrollGUIOfNote:Hide, G_Alarm_BG
	    ; -------------------------------------------
		  ;
	    ; -------------------------------------------
		  GuiControl, ScrollGUIOfNote:Show, G_ScrollEdit
		  ; -------------------------------------------
	  } ; if (ShowHide == "H")
	  ; -------------------------------------------
	  ;
	  ; -------------------------------------------
	  GuiControlGet, Alarm_Minute,, G_Edit_Minute, Value
	  GuiControlGet, Alarm_Hour,  , G_Edit_Hour,   Value
	  GuiControlGet, Alarm_Day,   , G_Edit_Day,    Value
	  GuiControlGet, Alarm_Month, , G_Edit_Month,  Value
	  GuiControlGet, Alarm_Year,  , G_Text_Year,   Value
	  ; ------------------------------------------
	  ;
	  ; -------------------------------------------
	  if (Current_Year == 2024 or Current_Year == 2028 or Current_Year == 2032 or Current_Year == 2036 or Current_Year == 2040 or Current_Year == 2044 or Current_Year == 2048 or Current_Year == 2052)
	  {
  		ArrayMonth := [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
  	}
  	else
  	{
		  ArrayMonth := [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
	  }
	  ; -------------------------------------------
	  MonthMaxDays := % ArrayMonth[Alarm_Month]
	  ; -------------------------------------------
	  ;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	  ; (Check) (Entered Time) Equal to or Less than (Current Time)
	  ; If True Add one Year
	  ; -------------------------------------------
	  if (Alarm_Year == Current_Year)
	  {
  		; -------------------------------------------
		  if (Alarm_Month == Current_Month)
		  {
  			; -------------------------------------------
			  if (Alarm_Day == Current_Day)
		    {
  				; -------------------------------------------
				  if (Alarm_Hour == Current_Hour)
		      {
  					; -------------------------------------------
					  if (Alarm_Minute <= Current_Minute)
					  {
      			  ; -------------------------------------------
			        TimeChanged := 1
			        ; -------------------------------------------
			        Alarm_Minute := Current_Minute + 1
			        ; -------------------------------------------
			        GuiControl, ScrollGUIOfNote:, G_Edit_Minute, %Alarm_Minute%
			        ; -------------------------------------------
					  } ; if (Alarm_Minute <= Current_Minute)
					  ; -------------------------------------------
				  } ; if (Alarm_Hour == Current_Hour)
				  ; -------------------------------------------
				  else if (Alarm_Hour < Current_Hour)
				  {
  			    ; -------------------------------------------
			      TimeChanged := 1
			      ; -------------------------------------------
			      Alarm_Year := Current_Year + 1
			      ; -------------------------------------------
			      GuiControl, ScrollGUIOfNote:, G_Text_Year, %Alarm_Year%
			      ; -------------------------------------------
				  } ; else if (Alarm_Hour < Current_Hour)
				  ; -------------------------------------------
			  } ; if (Alarm_Day == Current_Day)
			  else if (Alarm_Day < Current_Day)
			  {
  			  ; -------------------------------------------
			    TimeChanged := 1
			    ; -------------------------------------------
			    Alarm_Year := Current_Year + 1
			    ; -------------------------------------------
			    GuiControl, ScrollGUIOfNote:, G_Text_Year, %Alarm_Year%
			    ; -------------------------------------------
			  } ; else if (Alarm_Day < Current_Day)
			  ; -------------------------------------------
		  } ; if (Alarm_Month == Current_Month)
		  ; -------------------------------------------
		  else if (Alarm_Month < Current_Month)
		  {
  			; -------------------------------------------
			  TimeChanged := 1
			  ; -------------------------------------------
			  Alarm_Year := Current_Year + 1
			  ; -------------------------------------------
			  GuiControl, ScrollGUIOfNote:, G_Text_Year, %Alarm_Year%
			  ; -------------------------------------------
		  } ; else if (Alarm_Month < Current_Month)
		  ; -------------------------------------------
	  } ; if (Alarm_Year == Current_Year)
	  ; -------------------------------------------
	  ; (Check) (Entered Time) Equal to or Less than (Current Time)
	  ; If True Add one Year
	  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	  ;
	  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	  ; -------------------------------------------
	  if (TimeChanged == 0) ; (Entered Time + 1 Minute) Was NOT Less tham (Current Time)
	  {
  		if (Alarm_Minute > 59)
		  {
  			; -------------------------------------------
			  Alarm_Minute := 0
			  ; -------------------------------------------
			  if (Alarm_Hour > 23)
			  {
  				; -------------------------------------------
				  Alarm_Hour := 1
				  ; -------------------------------------------
				  if (Alarm_Day == MonthMaxDays)
				  {
  					; -------------------------------------------
				    Alarm_Day := 1
				    ; -------------------------------------------
					  if (Alarm_Month = 12)
					  {
  						; -------------------------------------------
						  TimeChanged := 1
    			    ; -------------------------------------------
			        Alarm_Month := 1
			        Alarm_Year := Current_Year + 1
						  ; -------------------------------------------
						  GuiControl, ScrollGUIOfNote:, G_Edit_Minute, %Alarm_Minute%
						  GuiControl, ScrollGUIOfNote:, G_Edit_Hour,   %Alarm_Hour%
						  GuiControl, ScrollGUIOfNote:, G_Edit_Day,    %Alarm_Day%
						  GuiControl, ScrollGUIOfNote:, G_Edit_Month,  %Alarm_Month%
						  GuiControl, ScrollGUIOfNote:, G_Text_Year,   %Alarm_Year%
    			    ; -------------------------------------------
					  } ; if (Alarm_Month == 12)
					  ; -------------------------------------------
				  } ; if (Alarm_Day == MonthMaxDays)
				  ; -------------------------------------------
			  } ; if (Alarm_Hour > 23)
			  ; -------------------------------------------
		  } ; if (Alarm_Minute > 59)
		  ; -------------------------------------------
		  else if (Alarm_Hour > 23)
		  {
  			; -------------------------------------------
			  Alarm_Hour := 1
			  ; -------------------------------------------
			  if (Alarm_Day == MonthMaxDays)
			  {
  				; -------------------------------------------
				  Alarm_Day := 1
				  ; -------------------------------------------
				  if (Alarm_Month = 12)
				  {
  					; -------------------------------------------
					  TimeChanged := 1
					  ; -------------------------------------------
					  Alarm_Month := 1
					  Alarm_Year := Current_Year + 1
					  ; -------------------------------------------
					  GuiControl, ScrollGUIOfNote:, G_Edit_Minute, %Alarm_Minute%
					  GuiControl, ScrollGUIOfNote:, G_Edit_Hour,   %Alarm_Hour%
					  GuiControl, ScrollGUIOfNote:, G_Edit_Day,    %Alarm_Day%
					  GuiControl, ScrollGUIOfNote:, G_Edit_Month,  %Alarm_Month%
					  GuiControl, ScrollGUIOfNote:, G_Text_Year,   %Alarm_Year%
					  ; -------------------------------------------
				  } ; if (Alarm_Month == 12)
				  ; -------------------------------------------
			  } ; if (Alarm_Day == MonthMaxDays)
			  ; -------------------------------------------
		  } ; if (Alarm_Hour > 23)
		  ; -------------------------------------------
		  else if (Alarm_Day == MonthMaxDays)
		  {
  			; -------------------------------------------
			  Alarm_Day := 1
			  ; -------------------------------------------
			  if (Alarm_Month = 12)
			  {
  				; -------------------------------------------
				  TimeChanged := 1
				  ; -------------------------------------------
				  Alarm_Month := 1
				  Alarm_Year := Current_Year + 1
				  ; -------------------------------------------
				  GuiControl, ScrollGUIOfNote:, G_Edit_Minute, %Alarm_Minute%
				  GuiControl, ScrollGUIOfNote:, G_Edit_Hour,   %Alarm_Hour%
				  GuiControl, ScrollGUIOfNote:, G_Edit_Day,    %Alarm_Day%
				  GuiControl, ScrollGUIOfNote:, G_Edit_Month,  %Alarm_Month%
				  GuiControl, ScrollGUIOfNote:, G_Text_Year,   %Alarm_Year%
				  ; -------------------------------------------
			  } ; if (Alarm_Month == 12)
			  ; -------------------------------------------
		  } ; if (Alarm_Day == MonthMaxDays)
		  ; -------------------------------------------
		  else if (Alarm_Month > 12)
		  {
  			; -------------------------------------------
			  TimeChanged := 1
			  ; -------------------------------------------
			  Alarm_Month := 1
			  Alarm_Year := Current_Year + 1
			  ; -------------------------------------------
			  GuiControl, ScrollGUIOfNote:, G_Edit_Minute, %Alarm_Minute%
			  GuiControl, ScrollGUIOfNote:, G_Edit_Hour,   %Alarm_Hour%
			  GuiControl, ScrollGUIOfNote:, G_Edit_Day,    %Alarm_Day%
			  GuiControl, ScrollGUIOfNote:, G_Edit_Month,  %Alarm_Month%
			  GuiControl, ScrollGUIOfNote:, G_Text_Year,   %Alarm_Year%
			  ; -------------------------------------------
		  } ; if (Alarm_Month == 12)
		  ; -------------------------------------------
	  } ; if (TimeChanged == 0) ; (Entered Time + 1 Minute) Was NOT Less tham (Current Time)
	  ; -------------------------------------------
	  ;
	  ; -------------------------------------------
	  if (ShowHide == "S")
	  {
  		; -------------------------------------------
		  GuiControl, ScrollGUIOfNote:Hide, G_ScrollEdit
		  ; -------------------------------------------
		  ;
		  ; -------------------------------------------
		  GuiControl, ScrollGUIOfNote:Show, G_Edit_Minute
		  GuiControl, ScrollGUIOfNote:Show, G_Edit_Hour
		  GuiControl, ScrollGUIOfNote:Show, G_Edit_Day
		  GuiControl, ScrollGUIOfNote:Show, G_Edit_Month
		  GuiControl, ScrollGUIOfNote:Show, G_Text_Year
		  ; -------------------------------------------
		  GuiControl, ScrollGUIOfNote:Show, G_IMG_Min
		  GuiControl, ScrollGUIOfNote:Show, G_IMG_Hour
	    GuiControl, ScrollGUIOfNote:Show, G_IMG_Day
	    GuiControl, ScrollGUIOfNote:Show, G_IMG_Month
	    ; -------------------------------------------
	    GuiControl, ScrollGUIOfNote:Show, G_Alarm_Accept
	    ; -------------------------------------------
	    GuiControl, ScrollGUIOfNote:Show, G_Alarm_Sound
	    ; -------------------------------------------
	    GuiControl, ScrollGUIOfNote:Show, G_Alarm_Cancel
	    ; -------------------------------------------
	    GuiControl, ScrollGUIOfNote:Show, G_Alarm_BG
	    ; -------------------------------------------
	  } ; if (ShowHide == "S")
	  ; -------------------------------------------
	  ;
    ; -------------------------------------------
    if (StrLen(Alarm_Month) == 1)
    {
    	Alarm_Month := "0" Alarm_Month
    }
    if (StrLen(Alarm_Day) == 1)
    {
  	  Alarm_Day := "0" Alarm_Day
    }
    if (StrLen(Alarm_Hour) == 1)
    {
    	Alarm_Hour := "0" Alarm_Hour
    }
    if (StrLen(Alarm_Month) == 1)
    {
  	  Alarm_Minute := "0" Alarm_Minute
    }
    ; -------------------------------------------
		if (StrLen(Alarm_Minute) == 1)
		{
			Alarm_Minute := "0" Alarm_Minute
		}
		if (StrLen(Alarm_Hour) == 1)
		{
			Alarm_Hour := "0" Alarm_Hour
		}
		if (StrLen(Alarm_Day) == 1)
		{
			Alarm_Day := "0" Alarm_Day
		}
		if (StrLen(Alarm_Month) == 1)
		{
			Alarm_Month := "0" Alarm_Month
		}
		; -------------------------------------------
    AlarmTime := Alarm_Year Alarm_Month Alarm_Day Alarm_Hour Alarm_Minute
    ; -------------------------------------------
	  return AlarmTime
	  ; -------------------------------------------
	} ; else ; Not (ShowHide == "R") ; Reset
	; -------------------------------------------
} ; F_CheckTime()
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
F_TimeDiff(EndTime)
{
	; -------------------------------------------
	TimeLeft := ""
	; -------------------------------------------
	FormatTime, StartTime, , yyyyMMddHHmm
	; -------------------------------------------
	S_Year   := SubStr(StartTime, 1, 4)
	S_Month  := SubStr(StartTime, 5, 2)
	S_Day    := SubStr(StartTime, 7, 2)
	S_Hour   := SubStr(StartTime, 9, 2)
	S_Minute := SubStr(StartTime, 11, 2)
	; -------------------------------------------
	E_Year   := SubStr(EndTime, 1, 4)
	E_Month  := SubStr(EndTime, 5, 2)
	E_Day    := SubStr(EndTime, 7, 2)
	E_Hour   := SubStr(EndTime, 9, 2)
	E_Minute := SubStr(EndTime, 11, 2)
	; -------------------------------------------
	;
	; -------------------------------------------
	if (S_Year == 2024 or S_Year == 2028 or S_Year == 2032 or S_Year == 2036 or S_Year == 2040 or S_Year == 2044 or S_Year == 2048 or S_Year == 2052)
	{
		S_ArrayMonth := [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
	}
	else
	{
		S_ArrayMonth := [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
	}
	; -------------------------------------------
	if (E_Year == 2024 or E_Year == 2028 or E_Year == 2032 or E_Year == 2036 or E_Year == 2040 or E_Year == 2044 or E_Year == 2048 or E_Year == 2052)
	{
		E_ArrayMonth := [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
	}
	else
	{
		E_ArrayMonth := [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
	}
	; -------------------------------------------
	;
	; -------------------------------------------
	T_Day := 0 ; [SET] (T_Day)
	T_Hour := 0 ; [SET] (T_Hour)
	T_Minute := 0 ; [SET] (T_Minute)
	; -------------------------------------------
	;
	if (E_Year > S_Year) ; Next Year
	{
	  ; -------------------------------------------
	  if (E_Month > S_Month) ; Same Year
	  {
  		; -------------------------------------------
		  TempMonth := S_Month
		  ; -------------------------------------------
		  ;
		  ; -------------------------------------------
		  MaxDays   := % S_ArrayMonth[TempMonth]
		  T_Day := MaxDays - S_Day ; Days Left in Current Month
		  ; -------------------------------------------
		  while ((TempMonth + 1) < E_Month)
		  {
  			; -------------------------------------------
			  TempMonth := TempMonth + 1
			  MaxDays   := % S_ArrayMonth[TempMonth]
			  T_Day := T_Day + MaxDays
			  ; -------------------------------------------
		  } ; while ((TempMonth + 1) < E_Month)
		  ; -------------------------------------------
		  T_Day := T_Day + E_Day
		  ; -------------------------------------------
		  ;
		  ; -------------------------------------------
		  if (E_Hour == S_Hour)
		  {
  			if (E_Minute < S_Minute)
			  {
  				T_Day := T_Day - 1
				  T_Hour := (23 - S_Hour) + E_Hour  ; Hours Left in the Day
				  T_Hour := T_Hour - 1
			  }
		  }
		  else if (E_Hour > S_Hour)
		  {
  		  ; -------------------------------------------
		    T_Hour := E_Hour - S_Hour
		    ; -------------------------------------------
		    if (E_Minute < S_Minute)
		    {
    			T_Hour := T_Hour - 1
		    }
		    ; -------------------------------------------
		  }
		  else if (E_Hour < S_Hour) ; Hour of the Next Day
	    {
    		; -------------------------------------------
		    T_Hour := (23 - S_Hour) + E_Hour  ; Hours Left in the Day
			  ; -------------------------------------------
		    if (T_Day > 0)
		    {
    			T_Day := T_Day - 1
		    }
		    ; -------------------------------------------
	    }
	    ; -------------------------------------------
	  } ; if (E_Month > S_Month) ; Same Year
	  else if (E_Month <= S_Month) ; Next Year
	  {
  		; -------------------------------------------
		  TempMonth := S_Month
		  ; -------------------------------------------
		  MaxDays   := % S_ArrayMonth[TempMonth]
		  T_Day := MaxDays - S_Day ; Days Left in Current Month
		  ; -------------------------------------------
		  while ((TempMonth + 1) != 12) ; Months Left in Current Year
		  {
  			; -------------------------------------------
			  TempMonth := TempMonth + 1
			  MaxDays   := % S_ArrayMonth[TempMonth]
			  T_Day := T_Day + MaxDays
			  ; -------------------------------------------
		  } ; while ((TempMonth + 1) != 12) ; Months Left in Current Year
		  ; -------------------------------------------
		  ;
		  ; -------------------------------------------
		  TempMonth := 0
		  ; -------------------------------------------
		  while ((TempMonth + 1) <= E_Month)
		  {
  			; -------------------------------------------
			  TempMonth := TempMonth + 1
			  MaxDays   := % E_ArrayMonth[TempMonth]
			  T_Day := T_Day + MaxDays
			  ; -------------------------------------------
		  } ; while ((TempMonth + 1) < E_Month)
		  ; -------------------------------------------
		  T_Day := T_Day + E_Day
		  ; -------------------------------------------
		  ;
		  ; -------------------------------------------
		  if (E_Hour == S_Hour)
		  {
  			if (E_Minute < S_Minute)
			  {
  				T_Day := T_Day - 1
				  T_Hour := (23 - S_Hour) + E_Hour  ; Hours Left in the Day
				  T_Hour := T_Hour - 1
			  }
		  }
		  else if (E_Hour > S_Hour)
		  {
  		  ; -------------------------------------------
		    T_Hour := E_Hour - S_Hour
		    ; -------------------------------------------
		    if (E_Minute < S_Minute)
		    {
    			T_Hour := T_Hour - 1
		    }
		    ; -------------------------------------------
		  }
		  else if (E_Hour < S_Hour) ; Hour of the Next Day
	    {
    		; -------------------------------------------
		    T_Hour := (23 - S_Hour) + E_Hour  ; Hours Left in the Day
			  ; -------------------------------------------
		    if (T_Day > 0)
		    {
    			T_Day := T_Day - 1
		    }
		    ; -------------------------------------------
	    }
	    ; -------------------------------------------
	  } ; else if (E_Month < S_Month) ; Next Year
	  ; -------------------------------------------
  } ; if (E_Year > S_Year) ; Next Year
	; -------------------------------------------
	else if (E_Month > S_Month) ; Same Year
	{
		; -------------------------------------------
		TempMonth := S_Month
		; -------------------------------------------
		;
		; -------------------------------------------
		MaxDays   := % S_ArrayMonth[TempMonth]
		T_Day := MaxDays - S_Day ; Days Left in Current Month
		; -------------------------------------------
		while ((TempMonth + 1) < E_Month)
		{
			; -------------------------------------------
			TempMonth := TempMonth + 1
			MaxDays   := % S_ArrayMonth[TempMonth]
			T_Day := T_Day + MaxDays
			; -------------------------------------------
		} ; while ((TempMonth + 1) < E_Month)
		; -------------------------------------------
		T_Day := T_Day + E_Day
		; -------------------------------------------
		;
		; -------------------------------------------
		if (E_Hour == S_Hour)
		{
			if (E_Minute < S_Minute)
			{
				T_Day := T_Day - 1
				T_Hour := (23 - S_Hour) + E_Hour  ; Hours Left in the Day
				T_Hour := T_Hour - 1
			}
		}
		else if (E_Hour > S_Hour)
		{
		  ; -------------------------------------------
		  T_Hour := E_Hour - S_Hour
		  ; -------------------------------------------
		  if (E_Minute < S_Minute)
		  {
  			T_Hour := T_Hour - 1
		  }
		  ; -------------------------------------------
		}
		else if (E_Hour < S_Hour) ; Hour of the Next Day
	  {
  		; -------------------------------------------
		  T_Hour := (23 - S_Hour) + E_Hour  ; Hours Left in the Day
			; -------------------------------------------
		  if (T_Day > 0)
		  {
  			T_Day := T_Day - 1
		  }
		  ; -------------------------------------------
	  }
	  ; -------------------------------------------
	} ; if (E_Month > S_Month) ; Same Year
	else if (E_Month < S_Month) ; Next Year
	{
		; -------------------------------------------
		TempMonth := S_Month
		; -------------------------------------------
		MaxDays   := % S_ArrayMonth[TempMonth]
		T_Day := MaxDays - S_Day ; Days Left in Current Month
		; -------------------------------------------
		while ((TempMonth + 1) != 12) ; Months Left in Current Year
		{
			; -------------------------------------------
			TempMonth := TempMonth + 1
			MaxDays   := % S_ArrayMonth[TempMonth]
			T_Day := T_Day + MaxDays
			; -------------------------------------------
		} ; while ((TempMonth + 1) != 12) ; Months Left in Current Year
		; -------------------------------------------
		;
		; -------------------------------------------
		TempMonth := 0
		; -------------------------------------------
		while ((TempMonth + 1) <= E_Month)
		{
			; -------------------------------------------
			TempMonth := TempMonth + 1
			MaxDays   := % E_ArrayMonth[TempMonth]
			T_Day := T_Day + MaxDays
			; -------------------------------------------
		} ; while ((TempMonth + 1) < E_Month)
		; -------------------------------------------
		T_Day := T_Day + E_Day
		; -------------------------------------------
		;
		; -------------------------------------------
		if (E_Hour == S_Hour)
		{
			if (E_Minute < S_Minute)
			{
				T_Day := T_Day - 1
				T_Hour := (23 - S_Hour) + E_Hour  ; Hours Left in the Day
				T_Hour := T_Hour - 1
			}
		}
		else if (E_Hour > S_Hour)
		{
		  ; -------------------------------------------
		  T_Hour := E_Hour - S_Hour
		  ; -------------------------------------------
		  if (E_Minute < S_Minute)
		  {
  			T_Hour := T_Hour - 1
		  }
		  ; -------------------------------------------
		}
		else if (E_Hour < S_Hour) ; Hour of the Next Day
	  {
  		; -------------------------------------------
		  T_Hour := (23 - S_Hour) + E_Hour  ; Hours Left in the Day
			; -------------------------------------------
		  if (T_Day > 0)
		  {
  			T_Day := T_Day - 1
		  }
		  ; -------------------------------------------
	  }
	  ; -------------------------------------------
	} ; else if (E_Month < S_Month) ; Next Year
	else if (E_Day > S_Day)
	{
		; -------------------------------------------
		T_Day := E_Day - S_Day
		; -------------------------------------------
		if (E_Hour == S_Hour)
		{
			if (E_Minute < S_Minute)
			{
				T_Day := T_Day - 1
				T_Hour := (23 - S_Hour) + E_Hour  ; Hours Left in the Day
				T_Hour := T_Hour - 1
			}
		}
		else if (E_Hour > S_Hour)
		{
		  ; -------------------------------------------
		  T_Hour := E_Hour - S_Hour
		  ; -------------------------------------------
		  if (E_Minute < S_Minute)
		  {
  			T_Hour := T_Hour - 1
		  }
		  ; -------------------------------------------
		}
		else if (E_Hour < S_Hour) ; Hour of the Next Day
	  {
  		; -------------------------------------------
		  T_Hour := (23 - S_Hour) + E_Hour  ; Hours Left in the Day
		  if (T_Day > 0)
		  {
  			T_Day := T_Day - 1
		  }
		  ; -------------------------------------------
	  }
	  ; -------------------------------------------
	}
	else if (E_Hour > S_Hour) ; The E_Hour is Later in Current Day
	{
		; -------------------------------------------
		T_Hour := E_Hour - S_Hour
		; -------------------------------------------
		if (E_Minute < S_Minute)
		{
			T_Hour := T_Hour - 1
		}
		; -------------------------------------------
	} ; if (E_Hour > S_Hour) ; The Hour on Current Day
	else if (E_Hour < S_Hour) ; Hour of the Next Day
	{
		; -------------------------------------------
		T_Hour := (23 - S_Hour) + E_Hour  ; Hours Left in the Day
		if (T_Day > 0)
		{
			T_Day := T_Day - 1
		}
		; -------------------------------------------
	} ; else if (E_Hour < S_Hour) ; Hour of the Next Day
	; -------------------------------------------			
	;
	; -------------------------------------------
	if (E_Minute > S_Minute) ; The Minute in Current Hour
	{
		T_Minute := E_Minute - S_Minute
	} ; if (E_Minute > S_Minute)
	else if (E_Minute < S_Minute) ; Minute of the Next Hour
	{
		; -------------------------------------------
		TempMinute := 60 - S_Minute ; Minutes Left in the Hour
		T_Minute := TempMinute + E_Minute
		; -------------------------------------------
	} ; else if (E_Minute < S_Minute) ; Minute of the Next Day
	; -------------------------------------------
	;
	; -------------------------------------------
	if (T_Month < 0)
	{
		T_Month := 0
	}
	if (T_Day < 0)
	{
		T_Day := 0
	}
	if (T_Hour < 0)
	{
		T_Hour := 0
	}
	if (T_Minute < 0)
	{
		T_Minute := 0
	}
	; -------------------------------------------
	;
	; -------------------------------------------
	if (T_Day > 0)
	{
		; -------------------------------------------
		if (StrLen(T_Hour) == 1)
		{
			T_Hour := "0" T_Hour
		}
		; -------------------------------------------
		if (StrLen(T_Minute) == 1)
		{
			T_Minute := "0" T_Minute
		}
		; -------------------------------------------
		TimeLeft := T_Day ":" T_Hour ":" T_Minute
		; -------------------------------------------
	}
	else if (T_Hour > 0)
	{
		; -------------------------------------------
		if (StrLen(T_Hour) == 1)
		{
   		T_Hour := "0" T_Hour
		}
		; -------------------------------------------
		if (StrLen(T_Minute) == 1)
		{
			T_Minute := "0" T_Minute
		}
		; -------------------------------------------
		TimeLeft := T_Hour ":" T_Minute
		; -------------------------------------------
	}
	else if (T_Minute > 0)
	{
		; -------------------------------------------
		if (StrLen(T_Minute) == 1)
		{
			T_Minute := "0" T_Minute
		}
		; -------------------------------------------
		TimeLeft := T_Minute
		; -------------------------------------------
	}
	; -------------------------------------------
	;
	; -------------------------------------------
	return TimeLeft
	; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
F_ScrollUpDown(Scroll_DataArray) ; > Scroll_DataArray
{
	; -------------------------------------------
	if (Scroll_DataArray.9 == 1) ; Alarm_Activated
	{
		; -------------------------------------------
		Mov_X := Scroll_DataArray.10 ; Alarm_Activated_PosX
		Mov_Y := Scroll_DataArray.11 ; Alarm_Activated_PosY
		; -------------------------------------------
Gui, ScrollGUIOfNote:+LastFound -Caption -AlwaysOnTop +ToolWindow -Border
		Gui, ScrollGUIOfNote:Show, x%Mov_X% y%Mov_Y%, ScrollTitleOfNote
		; -------------------------------------------
		WinGet, ScrollNote_ID, ID, ScrollTitleOfNote
		WinSet, Bottom, , ahk_id ScrollTitleOfNote
		; -------------------------------------------
		Scroll_DataArray.9 := 0 ; Alarm_Activated
		; -------------------------------------------
	}
	; -------------------------------------------
	;
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  ;(1)  Scroll_DataArray.1  ; Scroll_PosX            ; [#]
  ;(2)  Scroll_DataArray.2  ; Scroll_PosY            ; [#]
  ;(3)  Scroll_DataArray.3  ; Scroll_State           ; ["Closed","Open"]
  ;(4)  Scroll_DataArray.4  ; Scroll_AlarmOnOff      ; [0,1]
  ;(5)  Scroll_DataArray.5  ; Scroll_AlarmTime       ; [YYYYMMDDhhmm]
  ;(6)  Scroll_DataArray.6  ; Scroll_AlarmSoundOnOff ; [0,1]
  ;(7)  Scroll_DataArray.7  ; Scroll_WasMoved        ; [0,1]
  ;(8)  Scroll_DataArray.8  ; Scroll_AlarmSettings   ; [0,1]
  ;(9)  Scroll_DataArray.9  ; Alarm_Activated        ; [0,1]
  ;(10) Scroll_DataArray.10 ; Alarm_Activated_PosX   ; [#]
  ;(11) Scroll_DataArray.11 ; Alarm_Activated_PosY   ; [#]
  ; -------------------------------------------
  ; MUST BE THE LAST in the Array
  ;(12) Scroll_DataArray.12 Scroll_Entry             ; [String]
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	;
	; -------------------------------------------
	Scroll_State := Scroll_DataArray.3
	; -------------------------------------------
	Gui, ScrollGUIOfNote:+LastFound -Caption -AlwaysOnTop +ToolWindow -Border
	; -------------------------------------------
	if (Scroll_State == "Open") ; Scroll is Open > Close the Scroll
	{
		; -------------------------------------------
		if (Scroll_DataArray.8 == 1) ; Scroll_AlarmSettings
		{
			; -------------------------------------------
			Scroll_DataArray.8 := 0
			F_CheckTime("H") ; > AlarmTime
			; -------------------------------------------
			if (Scroll_DataArray.4 == 1) ; Scroll_AlarmOnOff
			{
				; -------------------------------------------
				GuiControl, ScrollGUIOfNote:Show, G_AlarmTime
				; -------------------------------------------
			}
			; -------------------------------------------
		}
		; -------------------------------------------
		;
		; -------------------------------------------
		Scroll_State := "Closed"
		; -------------------------------------------
		GuiControl, ScrollGUIOfNote:Hide, G_ScrollEdit
		; -------------------------------------------
		GuiControl, ScrollGUIOfNote:Hide, G_Edit_Day
		GuiControl, ScrollGUIOfNote:Hide, G_IMG_Day
		;
		GuiControl, ScrollGUIOfNote:Hide, G_Edit_Month
		GuiControl, ScrollGUIOfNote:Hide, G_IMG_Month
		;
		GuiControl, ScrollGUIOfNote:Hide, G_Text_Year
		;
		GuiControl, ScrollGUIOfNote:Hide, G_Edit_Minute
		GuiControl, ScrollGUIOfNote:Hide, G_IMG_Min
		;
		GuiControl, ScrollGUIOfNote:Hide, G_Edit_Hour
		GuiControl, ScrollGUIOfNote:Hide, G_IMG_Hour
		;
		; -------------------------------------------
		GuiControl, ScrollGUIOfNote:Hide, G_Alarm_Accept
		GuiControl, ScrollGUIOfNote:Hide, G_Alarm_Sound
		GuiControl, ScrollGUIOfNote:Hide, G_Alarm_Cancel
		; -------------------------------------------	
		GuiControl, ScrollGUIOfNote:Hide, G_AlarmSet
		GuiControl, ScrollGUIOfNote:Hide, G_DeleteNote
		; -------------------------------------------
		GuiControl, ScrollGUIOfNote:Hide, G_Alarm_BG
		; -------------------------------------------
		;
		; -------------------------------------------
		Image_Num := 7
		This_H := 175
		This_Y := 175
		; -------------------------------------------
		Loop 6
		{
			; -------------------------------------------
			Image_Num := Image_Num - 1
			This_H := This_H - 25
			Scroll_Image := A_ProgramFiles "\PopUpMenu_PUM\menu\cpl\com\scrollnote\support\Scroll_" Image_Num ".png"
			Scroll_Image := A_ProgramFiles "\PopUpMenu_PUM\menu\cpl\com\scrollnote\support\Scroll_" Image_Num ".png"
			GuiControl, ScrollGUIOfNote:, G_ScrollRoll, %Scroll_Image%
			GuiControl, ScrollGUIOfNote:Move, G_ScrollRoll, h%This_H%
			; -------------------------------------------
			;
			; -------------------------------------------
			GuiControl, ScrollGUIOfNote:Hide, G_ScrollRoll
			GuiControl, ScrollGUIOfNote:Hide, G_EndBL
			GuiControl, ScrollGUIOfNote:Hide, G_EndBR
			; -------------------------------------------
			;
			; -------------------------------------------
			This_Y := This_Y - 25
			EndBL_Image := A_ProgramFiles "\PopUpMenu_PUM\menu\cpl\com\scrollnote\support\End_Left.png"
			GuiControl, ScrollGUIOfNote:, G_EndBL, %EndBL_Image%
			EndBR_Image := A_ProgramFiles "\PopUpMenu_PUM\menu\cpl\com\scrollnote\support\End_Right.png"
			GuiControl, ScrollGUIOfNote:, G_EndBR, %EndBR_Image%
			GuiControl, ScrollGUIOfNote:Move, G_EndBL, Y%This_Y%
			GuiControl, ScrollGUIOfNote:Move, G_EndBR, Y%This_Y%
			; -------------------------------------------
			;
			; -------------------------------------------
			GuiControl, ScrollGUIOfNote:Show, G_ScrollRoll
			GuiControl, ScrollGUIOfNote:Show, G_EndBL
			GuiControl, ScrollGUIOfNote:Show, G_EndBR
			; -------------------------------------------
			Sleep, 100
			; -------------------------------------------
		} ; Loop 6
		; -------------------------------------------
		GuiControl, ScrollGUIOfNote:Hide, G_ScrollRoll
		GuiControl, ScrollGUIOfNote:Hide, G_EndBL
		GuiControl, ScrollGUIOfNote:Hide, G_EndBR
		; -------------------------------------------
	} ; if (Scroll_State == "Closed")
	else if (Scroll_State == "Closed") ; Scroll is Closed > Open the Scroll
	{
		; -------------------------------------------
		Scroll_State := "Open"
		; -------------------------------------------
		Image_Num := 0
		This_H := 0
		This_Y := 0
		; -------------------------------------------
		Loop 6
		{
			; -------------------------------------------
			Image_Num := Image_Num + 1
			This_H := This_H + 25
			; -------------------------------------------
			;
			; -------------------------------------------
			Scroll_Image := A_ProgramFiles "\PopUpMenu_PUM\menu\cpl\com\scrollnote\support\Scroll_" Image_Num ".png"
			GuiControl, ScrollGUIOfNote:, G_ScrollRoll, %Scroll_Image%
			GuiControl, ScrollGUIOfNote:Move, G_ScrollRoll, y23 h%This_H%
			; -------------------------------------------
			;
			; -------------------------------------------
			GuiControl, ScrollGUIOfNote:Hide, G_ScrollRoll
			GuiControl, ScrollGUIOfNote:Hide, G_EndBL
			GuiControl, ScrollGUIOfNote:Hide, G_EndBR
			; -------------------------------------------
			;
			; -------------------------------------------
			This_Y := This_Y + 25
			; -------------------------------------------
			Mov_Y := This_Y - 1
			GuiControl, ScrollGUIOfNote:Move, G_EndBL, Y%Mov_Y%
			GuiControl, ScrollGUIOfNote:Move, G_EndBR, Y%Mov_Y%
			; -------------------------------------------
			;
			; -------------------------------------------
			GuiControl, ScrollGUIOfNote:Show, G_ScrollRoll
			GuiControl, ScrollGUIOfNote:Show, G_EndBL
			GuiControl, ScrollGUIOfNote:Show, G_EndBR
			; -------------------------------------------
			Sleep, 100
			; -------------------------------------------
		} ; Loop 6
		; -------------------------------------------
		;
		; -------------------------------------------
		GuiControl, ScrollGUIOfNote:Show, G_EndBL
	  GuiControl, ScrollGUIOfNote:Show, G_AlarmSet
		GuiControl, ScrollGUIOfNote:Show, G_DeleteNote
		GuiControl, ScrollGUIOfNote:Show, G_EndBR
		; -------------------------------------------
		;
		; -------------------------------------------
		GuiControl, ScrollGUIOfNote:Show, G_ScrollEdit
		GuiControl, ScrollGUIOfNote:Focus, G_ScrollEdit
		; -------------------------------------------
	} ; else if (Scroll_State == "Open")
	; -------------------------------------------
	Scroll_DataArray.3 := Scroll_State
	; -------------------------------------------
	return Scroll_DataArray
	; -------------------------------------------
} ; F_ScrollUpDown(
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
F_ScrollMove(Scroll_DataArray) ; > Scroll_DataArray
{
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  ;(1)  Scroll_DataArray.1  ; Scroll_PosX            ; [#]
  ;(2)  Scroll_DataArray.2  ; Scroll_PosY            ; [#]
  ;(3)  Scroll_DataArray.3  ; Scroll_State           ; ["Closed","Open"]
  ;(4)  Scroll_DataArray.4  ; Scroll_AlarmOnOff      ; [0,1]
  ;(5)  Scroll_DataArray.5  ; Scroll_AlarmTime       ; [YYYYMMDDhhmm]
  ;(6)  Scroll_DataArray.6  ; Scroll_AlarmSoundOnOff ; [0,1]
  ;(7)  Scroll_DataArray.7  ; Scroll_WasMoved        ; [0,1]
  ;(8)  Scroll_DataArray.8  ; Scroll_AlarmSettings   ; [0,1]
  ;(9)  Scroll_DataArray.9  ; Alarm_Activated        ; [0,1]
  ;(10) Scroll_DataArray.10 ; Alarm_Activated_PosX   ; [#]
  ;(11) Scroll_DataArray.11 ; Alarm_Activated_PosY   ; [#]
  ; -------------------------------------------
  ; MUST BE THE LAST in the Array
  ;(12) Scroll_DataArray.12 Scroll_Entry             ; [String]
  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	;
	; -------------------------------------------
	Scroll_WasMoved := 0
	; -------------------------------------------
	Scroll_PosX := Scroll_DataArray.1
	Scroll_PosY := Scroll_DataArray.2
	; -------------------------------------------
	SetTitleMatchMode, 2
	if WinExist("ScrollTitleOfNote" . "ahk_class AutoHotkeyGUI")
	{
		CoordMode, Mouse , Screen
		WinGetPos, Gui_X, Gui_Y ; Use the window found by WinExist.
	}
	; -------------------------------------------
	CoordMode, Mouse , Screen
	MouseGetPos, Cur_X, Cur_Y
	Cur_X := Round(Cur_X)
	Cur_Y := Round(Cur_Y)
	; -------------------------------------------
	Dif_X := Cur_X - Gui_X
	Dif_Y := Cur_Y - Gui_Y
	; -------------------------------------------
	while (GetKeyState("LButton", "P") == 1)
	{
		; -------------------------------------------
		CoordMode, Mouse , Screen
		MouseGetPos, This_X, This_Y
		This_X := Round(This_X)
		This_Y := Round(This_Y)
		; -------------------------------------------
		if (This_X != Cur_X or This_Y != Cur_Y)
		{
			; -------------------------------------------
			Cur_X := This_X
			Cur_Y := This_Y
			; -------------------------------------------
			Scroll_PosX := This_X - Dif_X
			Scroll_PosY := This_Y - Dif_Y
			; -------------------------------------------
			CoordMode, Mouse, Screen
			Gui, ScrollGUIOfNote:Show, x%Scroll_PosX% y%Scroll_PosY%, ScrollTitleOfNote
			Gui, ScrollGUIOfNote:+LastFound -Caption -AlwaysOnTop +ToolWindow -Border
			; -------------------------------------------
			Scroll_WasMoved := 1
			; -------------------------------------------
		}
	  ; -------------------------------------------
	} ; while	while (GetKeyState("LButton", "P") == 1)
  ; -------------------------------------------
	;
	; -------------------------------------------
	Scroll_DataArray.1 := Scroll_PosX
	Scroll_DataArray.2 := Scroll_PosY
	Scroll_DataArray.7 := Scroll_WasMoved
	; -------------------------------------------
	return Scroll_DataArray
	; -------------------------------------------
} ; F_ScrollMove(
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
if (Scroll_PosX == "")
{
	Scroll_PosX := Round((A_ScreenWidth / 2) - 101)
	Scroll_DataArray.1 := Scroll_PosX
}
if (Scroll_PosY == "")
{
	Scroll_PosY := Round((A_ScreenHeight / 2) - 125)
	Scroll_DataArray.1 := Scroll_PosX
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
GuiControl, ScrollGUIOfNote:, G_ScrollTop, %A_ProgramFiles%\PopUpMenu_PUM\menu\cpl\com\scrollnote\support\Scroll_0.png
GuiControl, ScrollGUIOfNote:, G_EndTL, %A_ProgramFiles%\PopUpMenu_PUM\menu\cpl\com\scrollnote\support\End_Left.png
GuiControl, ScrollGUIOfNote:, EndTR, %A_ProgramFiles%\PopUpMenu_PUM\menu\cpl\com\scrollnote\support\End_Right.png
GuiControl, ScrollGUIOfNote:, G_Alarm_BG, %A_ProgramFiles%\PopUpMenu_PUM\menu\cpl\com\scrollnote\support\Alarm_BG.png

GuiControl, ScrollGUIOfNote:, G_IMG_Day, %A_ProgramFiles%\PopUpMenu_PUM\menu\cpl\com\scrollnote\support\IMG_Day.png
GuiControl, ScrollGUIOfNote:, G_IMG_Month, %A_ProgramFiles%\PopUpMenu_PUM\menu\cpl\com\scrollnote\support\IMG_Month.png
GuiControl, ScrollGUIOfNote:, G_IMG_Hour, %A_ProgramFiles%\PopUpMenu_PUM\menu\cpl\com\scrollnote\support\IMG_Hour.png
GuiControl, ScrollGUIOfNote:, G_IMG_Min, %A_ProgramFiles%\PopUpMenu_PUM\menu\cpl\com\scrollnote\support\IMG_Min.png

GuiControl, ScrollGUIOfNote:, G_Alarm_Accept, %A_ProgramFiles%\PopUpMenu_PUM\menu\cpl\com\scrollnote\support\Alarm_Accept.png
GuiControl, ScrollGUIOfNote:, G_Alarm_Cancel, %A_ProgramFiles%\PopUpMenu_PUM\menu\cpl\com\scrollnote\support\Alarm_Cancel.png
GuiControl, ScrollGUIOfNote:, G_Alarm_Sound, %A_ProgramFiles%\PopUpMenu_PUM\menu\cpl\com\scrollnote\support\AlarmSound_Off.png
GuiControl, ScrollGUIOfNote:, G_AlarmSet, %A_ProgramFiles%\PopUpMenu_PUM\menu\cpl\com\scrollnote\support\Alarm_Off.png
GuiControl, ScrollGUIOfNote:, G_EndBL, %A_ProgramFiles%\PopUpMenu_PUM\menu\cpl\com\scrollnote\support\End_Left.png
GuiControl, ScrollGUIOfNote:, G_EndBR, %A_ProgramFiles%\PopUpMenu_PUM\menu\cpl\com\scrollnote\support\End_Right.png
GuiControl, ScrollGUIOfNote:, G_DeleteNote, %A_ProgramFiles%\PopUpMenu_PUM\menu\cpl\com\scrollnote\support\DeleteNote.png
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Gui, ScrollGUIOfNote:Font, s12, Arial
Gui, ScrollGUIOfNote:Add, Picture, x25  y0   w136 h25 vG_ScrollTop gL_ScrollRoll, 
; -------------------------------------------
Gui, ScrollGUIOfNote:Add, Picture, x25  y25   w136 h175 vG_ScrollRoll,
; -------------------------------------------
Gui, ScrollGUIOfNote:Add, Picture, x0   y0   w25 h25 vG_EndTL gL_EndTL,
Gui, ScrollGUIOfNote:Add, Picture, x161 y0   w25 h25 vEndTR gL_EndTR,
; -------------------------------------------
;
; -------------------------------------------
Gui, ScrollGUIOfNote:Font, s12, Arial
Gui, ScrollGUIOfNote:Add, Edit, x31 y25 w124 r6 vG_ScrollEdit gL_ScrollEdit -VScroll,
; -------------------------------------------
;
; -------------------------------------------
Gui, ScrollGUIOfNote:Add, Picture, x31 y25 w124 h121 vG_Alarm_BG,
; -------------------------------------------
;
; -------------------------------------------
Gui, ScrollGUIOfNote:Font, s12, Arial
Gui, ScrollGUIOfNote:Add, Edit,    x40  y30  w30 r1  limit2+ Number +Center vG_Edit_Day -VScroll,
Gui, ScrollGUIOfNote:Add, Picture, x49  y58  w12 h11 vG_IMG_Day,
; -------------------------------------------
;
; -------------------------------------------
Gui, ScrollGUIOfNote:Font, s12, Arial
Gui, ScrollGUIOfNote:Add, Edit,    x78  y30  w30 r1  limit2+ Number +Center vG_Edit_Month -VScroll,
Gui, ScrollGUIOfNote:Add, Picture, x87  y58  w12 h11 vG_IMG_Month,
; -------------------------------------------
;
; -------------------------------------------
Gui, ScrollGUIOfNote:Font, s12, Arial
Gui, ScrollGUIOfNote:Add, Text, x113 y34 w36 h18 vG_Text_Year,
; -------------------------------------------
;
; -------------------------------------------
Gui, ScrollGUIOfNote:Font, s12, Arial
Gui, ScrollGUIOfNote:Add, Edit,    x59  y72  w30 r1  limit2+ Number +Center vG_Edit_Hour -VScroll,
Gui, ScrollGUIOfNote:Add, Picture, x69  y99  w13 h13 vG_IMG_Hour,
; -------------------------------------------
;
; -------------------------------------------
Gui, ScrollGUIOfNote:Font, s12, Arial
Gui, ScrollGUIOfNote:Add, Edit,    x97  y72  w30 r1  limit2+ Number Center vG_Edit_Minute -VScroll,
Gui, ScrollGUIOfNote:Add, Picture, x106 y99  w13 h13 vG_IMG_Min,
; -------------------------------------------
;
; -------------------------------------------
Gui, ScrollGUIOfNote:Add, Picture, x32  y115 w30 h30 vG_Alarm_Accept gL_AlarmAccept,
Gui, ScrollGUIOfNote:Add, Picture, x77  y113 w32 h32 vG_Alarm_Sound gL_AlarmSound,
Gui, ScrollGUIOfNote:Add, Picture, x124 y115 w30 h30 vG_Alarm_Cancel gL_AlarmCancel,
; -------------------------------------------
;
; -------------------------------------------
Gui, ScrollGUIOfNote:Add, Picture, x0   y150 w25 h25 vG_EndBL gL_EndBL,
Gui, ScrollGUIOfNote:Add, Picture, x161 y150 w25 h25 vG_EndBR gL_EndBR,
; -------------------------------------------
Gui, ScrollGUIOfNote:Add, Picture, x25  y150  w68 h25 vG_AlarmSet      gL_AlarmSet,
Gui, ScrollGUIOfNote:Add, Picture, x93  y150  w68 h25 vG_DeleteNote gL_DeleteNote,
;
; -------------------------------------------
Gui ScrollGUIOfNote:Add, Text,     x42 y3 w97 h18 BackgroundTrans Center vG_AlarmTime,
; -------------------------------------------
Gui, ScrollGUIOfNote:+LastFound -Caption -AlwaysOnTop +ToolWindow -Border ; Gui Start (AlwaysOnTop)
; -------------------------------------------
Gui, ScrollGUIOfNote:Color, 2200CF
WinSet, TransColor, 2200CF
; -------------------------------------------
Gui, ScrollGUIOfNote:Show, x%Scroll_PosX% y%Scroll_PosY%, ScrollTitleOfNote
Gui, ScrollGUIOfNote:+LastFound -Caption -AlwaysOnTop +ToolWindow -Border ; Gui Start (AlwaysOnTop)
; -------------------------------------------
;
; -------------------------------------------
GuiControl, ScrollGUIOfNote:Hide, G_ScrollRoll
; -------------------------------------------
;
; -------------------------------------------
GuiControl, ScrollGUIOfNote:Hide, G_ScrollEdit
; -------------------------------------------
;
; -------------------------------------------
GuiControl, ScrollGUIOfNote:Hide, G_Edit_Day
GuiControl, ScrollGUIOfNote:Hide, G_IMG_Day
;
GuiControl, ScrollGUIOfNote:Hide, G_Edit_Month
GuiControl, ScrollGUIOfNote:Hide, G_IMG_Month
;
GuiControl, ScrollGUIOfNote:Hide, G_Text_Year
;
GuiControl, ScrollGUIOfNote:Hide, G_Edit_Minute
GuiControl, ScrollGUIOfNote:Hide, G_IMG_Min
;
GuiControl, ScrollGUIOfNote:Hide, G_Edit_Hour
GuiControl, ScrollGUIOfNote:Hide, G_IMG_Hour
;
; -------------------------------------------
GuiControl, ScrollGUIOfNote:Hide, G_Alarm_Accept
GuiControl, ScrollGUIOfNote:Hide, G_Alarm_Sound
GuiControl, ScrollGUIOfNote:Hide, G_Alarm_Cancel
; -------------------------------------------	
GuiControl, ScrollGUIOfNote:Hide, G_AlarmSet
GuiControl, ScrollGUIOfNote:Hide, G_DeleteNote
; -------------------------------------------
GuiControl, ScrollGUIOfNote:Hide, G_Alarm_BG
; -------------------------------------------
;
; -------------------------------------------
GuiControl, ScrollGUIOfNote:Hide, G_EndBL
GuiControl, ScrollGUIOfNote:Hide, G_EndBR
; -------------------------------------------
GuiControl, ScrollGUIOfNote:Hide, G_AlarmTime
; -------------------------------------------
GuiControl, ScrollGUIOfNote:, G_ScrollTop, %A_ProgramFiles%\PopUpMenu_PUM\menu\cpl\com\scrollnote\support\Scroll_0.png
GuiControl, ScrollGUIOfNote:, G_EndTL, %A_ProgramFiles%\PopUpMenu_PUM\menu\cpl\com\scrollnote\support\End_Left.png
GuiControl, ScrollGUIOfNote:, EndTR, %A_ProgramFiles%\PopUpMenu_PUM\menu\cpl\com\scrollnote\support\End_Right.png
GuiControl, ScrollGUIOfNote:, G_Alarm_BG, %A_ProgramFiles%\PopUpMenu_PUM\menu\cpl\com\scrollnote\support\Alarm_BG.png

GuiControl, ScrollGUIOfNote:, G_IMG_Day, %A_ProgramFiles%\PopUpMenu_PUM\menu\cpl\com\scrollnote\support\IMG_Day.png
GuiControl, ScrollGUIOfNote:, G_IMG_Month, %A_ProgramFiles%\PopUpMenu_PUM\menu\cpl\com\scrollnote\support\IMG_Month.png
GuiControl, ScrollGUIOfNote:, G_IMG_Hour, %A_ProgramFiles%\PopUpMenu_PUM\menu\cpl\com\scrollnote\support\IMG_Hour.png
GuiControl, ScrollGUIOfNote:, G_IMG_Min, %A_ProgramFiles%\PopUpMenu_PUM\menu\cpl\com\scrollnote\support\IMG_Min.png

GuiControl, ScrollGUIOfNote:, G_Alarm_Accept, %A_ProgramFiles%\PopUpMenu_PUM\menu\cpl\com\scrollnote\support\Alarm_Accept.png
GuiControl, ScrollGUIOfNote:, G_Alarm_Cancel, %A_ProgramFiles%\PopUpMenu_PUM\menu\cpl\com\scrollnote\support\Alarm_Cancel.png
GuiControl, ScrollGUIOfNote:, G_Alarm_Sound, %A_ProgramFiles%\PopUpMenu_PUM\menu\cpl\com\scrollnote\support\AlarmSound_Off.png
GuiControl, ScrollGUIOfNote:, G_AlarmSet, %A_ProgramFiles%\PopUpMenu_PUM\menu\cpl\com\scrollnote\support\Alarm_Off.png
GuiControl, ScrollGUIOfNote:, G_EndBL, %A_ProgramFiles%\PopUpMenu_PUM\menu\cpl\com\scrollnote\support\End_Left.png
GuiControl, ScrollGUIOfNote:, G_EndBR, %A_ProgramFiles%\PopUpMenu_PUM\menu\cpl\com\scrollnote\support\End_Right.png
GuiControl, ScrollGUIOfNote:, G_DeleteNote, %A_ProgramFiles%\PopUpMenu_PUM\menu\cpl\com\scrollnote\support\DeleteNote.png
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; GuiControl StartUp
; -------------------------------------------
SetTimer, L_UpdateTime, 500
; -------------------------------------------
Temp_Year   := Alarm_Year
Temp_Month  := Alarm_Month
Temp_Day    := Alarm_Day
Temp_Hour   := Alarm_Hour
Temp_Minute := Alarm_Minute
; -------------------------------------------
if (SubStr(Temp_Month, 1, 1) == "0")
{
	Temp_Month := SubStr(Temp_Month, 2)
}
if (SubStr(Temp_Day, 1, 1) == "0")
{
	Temp_Day := SubStr(Temp_Day, 2)
}
if (SubStr(Temp_Hour, 1, 1) == "0")
{
	Temp_Hour := SubStr(Temp_Hour, 2)
}
if (SubStr(Temp_Minute, 1, 1) == "0")
{
	Temp_Minute := SubStr(Temp_Minute, 2)
}
; -------------------------------------------
GuiControl, ScrollGUIOfNote:, G_Edit_Minute, %Temp_Minute%
GuiControl, ScrollGUIOfNote:, G_Edit_Hour, %Temp_Hour%
GuiControl, ScrollGUIOfNote:, G_Edit_Day, %Temp_Day%
GuiControl, ScrollGUIOfNote:, G_Edit_Month, %Temp_Month%
; -------------------------------------------
GuiControl, ScrollGUIOfNote:+BackgroundTrans, G_Text_Year
GuiControl, ScrollGUIOfNote:, G_Text_Year, %Temp_Year%
; -------------------------------------------
GuiControl, ScrollGUIOfNote:, G_ScrollEdit, %Scroll_Entry%
; -------------------------------------------
;
; -------------------------------------------
if (Scroll_FileArray.4 == 0) ; Scroll_AlarmOnOff 
{
  GuiControl, ScrollGUIOfNote:, G_AlarmSet, %A_ProgramFiles%\PopUpMenu_PUM\menu\cpl\com\scrollnote\support\Alarm_Off.png
}
else if (Scroll_FileArray.4 == 1) ; Scroll_AlarmOnOff 
{
	GuiControl, ScrollGUIOfNote:, G_AlarmSet, %A_ProgramFiles%\PopUpMenu_PUM\menu\cpl\com\scrollnote\support\Alarm_On.png
}
; -------------------------------------------
;
; -------------------------------------------
if (Scroll_FileArray.6 == 0) ; Scroll_AlarmSoundOnOff
{
  GuiControl, ScrollGUIOfNote:, G_Alarm_Sound, %A_ProgramFiles%\PopUpMenu_PUM\menu\cpl\com\scrollnote\support\AlarmSound_Off.png
}
else if (Scroll_FileArray.6 == 1) ; Scroll_AlarmSoundOnOff
{
	GuiControl, ScrollGUIOfNote:, G_Alarm_Sound, %A_ProgramFiles%\PopUpMenu_PUM\menu\cpl\com\scrollnote\support\AlarmSound_On.png
}
; -------------------------------------------
; GuiControl StartUp
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; -------------------------------------------
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
L_UpdateTime: ; This Label is on a Timer
{
	; -------------------------------------------
	if (Scroll_DataArray.8 == 0) ; Scroll_AlarmSettings
	{
  	; -------------------------------------------
  	if (FirstTimeLoad == 1) ; This a New Scroll Note
  	{
		  ; -------------------------------------------
		  FirstTimeLoad := 0
		  ; -------------------------------------------
      Scroll_DataArray := F_ScrollUpDown(Scroll_DataArray) ; > Scroll_DataArray
			; -------------------------------------------
	  } ; if (Scroll_DataArray.8 == 0) ; Scroll_AlarmSettings
	  else if (FirstTimeLoad == 2) ; File Exist (This a Existing Scroll Note with is a New Login)
	  {
  		; -------------------------------------------
		  FirstTimeLoad := 0
		  ; -------------------------------------------
		  if (Scroll_DataArray.3 == "Open")
		  {
  			Scroll_DataArray.3 := "Closed"
			  Scroll_DataArray := F_ScrollUpDown(Scroll_DataArray) ; > Scroll_DataArray
		  } ; if (Scroll_DataArray.3 == "Open")
		  ; -------------------------------------------
	  } ; else if (FirstTimeLoad == 2) ; File Exist (This a Existing Scroll Note with is a New Login)
    ; -------------------------------------------
	  FormatTime, TimeRightNow , , yyyyMMddHHmm
	  Current_Year := SubStr(TimeRightNow, 1, 4)
	  Current_Month := SubStr(TimeRightNow, 5, 2)
	  Current_Day := SubStr(TimeRightNow, 7, 2)
	  Current_Hour := SubStr(TimeRightNow, 9, 2)
	  Current_Minute := SubStr(TimeRightNow, 11, 2)
	  ; -------------------------------------------
	  Scroll_CurrentTime := Current_Year Current_Month Current_Day Current_Hour Current_Minute
	  ; -------------------------------------------
	  ;
	  ; -------------------------------------------
	  if (Scroll_DataArray.4 == 1) ; Scroll_AlarmSettings Scroll_AlarmOnOff
	  {
			; -------------------------------------------
			Scroll_AlarmTime := Scroll_DataArray.5
  		; -------------------------------------------
			ShowAlarmTime := F_TimeDiff(Scroll_AlarmTime)
			; -------------------------------------------
			if (ShowOldAlarmTime == "")
			{
				ShowOldAlarmTime := ShowAlarmTime
			}
		  ; -------------------------------------------
			if (ShowOldAlarmTime != ShowAlarmTime) ; Alarm Time is NOT Now
			{
				; -------------------------------------------
        ShowAlarmTime := F_TimeDiff(Scroll_AlarmTime)
		    GuiControl, ScrollGUIOfNote:, G_AlarmTime, %ShowAlarmTime%
		    GuiControl, ScrollGUIOfNote:Show, G_AlarmTime
				; -------------------------------------------
				Scroll_OldAlarmTime := Scroll_AlarmTime
				; -------------------------------------------
			}
		  ; -------------------------------------------
			;
			; -------------------------------------------
		  if (Scroll_CurrentTime >= Scroll_AlarmTime)  ; Alarm is NOW
		  {
  			; -------------------------------------------
			  if (Scroll_DataArray.6 == 1) ; Scroll_AlarmSoundOnOff
			  {
  				SoundPlay, %A_ProgramFiles%\PopUpMenu_PUM\menu\cpl\com\scrollnote\support\AlarmSound.mp3
			  } ; if (Scroll_DataArray.6 == 1) ; Scroll_AlarmSoundOnOff
			  ; -------------------------------------------
			  ;
		    ; -------------------------------------------
		    GuiControl, ScrollGUIOfNote:Hide, G_AlarmTime
	      ; -------------------------------------------
		    GuiControl, ScrollGUIOfNote:, G_Alarm_Sound, %A_ProgramFiles%\PopUpMenu_PUM\menu\cpl\com\scrollnote\support\AlarmSound_Off.png
		    ; -------------------------------------------
	      GuiControl, ScrollGUIOfNote:, G_AlarmSet, %A_ProgramFiles%\PopUpMenu_PUM\menu\cpl\com\scrollnote\support\Alarm_Off.png
	      ; -------------------------------------------
	      FormatTime, TimeRightNow , , yyyyMMddHHmm
	      Current_Year   := SubStr(TimeRightNow, 1, 4)
	      Current_Month  := SubStr(TimeRightNow, 5, 2)
	      Current_Day    := SubStr(TimeRightNow, 7, 2)
	      Current_Hour   := SubStr(TimeRightNow, 9, 2)
	      Current_Minute := SubStr(TimeRightNow, 11, 2)
	      ; -------------------------------------------
	      GuiControl, ScrollGUIOfNote:, G_Edit_Minute, %Current_Minute%
	      GuiControl, ScrollGUIOfNote:, G_Edit_Hour, %Current_Hour%
	      GuiControl, ScrollGUIOfNote:, G_Edit_Day, %Current_Day%
	      GuiControl, ScrollGUIOfNote:, G_Edit_Month, %Current_Month%
	      GuiControl, ScrollGUIOfNote:, Edit_Year, %Current_Year%
	      ; -------------------------------------------
			  ;
			  ; -------------------------------------------
			  Mov_X := Round((A_ScreenWidth / 2) - 101)
	      Mov_Y := Round((A_ScreenHeight / 2) - 125)
	      ; -------------------------------------------
	      Gui, ScrollGUIOfNote:Show, x%Mov_X% y%Mov_Y%, ScrollTitleOfNote
	      ; -------------------------------------------
			  ;
			  ; -------------------------------------------
			  if (Scroll_DataArray.3 == "Closed")
	      {
  				Scroll_DataArray := F_ScrollUpDown(Scroll_DataArray) ; > Scroll_DataArray
  	    } ; if (Scroll_State == "Open")
  	    ; -------------------------------------------			
			  Gui, ScrollGUIOfNote:+LastFound -Caption +AlwaysOnTop +ToolWindow -Border ; Alarm in ON (AlwaysOnTop)
	      ; -------------------------------------------
			  ;
  	    ; -------------------------------------------
  	    ;
			  ; -------------------------------------------
        Scroll_DataArray.4 := 0 ; Scroll_AlarmOnOff
        Scroll_DataArray.6 := 0 ; Scroll_AlarmSoundOnOff
			  ; -------------------------------------------
				;
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        ;(1)  Scroll_DataArray.1  ; Scroll_PosX            ; [#]
        ;(2)  Scroll_DataArray.2  ; Scroll_PosY            ; [#]
        ;(3)  Scroll_DataArray.3  ; Scroll_State           ; ["Closed","Open"]
        ;(4)  Scroll_DataArray.4  ; Scroll_AlarmOnOff      ; [0,1]
        ;(5)  Scroll_DataArray.5  ; Scroll_AlarmTime       ; [YYYYMMDDhhmm]
        ;(6)  Scroll_DataArray.6  ; Scroll_AlarmSoundOnOff ; [0,1]
        ;(7)  Scroll_DataArray.7  ; Scroll_WasMoved        ; [0,1]
        ;(8)  Scroll_DataArray.8  ; Scroll_AlarmSettings   ; [0,1]
        ;(9)  Scroll_DataArray.9  ; Alarm_Activated        ; [0,1]
        ;(10) Scroll_DataArray.10 ; Alarm_Activated_PosX   ; [#]
        ;(11) Scroll_DataArray.11 ; Alarm_Activated_PosY   ; [#]
        ; -------------------------------------------
        ; MUST BE THE LAST in the Array
        ;(12) Scroll_DataArray.12 Scroll_Entry             ; [String]
        ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
				;
				; -------------------------------------------
				Scroll_DataArray.9 := 1 ; Alarm_Activated
				Scroll_DataArray.10 := Scroll_DataArray.1
				Scroll_DataArray.11 := Scroll_DataArray.2
				; -------------------------------------------
				;
				; -------------------------------------------
			  F_Scroll_UpdateText(Scroll_DataArray) ; > Nothing
			  ; -------------------------------------------
		  } ; if (Scroll_CurrentTime >= Scroll_AlarmTime)
	  } ; if (Scroll_AlarmOnOff == 1) ; Alarm in Set and the Set Window is Not Open
	} ; if (Scroll_DataArray.8 == 0) ; Scroll_AlarmSettings
} ; L_UpdateTime:
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
L_ScrollEdit:
{
	; -------------------------------------------
	if (Scroll_DataArray.8 == 0) ; Scroll_AlarmSettings
	{
		; -------------------------------------------
		F_Scroll_UpdateText(Scroll_DataArray) ; > Nothing
		; -------------------------------------------
	} ; if (Scroll_DataArray.8 == 0) ; Scroll_AlarmSettings
	; -------------------------------------------
} ; L_ScrollEdit:
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
L_AlarmSound:
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
{
	; -------------------------------------------
	if (Scroll_DataArray.3 == "Open") ; Scroll_State
	{
		; -------------------------------------------
		Scroll_DataArray.8 := 1 ; Scroll_AlarmSettings
		; -------------------------------------------
		;
		; -------------------------------------------
		F_CheckTime("S")
		; -------------------------------------------
		;
		Scroll_AlarmSoundOnOff := Scroll_DataArray.6
	  ; -------------------------------------------
	  if (Scroll_DataArray.6 == 0) ; Scroll_AlarmSoundOnOff
	  {
  		; -------------------------------------------
		  Scroll_DataArray.6 := 1
		  GuiControl, ScrollGUIOfNote:, G_Alarm_Sound, %A_ProgramFiles%\PopUpMenu_PUM\menu\cpl\com\scrollnote\support\AlarmSound_On.png
		  ; -------------------------------------------
	  }
	  else if (Scroll_DataArray.6 == 1) ; Scroll_AlarmSoundOnOff
	  {
  		; -------------------------------------------
			Scroll_DataArray.6 := 0
		  GuiControl, ScrollGUIOfNote:, G_Alarm_Sound, %A_ProgramFiles%\PopUpMenu_PUM\menu\cpl\com\scrollnote\support\AlarmSound_Off.png
		  ; -------------------------------------------
	  }
	  ; -------------------------------------------
	  GuiControl, ScrollGUIOfNote:Show, G_Alarm_Sound
	  ; -------------------------------------------
	} ; if (Scroll_State == "Open")
	; -------------------------------------------
	;
	; -------------------------------------------
	F_Scroll_UpdateText(Scroll_DataArray) ; > Nothing
	; -------------------------------------------
} ; L_AlarmSound:
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
L_AlarmAccept:
{
	; -------------------------------------------
	FormatTime, TimeRightNow , , yyyyMMddHHmm
	Current_Year   := SubStr(TimeRightNow, 1, 4)
	Current_Month  := SubStr(TimeRightNow, 5, 2)
	Current_Day    := SubStr(TimeRightNow, 7, 2)
	Current_Hour   := SubStr(TimeRightNow, 9, 2)
	Current_Minute := SubStr(TimeRightNow, 11, 2)
	; -------------------------------------------
	Scroll_CurrentTime := Current_Year Current_Month Current_Day Current_Hour Current_Minute
	; -------------------------------------------
	Scroll_AlarmTime := F_CheckTime("S")
	; -------------------------------------------
	;
	; -------------------------------------------
	if (Scroll_AlarmTime > Scroll_CurrentTime)
	{
		; -------------------------------------------
		TimeChanged := F_CheckTime("H") ; "H" Hide Alarm Settings
		Scroll_DataArray.8 := 0 ; Scroll_AlarmSettings
		; -------------------------------------------
		;
		; -------------------------------------------
		Scroll_DataArray.4 := 1 ; Scroll_AlarmOnOff
		; -------------------------------------------
		Scroll_DataArray.5 := Scroll_AlarmTime
		; -------------------------------------------
		;
		; -------------------------------------------
		GuiControl, ScrollGUIOfNote:, G_AlarmSet, %A_ProgramFiles%\PopUpMenu_PUM\menu\cpl\com\scrollnote\support\Alarm_On.png
		GuiControl, ScrollGUIOfNote:Show, G_AlarmSet
		; -------------------------------------------
		ShowAlarmTime := F_TimeDiff(Scroll_AlarmTime)
		GuiControl, ScrollGUIOfNote:, G_AlarmTime, %ShowAlarmTime%
		GuiControl, ScrollGUIOfNote:Show, G_AlarmTime
		; -------------------------------------------
	} ; if (Scroll_AlarmTime != Scroll_CurrentTime)
	; -------------------------------------------
	;
	; -------------------------------------------
	F_Scroll_UpdateText(Scroll_DataArray) ; > Nothing
	; -------------------------------------------
} ; L_AlarmAccept:
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
L_AlarmCancel:
{
	; -------------------------------------------
	F_CheckTime("R")
	; -------------------------------------------
	;
	; -------------------------------------------
	Scroll_DataArray.4 := 0 ; Scroll_AlarmOnOff
	Scroll_DataArray.6 := 0 ; Scroll_AlarmSoundOnOff
	Scroll_DataArray.8 := 0 ; Scroll_AlarmSettings
	; -------------------------------------------
	;
	; -------------------------------------------
	;~ F_Scroll_UpdateText(Scroll_DataArray) ; > Nothing
	; -------------------------------------------
} ; L_AlarmCancel:
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
L_AlarmSet:
{
	; -------------------------------------------
	if (Scroll_DataArray.8 == 0) ; Scroll_AlarmSettings
	{
		; -------------------------------------------
		GuiControl, ScrollGUIOfNote:Hide, G_AlarmTime
	  ; -------------------------------------------
	  if (Scroll_DataArray.4 == 0) ; Scroll_AlarmOnOff
	  {
    	; -------------------------------------------
  	  FormatTime, Scroll_AlarmTime, , yyyyMMddHHmm
	    Alarm_Year   := SubStr(TimeRightNow, 1, 4)
	    Alarm_Month  := SubStr(TimeRightNow, 5, 2)
	    Alarm_Day    := SubStr(TimeRightNow, 7, 2)
	    Alarm_Hour   := SubStr(TimeRightNow, 9, 2)
	    Alarm_Minute := SubStr(TimeRightNow, 11, 2)
	    ; -------------------------------------------
		  Scroll_DataArray.5 := Scroll_AlarmTime
		  ; -------------------------------------------
	  } ; if (Scroll_DataArray.5 == "")
		else if (Scroll_DataArray.4 == 1) ; Scroll_AlarmOnOff
		{
			; -------------------------------------------
      Scroll_AlarmTime := Scroll_DataArray.5
	    ; -------------------------------------------
	    Alarm_Year   := SubStr(Scroll_AlarmTime, 1, 4)
	    Alarm_Month  := SubStr(Scroll_AlarmTime, 5, 2)
	    Alarm_Day    := SubStr(Scroll_AlarmTime, 7, 2)
	    Alarm_Hour   := SubStr(Scroll_AlarmTime, 9, 2)
	    Alarm_Minute := SubStr(Scroll_AlarmTime, 11, 2)
	    ; -------------------------------------------
		}
	  Temp_Year   := Alarm_Year
	  Temp_Month  := Alarm_Month
	  Temp_Day    := Alarm_Day
	  Temp_Hour   := Alarm_Hour
	  Temp_Minute := Alarm_Minute
	  ; -------------------------------------------
	  if (SubStr(Temp_Month, 1, 1) == "0")
	  {
  		Temp_Month := SubStr(Temp_Month, 2)
  	} ; if (SubStr(Temp_Month, 1, 1) == "0")
  	if (SubStr(Temp_Day, 1, 1) == "0")
  	{
		  Temp_Day := SubStr(Temp_Day, 2)
	  } ; if (SubStr(Temp_Day, 1, 1) == "0")
	  if (SubStr(Temp_Hour, 1, 1) == "0")
	  {
  		Temp_Hour := SubStr(Temp_Hour, 2)
  	} ; if (SubStr(Temp_Hour, 1, 1) == "0")
  	if (SubStr(Temp_Minute, 1, 1) == "0")
  	{
		  Temp_Minute := SubStr(Temp_Minute, 2)
	  } ; if (SubStr(Temp_Minute, 1, 1) == "0")
	  ; -------------------------------------------
	  GuiControl, ScrollGUIOfNote:, G_Edit_Minute, %Temp_Minute%
	  GuiControl, ScrollGUIOfNote:, G_Edit_Hour, %Temp_Hour%
	  GuiControl, ScrollGUIOfNote:, G_Edit_Day, %Temp_Day%
	  GuiControl, ScrollGUIOfNote:, G_Edit_Month, %Temp_Month%
	  ; -------------------------------------------
	  GuiControl, ScrollGUIOfNote:+BackgroundTrans, G_Text_Year
	  GuiControl, ScrollGUIOfNote:, G_Text_Year, %Temp_Year%
	  ; -------------------------------------------
	  ;
	  ; -------------------------------------------
  	F_CheckTime("S") ; "S" Show Alarm Settings
  	Scroll_DataArray.8 := 1 ; Scroll_AlarmSettings
  	; -------------------------------------------
	} ; if (Scroll_AlarmSettings == 0)
	; -------------------------------------------
	;
	; -------------------------------------------
	F_Scroll_UpdateText(Scroll_DataArray) ; > Nothing
	; -------------------------------------------
} ; L_AlarmSet:
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
L_EndTL:
{
	; -------------------------------------------
	Scroll_DataArray := F_ScrollMove(Scroll_DataArray) ; > Scroll_DataArray
	; -------------------------------------------
	if (Scroll_DataArray.7 == 0) ; Scroll_WasMoved
	{
		; -------------------------------------------
	  F_CheckTime("")
	  ; -------------------------------------------
		Scroll_DataArray := F_ScrollUpDown(Scroll_DataArray) ; > Scroll_DataArray
	  ; -------------------------------------------
	} ; if (Scroll_DataArray.7 == 0) ; Scroll_WasMoved
	; -------------------------------------------
	;
	; -------------------------------------------
	F_Scroll_UpdateText(Scroll_DataArray) ; > Nothing
	; -------------------------------------------
} ; L_EndTL:
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
L_EndTR:
{
	; -------------------------------------------
	Scroll_DataArray := F_ScrollMove(Scroll_DataArray) ; > Scroll_DataArray
	; -------------------------------------------
	if (Scroll_DataArray.7 == 0) ; Scroll_WasMoved
	{
		; -------------------------------------------
	  F_CheckTime("")
	  ; -------------------------------------------
		Scroll_DataArray := F_ScrollUpDown(Scroll_DataArray) ; > Scroll_DataArray
	  ; -------------------------------------------
	} ; if (Scroll_DataArray.7 == 0) ; Scroll_WasMoved
	; -------------------------------------------
	;
	; -------------------------------------------
	F_Scroll_UpdateText(Scroll_DataArray) ; > Nothing
	; -------------------------------------------
} ; L_EndTR:
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
L_EndBL:
{
	; -------------------------------------------
	Scroll_DataArray := F_ScrollMove(Scroll_DataArray) ; > Scroll_DataArray
	; -------------------------------------------
	if (Scroll_DataArray.7 == 0) ; Scroll_WasMoved
	{
	  ; -------------------------------------------
		F_CheckTime("H")
		Scroll_AlarmSettings := 0
		Scroll_DataArray.8 := Scroll_AlarmSettings
	  ; -------------------------------------------
		;
		; -------------------------------------------
		Scroll_DataArray.3 := "Open"
		Scroll_DataArray := F_ScrollUpDown(Scroll_DataArray) ; > Scroll_DataArray
	  ; -------------------------------------------
	}
	; -------------------------------------------
	;
	; -------------------------------------------
	F_Scroll_UpdateText(Scroll_DataArray) ; > Nothing
	; -------------------------------------------
} ; L_EndBL:
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
L_EndBR:
{
	; -------------------------------------------
	Scroll_DataArray := F_ScrollMove(Scroll_DataArray) ; > Scroll_DataArray
	; -------------------------------------------
	if (Scroll_DataArray.7 == 0) ; Scroll_WasMoved
	{
	  ; -------------------------------------------
		F_CheckTime("H")
		Scroll_AlarmSettings := 0
		Scroll_DataArray.8 := Scroll_AlarmSettings
	  ; -------------------------------------------
		;
		; -------------------------------------------
		Scroll_DataArray.3 := "Open"
		Scroll_DataArray := F_ScrollUpDown(Scroll_DataArray) ; > Scroll_DataArray
	  ; -------------------------------------------
	}
	; -------------------------------------------
	;
	; -------------------------------------------
	F_Scroll_UpdateText(Scroll_DataArray) ; > Nothing
	; -------------------------------------------
} ; L_EndBR:
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
L_DeleteNote:
{
	; -------------------------------------------
	Scroll_DataArray.3 := "Open"
	Scroll_DataArray := F_ScrollUpDown(Scroll_DataArray) ; > Scroll_DataArray
	; -------------------------------------------
  FileDelete, %A_ScriptFullPath%
	SplitPath, A_ScriptFullPath, , , , ThisScrollNote
	TextFile_ThisScrollNote := A_ScriptDir "\" ThisScrollNote ".txt"
	FileDelete, %TextFile_ThisScrollNote%
	; -------------------------------------------
	ExitApp
	; -------------------------------------------
} ; L_DeleteNote:
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
L_ScrollRoll:
{
	; -------------------------------------------
	Scroll_DataArray := F_ScrollMove(Scroll_DataArray) ; > Scroll_DataArray
	; -------------------------------------------
	if (Scroll_DataArray.7 == 0) ; Scroll_WasMoved
	{
		; -------------------------------------------
	  F_CheckTime("")
	  ; -------------------------------------------
		Scroll_DataArray := F_ScrollUpDown(Scroll_DataArray) ; > Scroll_DataArray
	  ; -------------------------------------------
	}
	; -------------------------------------------
	;
	; -------------------------------------------
	F_Scroll_UpdateText(Scroll_DataArray) ; > Nothing
	; -------------------------------------------
} ; L_ScrollRoll:
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; END OF FILE
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
