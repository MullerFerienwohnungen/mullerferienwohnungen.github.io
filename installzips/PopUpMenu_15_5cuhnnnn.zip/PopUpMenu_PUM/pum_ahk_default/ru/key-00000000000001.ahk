﻿#Include %A_ProgramFiles%\PopUpMenu_PUM\Shortcut_Run.ahk
Script_Line_2 := 2
Script_Line_3 := ["[Ctrl Down]", "[Shift Down]", "~1~", "[Shift Up]", "[Ctrl Up]"]
Script_Line_4 := "CabinetWClass"
Script_Line_5 := ""
Script_Line_6 := "1"
Shortcut_Run("key", Script_Line_2, Script_Line_3, Script_Line_4, Script_Line_5, Script_Line_6)
#NoTrayIcon
ExitApp
;Просмотр особо крупных значков
