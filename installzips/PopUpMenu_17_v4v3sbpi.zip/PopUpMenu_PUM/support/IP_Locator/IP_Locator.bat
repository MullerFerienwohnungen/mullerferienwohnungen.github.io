curl ipinfo.io/109.109.6.177/region > Region.txt
curl ipinfo.io/109.109.6.177/city > City.txt
curl ipinfo.io/109.109.6.177/country > Country.txt
curl ipinfo.io/109.109.6.177/postal > ZipCode.txt
curl ipinfo.io/109.109.6.177/timezone > TimeZone.txt
