﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
#SingleInstance, force
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %ProgramFiles%\PopUpMenu_PUM\Array_FromFile.ahk ; Array_FromFile(FilePath) ; > Array
#Include %ProgramFiles%\PopUpMenu_PUM\Array_Add.ahk ; Array_Add(ThisArray, AddThis, ThisPos) ; > ThisArray
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Menu, Tray, Icon, %A_ScriptDir%\ScriptImage.png
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
if (A_IsAdmin == 0) ; Always Run As AdMin
{
  Run, *RunAs %A_ScriptFullPath%
} ; Always Run As AdMin
; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Functions
; -------------------------------------------
ClickPoint(ThisPoint, ReletiveTo)
{
	; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	BlockInput, MouseMove
	BlockInput, On
	; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	;
  ; -------------------------------------------
  Point_X := ThisPoint.1
  Point_Y := ThisPoint.2
  ; -------------------------------------------
  CoordMode, Mouse, %ReletiveTo%
  MouseMove, Point_X, Point_Y
  Sleep, 100
  Send, {LButton}
  Sleep, 100
  ; -------------------------------------------
	;
	; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	BlockInput, MouseMoveOff
	BlockInput, Off
	; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
} ; Function (ClickPoint)
; -------------------------------------------
GetAllEXEList() ; > (Array_ExeSearch)
{
	; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	; Get All EXEs  List
	; -------------------------------------------
	SearchPath := "C:\Users\" A_UserName "\AppData"
	Array_FilePath := Array_Add(Array_FilePath, SearchPath, "End") ; > ThisArray
	; -------------------------------------------
	SearchPath := "C:\Users\" A_UserName "\Documents"
	Array_FilePath := Array_Add(Array_FilePath, SearchPath, "End") ; > ThisArray
	; -------------------------------------------
	SearchPath := "C:\Windows\SysWOW64\config\systemprofile\AppData"
	Array_FilePath := Array_Add(Array_FilePath, SearchPath, "End") ; > ThisArray
	; -------------------------------------------
	SearchPath := "C:\Program Files"
	Array_FilePath := Array_Add(Array_FilePath, SearchPath, "End") ; > ThisArray
	; -------------------------------------------
	SearchPath := "C:\Program Files (x86)"
	Array_FilePath := Array_Add(Array_FilePath, SearchPath, "End") ; > ThisArray
	; -------------------------------------------
	SearchPath := "C:\ProgramData"
	Array_FilePath := Array_Add(Array_FilePath, SearchPath, "End") ; > ThisArray
	; -------------------------------------------
	;
	; -------------------------------------------
	Array_ExeNew_Len := 0
	Length_ExeSearch := 0
	FilesSearch      := 0
	; -------------------------------------------
	for Index, FilePath in Array_FilePath
	{
		; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
		MiddleScreen := A_ScreenWidth * 0.5
		; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
		; -------------------------------------------
		Loop, Files, %FilePath%\*.exe, R
		{
			; -------------------------------------------
			ThisFilePath := A_LoopFileFullPath			
			; -------------------------------------------
			FilesSearch := FilesSearch + 1
			; -------------------------------------------
			;
			; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@	
			Msg := Msg "Creating All EXE List`n"
			Msg := Msg "FilePath = " FilePath "`n"
			Msg := Msg "Number of EXEs = " FilesSearch "`n"
			CoordMode, ToolTip, Screen
			ToolTip, %Msg%, %MiddleScreen%, 0
			Msg := ""
			; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@						
			;
			; -------------------------------------------
			Array_ExeSearch := Array_Add(Array_ExeSearch, ThisFilePath, "End") ; > ThisArray
			; -------------------------------------------
		} ; Loop, Files, %FilePath%\*.exe, R
	} ; for Index, FilePath in Array_FilePath
	; -------------------------------------------
	Array_ExeSearch_Len := Array_ExeSearch.MaxIndex() ; Highest Length
	; -------------------------------------------
	ToolTip
	; -------------------------------------------
	;
	; -------------------------------------------
	Length_Array_ExeSearch := Array_ExeSearch.MaxIndex() ; Highest Length
	if (Length_Array_ExeSearch == 0 or Length_Array_ExeSearch == "")
	{
  	Array_ExeSearch := []
	}
	; -------------------------------------------
	return Array_ExeSearch
	; -------------------------------------------
} ; GetAllEXEList() ; > (Array_ExeSearch)
; -------------------------------------------
Firewall_Blocker(ArrayKeyWord) ; ArrayKeyWord
{
	; -------------------------------------------
	if (ArrayKeyWord != "")
	{
		; -------------------------------------------
		Array_ExeSearch := GetAllEXEList() ; > (Array_ExeSearch)
		; -------------------------------------------
		;
		; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		; Run Firewall_App_Blocker_x64.exe
		; -------------------------------------------
		RunFirewallBlocker := A_ProgramFiles "\PopUpMenu_PUM\support\firewallblocker\Firewall_App_Blocker_x64.exe"
		; -------------------------------------------
		if FileExist(RunFirewallBlocker) ; File Exist (Firewall_App_Blocker_x64.exe)
		{
			; -------------------------------------------
			if !WinActive("ahk_exe Firewall_App_Blocker_x64.exe")
			{
				; -------------------------------------------
				Run, *RunAs %RunFirewallBlocker%
				; -------------------------------------------
				WaitTitle := "Firewall App Blocker v1.7"
				WinWait, %WaitTitle%,, 1
				; -------------------------------------------
				WinMaximize , %WaitTitle%
				; -------------------------------------------
			}
			; -------------------------------------------
			Breaktime := A_TickCount + 5000
			TimedOut := 0
			SetTitleMatchMode, 2 ; WinTitle anywhere inside it to be a match.
			while !WinExist(WaitTitle)
			{
				; -------------------------------------------
				if (A_TickCount > Breaktime)
				{
					; -------------------------------------------
					ToolTip
					; -------------------------------------------
					;
					; -------------------------------------------
					if WinExist("ahk_exe Firewall_App_Blocker_x64.exe")
					{
						WinClose
					}
					; -------------------------------------------
					Msg := Msg "Timed Out`n"
					Msg := Msg "Window Wait = " WaitTitle "`n"
					MsgBox, 262144, , %Msg%, 3
					Msg := ""
					; -------------------------------------------
					ExitApp
					; -------------------------------------------
				}
				; -------------------------------------------
			}
			; -------------------------------------------
			Sleep, 500
			; -------------------------------------------
			; Run Firewall_App_Blocker_x64.exe
			; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		} ; (Firewall_App_Blocker_x64.exe) Exist
		else ; (Firewall_App_Blocker_x64.exe) Does NOT Exist
		{
			; -------------------------------------------
			ToolTip
			; -------------------------------------------
			;
			; -------------------------------------------
			Msg := Msg "Firewall_App_Blocker_x64.exe`n"
			Msg := Msg "Does Not Exist`n"
			Msg := Msg "Exit App`n"
			MsgBox, 262144, , %Msg%, 3
			Msg := ""
			; -------------------------------------------
			ExitApp
			; -------------------------------------------
		} ; else ; (Firewall_App_Blocker_x64.exe) Does NOT Exist
		; -------------------------------------------
		; Run Firewall_App_Blocker_x64.exe
		; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		;
		; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		; Delete OLD (CurrentFirewallBlockList.ini)
		; -------------------------------------------
		CurrentFirewallBlockList := A_Temp "\CurrentFirewallBlockList.ini"
		FileDelete, %CurrentFirewallBlockList%
		; -------------------------------------------
		; Delete OLD (CurrentFirewallBlockList.ini)
		; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		;
		; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		; Create (CurrentFirewallBlockList.ini)
		; -------------------------------------------
		Sleep, 250
    ; -------------------------------------------
	  SetTitleMatchMode, 2 ; A window's title can contain WinTitle anywhere inside it to be a match.
	  while !WinActive("ahk_exe Firewall_App_Blocker_x64.exe")
	  {
      if WinExist("ahk_exe Firewall_App_Blocker_x64.exe")
      {
  		  ; -------------------------------------------
		    WinActivate
		    Sleep, 500
		    ; -------------------------------------------
      }
		  SetTitleMatchMode, 2 ; A window's title can contain WinTitle anywhere inside it to be a match.
		  if WinActive("ahk_exe Firewall_App_Blocker_x64.exe")
		  {
  			break ; Break out of while
		  }
		  ; -------------------------------------------
		} ; while !WinActive("ahk_exe Firewall_App_Blocker_x64.exe")
		; -------------------------------------------
		Point_ExportList := [407, 24]
		ClickPoint(Point_ExportList, "Client")
		; -------------------------------------------
		;
		; -------------------------------------------
		BreakTime := 1000 + A_TickCount
		while !WinExist("Save As")
		{
			; -------------------------------------------
			if WinExist("Save As")
			{
			  ; -------------------------------------------
			  BlockListExist := 1
			  ; -------------------------------------------
			  Sleep, 500
		    ; -------------------------------------------
				BlockInput, On
		    Send, %CurrentFirewallBlockList%
		    Sleep, 50
		    Send, {Enter}
		    Sleep, 500
				BlockInput, Off
		    ; -------------------------------------------
				break ; Breal Out of while Loop
				; -------------------------------------------
			}
			else
			{
				BlockListExist := 0
			}
			; -------------------------------------------
			if (A_TickCount > BreakTime)
			{
				; -------------------------------------------
				break ; Breal Out of while Loop
				; -------------------------------------------
			}
		}
		; -------------------------------------------
		; Create (CurrentFirewallBlockList.ini)
		; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		;
		; -------------------------------------------
		if (BlockListExist == 1)
		{
		  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		  ; Check if (CurrentFirewallBlockList) Exist
		  ; Create (Array_BlockListCurrent)
		  ; -------------------------------------------
		  Array_BlockListCurrent := ""
		  ; -------------------------------------------
		  if FileExist(CurrentFirewallBlockList)
		  {
  			; -------------------------------------------
			  Array_ExeCurrent := Array_FromFile(CurrentFirewallBlockList)
			  ; -------------------------------------------
			  for Index, ThisLine in Array_ExeCurrent
			  {
  				; -------------------------------------------
				  StringLower, ThisLine, ThisLine
				  ; -------------------------------------------
				  Position1 := InStr(ThisLine, "=")
				  ThisLine := SubStr(ThisLine, Position1 + 1)
				  Position1 := InStr(ThisLine, "|")
				  ThisLine := SubStr(ThisLine, 1, Position1 - 1)  
				  ; -------------------------------------------
				  ;
				  ; -------------------------------------------
				  if (InStr(ThisLine, ".exe") > 0)
				  {
  					; -------------------------------------------
					  Array_BlockListCurrent := Array_Add(Array_BlockListCurrent, ThisLine, ThisPos) ; > ThisArray
					  ; -------------------------------------------
				  } ; if (InStr(ThisLine, ".exe") > 0)
				  ; -------------------------------------------
			  } ; for Index, ThisLine in Array_ExeCurrent
			  ; -------------------------------------------
		  } ; if FileExist(CurrentFirewallBlockList)
		  else ; (CurrentFirewallBlockList) Does NOT exist
		  {
  			; -------------------------------------------
			  ToolTip
			  ; -------------------------------------------
			  ;
			  ; -------------------------------------------
			  if WinExist("ahk_exe Firewall_App_Blocker_x64.exe")
			  {
  				WinClose
			  }
			  ; -------------------------------------------
			  Msg := Msg "FILE NOT FOUND`n"
			  Msg := Msg CurrentFirewallBlockList "`n"
			  Msg := Msg "Exit App`n" 
			  MsgBox, 0, , %Msg%, 3
			  Msg := ""
			  ; -------------------------------------------
			  ExitApp
			  ; -------------------------------------------
		  } ; else ; (CurrentFirewallBlockList) Does NOT exist
		  ; -------------------------------------------
		  ; Check if (CurrentFirewallBlockList) Exist
		  ; Create (Array_BlockListCurrent)
		  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		} ; if (BlockListExist == 1)
		; -------------------------------------------
		;
		; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		; Create (Array_BlockListAdd)
		; -------------------------------------------
		Array_BlockListAdd := ""
		; -------------------------------------------
		for Index1, ThisExe in Array_ExeSearch
		{
			; -------------------------------------------
			StringLower, ThisExe, ThisExe
			; -------------------------------------------
			AlreadyInBlockList := 0
			; -------------------------------------------
			for Index2, CurrentBlockedExe in Array_BlockListCurrent
			{
				; -------------------------------------------
				if (CurrentBlockedExe == ThisExe) ; Already in Current Block List
				{
					AlreadyInBlockList := 1
				}
				; -------------------------------------------
			} ; for Index2, CurrentBlockedExe in Array_BlockListCurrent
			; -------------------------------------------
			if (AlreadyInBlockList == 0)
			{
				if (InStr(ThisExe, ArrayKeyWord) > 0)
				{
					; -------------------------------------------
					Array_BlockListAdd := Array_Add(Array_BlockListAdd, ThisExe, ThisPos) ; > ThisArray
					; -------------------------------------------
				} ; if (InStr(ThisExe, ArrayKeyWord) > 0)
			} ; if (AlreadyInBlockList == 0)
			; -------------------------------------------
		}
		; -------------------------------------------
		; Create (Array_BlockListAdd)
		; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		;
		; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		; Add to Block Line in Firewall Blocker
		; -------------------------------------------
		Array_BlockListAdd_Len := Array_BlockListAdd.MaxIndex() ; Highest Length
		; -------------------------------------------
		if (Array_BlockListAdd_Len == "")
		{
			Array_BlockListAdd_Len := 0
		}
		; -------------------------------------------
		if (Array_BlockListAdd_Len > 0)
		{
			; -------------------------------------------
			for Index, NewItem in Array_BlockListAdd
			{
				; -------------------------------------------
				if FileExist(NewItem)
				{
				  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
				  MiddleScreen := A_ScreenWidth * 0.5
				  Msg := Msg "Adding`n"
				  Msg := Msg NewItem "`n"
				  Msg := Msg "To Current Block List`n"
				  CoordMode, ToolTip, Screen
				  ToolTip, %Msg%, %MiddleScreen%, 0
				  Msg := ""
				  ; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
				  ;
          ; -------------------------------------------
	        SetTitleMatchMode, 2 ; A window's title can contain WinTitle anywhere inside it to be a match.
	        while !WinActive("ahk_exe Firewall_App_Blocker_x64.exe")
	        {
            if WinExist("ahk_exe Firewall_App_Blocker_x64.exe")
            {
        		  ; -------------------------------------------
		          WinActivate
		          Sleep, 500
		          ; -------------------------------------------
            }
		        SetTitleMatchMode, 2 ; A window's title can contain WinTitle anywhere inside it to be a match.
		        if WinActive("ahk_exe Firewall_App_Blocker_x64.exe")
		        {
        			break ; Break out of while
		        }
		        ; -------------------------------------------
		      } ; while !WinActive("ahk_exe Firewall_App_Blocker_x64.exe")
		      ; -------------------------------------------
		      Point_AddExeToBlock := [22, 24] ; Client
		      ClickPoint(Point_AddExeToBlock, "Client")
		      ; -------------------------------------------
					;
  		    ; -------------------------------------------
		      ; Wait for Window
		      ; -------------------------------------------
					BlockInput, On
					Sleep, 500
					Send, %NewItem%
					Sleep, 50
					Send, {Enter}
					Sleep, 500
					BlockInput, Off
					; -------------------------------------------
			  } ; if FileExist(NewItem)
			} ; for Index, NewItem in Array_BlockListAdd
			; -------------------------------------------
			;
			; -------------------------------------------
			ToolTip
			; -------------------------------------------
			;
			; -------------------------------------------
			SetTitleMatchMode, 2 ; A window's title can contain WinTitle anywhere inside it to be a match.
			if WinActive("ahk_exe Firewall_App_Blocker_x64.exe")
			{
				BlockInput, On
				Send, {Alt Down}{F4}{Alt Up}
				BlockInput, Off
			}
			; -------------------------------------------
			Msg := Msg "==================`n"
			Msg := Msg "Blocked = " ArrayKeyWord "`n"
			Msg := Msg "Items Added = " Array_BlockListAdd_Len "`n"
			Msg := Msg "==================`n"
			MsgBox, 0, , %Msg%, 3
			Msg := ""
			; -------------------------------------------
			ExitApp
			; -------------------------------------------
		} ; if (Array_BlockListAdd_Len > 0)
		else ; (Array_BlockListAdd_Len == 0) ; No New Items to Add
		{
			; -------------------------------------------
			ToolTip
			; -------------------------------------------
			;
			; -------------------------------------------
			SetTitleMatchMode, 2 ; A window's title can contain WinTitle anywhere inside it to be a match.
			if WinActive("ahk_exe Firewall_App_Blocker_x64.exe")
			{
				BlockInput, On
				Send, {Alt Down}{F4}{Alt Up}
				BlockInput, Off
			}
			; -------------------------------------------
			Msg := Msg "No New Items to Add`n"
			MsgBox, 262144, , %Msg%, 3
			Msg := ""
			; -------------------------------------------
			ExitApp
			; -------------------------------------------
		} ; else ; (Array_BlockListAdd_Len == 0) ; No New Items to Add
		; -------------------------------------------
	} ; if (ArrayKeyWord != "")
} ; Firewall_Blocker(ArrayKeyWord) ; ArrayKeyWord
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Gui
; -------------------------------------------
Gui, Font, c000000 s10 w700, arial
Gui, Add, Text,, Block This Keyword:
Gui, Add, Edit, w200 vKeyWord
Gui, Add, Button, Default x10 y70 w80 h30 w80, OK
Gui, Add, Button, Default x135 y70 w80 h30 w80, CANCEL
Gui, Show, w225 h120, Firewall Blocker
return  ; End of auto-execute section. The script is idle until the user does something.
; -------------------------------------------
; Gui
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Labels
; -------------------------------------------
GuiClose:
{
	ExitApp
}
return
; -------------------------------------------
ButtonOK:
{
  Gui, Submit
	KeyWord := StrReplace(KeyWord, A_Space, "")
	if (StrLen(KeyWord) > 0)
	{
		; -------------------------------------------
		Firewall_Blocker(KeyWord) ; KeyWord Item to Search for
		; -------------------------------------------
	}
	else
	{
		; -------------------------------------------
		Msg := Msg "Nothing Was Entered as a Keyword`n"
		MsgBox, 48, , %Msg%, 2
		Msg := ""
		ExitApp
		; -------------------------------------------
	}
}
return
; -------------------------------------------
ButtonCANCEL:
{
  ExitApp
}
return
; -------------------------------------------
; Labels
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Hot Key
; -------------------------------------------
Esc::
{
	ExitApp
}
return
; -------------------------------------------
; Hot Key
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; END OF FILE
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
