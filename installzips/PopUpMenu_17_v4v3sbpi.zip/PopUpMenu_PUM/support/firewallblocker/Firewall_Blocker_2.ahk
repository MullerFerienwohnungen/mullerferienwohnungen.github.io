﻿#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
#SingleInstance, force
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include %ProgramFiles%\PopUpMenu_PUM\Array_FromFile.ahk ; Array_FromFile(FilePath) ; > Array
#Include %ProgramFiles%\PopUpMenu_PUM\Array_Add.ahk ; Array_Add(ThisArray, AddThis, ThisPos) ; > ThisArray
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Menu, Tray, Icon, %A_ScriptDir%\ScriptImage.png
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Functions
; -------------------------------------------
GetBlockList(BlockKeyWord) ; > (Array_BlockItems)
{
	; -------------------------------------------
	SearchPath := "C:\Users\" A_UserName "\AppData"
	Array_FilePath := Array_Add(Array_FilePath, SearchPath, "End") ; > ThisArray
	; -------------------------------------------
	SearchPath := "C:\Users\" A_UserName "\Documents"
	Array_FilePath := Array_Add(Array_FilePath, SearchPath, "End") ; > ThisArray
	; -------------------------------------------
	SearchPath := "C:\Windows\SysWOW64\config\systemprofile\AppData"
	Array_FilePath := Array_Add(Array_FilePath, SearchPath, "End") ; > ThisArray
	; -------------------------------------------
	SearchPath := "C:\Program Files"
	Array_FilePath := Array_Add(Array_FilePath, SearchPath, "End") ; > ThisArray
	; -------------------------------------------
	SearchPath := "C:\Program Files (x86)"
	Array_FilePath := Array_Add(Array_FilePath, SearchPath, "End") ; > ThisArray
	; -------------------------------------------
	SearchPath := "C:\ProgramData"
	Array_FilePath := Array_Add(Array_FilePath, SearchPath, "End") ; > ThisArray
	; -------------------------------------------
	;
	; -------------------------------------------
	MiddleScreen     := A_ScreenWidth * 0.5
	; -------------------------------------------
	;
	; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@	
	Msg := Msg "Creating in Firewall Block List`n"
	CoordMode, ToolTip, Screen
	ToolTip, %Msg%, %MiddleScreen%, 0
	; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	;
	; -------------------------------------------
	for Index, FilePath in Array_FilePath
	{
		Loop, Files, %FilePath%\*.exe, R
		{
			; -------------------------------------------
			ThisFilePath := A_LoopFileFullPath			
			; -------------------------------------------
			if (InStr(ThisFilePath, BlockKeyWord) > 0)
			{
		    ; -------------------------------------------
			  Array_BlockItems := Array_Add(Array_BlockItems, ThisFilePath, "End") ; > ThisArray
			  ; -------------------------------------------
		  }
		} ; Loop, Files, %FilePath%\*.exe, R
	} ; for Index, FilePath in Array_FilePath
	; -------------------------------------------
	;
	; -------------------------------------------
	Length_Array_BlockItems := Array_BlockItems.MaxIndex() ; Highest Length
	if (Length_Array_BlockItems == 0 or Length_Array_BlockItems == "")
	{
  	Array_BlockItems := []
	}
	; -------------------------------------------
	return Array_BlockItems
	; -------------------------------------------
} ; Function (GetBlockList)
; -------------------------------------------
Firewall_Blocker(BlockThisKeyWord) ; > Nothing
{
	; -------------------------------------------
	if (BlockThisKeyWord != "")
	{
		; -------------------------------------------
		InOut           := "out"
		BlockAllow      := "block"
		; -------------------------------------------
		ThisBat     := A_Temp "\Firewall_Blocker_RunBat.bat"
		ThisBatLink := A_Temp "\Firewall_Blocker_RunBat.lnk"
		; -------------------------------------------
		FileDelete, %ThisBat%
		FileDelete, %ThisBatLink%
		; -------------------------------------------
		;
		; -------------------------------------------
		ArrayBlockTheseExes        := GetBlockList(BlockThisKeyWord) ; > (ArrayBlockTheseExes)
		Length_ArrayBlockTheseExes := ArrayBlockTheseExes.MaxIndex() ; Highest Length
		; -------------------------------------------
		;
		;
		; -------------------------------------------
		if (Length_ArrayBlockTheseExes > 0)
		{
			; -------------------------------------------
		  EnableFireWall_RunBat() ; > Nothing
			NotificationFireWall_RunBat(1)
			; -------------------------------------------
			for Index, ItemPath in ArrayBlockTheseExes
			{
				; -------------------------------------------
				SplitPath, ItemPath, ItemExtName
				BatEntry := "netsh advfirewall firewall add rule name=""" BlockThisKeyWord """ dir=" InOut " program=""" ItemPath """ protocol=tcp localport=23 action=" BlockAllow
				; -------------------------------------------
				FileAppend, %BatEntry%`n, %ThisBat%
				; -------------------------------------------			
			} ; for Index, ItemPath in ArrayBlockTheseExes
	    ; -------------------------------------------
	    Sleep, 100
	    ; -------------------------------------------
		}
			
			
			
			Msg := Msg "Number of Items = " Length_ArrayBlockTheseExes "`n"
			if FileExist(ThisBat)
			{
				Msg := Msg "Exist`n"
				Msg := Msg "ThisBat = " ThisBat "`n"
			}
			else
			{
				Msg := Msg "NOT Exist`n"
				Msg := Msg "ThisBat = " ThisBat "`n"
			}
			MsgBox, 4096, , %Msg%
			Msg := ""
			ExitApp
			
			
			
			
			if FileExist(ThisBat)
			{
	      FileCreateShortcut, %ThisBat%, %ThisBatLink%
	      Sleep, 100
	      ; -------------------------------------------
	      Run %ThisBatLink% , , Hide
	      Sleep, 1000
	      ; -------------------------------------------
			} ; if FileExist(ThisBat)
		} ; if (Length_ArrayBlockTheseExes > 0)
	} ; if (ArrayKeyWord != "")
} ; Function (Firewall_Blocker)
; -------------------------------------------
EnableFireWall_RunBat() ; > Nothing
{
	; -------------------------------------------
	ThisBat     := A_Temp "\EnableFireWall_Bat.bat"
	ThisBatLink := A_Temp "\EnableFireWall_Bat.lnk"
	; -------------------------------------------
	FileDelete, %ThisBat%
	FileDelete, %ThisBatLink%
	; -------------------------------------------
	;
	; -------------------------------------------
	BatEntry := "netsh.exe advfirewall set allprofiles state on"
	; -------------------------------------------
	FileAppend, %BatEntry%`n, %ThisBat%
	Sleep, 100
	; -------------------------------------------
	FileCreateShortcut, %ThisBat%, %ThisBatLink%
	Sleep, 100
	; -------------------------------------------
	Run %ThisBatLink% , , Hide
	Sleep, 1000
	; -------------------------------------------
} ; Function (EnableFireWall_Bat)
; -------------------------------------------
NotificationFireWall_RunBat(Notification) ; Notification [0,1] > Nothing
{
	; -------------------------------------------
	ThisBat     := A_Temp "\NotificationFireWall_Bat.bat"
	ThisBatLink := A_Temp "\NotificationFireWall_Bat.lnk"
	; -------------------------------------------
	FileDelete, %ThisBat%
	FileDelete, %ThisBatLink%
	; -------------------------------------------
	;
	; -------------------------------------------
	BatEntry_1 := "netsh advfirewall set allprofiles firewallpolicy blockinbound,allowoutbound"
	; -------------------------------------------
	if (Notification == 1)
	{
		BatEntry_2 := "netsh advfirewall set allprofiles settings inboundusernotification enable"
		BatEntry_3 := "netsh advfirewall set allprofiles settings unicastresponsetomulticast enable"
	}
	else
	{
		BatEntry_2 := "netsh advfirewall set allprofiles settings inboundusernotification disable"
		BatEntry_3 := "netsh advfirewall set allprofiles settings unicastresponsetomulticast disable"
	}
	; -------------------------------------------
	BatEntry_4 := "netsh advfirewall set allprofiles logging filename %SystemRoot%\System32\LogFiles\Firewall\pfirewall.log"
	; -------------------------------------------
	FileAppend, %BatEntry%`n, %ThisBat%
	Sleep, 100
	; -------------------------------------------
	FileCreateShortcut, %ThisBat%, %ThisBatLink%
	Sleep, 100
	; -------------------------------------------
	Run %ThisBatLink% , , Hide
	Sleep, 1000
	; -------------------------------------------
} ; Function (NotificationFireWall_Bat)
; -------------------------------------------
; Functions
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Gui
; -------------------------------------------
Gui, Font, c000000 s10 w700, arial
Gui, Add, Text,, Block This Keyword:
Gui, Add, Edit, w200 vKeyWord
Gui, Add, Text, x10 y75, CLICK OK To Start
Gui, Add, Button, Default x10 y100 w80 h30 w80, OK
Gui, Add, Button, Default x135 y100 w80 h30 w80, CANCEL
Gui, Show, w225 h150, Firewall Blocker
return  ; End of auto-execute section. The script is idle until the user does something.
; -------------------------------------------
; Gui
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Labels
; -------------------------------------------
GuiClose:
{
	ExitApp
}
return
; -------------------------------------------
ButtonOK:
{
  Gui, Submit
	;~ KeyWord := StrReplace(KeyWord, A_Space, "")
	if (StrLen(KeyWord) > 0)
	{
		; -------------------------------------------
		EnableFireWall_RunBat() ; > Nothing
		NotificationFireWall_RunBat(1) ; Notification [0,1] > Nothing
		Firewall_Blocker(KeyWord) ; KeyWord Item to Search for
		; -------------------------------------------
		Sleep, 1000
		ExitApp
		; -------------------------------------------
	}
	else
	{
		; -------------------------------------------
		Msg := Msg "Nothing Was Entered as a Keyword`n"
		MsgBox, 48, , %Msg%, 2
		Msg := ""
		ExitApp
		; -------------------------------------------
	}
}
return
; -------------------------------------------
ButtonCANCEL:
{
  ExitApp
}
return
; -------------------------------------------
; Labels
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Hot Key
; -------------------------------------------
Esc::
{
	ExitApp
}
return
; -------------------------------------------
; Hot Key
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; END OF FILE
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
