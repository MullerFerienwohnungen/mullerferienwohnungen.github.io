#NoEnv
#MaxHotkeysPerInterval 99000000
#HotkeyInterval 99000000
#KeyHistory 0
ListLines Off
Process, Priority, , A
SetBatchLines, -1
SetKeyDelay, -1, -1
SetMouseDelay, -1
SetDefaultMouseSpeed, 0
SetWinDelay, -1
SetControlDelay, -1
SendMode Input
#SingleInstance, force
Menu, Tray, Icon, %A_ScriptDir%\PopUpMenu_Tracker.png
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;Gui, Tracker:Color, c6e5d2 ; Green Color
;Gui, Tracker:Color, edbaba ; Red Color
;Gui, Tracker:Color, 333f82 ; Blue Color
;Gui, Tracker:Color, eceba9 ; Yellow Color
;Gui, Tracker:Color, e7d8fe ; Purple Color
; -------------------------------------------
; Green Color  +c099d29
; Red Color    +cc42424
; Blue Color   +c333f82
; Yellow Color +cff9000
; Black Color  +c000000
; Purple Color +ce7d8fe
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Tracker_ConnectCheck(flag=0x40) ; > [0/1]
{
  return DllCall("Wininet.dll\InternetGetConnectedState", "Str", flag,"Int",0)
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Path Check / Image Check
; -------------------------------------------
Path_IMG := A_AppData "\PopUpMenu_PUM\PopUpMenu_Tracker"
; -------------------------------------------
if !FileExist(Path_IMG)
{
	FileCreateDir, %Path_IMG%
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
IMG_Img_1 := A_ProgramFiles "\PopUpMenu_PUM\support\PopUpMenu_Tracker\ClipBoardEmpty.png"
if !FileExist(IMG_Img_1)
{
	; -------------------------------------------
	CP_Img_1 := A_ProgramFiles "\PopUpMenu_PUM\support\PopUpMenu_Tracker\ClipBoardEmpty.png"
	if FileExist(CP_Img_1)
	{
		FileCopy, %CP_Img_1%, %IMG_Img_1%, 1
	}
	else
	{
		; -------------------------------------------
		URL_Img_1 := "https://mullerferienwohnungen.github.io/support/PopUpMenu_Tracker/ClipBoardEmpty.png"
		if (Tracker_ConnectCheck(flag=0x40)  == 1) ; Has Internet Connection
		{
			URLDownloadToFile, %URL_Img_1%, %IMG_Img_1% ; (385_8)(Get IP [www.netikus.net URL Address])/(380_6)(Get IP [System Text File Path])
		}
		; -------------------------------------------
	}
	; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
IMG_Img_2 := A_ProgramFiles "\PopUpMenu_PUM\support\PopUpMenu_Tracker\ClipBoardFull.png"
if !FileExist(IMG_Img_2)
{
	; -------------------------------------------
	CP_Img_2 := A_ProgramFiles "\PopUpMenu_PUM\support\PopUpMenu_Tracker\ClipBoardFull.png"
	if FileExist(CP_Img_2)
	{
		FileCopy, %CP_Img_2%, %IMG_Img_2%, 1
	}
	else
	{
		; -------------------------------------------
		URL_Img_2 := "https://mullerferienwohnungen.github.io/support/PopUpMenu_Tracker/ClipBoardFull.png"
		if (Tracker_ConnectCheck(flag=0x40) == 1) ; Has Internet Connection
		{
			URLDownloadToFile, %URL_Img_2%, %IMG_Img_2% ; (385_8)(Get IP [www.netikus.net URL Address])/(380_6)(Get IP [System Text File Path])
		}
		; -------------------------------------------
	}
	; -------------------------------------------
}
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
if (InStr(A_ScriptDir, "Dropbox") > 0)
{
	; -------------------------------------------
	Path_DAT := A_ScriptDir "\PopUpMenu_Tracker" 
	; -------------------------------------------
}
else
{
	; -------------------------------------------
	Path_DAT := A_AppData "\PopUpMenu_PUM\PopUpMenu_Tracker"
	; -------------------------------------------
}
; -------------------------------------------
if !FileExist(Path_DAT)
{
	FileCreateDir, %Path_DAT%
}
; -------------------------------------------
;
; -------------------------------------------
Folder_PreSet := A_AppData "\PopUpMenu_PUM\PopUpMenu_Tracker\Presets"
if !FileExist(Folder_PreSet)
{
	FileCreateDir, %Folder_PreSet%
}
; -------------------------------------------
;
; -------------------------------------------
; Path Check
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#Include C:\Program Files\PopUpMenu_PUM\Array_FromFile.ahk ; Array_FromFile(AudioPath) ; > Array
#Include C:\Program Files\PopUpMenu_PUM\Array_Add.ahk ; Array_Add(ThisArray, AddThis, ThisPos) ; > ThisArray
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Functions
; -------------------------------------------
CurrentSelectedCategory() ; > Category
{
	; -------------------------------------------
	GuiControlGet, OnOff_CatBrowser, Tracker:, Radio_CatBrowser
	GuiControlGet, OnOff_CatBuySell, Tracker:, Radio_CatBuySell
	GuiControlGet, OnOff_CatContact, Tracker:, Radio_CatContact
	GuiControlGet, OnOff_CatDownLoad, Tracker:, Radio_CatDownLoad
	GuiControlGet, OnOff_CatEmail, Tracker:, Radio_CatEmail
	GuiControlGet, OnOff_CatForum, Tracker:, Radio_CatForum
	GuiControlGet, OnOff_CatGame, Tracker:, Radio_CatGame
	GuiControlGet, OnOff_CatGame, Tracker:, Radio_CatGame
	GuiControlGet, OnOff_CatInternet, Tracker:, Radio_CatInternet
	GuiControlGet, OnOff_CatMailer, Tracker:, Radio_CatMailer
	GuiControlGet, OnOff_CatMoney, Tracker:, Radio_CatMoney
	GuiControlGet, OnOff_CatProgram, Tracker:, Radio_CatProgram
	GuiControlGet, OnOff_CatSocial, Tracker:, Radio_CatSocial
	GuiControlGet, OnOff_CatWebHosting, Tracker:, Radio_CatWebHosting
	GuiControlGet, OnOff_CatWebTempletes, Tracker:, Radio_CatWebTempletes
	GuiControlGet, OnOff_CatWebSite, Tracker:, Radio_CatWebSite
	GuiControlGet, OnOff_CatNone, Tracker:, Radio_CatNone
	; -------------------------------------------
	if (OnOff_CatBrowser == 1)
	{
		Category := "browser"
	}
	else if (OnOff_CatBuySell == 1)
	{
		Category := "buysell"
	}
	else if (OnOff_CatContact == 1)
	{
		Category := "contact"
	}
	else if (OnOff_CatDownLoad == 1)
	{
		Category := "downLoad"
	}
	else if (OnOff_CatEmail == 1)
	{
		Category := "email"
	}
	else if (OnOff_CatForum == 1)
	{
		Category := "forum"
	}
	else if (OnOff_CatGame == 1)
	{
		Category := "game"
	}
	else if (OnOff_CatInternet == 1)
	{
		Category := "internet"
	}
	else if (OnOff_CatMailer == 1)
	{
		Category := "mailer"
	}
	else if (OnOff_CatMoney == 1)
	{
		Category := "money"
	}
	else if (OnOff_CatProgram == 1)
	{
		Category := "program"
	}
	else if (OnOff_CatSocial == 1)
	{
		Category := "social"
	}
	else if (OnOff_CatWebHosting == 1)
	{
		Category := "webhosting"
	}
	else if (OnOff_CatWebTempletes == 1)
	{
		Category := "WebTempletes"
	}
	else if (OnOff_CatWebSite == 1)
	{
		Category := "website"
	}
	else if (OnOff_CatNone == 1)
	{
		Category := "none"
	}
	; -------------------------------------------
	return Category
	; -------------------------------------------
}
; -------------------------------------------
HasRecordChanged(Array_ThisRecord) ; > 0 -OR- 1
{
	;~ ; -------------------------------------------
	;~ Name_FileRecord    := Array_CurrentRecord.1
	;~ Value_Category     := Array_CurrentRecord.2
	;~ Value_RecordName   := Array_CurrentRecord.3
	;~ Value_SubName      := Array_CurrentRecord.4
	;~ Value_Password     := Array_CurrentRecord.5
	;~ Value_FirstEmail   := Array_CurrentRecord.6
	;~ Value_SecondEmail  := Array_CurrentRecord.7
	;~ Value_LoginName    := Array_CurrentRecord.8
	;~ Value_BusinessName := Array_CurrentRecord.9
	;~ Value_FirstName    := Array_CurrentRecord.10
	;~ Value_LastName     := Array_CurrentRecord.11
	;~ Value_Phone        := Array_CurrentRecord.12
	;~ Value_Country      := Array_CurrentRecord.13
	;~ Value_City         := Array_CurrentRecord.14
	;~ Value_Street       := Array_CurrentRecord.15
	;~ Value_ZipCode      := Array_CurrentRecord.16
	;~ Value_Notes        := Array_CurrentRecord.17
	;~ ; -------------------------------------------
	RecordHasChanged := 0
	; -------------------------------------------
	for Index_HasRecordChanged, ThisRecord in Array_ThisRecord
	{
		; -------------------------------------------
		ThisRecord := StrReplace(ThisRecord, "<EMPTY>", "")
		StringLower, ThisRecord, ThisRecord
		; -------------------------------------------
		;
		; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		if (Index_HasRecordChanged == 2) ; Radio_Category
		{
			SelectedCategory := CurrentSelectedCategory() ; > Category
			if (ThisRecord != SelectedCategory)
			{
				RecordHasChanged := 1
			}
		}
		; -------------------------------------------
		else if (Index_HasRecordChanged == 3) ; Edit_RecordName
		{
			; -------------------------------------------
			RecordCurrentValue := ""
			; -------------------------------------------
			GuiControlGet, RecordCurrentValue, Tracker:, Edit_RecordName
			StringLower, RecordCurrentValue, RecordCurrentValue
			; -------------------------------------------
			RecordCurrentValue := RemoveTabSpace(RecordCurrentValue)
			; -------------------------------------------
			if (ThisRecord != RecordCurrentValue)
			{
				RecordHasChanged := 1
			} ; if (ThisRecord != RecordCurrentValue)
		}
		; -------------------------------------------
		else if (Index_HasRecordChanged == 4) ; Edit_SubName
		{
			; -------------------------------------------
			RecordCurrentValue := ""
			; -------------------------------------------
			GuiControlGet, RecordCurrentValue, Tracker:, Edit_SubName
			StringLower, RecordCurrentValue, RecordCurrentValue
			; -------------------------------------------
			RecordCurrentValue := RemoveTabSpace(RecordCurrentValue)
			; -------------------------------------------
			if (ThisRecord != RecordCurrentValue)
			{
				RecordHasChanged := 1
			} ; if (ThisRecord != RecordCurrentValue)
		}
		; -------------------------------------------
		else if (Index_HasRecordChanged == 5) ; Edit_Password
		{
			; -------------------------------------------
			RecordCurrentValue := ""
			; -------------------------------------------
			GuiControlGet, RecordCurrentValue, Tracker:, Edit_Password
			StringLower, RecordCurrentValue, RecordCurrentValue
			; -------------------------------------------
			RecordCurrentValue := RemoveTabSpace(RecordCurrentValue)
			; -------------------------------------------
			if (ThisRecord != RecordCurrentValue)
			{
				RecordHasChanged := 1
			} ; if (ThisRecord != RecordCurrentValue)
		}
		; -------------------------------------------
		else if (Index_HasRecordChanged == 6) ; Edit_FirstEmail
		{
			; -------------------------------------------
			RecordCurrentValue := ""
			; -------------------------------------------
			GuiControlGet, RecordCurrentValue, Tracker:, Edit_FirstEmail
			StringLower, RecordCurrentValue, RecordCurrentValue
			; -------------------------------------------
			RecordCurrentValue := RemoveTabSpace(RecordCurrentValue)
			; -------------------------------------------
			if (ThisRecord != RecordCurrentValue)
			{
				RecordHasChanged := 1
			} ; if (ThisRecord != RecordCurrentValue)
		}
		; -------------------------------------------
		else if (Index_HasRecordChanged == 7) ; Edit_SecondEmail
		{
			; -------------------------------------------
			RecordCurrentValue := ""
			; -------------------------------------------
			GuiControlGet, RecordCurrentValue, Tracker:, Edit_SecondEmail
			StringLower, RecordCurrentValue, RecordCurrentValue
			; -------------------------------------------
			RecordCurrentValue := RemoveTabSpace(RecordCurrentValue)
			; -------------------------------------------
			if (ThisRecord != RecordCurrentValue)
			{
				RecordHasChanged := 1
			} ; if (ThisRecord != RecordCurrentValue)
		}
		; -------------------------------------------
		else if (Index_HasRecordChanged == 8) ; Edit_LoginName
		{
			; -------------------------------------------
			RecordCurrentValue := ""
			; -------------------------------------------
			GuiControlGet, RecordCurrentValue, Tracker:, Edit_LoginName
			StringLower, RecordCurrentValue, RecordCurrentValue
			; -------------------------------------------
			RecordCurrentValue := RemoveTabSpace(RecordCurrentValue)
			; -------------------------------------------
			if (ThisRecord != RecordCurrentValue)
			{
				RecordHasChanged := 1
			} ; if (ThisRecord != RecordCurrentValue)
		}
		; -------------------------------------------
		else if (Index_HasRecordChanged == 9) ; Edit_BusinessName
		{
			; -------------------------------------------
			RecordCurrentValue := ""
			; -------------------------------------------
			GuiControlGet, RecordCurrentValue, Tracker:, Edit_BusinessName
			StringLower, RecordCurrentValue, RecordCurrentValue
			; -------------------------------------------
			RecordCurrentValue := RemoveTabSpace(RecordCurrentValue)
			; -------------------------------------------
			if (ThisRecord != RecordCurrentValue)
			{
			  RecordHasChanged := 1
			} ; if (ThisRecord != RecordCurrentValue)
		}
		; -------------------------------------------
		else if (Index_HasRecordChanged == 10) ; Edit_FirstName
		{
			; -------------------------------------------
			RecordCurrentValue := ""
			; -------------------------------------------
			GuiControlGet, RecordCurrentValue, Tracker:, Edit_FirstName
			StringLower, RecordCurrentValue, RecordCurrentValue
			; -------------------------------------------
			RecordCurrentValue := RemoveTabSpace(RecordCurrentValue)
			; -------------------------------------------
			if (ThisRecord != RecordCurrentValue)
			{
			  RecordHasChanged := 1
			} ; if (ThisRecord != RecordCurrentValue)
		}
		; -------------------------------------------
		else if (Index_HasRecordChanged == 11) ; Edit_LastName
		{
			; -------------------------------------------
			RecordCurrentValue := ""
			; -------------------------------------------
			GuiControlGet, RecordCurrentValue, Tracker:, Edit_LastName
			StringLower, RecordCurrentValue, RecordCurrentValue
			; -------------------------------------------
			RecordCurrentValue := RemoveTabSpace(RecordCurrentValue)
			; -------------------------------------------
			if (ThisRecord != RecordCurrentValue)
			{
			  RecordHasChanged := 1
			} ; if (ThisRecord != RecordCurrentValue)
		}
		; -------------------------------------------
		else if (Index_HasRecordChanged == 12) ; Edit_Phone
		{
			; -------------------------------------------
			RecordCurrentValue := ""
			; -------------------------------------------
			GuiControlGet, RecordCurrentValue, Tracker:, Edit_Phone
			StringLower, RecordCurrentValue, RecordCurrentValue
			; -------------------------------------------
			RecordCurrentValue := RemoveTabSpace(RecordCurrentValue)
			; -------------------------------------------
			if (ThisRecord != RecordCurrentValue)
			{
				RecordHasChanged := 1
			} ; if (ThisRecord != RecordCurrentValue)
		}
		; -------------------------------------------
		else if (Index_HasRecordChanged == 13) ; Edit_Country
		{
			; -------------------------------------------
			RecordCurrentValue := ""
			; -------------------------------------------
			GuiControlGet, RecordCurrentValue, Tracker:, Edit_Country
			StringLower, RecordCurrentValue, RecordCurrentValue
			; -------------------------------------------
			RecordCurrentValue := RemoveTabSpace(RecordCurrentValue)
			; -------------------------------------------
			if (ThisRecord != RecordCurrentValue)
			{
				RecordHasChanged := 1
			} ; if (ThisRecord != RecordCurrentValue)
		}
		; -------------------------------------------
		else if (Index_HasRecordChanged == 14) ; Edit_City
		{
			; -------------------------------------------
			RecordCurrentValue := ""
			; -------------------------------------------
			GuiControlGet, RecordCurrentValue, Tracker:, Edit_City
			StringLower, RecordCurrentValue, RecordCurrentValue
			; -------------------------------------------
			RecordCurrentValue := RemoveTabSpace(RecordCurrentValue)
			; -------------------------------------------
			if (ThisRecord != RecordCurrentValue)
			{
				RecordHasChanged := 1
			} ; if (ThisRecord != RecordCurrentValue)
		}
		; -------------------------------------------
		else if (Index_HasRecordChanged == 15) ; Edit_Street
		{
			; -------------------------------------------
			RecordCurrentValue := ""
			; -------------------------------------------
			GuiControlGet, RecordCurrentValue, Tracker:, Edit_Street
			StringLower, RecordCurrentValue, RecordCurrentValue
			; -------------------------------------------
			RecordCurrentValue := RemoveTabSpace(RecordCurrentValue)
			; -------------------------------------------
			if (ThisRecord != RecordCurrentValue)
			{
			  RecordHasChanged := 1
			} ; if (ThisRecord != RecordCurrentValue)
		}
		; -------------------------------------------
		else if (Index_HasRecordChanged == 16) ; Edit_ZipCode
		{
			; -------------------------------------------
			RecordCurrentValue := ""
			; -------------------------------------------
			GuiControlGet, RecordCurrentValue, Tracker:, Edit_ZipCode
			StringLower, RecordCurrentValue, RecordCurrentValue
			; -------------------------------------------
			RecordCurrentValue := RemoveTabSpace(RecordCurrentValue)
			; -------------------------------------------
			if (ThisRecord != RecordCurrentValue)
			{
			  RecordHasChanged := 1
			} ; if (ThisRecord != RecordCurrentValue)
		}
		; -------------------------------------------
		else if (Index_HasRecordChanged == 17) ; Edit_Notes
		{
			; -------------------------------------------
			RecordCurrentValue := ""
			; -------------------------------------------
			GuiControlGet, RecordCurrentValue, Tracker:, Edit_Notes
			StringLower, RecordCurrentValue, RecordCurrentValue
			; -------------------------------------------
			RecordCurrentValue := RemoveTabSpace(RecordCurrentValue)
			; -------------------------------------------
			if (ThisRecord != RecordCurrentValue)
			{
			  RecordHasChanged := 1
			} ; if (ThisRecord != RecordCurrentValue)
		}
		; -------------------------------------------
		;
		; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	} ; for Index_HasRecordChanged, ThisRecord in Array_ThisRecord
	; -------------------------------------------
	;
	; -------------------------------------------
	return RecordHasChanged
	; -------------------------------------------
}
; -------------------------------------------
RemoveTabSpace(ThisText) ; > ThisText (With Out Leading or Ending, Spaces or Tabs)
{
	; -------------------------------------------
	while (SubStr(ThisText, 1, 1) == A_Space) ; Remoce All Leading Spaces
	{
		ThisText := SubStr(ThisText, 2)
  }
	while (SubStr(ThisText, StrLen(ThisText)) == A_Space) ; Remoce All Ending Spaces
	{
		ThisText := SubStr(ThisText, 1, StrLen(ThisText) - 1)
  }
	while (SubStr(ThisText, 1, 1) == A_Tab) ; Remoce All Leading Tabs
	{
		ThisText := SubStr(ThisText, 2)
  }
	while (SubStr(ThisText, StrLen(ThisText)) == A_Tab) ; Remoce All Ending Tab
	{
		ThisText := SubStr(ThisText, 1, StrLen(ThisText) - 1)
  }
	; -------------------------------------------
	return ThisText
	; -------------------------------------------
}
; -------------------------------------------
PreSetEditCheck(ThisEditObject, PreSetValue_1, PreSetValue_2, PreSetValue_3)
{
	; -------------------------------------------
	GuiControlGet, ThisValue, Tracker:, %ThisEditObject%
	StringLower, ThisValue, ThisValue
	; -------------------------------------------
	ThisValue := RemoveTabSpace(ThisValue) ; > ThisText (With Out Leading or Ending, Spaces or Tabs)
	; -------------------------------------------
	;
	; -------------------------------------------
	StringLower, PreSetValue_1, PreSetValue_1
	StringLower, PreSetValue_2, PreSetValue_2
	StringLower, PreSetValue_3, PreSetValue_3
	; -------------------------------------------
	ThisObject := StrReplace(ThisEditObject, "Edit_", "")
	; -------------------------------------------
	ThisPreSet_1 := "Radio_" ThisObject "_1"
	ThisPreSet_2 := "Radio_" ThisObject "_2"
	ThisPreSet_3 := "Radio_" ThisObject "_3"
	; -------------------------------------------
	;
	; -------------------------------------------
	if (StrLen(ThisValue) > 0) ; This Edit Feild Has a Value
	{
		; -------------------------------------------
	  if (ThisValue == PreSetValue_1)
	  {
  		; -------------------------------------------
		  GuiControl, Tracker:+cc42424, %ThisPreSet_1% ; Red Color
		  ; -------------------------------------------
		  if (StrLen(PreSetValue_2) > 0) ; This PreSet Has a Value
		  {
  			GuiControl, Tracker:+c099d29, %ThisPreSet_2% ; Green Color
		  }
		  else ; This PreSet Has NO Value
		  {
  			GuiControl, Tracker:+c000000, %ThisPreSet_2% ; Black Color
		  }
		  ; -------------------------------------------
		  if (StrLen(PreSetValue_3) > 0) ; This PreSet Has a Value
		  {
  			GuiControl, Tracker:+c099d29, %ThisPreSet_3% ; Green Color
		  }
		  else ; This PreSet Has NO Value
		  {
  			GuiControl, Tracker:+c000000, %ThisPreSet_3% ; Black Color
		  }
		  ; -------------------------------------------
	  }
	  else if (ThisValue == PreSetValue_2)
	  {
  		; -------------------------------------------
		  GuiControl, Tracker:+cc42424, %ThisPreSet_2% ; Red Color
		  ; -------------------------------------------
		  if (StrLen(PreSetValue_1) > 0) ; This PreSet Has a Value
		  {
  			GuiControl, Tracker:+c099d29, %ThisPreSet_1% ; Green Color
		  }
		  else ; This PreSet Has NO Value
		  {
  			GuiControl, Tracker:+c000000, %ThisPreSet_1% ; Black Color
		  }
		  ; -------------------------------------------
		  if (StrLen(PreSetValue_3) > 0) ; This PreSet Has a Value
		  {
  			GuiControl, Tracker:+c099d29, %ThisPreSet_3% ; Green Color
		  }
		  else ; This PreSet Has NO Value
		  {
  			GuiControl, Tracker:+c000000, %ThisPreSet_3% ; Black Color
		  }
		  ; -------------------------------------------
	  }
	  else if (ThisValue == PreSetValue_3)
	  {
  		; -------------------------------------------
		  GuiControl, Tracker:+cc42424, %ThisPreSet_3% ; Red Color
		  ; -------------------------------------------
		  if (StrLen(PreSetValue_1) > 0) ; This PreSet Has a Value
		  {
  			GuiControl, Tracker:+c099d29, %ThisPreSet_1% ; Green Color
		  }
		  else ; This PreSet Has NO Value
		  {
  			GuiControl, Tracker:+c000000, %ThisPreSet_1% ; Black Color
		  }
		  ; -------------------------------------------
		  if (StrLen(PreSetValue_2) > 0) ; This PreSet Has a Value
		  {
  			GuiControl, Tracker:+c099d29, %ThisPreSet_2% ; Green Color
		  }
		  else ; This PreSet Has NO Value
		  {
  			GuiControl, Tracker:+c000000, %ThisPreSet_2% ; Black Color
		  }
		  ; -------------------------------------------
	  }
	  else ; Not = to ThisValue
	  {
  		; -------------------------------------------
		  if (StrLen(PreSetValue_1) > 0) ; This PreSet Has a Value
		  {
  			; -------------------------------------------
			  GuiControlGet, OnOff_ThisPreSet_1, Tracker:, %ThisPreSet_1%
			  ; -------------------------------------------
			  if (OnOff_ThisPreSet_1 == 1)
			  {
  				GuiControl, Tracker:+cff9000, %ThisPreSet_1% ; Yellow Color
			  }
			  else
			  {
  				GuiControl, Tracker:+c099d29, %ThisPreSet_1% ; Green Color
			  }
			  ; -------------------------------------------
		  }
		  else ; This PreSet Has NO Value
		  {
  			GuiControl, Tracker:+c000000, %ThisPreSet_1% ; Black Color
		  }
		  ; -------------------------------------------
		  if (StrLen(PreSetValue_2) > 0) ; This PreSet Has a Value
		  {
  			; -------------------------------------------
			  GuiControlGet, OnOff_ThisPreSet_2, Tracker:, %ThisPreSet_2%
			  ; -------------------------------------------
			  if (OnOff_ThisPreSet_2 == 1)
			  {
  				GuiControl, Tracker:+cff9000, %ThisPreSet_2% ; Yellow Color
			  }
			  else
			  {
  				GuiControl, Tracker:+c099d29, %ThisPreSet_2% ; Green Color
			  }
			  ; -------------------------------------------
		  }
		  else ; This PreSet Has NO Value
		  {
  			GuiControl, Tracker:+c000000, %ThisPreSet_2% ; Black Color
		  }
		  ; -------------------------------------------
		  if (StrLen(PreSetValue_3) > 0) ; This PreSet Has a Value
		  {
  			; -------------------------------------------
			  GuiControlGet, OnOff_ThisPreSet_3, Tracker:, %ThisPreSet_3%
			  ; -------------------------------------------
			  if (OnOff_ThisPreSet_3 == 1)
			  {
  				GuiControl, Tracker:+cff9000, %ThisPreSet_3% ; Yellow Color
			  }
			  else
			  {
  				GuiControl, Tracker:+c099d29, %ThisPreSet_3% ; Green Color
			  }
			  ; -------------------------------------------
		  }
		  else ; This PreSet Has NO Value
		  {
  			GuiControl, Tracker:+c000000, %ThisPreSet_3% ; Black Color
		  }
		  ; -------------------------------------------
	  } ; else ; Not = to ThisValue
	  ; ------------------------------------------
	}
	else ; ThisValue in Empty
	{
		; -------------------------------------------
		if (StrLen(PreSetValue_1) > 0) ; This PreSet Has a Value
		{
			; -------------------------------------------
			GuiControlGet, OnOff_ThisPreSet_1, Tracker:, %ThisPreSet_1%
			; -------------------------------------------
			if (OnOff_ThisPreSet_1 == 1)
			{
				GuiControl, Tracker:+cff9000, %ThisPreSet_1% ; Yellow Color
			}
			else
			{
				GuiControl, Tracker:+c099d29, %ThisPreSet_1% ; Green Color
			}
			; -------------------------------------------
		}
		else ; This PreSet Has NO Value
		{
			GuiControl, Tracker:+c000000, %ThisPreSet_1% ; Black Color
		}
		; -------------------------------------------
		if (StrLen(PreSetValue_2) > 0) ; This PreSet Has a Value
		{
			; -------------------------------------------
			GuiControlGet, OnOff_ThisPreSet_2, Tracker:, %ThisPreSet_2%
			; -------------------------------------------
			if (OnOff_ThisPreSet_2 == 1)
			{
				GuiControl, Tracker:+cff9000, %ThisPreSet_2% ; Yellow Color
			}
			else
			{
				GuiControl, Tracker:+c099d29, %ThisPreSet_2% ; Green Color
			}
			; -------------------------------------------
		}
		else ; This PreSet Has NO Value
		{
			GuiControl, Tracker:+c000000, %ThisPreSet_2% ; Black Color
		}
		; -------------------------------------------
		if (StrLen(PreSetValue_3) > 0) ; This PreSet Has a Value
		{
			; -------------------------------------------
			GuiControlGet, OnOff_ThisPreSet_3, Tracker:, %ThisPreSet_3%
			; -------------------------------------------
			if (OnOff_ThisPreSet_3 == 1)
			{
				GuiControl, Tracker:+cff9000, %ThisPreSet_3% ; Yellow Color
			}
			else
			{
				GuiControl, Tracker:+c099d29, %ThisPreSet_3% ; Green Color
			}
			; -------------------------------------------
		}
		else ; This PreSet Has NO Value
		{
			GuiControl, Tracker:+c000000, %ThisPreSet_3% ; Black Color
		}
		; -------------------------------------------
	} ; else ; ThisValue in Empty
	; ------------------------------------------		
	;
	; -------------------------------------------
	GuiControl, Tracker:MoveDraw, %ThisPreSet_1%
	GuiControl, Tracker:MoveDraw, %ThisPreSet_2%
	GuiControl, Tracker:MoveDraw, %ThisPreSet_3%
	; -------------------------------------------
}
; -------------------------------------------
GetPreSet(ThisObject, Selected) ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_FirstEmail_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
{
  ; -------------------------------------------
  if (InStr(A_ScriptDir, "Dropbox") > 0)
  {
  	Path_DAT := A_ScriptDir "\PopUpMenu_Tracker"
  }
  else
  {
  	Path_DAT := A_AppData "\PopUpMenu_PUM\PopUpMenu_Tracker"
  }
  ; -------------------------------------------
  ;
	; -------------------------------------------
	File_PreSet := A_AppData "\PopUpMenu_PUM\PopUpMenu_Tracker\Presets\" ThisObject ".txt"
	; -------------------------------------------
  if !FileExist(File_PreSet) ; Check if Exist | Create File
	{
	  FileAppend, %A_Space%, %File_PreSet%, UTF-8
		Sleep, 250
	}
  ; -------------------------------------------
	;
	; -------------------------------------------
	ThisPreSet_1 := "Radio_" ThisObject "_1"
	ThisPreSet_2 := "Radio_" ThisObject "_2"
	ThisPreSet_3 := "Radio_" ThisObject "_3"
	; -------------------------------------------
	if (Selected == 1)
	{
		; -------------------------------------------
		GuiControlGet, OnOff_ThisPreSet_1, Tracker:, %ThisPreSet_1%
		GuiControlGet, OnOff_ThisPreSet_2, Tracker:, %ThisPreSet_2%
		GuiControlGet, OnOff_ThisPreSet_3, Tracker:, %ThisPreSet_3%
		; -------------------------------------------
		if (OnOff_ThisPreSet_1 == 1)
		{
			Selected := ThisPreSet_1
		}
		else if (OnOff_ThisPreSet_2 == 1)
		{
			Selected := ThisPreSet_2
		}
		else if (OnOff_ThisPreSet_3 == 1)
		{
			Selected := ThisPreSet_3
		}
		; -------------------------------------------
	}
	; -------------------------------------------
	FileReadLine, PreSetValue_1, %File_PreSet%, 1
	FileReadLine, PreSetValue_2, %File_PreSet%, 2
	FileReadLine, PreSetValue_3, %File_PreSet%, 3
	; -------------------------------------------
	;
	; -------------------------------------------
	PreSetValue_1 := RemoveTabSpace(PreSetValue_1) ; > ThisText (With Out Leading or Ending, Spaces or Tabs)
	PreSetValue_2 := RemoveTabSpace(PreSetValue_2) ; > ThisText (With Out Leading or Ending, Spaces or Tabs)
	PreSetValue_3 := RemoveTabSpace(PreSetValue_3) ; > ThisText (With Out Leading or Ending, Spaces or Tabs)
	; -------------------------------------------
	;
	; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	if (Selected == ThisPreSet_1)
	{
		; -------------------------------------------
		GuiControl, Tracker:+cc42424, %ThisPreSet_1% ; Red Color
		; -------------------------------------------
		if (StrLen(PreSetValue_2) > 0)
		{
		  GuiControl, Tracker:+c099d29, %ThisPreSet_2% ; Green Color
		}
		else
		{
		  GuiControl, Tracker:+c000000, %ThisPreSet_2% ; Black Color
		}
		; -------------------------------------------
		if (StrLen(PreSetValue_3) > 0)
		{
		  GuiControl, Tracker:+c099d29, %ThisPreSet_3% ; Green Color
		}
		else
		{
		  GuiControl, Tracker:+c000000, %ThisPreSet_3% ; Black Color
		}
		; -------------------------------------------
	}
	; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	else if (Selected == ThisPreSet_2)
	{
		; -------------------------------------------
		GuiControl, Tracker:+cc42424, %ThisPreSet_2% ; Red Color
		; -------------------------------------------
		if (StrLen(PreSetValue_1) > 0)
		{
		  GuiControl, Tracker:+c099d29, %ThisPreSet_1% ; Green Color
		}
		else
		{
		  GuiControl, Tracker:+c000000, %ThisPreSet_1% ; Black Color
		}
		; -------------------------------------------
		if (StrLen(PreSetValue_3) > 0)
		{
		  GuiControl, Tracker:+c099d29, %ThisPreSet_3% ; Green Color
		}
		else
		{
		  GuiControl, Tracker:+c000000, %ThisPreSet_3% ; Black Color
		}
		; -------------------------------------------
	}
	; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	else if (Selected == ThisPreSet_3)
	{
		; -------------------------------------------
		GuiControl, Tracker:+cc42424, %ThisPreSet_3% ; Red Color
		; -------------------------------------------
		if (StrLen(PreSetValue_1) > 0)
		{
		  GuiControl, Tracker:+c099d29, %ThisPreSet_1% ; Green Color
		}
		else
		{
		  GuiControl, Tracker:+c000000, %ThisPreSet_1% ; Black Color
		}
		; -------------------------------------------
		if (StrLen(PreSetValue_3) > 0)
		{
		  GuiControl, Tracker:+c099d29, %ThisPreSet_2% ; Green Color
		}
		else
		{
		  GuiControl, Tracker:+c000000, %ThisPreSet_2% ; Black Color
		}
		; -------------------------------------------
	}
	; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	else
	{
		; -------------------------------------------
		if (StrLen(PreSetValue_1) > 0)
		{
		  GuiControl, Tracker:+c099d29, %ThisPreSet_1% ; Green Color
		}
		else
		{
		  GuiControl, Tracker:+c000000, %ThisPreSet_1% ; Black Color
		}
		; -------------------------------------------
		if (StrLen(PreSetValue_2) > 0)
		{
		  GuiControl, Tracker:+c099d29, %ThisPreSet_2% ; Green Color
		}
		else
		{
		  GuiControl, Tracker:+c000000, %ThisPreSet_2% ; Black Color
		}
		; -------------------------------------------
		if (StrLen(PreSetValue_3) > 0)
		{
		  GuiControl, Tracker:+c099d29, %ThisPreSet_3% ; Green Color
		}
		else
		{
		  GuiControl, Tracker:+c000000, %ThisPreSet_3% ; Black Color
		}
		; -------------------------------------------
		GuiControl, Tracker:, %ThisPreSet_1%, 0
		GuiControl, Tracker:, %ThisPreSet_2%, 0
		GuiControl, Tracker:, %ThisPreSet_3%, 0
		; -------------------------------------------
	}
	; -------------------------------------------
	;
	; -------------------------------------------
	GuiControl, Tracker:MoveDraw, %ThisPreSet_1%
	GuiControl, Tracker:MoveDraw, %ThisPreSet_2%
	GuiControl, Tracker:MoveDraw, %ThisPreSet_3%
	; -------------------------------------------
	ReturnArray := [PreSetValue_1, PreSetValue_2, PreSetValue_3]
	return ReturnArray
	; -------------------------------------------
}
; -------------------------------------------
SelectCategoryRadio(SelectThis) ; "" or "Object Name" will Select That Radio
{
	; -------------------------------------------
	if (StrLen(SelectThis) > 0)
	{
		GuiControl, Tracker:, %SelectThis%, 1
	}
	; -------------------------------------------
	Array_Radio := ["Radio_CatBrowser", "Radio_CatBuySell", "Radio_CatContact", "Radio_CatDownLoad", "Radio_CatEmail", "Radio_CatForum", "Radio_CatGame", "Radio_CatInternet", "Radio_CatMailer", "Radio_CatMoney", "Radio_CatProgram", "Radio_CatSocial", "Radio_CatWebHosting", "Radio_CatWebTempletes", "Radio_CatWebSite", "Radio_CatNone"]
	; -------------------------------------------
	for Index, ThisRadio in Array_Radio
	{
		; -------------------------------------------
		GuiControlGet, This_OnOff, Tracker:, %ThisRadio%
		; -------------------------------------------
		if (This_OnOff == 1)
		{
			; -------------------------------------------
			GuiControl, Tracker:+cc42424, %ThisRadio% ; Red Color
			GuiControl, Tracker:MoveDraw, %ThisRadio%
			; -------------------------------------------
		}
		else
		{
			; -------------------------------------------
			GuiControl, Tracker:+c000000, %ThisRadio% ; Black Color
			GuiControl, Tracker:MoveDraw, %ThisRadio%
			; -------------------------------------------
		}
	} ; for Index, ThisRadio in Array_Radio
}
; -------------------------------------------
GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
{
	; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	; Color_TitleTextDisplay
	; -------------------------------------------
	if (Color_TitleTextDisplay == "Green")
	{
		; -------------------------------------------
		GuiControl, Tracker:+c099d29, TitleTextDisplay ; Green Color
		; -------------------------------------------
	}
	else if (Color_TitleTextDisplay == "Red")
	{
		; -------------------------------------------
		GuiControl, Tracker:+cc42424, TitleTextDisplay ; Red Color
		; -------------------------------------------
	}
	else if (Color_TitleTextDisplay == "Blue")
	{
		; -------------------------------------------
		GuiControl, Tracker:+c333f82, TitleTextDisplay ; Blue Color
		; -------------------------------------------
	}
	else if (Color_TitleTextDisplay != "X")
	{
		; -------------------------------------------
		GuiControl, Tracker:+c000000, TitleTextDisplay ; Black Color
		; -------------------------------------------
	}
	; -------------------------------------------
	; Color_TitleTextDisplay
	; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	;
		; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	; Color_TextDisplay
	; -------------------------------------------
	if (Color_TextDisplay == "Green")
	{
		; -------------------------------------------
		GuiControl, Tracker:+c099d29, TextDisplay ; Green Color
		; -------------------------------------------
	}
	else if (Color_TextDisplay == "Red")
	{
		; -------------------------------------------
		GuiControl, Tracker:+cc42424, TextDisplay ; Red Color
		; -------------------------------------------
	}
	else if (Color_TextDisplay == "Blue")
	{
		; -------------------------------------------
		GuiControl, Tracker:+c333f82, TextDisplay ; Blue Color
		; -------------------------------------------
	}
	else if (Color_TextDisplay != "X")
	{
		; -------------------------------------------
		GuiControl, Tracker:+c000000, TextDisplay ; Black Color
		; -------------------------------------------
	}
	; -------------------------------------------
	; Color_TextDisplay
	; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
	; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	; Value_TitleTextDisplay | Value_TextDisplay
	; -------------------------------------------
	if (Value_TitleTextDisplay != "X")
	{
    GuiControl, Tracker:, TitleTextDisplay, %Value_TitleTextDisplay%
	}
	if (Value_TextDisplay != "X")
	{
    GuiControl, Tracker:, TextDisplay, %Value_TextDisplay%
	}
	; -------------------------------------------
	; Value_TitleTextDisplay | Value_TextDisplay
	; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	;
	; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	; MoveDraw
	; -------------------------------------------
	if (Color_TitleTextDisplay != "X" or Value_TitleTextDisplay != "X")
	{
    GuiControl, Tracker:MoveDraw, TitleTextDisplay
	}
	if (Color_TextDisplay != "X" or Value_TextDisplay != "X")
	{
    GuiControl, Tracker:MoveDraw, TextDisplay
	}
	; -------------------------------------------
	; MoveDraw
	; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
}
; -------------------------------------------
ConvertTime(ConvertThis) ; "" > ("2023.07.10.15.12.29") | ("2023.07.10.15.12.29") > "10 Jul, 2023 @ 15:12:29"
{
	; -------------------------------------------
	if (ConvertThis == "")
	{
    ; -------------------------------------------
    FormatTime, TimeRightNow , , yyyyMMddHHmmss
    ThisYear := SubStr(TimeRightNow, 1, 4)
    ThisMonth := SubStr(TimeRightNow, 5, 2)
    ThisDay := SubStr(TimeRightNow, 7, 2)
    ThisHour := SubStr(TimeRightNow, 9, 2)
    ThisMinute := SubStr(TimeRightNow, 11, 2)
    ThisSecond := SubStr(TimeRightNow, 13, 2)
    ; -------------------------------------------
		ReturnTime := ThisYear "." ThisMonth "." ThisDay "." ThisHour "." ThisMinute "." ThisSecond
		; -------------------------------------------
	}
	else
	{
		; -------------------------------------------
		NumYear := SubStr(ConvertThis, 1, 4)
		NumMonth := SubStr(ConvertThis, 6, 2)
		NumDay := SubStr(ConvertThis, 9, 2)
		NumHour := SubStr(ConvertThis, 12, 2)
		NumMinute := SubStr(ConvertThis, 15, 2)
		NumSecond := SubStr(ConvertThis, 18, 2)
		; -------------------------------------------
		if (NumMonth == "01")
		{
			NameMonth := "Jan"
		}
		else if (NumMonth == "02")
		{
			NameMonth := "Feb"
		}
		else if (NumMonth == "03")
		{
			NameMonth := "Mar"
		}
		else if (NumMonth == "04")
		{
			NameMonth := "Apr"
		}
		else if (NumMonth == "05")
		{
			NameMonth := "May"
		}
		else if (NumMonth == "06")
		{
			NameMonth := "Jun"
		}
		else if (NumMonth == "07")
		{
			NameMonth := "Jul"
		}
		else if (NumMonth == "08")
		{
			NameMonth := "Aug"
		}
		else if (NumMonth == "09")
		{
			NameMonth := "Sep"
		}
		else if (NumMonth == "10")
		{
			NameMonth := "Oct"
		}
		else if (NumMonth == "11")
		{
			NameMonth := "Nov"
		}
		else if (NumMonth == "12")
		{
			NameMonth := "Dec"
		}
		; -------------------------------------------
		ReturnTime := NumDay " " NameMonth ", " NumYear " @ " NumHour ":" NumMinute ":" NumSecond
		; -------------------------------------------
	}
	; -------------------------------------------
	return ReturnTime
	; -------------------------------------------
}
; -------------------------------------------
PasswordGenerate() ; > OnOff_Password
{
	; -------------------------------------------
	; is Length 62
	Array_Character := ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "`!", "`@", "`#", "`$", "`^", "`&", "`*", "`_", "`+", "`="]
	; -------------------------------------------
	GuiControlGet, PasswordLength, Tracker:, Edit_PasswordLength
	if (PasswordLength == "" or PasswordLength == 0)
	{
		PasswordLength := 16
		GuiControl, Tracker:, Edit_PasswordLength , 16
	}
	; -------------------------------------------
	while (InStr(ThisPassword, "`!") == 0 && InStr(ThisPassword, "`@") == 0 && InStr(ThisPassword, "`#") == 0 && InStr(ThisPassword, "`$") == 0 && InStr(ThisPassword, "`^") == 0 && InStr(ThisPassword, "`&") == 0 && InStr(ThisPassword, "`*") == 0 && InStr(ThisPassword, "`_") == 0 && InStr(ThisPassword, "`+") == 0 && InStr(ThisPassword, "`=") == 0)
	{
		; -------------------------------------------
		ThisPassword := ""
		; -------------------------------------------
	  Loop %PasswordLength%
	  {
  		; -------------------------------------------
		  Random, GetNum, 1, 62
		  AddThis := Array_Character[GetNum]
		  ThisPassword := AddThis ThisPassword
		  ; -------------------------------------------
	  }
		; -------------------------------------------
	}
	; -------------------------------------------
	GuiControl, Tracker:, Edit_Password, %ThisPassword%
	; -------------------------------------------
	;
	; -------------------------------------------
	GuiControl, Tracker:+cc42424, Radio_Password ; Red Color
	GuiControl, Tracker:MoveDraw, Radio_Password
	; -------------------------------------------
	OnOff_Password := 1
	; -------------------------------------------
	Sleep, 100
	GuiControl, Tracker:, Radio_Password, %OnOff_Password%
	; -------------------------------------------
	BlockInput, Off
	BlockInput, MouseMoveOff
	; -------------------------------------------
	return OnOff_Password
	; -------------------------------------------
}
; -------------------------------------------
Clipboard_OnOff(Gui_Object, OnClipBoard) ; > OnClipBoard
{
  ; -------------------------------------------
	Image_Clipboard_F := A_ProgramFiles "\PopUpMenu_PUM\support\PopUpMenu_Tracker\ClipBoardFull.png"
	Image_Clipboard_E := A_ProgramFiles "\PopUpMenu_PUM\support\PopUpMenu_Tracker\ClipBoardEmpty.png"
	; -------------------------------------------
	Clipboard_Object := "Clipboard_" Gui_Object
	Edit_Object := "Edit_" Gui_Object
	; -------------------------------------------
	if (Gui_Object == OnClipBoard) ; ON Clipboard, REMOVE From Clipboard
	{
		; -------------------------------------------
		OnClipBoard := ""
		Clipboard := 
		; -------------------------------------------
		GuiControl, Tracker:, %Clipboard_Object%, %Image_Clipboard_E%
		GuiControl, Tracker:MoveDraw, %Clipboard_Object%
		GuiControl, Tracker:Show, %Clipboard_Object%,
		; -------------------------------------------
	} ; ON Clipboard, REMOVE From Clipboard
	else  ; Not On Clipboard, Add to Clipboard
	{
	  ; -------------------------------------------
	  GuiControlGet, ObjectValue, Tracker:, %Edit_Object%
  	; -------------------------------------------
		;
  	; -------------------------------------------
		ObjectValue := RemoveTabSpace(ObjectValue) ; > ThisText (With Out Leading or Ending, Spaces or Tabs)
  	; -------------------------------------------
		;
	  ; -------------------------------------------
		if (StrLen(ObjectValue) > 0)
		{
			; -------------------------------------------
			OnClipBoard := Gui_Object
			Clipboard := 
			Sleep, 100
			Clipboard := ObjectValue
			; -------------------------------------------
			if (Gui_Object == "Notes")
			{
				GuiControl, Tracker:, Clipboard_Notes, %Image_Clipboard_F%
				GuiControl, Tracker:MoveDraw, Clipboard_Notes
			  GuiControl, Tracker:Show, Clipboard_Notes
			}
			else if (Gui_Object == "Password")
			{
				GuiControl, Tracker:, Clipboard_Password, %Image_Clipboard_F%
				GuiControl, Tracker:MoveDraw, Clipboard_Password
			  GuiControl, Tracker:Show, Clipboard_Password
			}
			else if (Gui_Object == "FirstEmail")
			{
				GuiControl, Tracker:, Clipboard_FirstEmail, %Image_Clipboard_F%
				GuiControl, Tracker:MoveDraw, Clipboard_FirstEmail
			  GuiControl, Tracker:Show, Clipboard_FirstEmail
			}
			else if (Gui_Object == "SecondEmail")
			{
				GuiControl, Tracker:, Clipboard_SecondEmail, %Image_Clipboard_F%
				GuiControl, Tracker:MoveDraw, Clipboard_SecondEmail
			  GuiControl, Tracker:Show, Clipboard_SecondEmail
			}
			else if (Gui_Object == "LoginName")
			{
				GuiControl, Tracker:, Clipboard_LoginName, %Image_Clipboard_F%
				GuiControl, Tracker:MoveDraw, Clipboard_LoginName
			  GuiControl, Tracker:Show, Clipboard_LoginName
			}
			else if (Gui_Object == "BusinessName")
			{
				GuiControl, Tracker:, Clipboard_BusinessName, %Image_Clipboard_F%
				GuiControl, Tracker:MoveDraw, Clipboard_BusinessName
			  GuiControl, Tracker:Show, Clipboard_BusinessName
			}
			else if (Gui_Object == "FirstName")
			{
				GuiControl, Tracker:, Clipboard_FirstName, %Image_Clipboard_F%
				GuiControl, Tracker:MoveDraw, Clipboard_FirstName
			  GuiControl, Tracker:Show, Clipboard_FirstName
			}
			else if (Gui_Object == "LastName")
			{
				GuiControl, Tracker:, Clipboard_LastName, %Image_Clipboard_F%
				GuiControl, Tracker:MoveDraw, Clipboard_LastName
			  GuiControl, Tracker:Show, Clipboard_LastName
			}
			else if (Gui_Object == "Phone")
			{
				GuiControl, Tracker:, Clipboard_Phone, %Image_Clipboard_F%
				GuiControl, Tracker:MoveDraw, Clipboard_Phone
			  GuiControl, Tracker:Show, Clipboard_Phone
			}
			else if (Gui_Object == "Country")
			{
				GuiControl, Tracker:, Clipboard_Country, %Image_Clipboard_F%
				GuiControl, Tracker:MoveDraw, Clipboard_Country
			  GuiControl, Tracker:Show, Clipboard_Country
			}
			else if (Gui_Object == "City")
			{
				GuiControl, Tracker:, Clipboard_City, %Image_Clipboard_F%
				GuiControl, Tracker:MoveDraw, Clipboard_City
			  GuiControl, Tracker:Show, Clipboard_City
			}
			else if (Gui_Object == "Street")
			{
				GuiControl, Tracker:, Clipboard_Street, %Image_Clipboard_F%
				GuiControl, Tracker:MoveDraw, Clipboard_Street
			  GuiControl, Tracker:Show, Clipboard_Street
			}
			else if (Gui_Object == "ZipCode")
			{
				GuiControl, Tracker:, Clipboard_ZipCode, %Image_Clipboard_F%
				GuiControl, Tracker:MoveDraw, Clipboard_ZipCode
			  GuiControl, Tracker:Show, Clipboard_ZipCode
			}
			; -------------------------------------------
		}
	} ; Not On Clipboard, Add to Clipboard
	; -------------------------------------------
	;
	; -------------------------------------------
	Array_ClipboardObject := ["Clipboard_Notes", "Clipboard_Password", "Clipboard_FirstEmail", "Clipboard_SecondEmail", "Clipboard_LoginName", "Clipboard_BusinessName", "Clipboard_FirstName", "Clipboard_LastName", "Clipboard_Phone", "Clipboard_Country", "Clipboard_City", "Clipboard_Street", "Clipboard_ZipCode"]		
	; -------------------------------------------
	for Index, ThisClipObject in Array_ClipboardObject
	{
		; -------------------------------------------
		if (ThisClipObject != Clipboard_Object) ; All OTHER Clipboards that are Showing Now, Change to Empty Clipboard
		{
			; ------------------------------------------
		  GuiControlGet, CheckIfShowing, Tracker:Visible, %ThisClipObject%
		  ; -------------------------------------------
		  if (CheckIfShowing == 1) ; 1 = Is Showing, 0 = Not Being Shown
		  {
    	  GuiControl, Tracker:, %ThisClipObject%, %Image_Clipboard_E%
		    GuiControl, Tracker:Show, %ThisClipObject%,
		  }
		  ; -------------------------------------------
		} ; for Index, ThisClipObject in Array_ClipboardObject
	} ; for Index, ThisClipObject in Array_ClipboardObject
	; -------------------------------------------
	BlockInput, Off
	BlockInput, MouseMoveOff
	; -------------------------------------------
	return OnClipBoard
	; -------------------------------------------
}
; -------------------------------------------
Clipboard_ShowHide(Gui_Object, ShowHide) ; (ShowHide = "Show" or "Hide") > OnClipBoard
{
  ; -------------------------------------------
	Image_ClipBoardEmpty := A_ProgramFiles "\PopUpMenu_PUM\support\PopUpMenu_Tracker\ClipBoardEmpty.png"
	; -------------------------------------------
	Clipboard_Object := "Clipboard_" Gui_Object
	; -------------------------------------------
	if (ShowHide == "Show")
	{
		; -------------------------------------------
		GuiControl, Tracker:, %Clipboard_Object%, %Image_ClipBoardEmpty%
		GuiControl, Tracker:MoveDraw, %Clipboard_Object%
  	GuiControl, Tracker:Show, %Clipboard_Object%,
		; -------------------------------------------
	}
	else if (ShowHide == "Hide")
	{
		; -------------------------------------------
		GuiControl, Tracker:Hide, %Clipboard_Object%,
		; -------------------------------------------
	}
}
; -------------------------------------------
SetEditFields(Array_CurrentRecord)
{
	; -------------------------------------------
	ArrayEditFeild := ["RecordName", "SubName", "Password", "FirstEmail", "SecondEmail", "LoginName", "BusinessName", "FirstName", "LastName", "Phone", "Country", "City", "Street", "ZipCode", "Notes"]
	; -------------------------------------------
	Name_FileRecord    := Array_CurrentRecord.1
	Value_Category     := Array_CurrentRecord.2
	Value_RecordName   := Array_CurrentRecord.3
	Value_SubName      := Array_CurrentRecord.4
	Value_Password     := Array_CurrentRecord.5
	Value_FirstEmail   := Array_CurrentRecord.6
	Value_SecondEmail  := Array_CurrentRecord.7
	Value_LoginName    := Array_CurrentRecord.8
	Value_BusinessName := Array_CurrentRecord.9
	Value_FirstName    := Array_CurrentRecord.10
	Value_LastName     := Array_CurrentRecord.11
	Value_Phone        := Array_CurrentRecord.12
	Value_Country      := Array_CurrentRecord.13
	Value_City         := Array_CurrentRecord.14
	Value_Street       := Array_CurrentRecord.15
	Value_ZipCode      := Array_CurrentRecord.16
	Value_Notes        := Array_CurrentRecord.17
	; -------------------------------------------
	;
	for Index, GuiObject in ArrayEditFeild
	{
		; -------------------------------------------
		if (GuiObject == "RecordName")
		{
			; -------------------------------------------
	    if (Value_RecordName != "<EMPTY>")
	    {
    		; -------------------------------------------
		    GuiControl, Tracker:+cc42424, Radio_RecordName ; Red Color
		    GuiControl, Tracker:MoveDraw, Radio_RecordName
		    GuiControl, Tracker:, Radio_RecordName, 1
		    ; -------------------------------------------
		    GuiControl, Tracker:, Edit_RecordName, %Value_RecordName%
		    ; -------------------------------------------
	    }
	    else if (Value_RecordName == "<EMPTY>")
	    {
    		; -------------------------------------------
		    Clipboard_ShowHide(GuiObject, "Hide") ; (ShowHide = "Show" or "Hide") > OnClipBoard
		    ; -------------------------------------------
		    GuiControl, Tracker:+c000000, Radio_RecordName ; Black Color
		    GuiControl, Tracker:MoveDraw, Radio_RecordName
		    GuiControl, Tracker:, Radio_RecordName, 0
		    ; -------------------------------------------
		    GuiControl, Tracker:, Edit_RecordName,
		    ; -------------------------------------------
	    }
	    ; -------------------------------------------
		} ; if (GuiObject == "RecordName")
		; -------------------------------------------
		else if (GuiObject == "SubName")
		{
			; -------------------------------------------
	    if (Value_SubName != "<EMPTY>")
	    {
    		; -------------------------------------------
		    GuiControl, Tracker:+cc42424, Radio_SubName ; Red Color
		    GuiControl, Tracker:MoveDraw, Radio_SubName
		    GuiControl, Tracker:, Radio_SubName, 1
		    ; -------------------------------------------
		    GuiControl, Tracker:, Edit_SubName, %Value_SubName%
		    ; -------------------------------------------
	    }
	    else if (Value_SubName == "<EMPTY>")
	    {
    		; -------------------------------------------
		    Clipboard_ShowHide(GuiObject, "Hide") ; (ShowHide = "Show" or "Hide") > OnClipBoard
		    ; -------------------------------------------
		    GuiControl, Tracker:+c000000, Radio_SubName ; Black Color
		    GuiControl, Tracker:MoveDraw, Radio_SubName
		    GuiControl, Tracker:, Radio_SubName, 0
		    ; -------------------------------------------
		    GuiControl, Tracker:, Edit_SubName,
		    ; -------------------------------------------
	    }
	    ; -------------------------------------------
		} ; if (GuiObject == "SubName")
		; -------------------------------------------
		else if (GuiObject == "Password")
		{
			; -------------------------------------------
	    if (Value_Password != "<EMPTY>")
	    {
    		; -------------------------------------------
		    GuiControl, Tracker:+cc42424, Radio_Password ; Red Color
		    GuiControl, Tracker:MoveDraw, Radio_Password
		    GuiControl, Tracker:, Radio_Password, 1
		    ; -------------------------------------------
		    GuiControl, Tracker:, Edit_Password, %Value_Password%
		    ; -------------------------------------------
				Clipboard_ShowHide("Password", "Show") ; (ShowHide = "Show" or "Hide") > OnClipBoard
				; -------------------------------------------
	    }
	    else if (Value_Password == "<EMPTY>")
	    {
    		; -------------------------------------------
		    Clipboard_ShowHide(GuiObject, "Hide") ; (ShowHide = "Show" or "Hide") > OnClipBoard
		    ; -------------------------------------------
		    GuiControl, Tracker:+c000000, Radio_Password ; Black Color
		    GuiControl, Tracker:MoveDraw, Radio_Password
		    GuiControl, Tracker:, Radio_Password, 0
		    ; -------------------------------------------
		    GuiControl, Tracker:, Edit_Password,
		    ; -------------------------------------------
	    }
	    ; -------------------------------------------
		} ; if (GuiObject == "Password")
		; -------------------------------------------
		else if (GuiObject == "FirstEmail")
		{
			; -------------------------------------------
	    if (Value_FirstEmail != "<EMPTY>")
	    {
    		; -------------------------------------------
		    GuiControl, Tracker:+cc42424, Radio_FirstEmail ; Red Color
		    GuiControl, Tracker:MoveDraw, Radio_FirstEmail
		    GuiControl, Tracker:, Radio_FirstEmail, 1
		    ; -------------------------------------------
		    GuiControl, Tracker:, Edit_FirstEmail, %Value_FirstEmail%
		    ; -------------------------------------------
				Clipboard_ShowHide("FirstEmail", "Show") ; (ShowHide = "Show" or "Hide") > OnClipBoard
				; -------------------------------------------
	    }
	    else if (Value_FirstEmail == "<EMPTY>")
	    {
    		; -------------------------------------------
		    Clipboard_ShowHide(GuiObject, "Hide") ; (ShowHide = "Show" or "Hide") > OnClipBoard
		    ; -------------------------------------------
		    GuiControl, Tracker:+c000000, Radio_FirstEmail ; Black Color
		    GuiControl, Tracker:MoveDraw, Radio_FirstEmail
		    GuiControl, Tracker:, Radio_FirstEmail, 0
		    ; -------------------------------------------
		    GuiControl, Tracker:, Edit_FirstEmail,
		    ; -------------------------------------------
	    }
	    ; -------------------------------------------
		} ; if (GuiObject == "FirstEmail")
		; -------------------------------------------
		else if (GuiObject == "SecondEmail")
		{
			; -------------------------------------------
	    if (Value_SecondEmail != "<EMPTY>")
	    {
    		; -------------------------------------------
		    GuiControl, Tracker:+cc42424, Radio_SecondEmail ; Red Color
		    GuiControl, Tracker:MoveDraw, Radio_SecondEmail
		    GuiControl, Tracker:, Radio_SecondEmail, 1
		    ; -------------------------------------------
		    GuiControl, Tracker:, Edit_SecondEmail, %Value_SecondEmail%
		    ; -------------------------------------------
				Clipboard_ShowHide("SecondEmail", "Show") ; (ShowHide = "Show" or "Hide") > OnClipBoard
				; -------------------------------------------
	    }
	    else if (Value_SecondEmail == "<EMPTY>")
	    {
    		; -------------------------------------------
		    Clipboard_ShowHide(GuiObject, "Hide") ; (ShowHide = "Show" or "Hide") > OnClipBoard
		    ; -------------------------------------------
		    GuiControl, Tracker:+c000000, Radio_SecondEmail ; Black Color
		    GuiControl, Tracker:MoveDraw, Radio_SecondEmail
		    GuiControl, Tracker:, Radio_SecondEmail, 0
		    ; -------------------------------------------
		    GuiControl, Tracker:, Edit_SecondEmail,
		    ; -------------------------------------------
	    }
	    ; -------------------------------------------
		} ; if (GuiObject == "SecondEmail")
		; -------------------------------------------
		else if (GuiObject == "LoginName")
		{
			; -------------------------------------------
	    if (Value_LoginName != "<EMPTY>")
	    {
    		; -------------------------------------------
		    GuiControl, Tracker:+cc42424, Radio_LoginName ; Red Color
		    GuiControl, Tracker:MoveDraw, Radio_LoginName
		    GuiControl, Tracker:, Radio_LoginName, 1
		    ; -------------------------------------------
		    GuiControl, Tracker:, Edit_LoginName, %Value_LoginName%
		    ; -------------------------------------------
				Clipboard_ShowHide("LoginName", "Show") ; (ShowHide = "Show" or "Hide") > OnClipBoard
				; -------------------------------------------
	    }
	    else if (Value_LoginName == "<EMPTY>")
	    {
    		; -------------------------------------------
		    Clipboard_ShowHide(GuiObject, "Hide") ; (ShowHide = "Show" or "Hide") > OnClipBoard
		    ; -------------------------------------------
		    GuiControl, Tracker:+c000000, Radio_LoginName ; Black Color
		    GuiControl, Tracker:MoveDraw, Radio_LoginName
		    GuiControl, Tracker:, Radio_LoginName, 0
		    ; -------------------------------------------
		    GuiControl, Tracker:, Edit_LoginName,
		    ; -------------------------------------------
	    }
	    ; -------------------------------------------
		} ; if (GuiObject == "LoginName")
		; -------------------------------------------
		else if (GuiObject == "BusinessName")
		{
			; -------------------------------------------
	    if (Value_BusinessName != "<EMPTY>")
	    {
    		; -------------------------------------------
		    GuiControl, Tracker:+cc42424, Radio_BusinessName ; Red Color
		    GuiControl, Tracker:MoveDraw, Radio_BusinessName
		    GuiControl, Tracker:, Radio_BusinessName, 1
		    ; -------------------------------------------
		    GuiControl, Tracker:, Edit_BusinessName, %Value_BusinessName%
		    ; -------------------------------------------
				Clipboard_ShowHide("BusinessName", "Show") ; (ShowHide = "Show" or "Hide") > OnClipBoard
				; -------------------------------------------
	    }
	    else if (Value_BusinessName == "<EMPTY>")
	    {
    		; -------------------------------------------
		    Clipboard_ShowHide(GuiObject, "Hide") ; (ShowHide = "Show" or "Hide") > OnClipBoard
		    ; -------------------------------------------
		    GuiControl, Tracker:+c000000, Radio_BusinessName ; Black Color
		    GuiControl, Tracker:MoveDraw, Radio_BusinessName
		    GuiControl, Tracker:, Radio_BusinessName, 0
		    ; -------------------------------------------
		    GuiControl, Tracker:, Edit_BusinessName,
		    ; -------------------------------------------
	    }
	    ; -------------------------------------------
		} ; if (GuiObject == "BusinessName")
		; -------------------------------------------
    else if (GuiObject == "FirstName")
		{
			; -------------------------------------------
	    if (Value_FirstName != "<EMPTY>")
	    {
    		; -------------------------------------------
		    GuiControl, Tracker:+cc42424, Radio_FirstName ; Red Color
		    GuiControl, Tracker:MoveDraw, Radio_FirstName
		    GuiControl, Tracker:, Radio_FirstName, 1
		    ; -------------------------------------------
		    GuiControl, Tracker:, Edit_FirstName, %Value_FirstName%
		    ; -------------------------------------------
				Clipboard_ShowHide("FirstName", "Show") ; (ShowHide = "Show" or "Hide") > OnClipBoard
				; -------------------------------------------
	    }
	    else if (Value_FirstName == "<EMPTY>")
	    {
    		; -------------------------------------------
		    Clipboard_ShowHide(GuiObject, "Hide") ; (ShowHide = "Show" or "Hide") > OnClipBoard
		    ; -------------------------------------------
		    GuiControl, Tracker:+c000000, Radio_FirstName ; Black Color
		    GuiControl, Tracker:MoveDraw, Radio_FirstName
		    GuiControl, Tracker:, Radio_FirstName, 0
		    ; -------------------------------------------
		    GuiControl, Tracker:, Edit_FirstName,
		    ; -------------------------------------------
	    }
	    ; -------------------------------------------
		} ; if (GuiObject == "FirstName")
		; -------------------------------------------
		else if (GuiObject == "LastName")
		{
			; -------------------------------------------
	    if (Value_LastName != "<EMPTY>")
	    {
    		; -------------------------------------------
		    GuiControl, Tracker:+cc42424, Radio_LastName ; Red Color
		    GuiControl, Tracker:MoveDraw, Radio_LastName
		    GuiControl, Tracker:, Radio_LastName, 1
		    ; -------------------------------------------
		    GuiControl, Tracker:, Edit_LastName, %Value_LastName%
		    ; -------------------------------------------
				Clipboard_ShowHide("LastName", "Show") ; (ShowHide = "Show" or "Hide") > OnClipBoard
				; -------------------------------------------
	    }
	    else if (Value_LastName == "<EMPTY>")
	    {
    		; -------------------------------------------
		    Clipboard_ShowHide(GuiObject, "Hide") ; (ShowHide = "Show" or "Hide") > OnClipBoard
		    ; -------------------------------------------
		    GuiControl, Tracker:+c000000, Radio_LastName ; Black Color
		    GuiControl, Tracker:MoveDraw, Radio_LastName
		    GuiControl, Tracker:, Radio_LastName, 0
		    ; -------------------------------------------
		    GuiControl, Tracker:, Edit_LastName,
		    ; -------------------------------------------
	    }
	    ; -------------------------------------------
		} ; if (GuiObject == "LastName")
		; -------------------------------------------
		else if (GuiObject == "Phone")
		{
			; -------------------------------------------
	    if (Value_Phone != "<EMPTY>")
	    {
    		; -------------------------------------------
		    GuiControl, Tracker:+cc42424, Radio_Phone ; Red Color
		    GuiControl, Tracker:MoveDraw, Radio_Phone
		    GuiControl, Tracker:, Radio_Phone, 1
		    ; -------------------------------------------
		    GuiControl, Tracker:, Edit_Phone, %Value_Phone%
		    ; -------------------------------------------
				Clipboard_ShowHide("Phone", "Show") ; (ShowHide = "Show" or "Hide") > OnClipBoard
				; -------------------------------------------
	    }
	    else if (Value_Phone == "<EMPTY>")
	    {
    		; -------------------------------------------
		    Clipboard_ShowHide(GuiObject, "Hide") ; (ShowHide = "Show" or "Hide") > OnClipBoard
		    ; -------------------------------------------
		    GuiControl, Tracker:+c000000, Radio_Phone ; Black Color
		    GuiControl, Tracker:MoveDraw, Radio_Phone
		    GuiControl, Tracker:, Radio_Phone, 0
		    ; -------------------------------------------
		    GuiControl, Tracker:, Edit_Phone,
		    ; -------------------------------------------
	    }
	    ; -------------------------------------------
		} ; if (GuiObject == "Phone")
		; -------------------------------------------
		else if (GuiObject == "Country")
		{
			; -------------------------------------------
	    if (Value_Country != "<EMPTY>")
	    {
    		; -------------------------------------------
		    GuiControl, Tracker:+cc42424, Radio_Country ; Red Color
		    GuiControl, Tracker:MoveDraw, Radio_Country
		    GuiControl, Tracker:, Radio_Country, 1
		    ; -------------------------------------------
		    GuiControl, Tracker:, Edit_Country, %Value_Country%
		    ; -------------------------------------------
				Clipboard_ShowHide("Country", "Show") ; (ShowHide = "Show" or "Hide") > OnClipBoard
				; -------------------------------------------
	    }
	    else if (Value_Country == "<EMPTY>")
	    {
    		; -------------------------------------------
		    Clipboard_ShowHide(GuiObject, "Hide") ; (ShowHide = "Show" or "Hide") > OnClipBoard
		    ; -------------------------------------------
		    GuiControl, Tracker:+c000000, Radio_Country ; Black Color
		    GuiControl, Tracker:MoveDraw, Radio_Country
		    GuiControl, Tracker:, Radio_Country, 0
		    ; -------------------------------------------
		    GuiControl, Tracker:, Edit_Country,
		    ; -------------------------------------------
	    }
	    ; -------------------------------------------
		} ; if (GuiObject == "Country")
		; -------------------------------------------
		else if (GuiObject == "City")
		{
			; -------------------------------------------
	    if (Value_City != "<EMPTY>")
	    {
    		; -------------------------------------------
		    GuiControl, Tracker:+cc42424, Radio_City ; Red Color
		    GuiControl, Tracker:MoveDraw, Radio_City
		    GuiControl, Tracker:, Radio_City, 1
		    ; -------------------------------------------
		    GuiControl, Tracker:, Edit_City, %Value_City%
		    ; -------------------------------------------
				Clipboard_ShowHide("City", "Show") ; (ShowHide = "Show" or "Hide") > OnClipBoard
				; -------------------------------------------
	    }
	    else if (Value_City == "<EMPTY>")
	    {
    		; -------------------------------------------
		    Clipboard_ShowHide(GuiObject, "Hide") ; (ShowHide = "Show" or "Hide") > OnClipBoard
		    ; -------------------------------------------
		    GuiControl, Tracker:+c000000, Radio_City ; Black Color
		    GuiControl, Tracker:MoveDraw, Radio_City
		    GuiControl, Tracker:, Radio_City, 0
		    ; -------------------------------------------
		    GuiControl, Tracker:, Edit_City,
		    ; -------------------------------------------
	    }
	    ; -------------------------------------------
		} ; if (GuiObject == "City")
		; -------------------------------------------
		else if (GuiObject == "Street")
		{
			; -------------------------------------------
	    if (Value_Street != "<EMPTY>")
	    {
    		; -------------------------------------------
		    GuiControl, Tracker:+cc42424, Radio_Street ; Red Color
		    GuiControl, Tracker:MoveDraw, Radio_Street
		    GuiControl, Tracker:, Radio_Street, 1
		    ; -------------------------------------------
		    GuiControl, Tracker:, Edit_Street, %Value_Street%
		    ; -------------------------------------------
				Clipboard_ShowHide("Street", "Show") ; (ShowHide = "Show" or "Hide") > OnClipBoard
				; -------------------------------------------
	    }
	    else if (Value_Street == "<EMPTY>")
	    {
    		; -------------------------------------------
		    Clipboard_ShowHide(GuiObject, "Hide") ; (ShowHide = "Show" or "Hide") > OnClipBoard
		    ; -------------------------------------------
		    GuiControl, Tracker:+c000000, Radio_Street ; Black Color
		    GuiControl, Tracker:MoveDraw, Radio_Street
		    GuiControl, Tracker:, Radio_Street, 0
		    ; -------------------------------------------
		    GuiControl, Tracker:, Edit_Street,
		    ; -------------------------------------------
	    }
	    ; -------------------------------------------
		} ; if (GuiObject == "Street")
		; -------------------------------------------
		else if (GuiObject == "ZipCode")
		{
			; -------------------------------------------
	    if (Value_ZipCode != "<EMPTY>")
	    {
    		; -------------------------------------------
		    GuiControl, Tracker:+cc42424, Radio_ZipCode ; Red Color
		    GuiControl, Tracker:MoveDraw, Radio_ZipCode
		    GuiControl, Tracker:, Radio_ZipCode, 1
		    ; -------------------------------------------
		    GuiControl, Tracker:, Edit_ZipCode, %Value_ZipCode%
		    ; -------------------------------------------
				Clipboard_ShowHide("ZipCode", "Show") ; (ShowHide = "Show" or "Hide") > OnClipBoard
				; -------------------------------------------
	    }
	    else if (Value_ZipCode == "<EMPTY>")
	    {
    		; -------------------------------------------
		    Clipboard_ShowHide(GuiObject, "Hide") ; (ShowHide = "Show" or "Hide") > OnClipBoard
		    ; -------------------------------------------
		    GuiControl, Tracker:+c000000, Radio_ZipCode ; Black Color
		    GuiControl, Tracker:MoveDraw, Radio_ZipCode
		    GuiControl, Tracker:, Radio_ZipCode, 0
		    ; -------------------------------------------
		    GuiControl, Tracker:, Edit_ZipCode,
		    ; -------------------------------------------
	    }
	    ; -------------------------------------------
		} ; if (GuiObject == "ZipCode")
		; -------------------------------------------
		else if (GuiObject == "Notes")
		{
			; -------------------------------------------
	    if (Value_Notes != "<EMPTY>")
	    {
    		; -------------------------------------------
		    GuiControl, Tracker:+cc42424, Radio_Notes ; Red Color
		    GuiControl, Tracker:MoveDraw, Radio_Notes
		    GuiControl, Tracker:, Radio_Notes, 1
		    ; -------------------------------------------
		    GuiControl, Tracker:, Edit_Notes, %Value_Notes%
		    ; -------------------------------------------
				Clipboard_ShowHide("Notes", "Show") ; (ShowHide = "Show" or "Hide") > OnClipBoard
				; -------------------------------------------
	    }
	    else if (Value_Notes == "<EMPTY>")
	    {
    		; -------------------------------------------
		    Clipboard_ShowHide(GuiObject, "Hide") ; (ShowHide = "Show" or "Hide") > OnClipBoard
		    ; -------------------------------------------
		    GuiControl, Tracker:+c000000, Radio_Notes ; Black Color
		    GuiControl, Tracker:MoveDraw, Radio_Notes
		    GuiControl, Tracker:, Radio_Notes, 0
		    ; -------------------------------------------
		    GuiControl, Tracker:, Edit_Notes,
		    ; -------------------------------------------
	    }
	    ; -------------------------------------------
		} ; if (GuiObject == "Notes")
		; -------------------------------------------
	} ; for Index, GuiObject in ArrayEditFeild
	; -------------------------------------------
}
; -------------------------------------------
CategorySearch(ArrayAllRecords) ; ArrayAllRecords > [ListBox_Search_List, Array_SearchList]
{
	; -------------------------------------------
	Reset_EditFields()
	; -------------------------------------------
	Array_ToSort := ""
  Array_Sorted := "" 
  Array_ThisRecord :=  ""
  Array_SearchList :=  ""
  ArrayReturn :=  ""
  ListBox_Search_List := ""
	; -------------------------------------------
	Category := CurrentSelectedCategory() ; > Category
	; -------------------------------------------
	;
	; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	; (Array_ToSort) Pre to put displayed list in alphabetical order
	; -------------------------------------------
	Array_ToSort =: ""
	; -------------------------------------------
	for Index, ArrayThisRecord in ArrayAllRecords
	{
		; -------------------------------------------
		; ArrayThisRecord := [A_LoopFileFullPath, Value_Category, Value_RecordName, Value_SubName]
    ; ArrayAllRecords := [ArrayThisRecord, ArrayThisRecord, etc]
		; -------------------------------------------
		FileRecord       := ArrayThisRecord.1
		Value_Category   := ArrayThisRecord.2
		Value_RecordName := ArrayThisRecord.3
		Value_SubName    := ArrayThisRecord.4
		; -------------------------------------------
		if (Category == "none") ; All Categories
		{
			; -------------------------------------------
			if (StrLen(Value_SubName) > 0)
			{
				Text_ThisRecord := "(_" Value_Category "_)(_" Value_RecordName "_)(_" Value_SubName "_)"
			}
			else
			{
				Text_ThisRecord := "(_" Value_Category "_)(_" Value_RecordName "_)"
			}
			; -------------------------------------------
			Array_ToSort := Array_Add(Array_ToSort, Text_ThisRecord, ThisPos) ; > ThisArray
			; -------------------------------------------
		} ; if (Category == "none") ; All Categories
		else ; Spicific Category
		{
			; -------------------------------------------
			if (Category == Value_Category)
			{
				; -------------------------------------------
			  if (StrLen(Value_SubName) > 0)
				{
				  Text_ThisRecord := "(_" Value_RecordName "_)(_" Value_SubName "_)"
				}
				else
				{
					Text_ThisRecord := "(_" Value_RecordName "_)"
				}
				; -------------------------------------------
				Array_ToSort := Array_Add(Array_ToSort, Text_ThisRecord, ThisPos) ; > ThisArray
				; -------------------------------------------
			} ; if (Category == Value_Category)
			; -------------------------------------------
		} ; else ; Spicific Category
		; -------------------------------------------
	} ; for Index, ArrayThisRecord in ArrayAllRecords
	; -------------------------------------------
	; (Array_ToSort) Pre to put displayed list in alphabetical order
	; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	;
	; -------------------------------------------
	Array_ToSort_Len := Array_ToSort.MaxIndex() ; Highest Length
	; -------------------------------------------
	if (Array_ToSort_Len > 0)
	{
		; -------------------------------------------
		ArrayToString := ""
	  for Index, ThisText in Array_ToSort
	  {
			ArrayToString := ArrayToString "," ThisText
	  }
	  ; -------------------------------------------
		Sort ArrayToString, D,  ; (D,) use comma as delimiter.
		; -------------------------------------------
		Array_Sorted := StrSplit(ArrayToString, "`,", "`,") ; Omits periods.
		; -------------------------------------------
	  for Index, Text_Sorted in Array_Sorted
	  {
	    ; -------------------------------------------
	    for Index, ArrayThisRecord in ArrayAllRecords
	    {
    		; -------------------------------------------
		    ; ArrayThisRecord := [A_LoopFileFullPath, Value_Category, Value_RecordName, Value_SubName]
        ; ArrayAllRecords := [ArrayThisRecord, ArrayThisRecord, etc]
		    ; -------------------------------------------
				;
				; -------------------------------------------
				Text_ThisRecord := ""
				; -------------------------------------------
		    FileRecord := ArrayThisRecord.1
				; -------------------------------------------
				SplitPath, FileRecord, , , , Number_FileRecord
				; -------------------------------------------
		    Value_Category   := ArrayThisRecord.2
		    Value_RecordName := ArrayThisRecord.3
		    Value_SubName    := ArrayThisRecord.4
		    ; -------------------------------------------
				;
		    ; -------------------------------------------
		    if (Category == "none") ; All Categories
		    {
    			; -------------------------------------------
			    if (StrLen(Value_SubName) > 0)
			    {
    				Text_ThisRecord := "(_" Value_Category "_)(_" Value_RecordName "_)(_" Value_SubName "_)"
			    }
			    else
			    {
    				Text_ThisRecord := "(_" Value_Category "_)(_" Value_RecordName "_)"
			    }
			    ; -------------------------------------------
					;
			    ; -------------------------------------------
				} ; if (Category == "none") ; All Categories
  		  else ; Spicific Category
		    {
					; -------------------------------------------
					if (StrLen(Value_SubName) > 0)
					{
						Text_ThisRecord := "(_" Value_RecordName "_)(_" Value_SubName "_)"
					}
					else
					{
						Text_ThisRecord := "(_" Value_RecordName "_)"
					}
					; -------------------------------------------
		    } ; else ; Spicific Category
		    ; -------------------------------------------
				if (Text_Sorted == Text_ThisRecord)
				{
					Array_ThisRecord := [Number_FileRecord, Text_ThisRecord]
					Array_SearchList := Array_Add(Array_SearchList, Array_ThisRecord, ThisPos) ; > ThisArray
				}
				; -------------------------------------------
	    } ; for Index, ArrayThisRecord in ArrayAllRecords
	    ; -------------------------------------------
	    ; (Array_ToSort) Pre to put displayed list in alphabetical order
	    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		} ; for Index, Text_Sorted in Array_Sorted
		; -------------------------------------------
		;
	  ; -------------------------------------------
		ListBox_Search_List := ""
	  ; -------------------------------------------
	  for Index, Array_ThisRecord in Array_SearchList
	  {
  		; -------------------------------------------
		  Text_ThisRecord := Array_ThisRecord.2
		  ; -------------------------------------------
		  if (StrLen(ListBox_Search_List) == 0)
		  {
  		  ListBox_Search_List := Text_ThisRecord
		  }
		  else
		  {
				if (InStr(ListBox_Search_List, Text_ThisRecord) == 0)
				{
  		    ListBox_Search_List := ListBox_Search_List "|" Text_ThisRecord
				}
		  }
		  ; -------------------------------------------
	  }
		; -------------------------------------------
		ListBox_Search_List := StrReplace(ListBox_Search_List, "(_<EMPTY>_)", "")
	  ; -------------------------------------------
	} ; if (Array_ToSort_Len > 0)
	else
	{
		ListBox_Search_List := "NO Records Found"
	}
	; -------------------------------------------
	;
	; -------------------------------------------
	ArrayReturn := [ListBox_Search_List, Array_SearchList]
	return ArrayReturn
	; -------------------------------------------
}
; -------------------------------------------
Reset_EditFields()
{
	; -------------------------------------------
  GuiControl, Tracker:Disable, Update_FirstEmail
  GuiControl, Tracker:Disable, Update_SecondEmail
  GuiControl, Tracker:Disable, Update_LoginName
  GuiControl, Tracker:Disable, Update_BusinessName
  GuiControl, Tracker:Disable, Update_FirstName
  GuiControl, Tracker:Disable, Update_LastName
  GuiControl, Tracker:Disable, Update_Phone
  GuiControl, Tracker:Disable, Update_Country
  GuiControl, Tracker:Disable, Update_City
  GuiControl, Tracker:Disable, Update_Street
  GuiControl, Tracker:Disable, Update_ZipCode
  ; -------------------------------------------
  ;
	; -------------------------------------------
	ArrayEditFeild := ["Edit_RecordName", "Edit_SubName", "Edit_Notes", "Edit_Password", "Edit_FirstEmail", "Edit_SecondEmail", "Edit_LoginName", "Edit_BusinessName", "Edit_FirstName", "Edit_LastName", "Edit_Phone", "Edit_Country", "Edit_City", "Edit_Street", "Edit_ZipCode"]
	for Index, ThisEdit in ArrayEditFeild
	{
		; -------------------------------------------
		GuiControlGet, ThisValue, Tracker:, %ThisEdit%
		; -------------------------------------------
		if (StrLen(ThisValue) > 0)
		{
			GuiControl, Tracker:, %ThisEdit%,
		}
	}
	; -------------------------------------------
	;
	; -------------------------------------------
	Array_RadioReset := ["Radio_Notes", "Radio_Password", "Radio_FirstEmail", "Radio_FirstEmail_1", "Radio_FirstEmail_2", "Radio_FirstEmail_3", "Radio_SecondEmail", "Radio_SecondEmail_1", "Radio_SecondEmail_2", "Radio_SecondEmail_3", "Radio_LoginName", "Radio_LoginName_1", "Radio_LoginName_2", "Radio_LoginName_3", "Radio_BusinessName", "Radio_BusinessName_1", "Radio_BusinessName_2", "Radio_BusinessName_3", "Radio_FirstName", "Radio_FirstName_1", "Radio_FirstName_2", "Radio_FirstName_3", "Radio_LastName", "Radio_LastName_1", "Radio_LastName_2", "Radio_LastName_3", "Radio_Phone", "Radio_Phone_1", "Radio_Phone_2", "Radio_Phone_3", "Radio_Country", "Radio_Country_1", "Radio_Country_2", "Radio_Country_3", "Radio_City", "Radio_City_1", "Radio_City_2", "Radio_City_3", "Radio_Street", "Radio_Street_1", "Radio_Street_2", "Radio_Street_3", "Radio_ZipCode", "Radio_ZipCode_1", "Radio_ZipCode_2", "Radio_ZipCode_3"]
	; -------------------------------------------
	for Index, ThisRadio in Array_RadioReset
	{
		; -------------------------------------------
		GuiControlGet, ThisOnOff, Tracker:, %ThisRadio%
		; -------------------------------------------
		if (ThisOnOff == 1)
		{
			GuiControl, Tracker:, %ThisRadio%, 0
			GuiControl, Tracker:+c000000, %ThisRadio% ; Black Color
			GuiControl, Tracker:MoveDraw, %ThisRadio%
		}
		; -------------------------------------------
	}
	; -------------------------------------------
}
; -------------------------------------------
Reset_NewPassword(FirstLoad)
{
	; -------------------------------------------
	GuiControlGet, Show_Button_Accept, Tracker:Visible , Button_Accept
	; -------------------------------------------
	if (Show_Button_Accept == 1)
	{
		; -------------------------------------------
		Gui, Tracker:Color, e7d8fe ; Purple Color
		; -------------------------------------------
	}
	; -------------------------------------------
	;
	; -------------------------------------------
	GuiControl, Tracker:, Button_Accept,
	GuiControl, Tracker:Hide, Button_Accept
	; -------------------------------------------
	;
	; -------------------------------------------
  GuiControl, Tracker:Disable, Update_FirstEmail
  GuiControl, Tracker:Disable, Update_SecondEmail
  GuiControl, Tracker:Disable, Update_LoginName
  GuiControl, Tracker:Disable, Update_BusinessName
  GuiControl, Tracker:Disable, Update_FirstName
  GuiControl, Tracker:Disable, Update_LastName
  GuiControl, Tracker:Disable, Update_Phone
  GuiControl, Tracker:Disable, Update_Country
  GuiControl, Tracker:Disable, Update_City
  GuiControl, Tracker:Disable, Update_Street
  GuiControl, Tracker:Disable, Update_ZipCode
  ; -------------------------------------------
  GuiControl, Tracker:Hide, Button_CatBrowser
	GuiControl, Tracker:Hide, Button_CatBuySell
	GuiControl, Tracker:Hide, Button_CatContact
	GuiControl, Tracker:Hide, Button_CatDownLoad
	GuiControl, Tracker:Hide, Button_CatEmail
	GuiControl, Tracker:Hide, Button_CatForum
	GuiControl, Tracker:Hide, Button_CatGame
	GuiControl, Tracker:Hide, Button_CatInternet
	GuiControl, Tracker:Hide, Button_CatMailer
	GuiControl, Tracker:Hide, Button_CatMoney
	GuiControl, Tracker:Hide, Button_CatProgram
	GuiControl, Tracker:Hide, Button_CatSocial
	GuiControl, Tracker:Hide, Button_CatWebHosting
	GuiControl, Tracker:Hide, Button_CatWebTempletes
	GuiControl, Tracker:Hide, Button_CatWebSite
	GuiControl, Tracker:Hide, Button_CatNone
  ; -------------------------------------------
	;
	; -------------------------------------------
	Value_TitleTextDisplay := "New Record"
	Value_TextDisplay      := ""
	Color_TitleTextDisplay := "Green"
	Color_TextDisplay      := "X"
	GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
	; -------------------------------------------
	;
	; -------------------------------------------
	GuiControl, Tracker:+c099d29, Radio_NewRecord ; Green Color
	GuiControl, Tracker:MoveDraw, Radio_NewRecord
	; -------------------------------------------
	GuiControl, Tracker:+c000000, Radio_ExistingRecord ; Black Color
	GuiControl, Tracker:MoveDraw, Radio_ExistingRecord
	; -------------------------------------------
	GuiControl, Tracker:, Radio_NewRecord, 1
	GuiControl, Tracker:, Radio_ExistingRecord, 0
	; -------------------------------------------
	SelectCategoryRadio("Radio_CatNone")
	; -------------------------------------------
	GuiControl, Tracker:Hide, Button_Accept
	; -------------------------------------------
	if (FirstLoad == "")
	{
	  ; -------------------------------------------
		ArrayEditFeild := ["Edit_RecordName", "Edit_SubName", "Edit_Notes", "Edit_Password", "Edit_FirstEmail", "Edit_SecondEmail", "Edit_LoginName", "Edit_BusinessName", "Edit_FirstName", "Edit_LastName", "Edit_Phone", "Edit_Country", "Edit_City", "Edit_Street", "Edit_ZipCode"]
    for Index, ThisEdit in ArrayEditFeild
    {
			; -------------------------------------------
			GuiControlGet, ThisValue, Tracker:, %ThisEdit%
    	; -------------------------------------------
			if (StrLen(ThisValue) > 0)
			{
				GuiControl, Tracker:, %ThisEdit%,
			}
		}
    ; -------------------------------------------
		;
		; -------------------------------------------
    Array_RadioReset := ["Radio_Notes", "Radio_Password", "Radio_FirstEmail", "Radio_FirstEmail_1", "Radio_FirstEmail_2", "Radio_FirstEmail_3", "Radio_SecondEmail", "Radio_SecondEmail_1", "Radio_SecondEmail_2", "Radio_SecondEmail_3", "Radio_LoginName", "Radio_LoginName_1", "Radio_LoginName_2", "Radio_LoginName_3", "Radio_BusinessName", "Radio_BusinessName_1", "Radio_BusinessName_2", "Radio_BusinessName_3", "Radio_FirstName", "Radio_FirstName_1", "Radio_FirstName_2", "Radio_FirstName_3", "Radio_LastName", "Radio_LastName_1", "Radio_LastName_2", "Radio_LastName_3", "Radio_Phone", "Radio_Phone_1", "Radio_Phone_2", "Radio_Phone_3", "Radio_Country", "Radio_Country_1", "Radio_Country_2", "Radio_Country_3", "Radio_City", "Radio_City_1", "Radio_City_2", "Radio_City_3", "Radio_Street", "Radio_Street_1", "Radio_Street_2", "Radio_Street_3", "Radio_ZipCode", "Radio_ZipCode_1", "Radio_ZipCode_2", "Radio_ZipCode_3"]
    ; -------------------------------------------
    for Index, ThisRadio in Array_RadioReset
    {
			; -------------------------------------------
			GuiControlGet, ThisOnOff, Tracker:, %ThisRadio%
    	; -------------------------------------------
			if (ThisOnOff == 1)
			{
    	  GuiControl, Tracker:, %ThisRadio%, 0
  	    GuiControl, Tracker:+c000000, %ThisRadio% ; Black Color
  	    GuiControl, Tracker:MoveDraw, %ThisRadio%
			}
  	  ; -------------------------------------------
    }
	  ; -------------------------------------------
	} ; if (FirstLoad == "")
	; -------------------------------------------
	GuiControl, Tracker:, Edit_PasswordLength , 16
	; -------------------------------------------
}
; -------------------------------------------
EditFeildCheck(CheckThisEdit, Array_CurrentRecord) ; CheckThisEdit = Edit_ObjectName > (0) Empty Feild -OR- (ThisEditValue)
{
	; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	; ClipBoard Image
	; -------------------------------------------
	Image_ClipboardEmpty := A_ProgramFiles "\PopUpMenu_PUM\support\PopUpMenu_Tracker\ClipBoardEmpty.png"
	; -------------------------------------------
	Array_Edit := ["Edit_RecordName", "Edit_SubName", "Edit_Password", "Edit_Notes", "Edit_Password", "Edit_FirstEmail", "Edit_SecondEmail", "Edit_LoginName", "Edit_BusinessName", "Edit_FirstName", "Edit_LastName", "Edit_Phone",  "Edit_Country", "Edit_City", "Edit_Street", "Edit_ZipCode"]
	; -------------------------------------------
	for Index, ThisEdit in Array_Edit
	{
		; -------------------------------------------
		GuiControlGet, ThisEditValue, Tracker:, %ThisEdit%
		; -------------------------------------------
		ThisEditEmptyCheck := ThisEditValue
		ThisEditEmptyCheck := StrReplace(ThisEditEmptyCheck, A_Space, "")
		ThisEditEmptyCheck := StrReplace(ThisEditEmptyCheck, A_Tab, "")
		; -------------------------------------------
		ThisClipboard := StrReplace(ThisEdit, "Edit_", "Clipboard_")
		; -------------------------------------------
		if (StrLen(ThisEditEmptyCheck) == 0) ; Edit Feild is Empty
		{
			; -------------------------------------------
			if (ThisEdit != "Edit_RecordName" && ThisEdit != "Edit_SubName" && ThisEdit != "Edit_Password")
			{
				; -------------------------------------------
				GuiControlGet, CheckIfShowing, Tracker:Visible, %ThisClipboard%,
				; -------------------------------------------
				if (CheckIfShowing == 1)
				{
					; -------------------------------------------
					GuiControl, Tracker:Hide, %ThisClipboard%,
					GuiControl, Tracker:, %ThisClipboard%,
					GuiControl, Tracker:MoveDraw, %ThisClipboard%
					; -------------------------------------------
				}
				; -------------------------------------------
			}
			; -------------------------------------------
			if (CheckThisEdit == ThisEdit)
			{
				ReturnAnswer := 0 ; ReturnAnswer = (0) Empty Edit Feild
			}
			; -------------------------------------------
		} ; if (StrLen(ThisEditEmptyCheck) == 0) ; Edit Feild is Empty
		else ; Edit Feild is NOT Empty
		{
			; -------------------------------------------
			FeildHasValue := 1
			; ------------------------------------------
			GuiControlGet, CheckIfShowing, Tracker:Visible, %ThisClipboard%
			; -------------------------------------------
			if (CheckIfShowing == 0)
			{
				GuiControl, Tracker:, %ThisClipboard%, %Image_ClipboardEmpty%
				GuiControl, Tracker:Show, %ThisClipboard%
				GuiControl, Tracker:MoveDraw, %ThisClipboard%
			}
			; -------------------------------------------
			if (CheckThisEdit == ThisEdit)
			{
				ReturnAnswer := ThisEditValue ; ReturnAnswer = (ThisEditValue) Edit Feild is NOT Emply Return its Value
			}
			; -------------------------------------------
		} ; else ; Edit Feild is NOT Empty
		; -------------------------------------------
	} ; for Index, ThisEdit in Array_Edit
	; -------------------------------------------
	; ClipBoard Image
	; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	;
	; -------------------------------------------
	GuiControlGet, OnOff_NewRecord, Tracker:, Radio_NewRecord
	; -------------------------------------------
	if (OnOff_NewRecord == 1)
	{
		; -------------------------------------------
		GuiControlGet, OnOff_CatNone, Tracker:, Radio_CatNone
		; -------------------------------------------
		GuiControlGet, Value_RecordName, Tracker:, Edit_RecordName
		; -------------------------------------------
		Value_RecordName := StrReplace(Value_RecordName, A_Space, "")
		Value_RecordName := StrReplace(Value_RecordName, A_Tab, "")
		; -------------------------------------------
		if (StrLen(Value_RecordName) > 0)
		{
			; -------------------------------------------
  	  GuiControlGet, OnOff_CatBrowser, Tracker:, Radio_CatBrowser
	    GuiControlGet, OnOff_CatBuySell, Tracker:, Radio_CatBuySell
	    GuiControlGet, OnOff_CatContact, Tracker:, Radio_CatContact
	    GuiControlGet, OnOff_CatDownLoad, Tracker:, Radio_CatDownLoad
	    GuiControlGet, OnOff_CatEmail, Tracker:, Radio_CatEmail
	    GuiControlGet, OnOff_CatForum, Tracker:, Radio_CatForum
	    GuiControlGet, OnOff_CatGame, Tracker:, Radio_CatGame
	    GuiControlGet, OnOff_CatGame, Tracker:, Radio_CatGame
	    GuiControlGet, OnOff_CatInternet, Tracker:, Radio_CatInternet
	    GuiControlGet, OnOff_CatMailer, Tracker:, Radio_CatMailer
	    GuiControlGet, OnOff_CatMoney, Tracker:, Radio_CatMoney
	    GuiControlGet, OnOff_CatProgram, Tracker:, Radio_CatProgram
	    GuiControlGet, OnOff_CatSocial, Tracker:, Radio_CatSocial
	    GuiControlGet, OnOff_CatWebHosting, Tracker:, Radio_CatWebHosting
	    GuiControlGet, OnOff_CatWebTempletes, Tracker:, Radio_CatWebTempletes
	    GuiControlGet, OnOff_CatWebSite, Tracker:, Radio_CatWebSite
	    ; -------------------------------------------
      if (OnOff_CatBrowser == 1 or OnOff_CatBuySell == 1 or OnOff_CatContact == 1 or OnOff_CatDownLoad == 1 or OnOff_CatEmail == 1 or OnOff_CatForum == 1 or OnOff_CatGame == 1 or OnOff_CatInternet == 1 or OnOff_CatMailer == 1 or OnOff_CatMoney == 1 or OnOff_CatProgram == 1 or OnOff_CatSocial == 1 or OnOff_CatWebHosting == 1 or OnOff_CatWebTempletes == 1 or OnOff_CatWebSite == 1)
			{
				; -------------------------------------------
				GuiControlGet, Value_Button_Accept, Tracker:, Button_Accept
				; -------------------------------------------
				if (Value_Button_Accept != "Save New Record")
				{
				  ; -------------------------------------------
          Gui, Tracker:Color, c6e5d2 ; Green Color
				  ; -------------------------------------------
				}
				; -------------------------------------------
				;
				; -------------------------------------------
				GuiControl, Tracker:, Button_Accept, Save New Record
				GuiControl, Tracker:MoveDraw, %Button_Accept%
				GuiControl, Tracker:Show, Button_Accept
				; -------------------------------------------
			}
			; -------------------------------------------
			else
			{
				; -------------------------------------------
				GuiControlGet, Show_Button_Accept, Tracker:Visible , Button_Accept
				; -------------------------------------------
				if (Show_Button_Accept == 1)
				{
				  ; -------------------------------------------
          Gui, Tracker:Color, e7d8fe ; Purple Color
				  ; -------------------------------------------
				}
				; -------------------------------------------
				;
				; -------------------------------------------
				GuiControl, Tracker:, Button_Accept,
				GuiControl, Tracker:Hide, Button_Accept
				; -------------------------------------------
			}
			; -------------------------------------------
		}
		else
		{
			; -------------------------------------------
			GuiControlGet, Show_Button_Accept, Tracker:Visible , Button_Accept
			; -------------------------------------------
			if (Show_Button_Accept == 1)
			{
				; -------------------------------------------
				Gui, Tracker:Color, e7d8fe ; Purple Color
				; -------------------------------------------
			}
			; -------------------------------------------
			;
			; -------------------------------------------
			GuiControl, Tracker:, Button_Accept,
			GuiControl, Tracker:Hide, Button_Accept
			; -------------------------------------------
		}
		; -------------------------------------------
	}
	; -------------------------------------------
	;
	; -------------------------------------------
	GuiControlGet, OnOff_ExistingRecord, Tracker:, Radio_ExistingRecord
	; -------------------------------------------
	if (OnOff_ExistingRecord == 1)
	{
		; -------------------------------------------
		RecordHasChanged := HasRecordChanged(Array_CurrentRecord) ; > 0 -OR- 1
		; -------------------------------------------
		if (RecordHasChanged == 1) ; Record Has Changed
		{
			; -------------------------------------------
			if (Array_CurrentRecord != "")
			{
				; -------------------------------------------
				GuiControlGet, Value_Button_Accept, Tracker:, Button_Accept
				; -------------------------------------------
				if (Value_Button_Accept != "Update Record")
				{
    	    ; -------------------------------------------
	        ControlGetFocus, CurrentFocus, A
	        if (CurrentFocus != "ListBox1")
				  {
  					; -------------------------------------------
					  Gui, Tracker:Color, eceba9 ; Yellow Color
					  ; -------------------------------------------
					  ;
					  ; -------------------------------------------
					  GuiControl, Tracker:, Button_Accept, Update Record
					  GuiControl, Tracker:MoveDraw, %Button_Accept%
					  GuiControl, Tracker:Show, Button_Accept
					  ; -------------------------------------------
					  ;
					  ; -------------------------------------------
					  Value_TitleTextDisplay := "Changing Record"
					  Value_TextDisplay      := "X"
					  Color_TitleTextDisplay := "Red"
					  Color_TextDisplay      := "X"
					  GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
					  ; -------------------------------------------
				  }
				  ; -------------------------------------------
				}
				; -------------------------------------------
			}
			; -------------------------------------------
		} ; if (RecordHasChanged == 1) ; Record Has Changed
		; -------------------------------------------
		else
		{
			; -------------------------------------------
			if (Array_CurrentRecord != "")
			{
				; -------------------------------------------
				GuiControlGet, Value_Button_Accept, Tracker:, Button_Accept
				; -------------------------------------------
				if (Value_Button_Accept != "Delete Record") ; EditFeildCheck
				{
					; -------------------------------------------
					Gui, Tracker:Color, edbaba ; Red Color
					; -------------------------------------------
					;
					; -------------------------------------------
					GuiControl, Tracker:, Button_Accept, Delete Record
					GuiControl, Tracker:MoveDraw, %Button_Accept%
					GuiControl, Tracker:Show, Button_Accept
					; -------------------------------------------
					;
					; -------------------------------------------
					Value_TitleTextDisplay := "Existing Record"
					Value_TextDisplay      := "X"
					Color_TitleTextDisplay := "Green"
					Color_TextDisplay      := "X"
					GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
					; -------------------------------------------
				}
				; -------------------------------------------
			}
			; -------------------------------------------
			else
			{
				; -------------------------------------------
				GuiControlGet, Show_Button_Accept, Tracker:Visible , Button_Accept
				; -------------------------------------------
				if (Show_Button_Accept == 1)
				{
					; -------------------------------------------
					Gui, Tracker:Color, e7d8fe ; Purple Color
					; -------------------------------------------
				}
				; -------------------------------------------
				;
				; -------------------------------------------
				GuiControl, Tracker:, Button_Accept,
				GuiControl, Tracker:Hide, Button_Accept
				; -------------------------------------------
			}
			; -------------------------------------------
		}
		; -------------------------------------------
	} ; if (OnOff_ExistingRecord == 1)
	; -------------------------------------------
	;
	; -------------------------------------------
	; ReturnAnswer = (0) Empty Edit Feild
	; ReturnAnswer = (ThisEditValue) Edit Feild is NOT Emply Return its Value
	return ReturnAnswer
	; -------------------------------------------
}
; -------------------------------------------
; Functions
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; StartUp (ArrayAllRecords)
; -------------------------------------------
; ArrayThisRecord := [A_LoopFileFullPath, Value_Category, Value_RecordName, Value_SubName]
; ArrayAllRecords := [ArrayThisRecord, ArrayThisRecord, etc]
; -------------------------------------------
Loop, Files, %Path_DAT%\Files\*.txt
{
	; -------------------------------------------
	FileReadLine, Value_Category, %A_LoopFileFullPath%, 2
	FileReadLine, Value_RecordName, %A_LoopFileFullPath%, 4
	FileReadLine, Value_SubName, %A_LoopFileFullPath%, 6
	; -------------------------------------------
	ArrayThisRecord := [A_LoopFileFullPath, Value_Category, Value_RecordName, Value_SubName]
	ArrayAllRecords := Array_Add(ArrayAllRecords, ArrayThisRecord, "End") ; > ThisArray
	; -------------------------------------------
}
; -------------------------------------------
; ArrayThisRecord := [A_LoopFileFullPath, Value_Category, Value_RecordName, Value_SubName]
; ArrayAllRecords := [ArrayThisRecord, ArrayThisRecord, etc]
; -------------------------------------------
;
; -------------------------------------------
; StartUp (ArrayAllRecords)
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; -------------------------------------------
;
; Green Color  +c099d29
; Red Color    +cc42424
; Blue Color   +c333f82
; Yellow Color +cff9000
; Black Color  +c000000
;
; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
{ ; Gui Define
  ; -------------------------------------------
  BlockInput, On
  BlockInput, MouseMove
	; -------------------------------------------
  ;
	; -------------------------------------------
	BS_PUSHLIKE := 0x1000
	; -------------------------------------------
	;
	; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Minimize Window
	Gui, Tracker:Add, Picture,                   vMinimizeWindow          gLabel_MinimizeWindow      x0 y0 w970 h30, %A_ProgramFiles%\PopUpMenu_PUM\support\PopUpMenu_Tracker\minimize.png
	; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Minimize Window
	;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> NEW / EXISTING
  Gui, Tracker:Font, c000000 s10 w700, arial
  Gui, Tracker:Add, GroupBox,                                                                    x14  y38 w230 h35,
  Gui, Tracker:Add, Radio,                     vRadio_NewRecord         gLabel_NewRecord         x20  y50 w100 h20, New Record
  Gui, Tracker:Add, Radio,                     vRadio_ExistingRecord    gLabel_ExistingRecord    x120 y50 w120 h20, Existing Record
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> RECORD NAME
  Gui, Tracker:Font, c000000 s12 w700, arial
  Gui, Tracker:Add, Text,  c099d29                                                               x265 y54 w105 h30, Record Name
  Gui, Tracker:Add, Edit,                      vEdit_RecordName         gLabel_E_RecordName      x375 y52  w235 h25,
  ; -------------------------------------------
  Gui, Tracker:Font, c000000 s12 w700, arial
  Gui, Tracker:Add, Text,  c099d29                                                               x620 y54 w85 h30, Sub Name
  Gui, Tracker:Add, Edit,                      vEdit_SubName            gLabel_E_SubName         x705 y52  w235 h25,
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DISPLAY TEXT
  Gui, Tracker:Font, c000000 s12 w700, arial
  Gui, Tracker:Add, Text,  center              vTitleTextDisplay                                 x20  y225 w200 h30, TitleTextDisplay
  Gui, Tracker:Add, Text,  center              vTextDisplay                                      x20  y250 w200 h30, TextDisplay
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Notes
  Gui, Tracker:Add, Picture,                   vClipboard_Notes         gLabel_C_Notes           x387 y100 w30 h30,
  ;
  Gui, Tracker:Font, c000000 s12 w700, arial
  Gui, Tracker:Add, Radio,                     vRadio_Notes             gLabel_R_Notes           x370 y135 w70 h30, Notes
  ;
  Gui, Tracker:Font, c000000 s10 w700, arial
  Gui, Tracker:Add, Edit,   R7                 vEdit_Notes              gLabel_E_Notes           x440 y95 w500,
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> TEXT
  Gui, Tracker:Font, c000000 s16 w700, arial
  Gui, Tracker:Add, Text,  c333f82                                                               x465 y248 w405 h30, Additional Information
  ; -------------------------------------------
  Gui, Tracker:Font, c000000 s16 w700, arial
  Gui, Tracker:Add, Text,  c333f82                                                               x800 y248 w100 h30, Presets
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> EDIT INFO
  ; FirstEmail
  ; -------------------------------------------
  Gui, Tracker:Add, Picture,                   vClipboard_FirstEmail    gLabel_C_FirstEmail      x260 y280 w30 h30,
  ; -------------------------------------------
  Gui, Tracker:Font, c000000 s10 w700, arial
  Gui, Tracker:Add, Radio, %BS_PUSHLIKE%       vRadio_FirstEmail        gLabel_R_FirstEmail      x300 y285 w105 h30, First Email
  Gui, Tracker:Font, c000000 s10 w700, arial
  Gui, Tracker:Add, Edit,                      vEdit_FirstEmail         gLabel_E_FirstEmail      x420 y288 w325 h25,
  ;
  Gui, Tracker:Font, c000000 s12 w700, arial
  Gui, Tracker:Add, GroupBox,                                                                    x750 y275 w200 h44,
  Gui, Tracker:Add, Radio,                     vRadio_FirstEmail_1      gLabel_FirstEmail_1      x760 y290 w30 h25, 1
  Gui, Tracker:Add, Radio,                     vRadio_FirstEmail_2      gLabel_FirstEmail_2      x800 y290 w30 h25, 2
  Gui, Tracker:Add, Radio,                     vRadio_FirstEmail_3      gLabel_FirstEmail_3      x840 y290 w30 h25, 3
  Gui, Tracker:Font, c000000 s10 w700, arial
  Gui, Tracker:Add, Button,                    vUpdate_FirstEmail       gLabel_U_FirstEmail      x882 y289 w60 h25, Update
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; SecondEmail
  ; -------------------------------------------
  Gui, Tracker:Add, Picture,                   vClipboard_SecondEmail   gLabel_C_SecondEmail     x260 y320 w30 h30,
  ; -------------------------------------------
  Gui, Tracker:Font, c000000 s10 w700, arial
  Gui, Tracker:Add, Radio, %BS_PUSHLIKE%       vRadio_SecondEmail       gLabel_R_SecondEmail     x300 y325 w105 h30, Second Email
  Gui, Tracker:Font, c000000 s10 w700, arial
  Gui, Tracker:Add, Edit,                      vEdit_SecondEmail        gLabel_E_SecondEmail     x420 y329 w325 h25,
  ;
  Gui, Tracker:Font, c000000 s12 w700, arial
  Gui, Tracker:Add, GroupBox,                                                                    x750 y315 w200 h44,
  Gui, Tracker:Add, Radio,                     vRadio_SecondEmail_1      gLabel_SecondEmail_1    x760 y330 w30 h25, 1
  Gui, Tracker:Add, Radio,                     vRadio_SecondEmail_2      gLabel_SecondEmail_2    x800 y330 w30 h25, 2
  Gui, Tracker:Add, Radio,                     vRadio_SecondEmail_3      gLabel_SecondEmail_3    x840 y330 w30 h25, 3
  Gui, Tracker:Font, c000000 s10 w700, arial
  Gui, Tracker:Add, Button,                    vUpdate_SecondEmail       gLabel_U_SecondEmail    x882 y329 w60 h25, Update
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; LoginName
  ; -------------------------------------------
  Gui, Tracker:Add, Picture,                   vClipboard_LoginName     gLabel_C_LoginName       x260 y360 w30 h30,
  ; -------------------------------------------
  Gui, Tracker:Font, c000000 s10 w700, arial
  Gui, Tracker:Add, Radio, %BS_PUSHLIKE%       vRadio_LoginName         gLabel_R_LoginName       x300 y365 w105 h30, Login Name
  Gui, Tracker:Font, c000000 s10 w700, arial
  Gui, Tracker:Add, Edit,                      vEdit_LoginName          gLabel_E_LoginName       x420 y368 w325 h25,
  ;
  Gui, Tracker:Font, c000000 s12 w700, arial
  Gui, Tracker:Add, GroupBox,                                                                    x750 y355 w200 h44,
  Gui, Tracker:Add, Radio,                     vRadio_LoginName_1       gLabel_LoginName_1       x760 y370 w30 h25, 1
  Gui, Tracker:Add, Radio,                     vRadio_LoginName_2       gLabel_LoginName_2       x800 y370 w30 h25, 2
  Gui, Tracker:Add, Radio,                     vRadio_LoginName_3       gLabel_LoginName_3       x840 y370 w30 h25, 3
  Gui, Tracker:Font, c000000 s10 w700, arial
  Gui, Tracker:Add, Button,                    vUpdate_LoginName        gLabel_U_LoginName       x882 y369 w60 h25, Update
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; BusinessName
  ; -------------------------------------------
  Gui, Tracker:Add, Picture,                   vClipboard_BusinessName  gLabel_C_BusinessName    x260 y400 w30 h30,
  ; -------------------------------------------
  Gui, Tracker:Font, c000000 s10 w700, arial
  Gui, Tracker:Add, Radio, %BS_PUSHLIKE%       vRadio_BusinessName      gLabel_R_BusinessName    x300 y405 w105 h30, Business Name
  Gui, Tracker:Font, c000000 s10 w700, arial
  Gui, Tracker:Add, Edit,                      vEdit_BusinessName       gLabel_E_BusinessName    x420 y409 w325 h25,
  ;
  Gui, Tracker:Font, c000000 s12 w700, arial
  Gui, Tracker:Add, GroupBox,                                                                    x750 y395 w200 h44,
  Gui, Tracker:Add, Radio,                     vRadio_BusinessName_1    gLabel_BusinessName_1    x760 y410 w30 h25, 1
  Gui, Tracker:Add, Radio,                     vRadio_BusinessName_2    gLabel_BusinessName_2    x800 y410 w30 h25, 2
  Gui, Tracker:Add, Radio,                     vRadio_BusinessName_3    gLabel_BusinessName_3    x840 y410 w30 h25, 3
  Gui, Tracker:Font, c000000 s10 w700, arial
  Gui, Tracker:Add, Button,                    vUpdate_BusinessName     gLabel_U_BusinessName    x882 y409 w60 h25, Update
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; FirstName
  ; -------------------------------------------
  Gui, Tracker:Add, Picture,                   vClipboard_FirstName     gLabel_C_FirstName       x260 y440 w30 h30,
  ; -------------------------------------------
  Gui, Tracker:Font, c000000 s10 w700, arial
  Gui, Tracker:Add, Radio, %BS_PUSHLIKE%       vRadio_FirstName         gLabel_R_FirstName       x300 y445 w105 h30, First Name
  Gui, Tracker:Font, c000000 s10 w700, arial
  Gui, Tracker:Add, Edit,                      vEdit_FirstName          gLabel_E_FirstName       x420 y448 w325 h25,
  ;
  Gui, Tracker:Font, c000000 s12 w700, arial
  Gui, Tracker:Add, GroupBox,                                                                    x750 y435 w200 h44,
  Gui, Tracker:Add, Radio,                     vRadio_FirstName_1       gLabel_FirstName_1       x760 y450 w30 h25, 1
  Gui, Tracker:Add, Radio,                     vRadio_FirstName_2       gLabel_FirstName_2       x800 y450 w30 h25, 2
  Gui, Tracker:Add, Radio,                     vRadio_FirstName_3       gLabel_FirstName_3       x840 y450 w30 h25, 3
  Gui, Tracker:Font, c000000 s10 w700, arial
  Gui, Tracker:Add, Button,                    vUpdate_FirstName        gLabel_U_FirstName       x882 y449 w60 h25, Update
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; LastName
  ; -------------------------------------------
  Gui, Tracker:Add, Picture,                   vClipboard_LastName      gLabel_C_LastName        x260 y480 w30 h30,
  ; -------------------------------------------
  Gui, Tracker:Font, c000000 s10 w700, arial
  Gui, Tracker:Add, Radio, %BS_PUSHLIKE%       vRadio_LastName          gLabel_R_LastName        x300 y485 w105 h30, Last Name
  Gui, Tracker:Font, c000000 s10 w700, arial
  Gui, Tracker:Add, Edit,                      vEdit_LastName           gLabel_E_LastName        x420 y488 w325 h25,
  ;
  Gui, Tracker:Font, c000000 s12 w700, arial
  Gui, Tracker:Add, GroupBox,                                                                    x750 y475 w200 h44,
  Gui, Tracker:Add, Radio,                     vRadio_LastName_1        gLabel_LastName_1        x760 y490 w30 h25, 1
  Gui, Tracker:Add, Radio,                     vRadio_LastName_2        gLabel_LastName_2        x800 y490 w30 h25, 2
  Gui, Tracker:Add, Radio,                     vRadio_LastName_3        gLabel_LastName_3        x840 y490 w30 h25, 3
  Gui, Tracker:Font, c000000 s10 w700, arial
  Gui, Tracker:Add, Button,                    vUpdate_LastName         gLabel_U_LastName        x882 y489 w60 h25, Update
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; Phone
  ; -------------------------------------------
  Gui, Tracker:Add, Picture,                   vClipboard_Phone         gLabel_C_Phone           x260 y520 w30 h30,
  ; -------------------------------------------
  Gui, Tracker:Font, c000000 s10 w700, arial
  Gui, Tracker:Add, Radio, %BS_PUSHLIKE%       vRadio_Phone             gLabel_R_Phone           x300 y525 w105 h30, Phone
  Gui, Tracker:Font, c000000 s10 w700, arial
  Gui, Tracker:Add, Edit,                      vEdit_Phone              gLabel_E_Phone           x420 y528 w325 h25,
  ;
  Gui, Tracker:Font, c000000 s12 w700, arial
  Gui, Tracker:Add, GroupBox,                                                                    x750 y515 w200 h44,
  Gui, Tracker:Add, Radio,                     vRadio_Phone_1           gLabel_Phone_1           x760 y530 w30 h25, 1
  Gui, Tracker:Add, Radio,                     vRadio_Phone_2           gLabel_Phone_2           x800 y530 w30 h25, 2
  Gui, Tracker:Add, Radio,                     vRadio_Phone_3           gLabel_Phone_3           x840 y530 w30 h25, 3
  Gui, Tracker:Font, c000000 s10 w700, arial
  Gui, Tracker:Add, Button,                    vUpdate_Phone            gLabel_U_Phone           x882 y529 w60 h25, Update
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; Country
  ; -------------------------------------------
  Gui, Tracker:Add, Picture,                   vClipboard_Country       gLabel_C_Country         x260 y560 w30 h30,
  ; -------------------------------------------
  Gui, Tracker:Font, c000000 s10 w700, arial
  Gui, Tracker:Add, Radio, %BS_PUSHLIKE%       vRadio_Country           gLabel_R_Country         x300 y565 w105 h30, Country
  Gui, Tracker:Font, c000000 s10 w700, arial
  Gui, Tracker:Add, Edit,                      vEdit_Country            gLabel_E_Country         x420 y568 w325 h25,
  ;
  Gui, Tracker:Font, c000000 s12 w700, arial
  Gui, Tracker:Add, GroupBox,                                                                    x750 y555 w200 h44,
  Gui, Tracker:Add, Radio,                     vRadio_Country_1         gLabel_Country_1         x760 y570 w30 h25, 1
  Gui, Tracker:Add, Radio,                     vRadio_Country_2         gLabel_Country_2         x800 y570 w30 h25, 2
  Gui, Tracker:Add, Radio,                     vRadio_Country_3         gLabel_Country_3         x840 y570 w30 h25, 3
  Gui, Tracker:Font, c000000 s10 w700, arial
  Gui, Tracker:Add, Button,                    vUpdate_Country          gLabel_U_Country         x882 y569 w60 h25, Update
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; City
  ; -------------------------------------------
  Gui, Tracker:Add, Picture,                   vClipboard_City          gLabel_C_City            x260 y600 w30 h30,
  ; -------------------------------------------
  Gui, Tracker:Font, c000000 s10 w700, arial
  Gui, Tracker:Add, Radio, %BS_PUSHLIKE%       vRadio_City              gLabel_R_City            x300 y605 w105 h30, City
  Gui, Tracker:Font, c000000 s10 w700, arial
  Gui, Tracker:Add, Edit,                      vEdit_City               gLabel_E_City            x420 y608 w325 h25,
  ;
  Gui, Tracker:Font, c000000 s12 w700, arial
  Gui, Tracker:Add, GroupBox,                                                                    x750 y595 w200 h44,
  Gui, Tracker:Add, Radio,                     vRadio_City_1            gLabel_City_1            x760 y610 w30 h25, 1
  Gui, Tracker:Add, Radio,                     vRadio_City_2            gLabel_City_2            x800 y610 w30 h25, 2
  Gui, Tracker:Add, Radio,                     vRadio_City_3            gLabel_City_3            x840 y610 w30 h25, 3
  Gui, Tracker:Font, c000000 s10 w700, arial
  Gui, Tracker:Add, Button,                    vUpdate_City             gLabel_U_City            x882 y609 w60 h25, Update
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; Street
  ; -------------------------------------------
  Gui, Tracker:Add, Picture,                   vClipboard_Street        gLabel_C_Street          x260 y640 w30 h30,
  ; -------------------------------------------
  Gui, Tracker:Font, c000000 s10 w700, arial
  Gui, Tracker:Add, Radio, %BS_PUSHLIKE%       vRadio_Street            gLabel_R_Street          x300 y645 w105 h30, Street
  Gui, Tracker:Font, c000000 s10 w700, arial
  Gui, Tracker:Add, Edit,                      vEdit_Street             gLabel_E_Street          x420 y648 w325 h25,
  ;
  Gui, Tracker:Font, c000000 s12 w700, arial
  Gui, Tracker:Add, GroupBox,                                                                    x750 y635 w200 h44,
  Gui, Tracker:Add, Radio,                     vRadio_Street_1          gLabel_Street_1          x760 y650 w30 h25, 1
  Gui, Tracker:Add, Radio,                     vRadio_Street_2          gLabel_Street_2          x800 y650 w30 h25, 2
  Gui, Tracker:Add, Radio,                     vRadio_Street_3          gLabel_Street_3          x840 y650 w30 h25, 3
  Gui, Tracker:Font, c000000 s10 w700, arial
  Gui, Tracker:Add, Button,                    vUpdate_Street           gLabel_U_Street          x882 y649 w60 h25, Update
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; ZipCode
  ; -------------------------------------------
  Gui, Tracker:Add, Picture,                   vClipboard_ZipCode       gLabel_C_ZipCode         x260 y680 w30 h30,
  ; -------------------------------------------
  Gui, Tracker:Font, c000000 s10 w700, arial
  Gui, Tracker:Add, Radio, %BS_PUSHLIKE%       vRadio_ZipCode           gLabel_R_ZipCode         x300 y685 w105 h30, Zip Code
  Gui, Tracker:Font, c000000 s10 w700, arial
  Gui, Tracker:Add, Edit,                      vEdit_ZipCode            gLabel_E_ZipCode         x420 y688 w325 h25,
  ;
  Gui, Tracker:Font, c000000 s12 w700, arial
  Gui, Tracker:Add, GroupBox,                                                                    x750 y675 w200 h44,
  Gui, Tracker:Add, Radio,                     vRadio_ZipCode_1         gLabel_ZipCode_1         x760 y690 w30 h25, 1
  Gui, Tracker:Add, Radio,                     vRadio_ZipCode_2         gLabel_ZipCode_2         x800 y690 w30 h25, 2
  Gui, Tracker:Add, Radio,                     vRadio_ZipCode_3         gLabel_ZipCode_3         x840 y690 w30 h25, 3
  Gui, Tracker:Font, c000000 s10 w700, arial
  Gui, Tracker:Add, Button,                    vUpdate_ZipCode          gLabel_U_ZipCode         x882 y689 w60 h25, Update
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ; Category
  ; -------------------------------------------
  Gui, Tracker:Font, c000000 s12 w700, arial
  Gui, Tracker:Add, GroupBox,                                                                    x10  y270 w235 h475
  Gui, Tracker:Add, Radio,                     vRadio_CatBrowser        gLabel_CatBrowser        x20  y290 w145 h25, Browser
  Gui, Tracker:Add, Radio,                     vRadio_CatBuySell        gLabel_CatBuySell        x20  y318 w145 h25, Buy Sell
  Gui, Tracker:Add, Radio,                     vRadio_CatContact        gLabel_CatContact        x20  y346 w145 h25, Contact
  Gui, Tracker:Add, Radio,                     vRadio_CatDownLoad       gLabel_CatDownLoad       x20  y374 w145 h25, DownLoad
  Gui, Tracker:Add, Radio,                     vRadio_CatEmail          gLabel_CatEmail          x20  y402 w145 h25, Email
  Gui, Tracker:Add, Radio,                     vRadio_CatForum          gLabel_CatForum          x20  y430 w145 h25, Forum
  Gui, Tracker:Add, Radio,                     vRadio_CatGame           gLabel_CatGame           x20  y458 w145 h25, Game
  Gui, Tracker:Add, Radio,                     vRadio_CatInternet       gLabel_CatInternet       x20  y486 w145 h25, Internet
  Gui, Tracker:Add, Radio,                     vRadio_CatMailer         gLabel_CatMailer         x20  y514 w145 h25, Mailer
  Gui, Tracker:Add, Radio,                     vRadio_CatMoney          gLabel_CatMoney          x20  y542 w145 h25, Money
  Gui, Tracker:Add, Radio,                     vRadio_CatProgram        gLabel_CatProgram        x20  y570 w145 h25, Program
  Gui, Tracker:Add, Radio,                     vRadio_CatSocial         gLabel_CatSocial         x20  y598 w145 h25, Social
  Gui, Tracker:Add, Radio,                     vRadio_CatWebHosting     gLabel_CatWebHosting     x20  y626 w145 h25, Web Hosting
  Gui, Tracker:Add, Radio,                     vRadio_CatWebTempletes   gLabel_CatWebTempletes   x20  y654 w145 h25, Web Templetes
  Gui, Tracker:Add, Radio,                     vRadio_CatWebSite        gLabel_CatWebSite        x20  y682 w145 h25, Web Site
  Gui, Tracker:Add, Radio,                     vRadio_CatNone           gLabel_CatNone           x20  y710 w145 h25, No Category
	; -------------------------------------------
	Gui, Tracker:Add, Button,                    vButton_CatBrowser       gLabel_S_CatBrowser      x160 y290 w80 h25, Search
	Gui, Tracker:Add, Button,                    vButton_CatBuySell       gLabel_S_CatBuySell      x160 y318 w80 h25, Search
	Gui, Tracker:Add, Button,                    vButton_CatContact       gLabel_S_CatContact      x160 y346 w80 h25, Search
	Gui, Tracker:Add, Button,                    vButton_CatDownLoad      gLabel_S_CatDownLoad     x160 y374 w80 h25, Search
	Gui, Tracker:Add, Button,                    vButton_CatEmail         gLabel_S_CatEmail        x160 y402 w80 h25, Search
	Gui, Tracker:Add, Button,                    vButton_CatForum         gLabel_S_CatForum        x160 y430 w80 h25, Search
	Gui, Tracker:Add, Button,                    vButton_CatGame          gLabel_S_CatGame         x160 y458 w80 h25, Search
	Gui, Tracker:Add, Button,                    vButton_CatInternet      gLabel_S_CatInternet     x160 y486 w80 h25, Search
	Gui, Tracker:Add, Button,                    vButton_CatMailer        gLabel_S_CatMailer       x160 y514 w80 h25, Search
	Gui, Tracker:Add, Button,                    vButton_CatMoney         gLabel_S_CatMoney        x160 y542 w80 h25, Search
	Gui, Tracker:Add, Button,                    vButton_CatProgram       gLabel_S_CatProgram      x160 y570 w80 h25, Search
	Gui, Tracker:Add, Button,                    vButton_CatSocial        gLabel_S_CatSocial       x160 y598 w80 h25, Search
	Gui, Tracker:Add, Button,                    vButton_CatWebHosting    gLabel_S_CatWebHosting   x160 y626 w80 h25, Search
	Gui, Tracker:Add, Button,                    vButton_CatWebTempletes  gLabel_S_CatWebTempletes x160 y654 w80 h25, Search
	Gui, Tracker:Add, Button,                    vButton_CatWebSite       gLabel_S_CatWebSite      x160 y682 w80 h25, Search
	Gui, Tracker:Add, Button,                    vButton_CatNone          gLabel_S_CatNone         x160 y710 w80 h25, Search
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; -------------------------------------------
  Gui, Tracker:Font, c000000 s12 w700, arial
  Gui, Tracker:Add, Text,                                                                        x20  y785  w55 h30, Length
  ;
  Gui, Tracker:Font, c000000 s14 w700, arial
  Gui, Tracker:Add, Edit,      Limit2 Number   vEdit_PasswordLength                              x82  y780  w30 h30,
  ;
  Gui, Tracker:Font, c000000 s12 w700, arial
  Gui, Tracker:Add, Radio,                     vRadio_Password          gLabel_R_Password        x130 y780  w100 h30, Password
  ;
  Gui, Tracker:Font, c000000 s14 w700, arial
  Gui, Tracker:Add, Edit,                      vEdit_Password           gLabel_E_Password        x235 y780  w230 h30,
  ;
  Gui, Tracker:Add, Picture,                   vClipboard_Password      gLabel_C_Password        x478 y780 w30 h30,
  ;
  Gui, Tracker:Font, c000000 s12 w700, arial
  Gui, Tracker:Add, Button,                    vGenerate                gLabel_Generate          x520 y780 w120 h30, Generate
  ; -------------------------------------------
  ;
  ; -------------------------------------------
  Gui, Tracker:Font, c000000 s18 w700, arial ; s18-h27 min
  Gui, Tracker:Add, Button,                    vButton_Accept           gLabel_Accept            x660 y745 w120 h60,
  Gui, Tracker:Add, Button,                    vButton_Cancel           gLabel_Cancel            x800 y745 w150 h60, Cancel
  ; -------------------------------------------
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  GuiControl, Tracker:Focus, Edit_RecordName
  Gui, Tracker:Color , e7d8fe ; Purple
  Gui, Tracker:-Caption
  Gui, Tracker:Show, w970 h830, PopUpMenu:Tracker
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  ;
  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
} ; Gui Define
; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Gui StartUp
; -------------------------------------------
OnOff_Notes := 0
OnOff_Password := 0
OnOff_FirstEmail := 0
OnOff_SecondEmail := 0
OnOff_LoginName := 0
OnOff_BusinessName := 0
OnOff_FirstName := 0
OnOff_LastName := 0
OnOff_Country := 0
OnOff_City := 0
OnOff_Street := 0
OnOff_ZipCode := 0
; -------------------------------------------
; Green Color  +c099d29
; Red Color    +cc42424
; Blue Color   +c333f82
; Yellow Color +cff9000
; Black Color  +c000000
; -------------------------------------------
ArrayThisPreSet := GetPreSet("FirstEmail", 0) ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_FirstEmail_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
PresetValue_FirstEmail_1 := ArrayThisPreSet.1
PresetValue_FirstEmail_2 := ArrayThisPreSet.2
PresetValue_FirstEmail_3 := ArrayThisPreSet.3
; -------------------------------------------
ArrayThisPreSet := GetPreSet("SecondEmail", 0) ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_FirstEmail_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
PresetValue_SecondEmail_1 := ArrayThisPreSet.1
PresetValue_SecondEmail_2 := ArrayThisPreSet.2
PresetValue_SecondEmail_3 := ArrayThisPreSet.3
; -------------------------------------------
ArrayThisPreSet := GetPreSet("LoginName", 0) ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_FirstEmail_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
PresetValue_LoginName_1 := ArrayThisPreSet.1
PresetValue_LoginName_2 := ArrayThisPreSet.2
PresetValue_LoginName_3 := ArrayThisPreSet.3
; -------------------------------------------
ArrayThisPreSet := GetPreSet("BusinessName", 0) ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_FirstEmail_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
PresetValue_BusinessName_1 := ArrayThisPreSet.1
PresetValue_BusinessName_2 := ArrayThisPreSet.2
PresetValue_BusinessName_3 := ArrayThisPreSet.3
; -------------------------------------------
ArrayThisPreSet := GetPreSet("FirstName", 0) ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_FirstEmail_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
PresetValue_FirstName_1 := ArrayThisPreSet.1
PresetValue_FirstName_2 := ArrayThisPreSet.2
PresetValue_FirstName_3 := ArrayThisPreSet.3
; -------------------------------------------
ArrayThisPreSet := GetPreSet("LastName", 0) ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_FirstEmail_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
PresetValue_LastName_1 := ArrayThisPreSet.1
PresetValue_LastName_2 := ArrayThisPreSet.2
PresetValue_LastName_3 := ArrayThisPreSet.3
; -------------------------------------------
ArrayThisPreSet := GetPreSet("Phone", 0) ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_FirstEmail_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
PresetValue_Phone_1 := ArrayThisPreSet.1
PresetValue_Phone_2 := ArrayThisPreSet.2
PresetValue_Phone_3 := ArrayThisPreSet.3
; -------------------------------------------
ArrayThisPreSet := GetPreSet("Country", 0) ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_FirstEmail_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
PresetValue_Country_1 := ArrayThisPreSet.1
PresetValue_Country_2 := ArrayThisPreSet.2
PresetValue_Country_3 := ArrayThisPreSet.3
; -------------------------------------------
ArrayThisPreSet := GetPreSet("City", 0) ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_FirstEmail_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
PresetValue_City_1 := ArrayThisPreSet.1
PresetValue_City_2 := ArrayThisPreSet.2
PresetValue_City_3 := ArrayThisPreSet.3
; -------------------------------------------
ArrayThisPreSet := GetPreSet("Street", 0) ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_FirstEmail_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
PresetValue_Street_1 := ArrayThisPreSet.1
PresetValue_Street_2 := ArrayThisPreSet.2
PresetValue_Street_3 := ArrayThisPreSet.3
; -------------------------------------------
ArrayThisPreSet := GetPreSet("ZipCode", 0) ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_FirstEmail_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
PresetValue_ZipCode_1 := ArrayThisPreSet.1
PresetValue_ZipCode_2 := ArrayThisPreSet.2
PresetValue_ZipCode_3 := ArrayThisPreSet.3
; -------------------------------------------
GuiControl, Tracker:Hide, Button_Accept
; -------------------------------------------
GuiControl, Tracker:Hide, Clipboard_Notes
GuiControl, Tracker:Hide, Clipboard_FirstEmail
GuiControl, Tracker:Hide, Clipboard_SecondEmail
GuiControl, Tracker:Hide, Clipboard_LoginName
GuiControl, Tracker:Hide, Clipboard_BusinessName
GuiControl, Tracker:Hide, Clipboard_FirstName
GuiControl, Tracker:Hide, Clipboard_LastName
GuiControl, Tracker:Hide, Clipboard_Phone
GuiControl, Tracker:Hide, Clipboard_Country
GuiControl, Tracker:Hide, Clipboard_City
GuiControl, Tracker:Hide, Clipboard_Street
GuiControl, Tracker:Hide, Clipboard_ZipCode
GuiControl, Tracker:Hide, Clipboard_Password
; -------------------------------------------
GuiControl, Tracker:Hide, Button_CatBrowser
GuiControl, Tracker:Hide, Button_CatBuySell
GuiControl, Tracker:Hide, Button_CatContact
GuiControl, Tracker:Hide, Button_CatDownLoad
GuiControl, Tracker:Hide, Button_CatEmail
GuiControl, Tracker:Hide, Button_CatForum
GuiControl, Tracker:Hide, Button_CatGame
GuiControl, Tracker:Hide, Button_CatInternet
GuiControl, Tracker:Hide, Button_CatMailer
GuiControl, Tracker:Hide, Button_CatMoney
GuiControl, Tracker:Hide, Button_CatProgram
GuiControl, Tracker:Hide, Button_CatSocial
GuiControl, Tracker:Hide, Button_CatWebHosting
GuiControl, Tracker:Hide, Button_CatWebTempletes
GuiControl, Tracker:Hide, Button_CatWebSite
GuiControl, Tracker:Hide, Button_CatNone
; -------------------------------------------
;
; -------------------------------------------
Reset_NewPassword("FirstLoad")
; -------------------------------------------
;
; -------------------------------------------
BlockInput, Off
BlockInput, MouseMoveOff
; -------------------------------------------
;
; -------------------------------------------
return
; -------------------------------------------
; Gui StartUp
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; Labels
; -------------------------------------------
GuiClose:
ExitApp
; -------------------------------------------
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Label_MinimizeWindow:
{
	; -------------------------------------------
	WinMinimize, A
	; -------------------------------------------
}
return
Label_Generate:
{
	; -------------------------------------------
	ControlGetFocus, CurrentFocus, A
	if (CurrentFocus != "ListBox1")
	{
		; -------------------------------------------
	  BlockInput, On
	  BlockInput, MouseMove
	  ; -------------------------------------------
	  OnOff_Password := PasswordGenerate() ; > OnOff_Password
	  ; -------------------------------------------
	  BlockInput, Off
	  BlockInput, MouseMoveOff
	  ; -------------------------------------------
	}
}
return
; -------------------------------------------
Label_ListBox_RecordSelect:
{
	; -------------------------------------------
	;~ BlockInput, On
	;~ BlockInput, MouseMove
	; -------------------------------------------
	;
	; -------------------------------------------
	Array_CurrentRecord := ""
	; -------------------------------------------
	Value_TitleTextDisplay := "Getting Record"
	Value_TextDisplay      := ""
	Color_TitleTextDisplay := "Blue"
	Color_TextDisplay      := "X"
	GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
	; -------------------------------------------
	;
	; -------------------------------------------
	GuiControlGet, SelectedRecord, Tracker:, ListBox_Search ; [SET] Item_Selected (String)
	GuiControlGet, OnOff_CatNone, Tracker:, Radio_CatNone
	; -------------------------------------------
	SelectedCategory := CurrentSelectedCategory() ; > Category
	; -------------------------------------------
	;
	; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	; [SET] (ArrayAllRecords_Category)
	; -------------------------------------------
	if (SelectedCategory == "none")
	{
		; -------------------------------------------
		ArrayAllRecords_Category := ArrayAllRecords
		; -------------------------------------------
	}
	else ; Category is Selected
	{
		; -------------------------------------------
		SelectedRecord := "(_" SelectedCategory "_)" SelectedRecord
		; -------------------------------------------
		ArrayAllRecords_Category := ""
		; -------------------------------------------
		for Index_1, Array_CheckRecord in ArrayAllRecords
	  {
  		; -------------------------------------------
		  Check_Category := Array_CheckRecord.2
			; -------------------------------------------
			if (SelectedCategory == Check_Category)
			{
				; -------------------------------------------
    	  ArrayAllRecords_Category := Array_Add(ArrayAllRecords_Category, Array_CheckRecord, "End") ; > ThisArray
				; -------------------------------------------
			}
		} ; for Index_1, Array_CheckRecord in ArrayAllRecords
		; -------------------------------------------
	} ; else ; Category is Selected
	; -------------------------------------------
	;
	; -------------------------------------------
	; [SET] (ArrayAllRecords_Category)
	; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	;
	; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	; Get Currently Selected Record Information
	; (Array_CurrentRecord) == [RecordNumber, Category, RecordName, SubName, Password, FirstEmail, SecondEmail, LoginName, BusinessName, FirstName, LastName, Phone, Country, City, Street, ZipCode, Notes]
	;                                 1            2         3          4        5          6           7           8            9           10         11      12      13     14      15       16      17
	; -------------------------------------------
  ; ArrayThisRecord := [A_LoopFileFullPath, Value_Category, Value_RecordName, Value_SubName]
  ; ArrayAllRecords := [ArrayThisRecord, ArrayThisRecord, etc]
	; -------------------------------------------
	for Index_1, Array_CheckRecord in ArrayAllRecords_Category
	{
		; -------------------------------------------
		FullFilePath     := Array_CheckRecord.1
		Check_Category   := Array_CheckRecord.2
		Check_RecordName := Array_CheckRecord.3
		Check_SubName    := Array_CheckRecord.4
		; -------------------------------------------
		;
		if (InStr(Check_SubName, "<EMPTY>") == 0 or StrLen(Check_SubName) > 0)
		{
		  ; -------------------------------------------
		  Check_TextRecord := "(_" Check_Category "_)(_" Check_RecordName "_)(_" Check_SubName "_)"
		  ; -------------------------------------------
		}
		else
		{
		  ; -------------------------------------------
		  Check_TextRecord := "(_" Check_Category "_)(_" Check_RecordName "_)"
		  ; -------------------------------------------
		}
		; -------------------------------------------
		Check_TextRecord := StrReplace(Check_TextRecord, "(_<EMPTY>_)", "")
		; -------------------------------------------
		if (SelectedRecord == Check_TextRecord)
		{
			; -------------------------------------------
			FileReadLine, Value_Category, %FullFilePath%, 2
			FileReadLine, Value_RecordName, %FullFilePath%, 4
			FileReadLine, Value_SubName, %FullFilePath%, 6
			FileReadLine, Value_Password, %FullFilePath%, 8
			FileReadLine, Value_FirstEmail, %FullFilePath%, 10
			FileReadLine, Value_SecondEmail, %FullFilePath%, 12
			FileReadLine, Value_LoginName, %FullFilePath%, 14
			FileReadLine, Value_BusinessName, %FullFilePath%, 16
			FileReadLine, Value_FirstName, %FullFilePath%, 18
			FileReadLine, Value_LastName, %FullFilePath%, 20
			FileReadLine, Value_Phone, %FullFilePath%, 22
			FileReadLine, Value_Country, %FullFilePath%, 24
			FileReadLine, Value_City, %FullFilePath%, 26
			FileReadLine, Value_Street, %FullFilePath%, 28
			FileReadLine, Value_ZipCode, %FileRecord%, 30
			; -------------------------------------------
			Array_FileRecord := Array_FromFile(FullFilePath) ; > Array
			; -------------------------------------------
			Value_Notes := ""
			; -------------------------------------------
			for Index_N, ThisLine in Array_FileRecord
			{
				if (Index_N > 31) ; 31 = (_PopUpMenu_Tracker_)_Notes
				{
					if (StrLen(Value_Notes) == 0)
					{
						Value_Notes := Array_FileRecord[Index_N]
					}
					else
					{
						Value_Notes := Value_Notes "`n" Array_FileRecord[Index_N]
					} ; else
				} ; if (Index_N > 31) ; 31 = (_PopUpMenu_Tracker_)_Notes
			} ; for Index_N, ThisLine in Array_FileRecord
			; -------------------------------------------
			;
			; -------------------------------------------
			if (Value_SubName == "")
			{
				Value_SubName := "<EMPTY>"
			}
			if (Value_Password == "")
			{
				Value_Password := "<EMPTY>"
			}
			if (Value_FirstEmail == "")
			{
				Value_FirstEmail := "<EMPTY>"
			}
			if (Value_SecondEmail == "")
			{
				Value_SecondEmail := "<EMPTY>"
			}
			if (Value_LoginName == "")
			{
				Value_LoginName := "<EMPTY>"
			}
			if (Value_BusinessName == "")
			{
				Value_BusinessName := "<EMPTY>"
			}
			if (Value_FirstName == "")
			{
				Value_FirstName := "<EMPTY>"
			}
			if (Value_LastName == "")
			{
				Value_LastName := "<EMPTY>"
			}
			if (Value_Phone == "")
			{
				Value_Phone := "<EMPTY>"
			}
			if (Value_Country == "")
			{
				Value_Country := "<EMPTY>"
			}
			if (Value_City == "")
			{
				Value_City := "<EMPTY>"
			}
			if (Value_Street == "")
			{
				Value_Street := "<EMPTY>"
			}
			if (Value_ZipCode == "")
			{
				Value_ZipCode := "<EMPTY>"
			}
			if (Value_Notes == "")
			{
				Value_Notes := "<EMPTY>"
			}
			; -------------------------------------------
			;
			; -------------------------------------------
			Array_CurrentRecord := ""
			; -------------------------------------------
			Array_CurrentRecord := Array_Add(Array_CurrentRecord, FullFilePath, ThisPos)    ; 1
			Array_CurrentRecord := Array_Add(Array_CurrentRecord, Value_Category, ThisPos)     ; 2
			Array_CurrentRecord := Array_Add(Array_CurrentRecord, Value_RecordName, ThisPos)   ; 3
			Array_CurrentRecord := Array_Add(Array_CurrentRecord, Value_SubName, ThisPos)      ; 4
			Array_CurrentRecord := Array_Add(Array_CurrentRecord, Value_Password, ThisPos)     ; 5
			Array_CurrentRecord := Array_Add(Array_CurrentRecord, Value_FirstEmail, ThisPos)   ; 6
			Array_CurrentRecord := Array_Add(Array_CurrentRecord, Value_SecondEmail, ThisPos)  ; 7
			Array_CurrentRecord := Array_Add(Array_CurrentRecord, Value_LoginName, ThisPos)    ; 8
			Array_CurrentRecord := Array_Add(Array_CurrentRecord, Value_BusinessName, ThisPos) ; 9
			Array_CurrentRecord := Array_Add(Array_CurrentRecord, Value_FirstName, ThisPos)    ; 10
			Array_CurrentRecord := Array_Add(Array_CurrentRecord, Value_LastName, ThisPos)     ; 11
			Array_CurrentRecord := Array_Add(Array_CurrentRecord, Value_Phone, ThisPos)        ; 12
			Array_CurrentRecord := Array_Add(Array_CurrentRecord, Value_Country, ThisPos)      ; 13
			Array_CurrentRecord := Array_Add(Array_CurrentRecord, Value_City, ThisPos)         ; 14
			Array_CurrentRecord := Array_Add(Array_CurrentRecord, Value_Street, ThisPos)       ; 15
			Array_CurrentRecord := Array_Add(Array_CurrentRecord, Value_ZipCode, ThisPos)      ; 16
			Array_CurrentRecord := Array_Add(Array_CurrentRecord, Value_Notes, ThisPos)        ; 17
			; -------------------------------------------
			;
			; -------------------------------------------
			ModDate := ConvertTime(Name_FileRecord) ; "" > ("2023.07.10.15.12.29") | ("2023.07.10.15.12.29") > "10 Jul, 2023 @ 15:12:29"
			SetEditFields(Array_CurrentRecord)
			; -------------------------------------------
			;
  	  ; -------------------------------------------
	    GuiControlGet, Value_Button_Accept, Tracker:, Button_Accept
	    ; -------------------------------------------
	    if (Value_Button_Accept != "Delete Record") ; Label_ListBox_RecordSelect
	    {
    		; -------------------------------------------
		    Gui, Tracker:Color, edbaba ; Red Color
		    ; -------------------------------------------
	    }
	    ; -------------------------------------------
	    ;
	    ; -------------------------------------------
	    GuiControl, Tracker:, Button_Accept, Delete Record
	    GuiControl, Tracker:MoveDraw, %Button_Accept%
	    GuiControl, Tracker:Show, Button_Accept
	    ; -------------------------------------------
	    ;
	    ; -------------------------------------------
	    Value_TitleTextDisplay := "Existing Record"
	    Value_TextDisplay      := ModDate
	    Color_TitleTextDisplay := "Green"
	    Color_TextDisplay      := "Blue"
	    GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
	    ; -------------------------------------------
			;
			; -------------------------------------------
			break ; BREAK OUT of (for Index_1, Array_CheckRecord in ArrayAllRecords_Category)
			; -------------------------------------------
		} ; if (SelectedRecord == Text_ThisRecord)
		; -------------------------------------------
	} ; for Index_1, Array_CheckRecord in ArrayAllRecords_Category
	; -------------------------------------------
	;
	; -------------------------------------------
	BlockInput, Off
	BlockInput, MouseMoveOff
	; -------------------------------------------
}
return
; -------------------------------------------
Label_NewRecord:
{
	; -------------------------------------------
	BlockInput, On
	BlockInput, MouseMove
	; -------------------------------------------
	Array_CurrentRecord := ""
	; -------------------------------------------
	Reset_NewPassword("")
	; -------------------------------------------
	GuiControl, Tracker:Hide, ListBox_Search
	; -------------------------------------------
	ListBox_Search_Clear := "|"
	GuiControl, Tracker:, ListBox_Search, %ListBox_Search_Clear%
	; -------------------------------------------
	BlockInput, Off
	BlockInput, MouseMoveOff
	; -------------------------------------------
}
return
; -------------------------------------------
Label_ExistingRecord: ; Add Search ListBox
{
	; -------------------------------------------
	BlockInput, On
	BlockInput, MouseMove
	; -------------------------------------------
	;
	; -------------------------------------------
	GuiControl, Tracker:Show, Button_CatBrowser
	GuiControl, Tracker:Show, Button_CatBuySell
	GuiControl, Tracker:Show, Button_CatContact
	GuiControl, Tracker:Show, Button_CatDownLoad
	GuiControl, Tracker:Show, Button_CatEmail
	GuiControl, Tracker:Show, Button_CatForum
	GuiControl, Tracker:Show, Button_CatGame
	GuiControl, Tracker:Show, Button_CatInternet
	GuiControl, Tracker:Show, Button_CatMailer
	GuiControl, Tracker:Show, Button_CatMoney
	GuiControl, Tracker:Show, Button_CatProgram
	GuiControl, Tracker:Show, Button_CatSocial
	GuiControl, Tracker:Show, Button_CatWebHosting
	GuiControl, Tracker:Show, Button_CatWebTempletes
	GuiControl, Tracker:Show, Button_CatWebSite
	GuiControl, Tracker:Show, Button_CatNone
	; -------------------------------------------
	;
	; -------------------------------------------
	Value_TitleTextDisplay := "Loading Records"
	Value_TextDisplay      := "Please Wait"
	Color_TitleTextDisplay := "Blue"
	Color_TextDisplay      := "Blue"
	GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
	; -------------------------------------------
	;
	; -------------------------------------------
	GuiControl, Tracker:+c000000, Radio_NewRecord ; Black Color
	GuiControl, Tracker:MoveDraw, Radio_NewRecord
	GuiControl, Tracker:+cc42424, Radio_ExistingRecord ; Red Color
	GuiControl, Tracker:MoveDraw, Radio_ExistingRecord
	; -------------------------------------------
	GuiControl, Tracker:, Radio_NewRecord, 0
	GuiControl, Tracker:, Radio_ExistingRecord, 1
	; -------------------------------------------
	Clear_ListBox_Search_List := "|"
	GuiControl, Tracker:, ListBox_Search, %Clear_ListBox_Search_List%
	; -------------------------------------------
	;
	; -------------------------------------------
	if (Added_ListBox_Search != 1)
	{
		; -------------------------------------------
		Array_Returned := ""
		ListBox_Search_List := ""
		Array_SearchList := ""
		; -------------------------------------------
		Array_Returned := CategorySearch(ArrayAllRecords) ; > [ListBox_Search_List, Array_SearchList]
		ListBox_Search_List := Array_Returned.1
		Array_SearchList := Array_Returned.2
		; -------------------------------------------
		Gui, Tracker:Font, c000000 s8 w700, arial
		Gui, Tracker:Add, ListBox, R9 vListBox_Search gLabel_ListBox_RecordSelect x20 y85 w340,
		Added_ListBox_Search := 1
		GuiControl, Tracker:, ListBox_Search, %ListBox_Search_List%
		GuiControl, Tracker:Show, ListBox_Search
		; -------------------------------------------
	}
	else
	{
		; -------------------------------------------
		Array_Returned := ""
		ListBox_Search_List := ""
		Array_SearchList := ""
		; -------------------------------------------
		Array_Returned := CategorySearch(ArrayAllRecords) ; > [ListBox_Search_List, Array_SearchList]
		ListBox_Search_List := Array_Returned.1
		Array_SearchList := Array_Returned.2
		; -------------------------------------------
		GuiControl, Tracker:, ListBox_Search, %ListBox_Search_List%
		GuiControl, Tracker:Show, ListBox_Search
		; -------------------------------------------
	}
	; -------------------------------------------
	;
	; -------------------------------------------
	Value_TitleTextDisplay := "Select Record"
	Value_TextDisplay      := ""
	Color_TitleTextDisplay := "Blue"
	Color_TextDisplay      := "X"
	GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
	; -------------------------------------------
	;
	; -------------------------------------------
	BlockInput, Off
	BlockInput, MouseMoveOff
	; -------------------------------------------
}
return
; -------------------------------------------
Label_E_RecordName: ; Edit Feild
{
	; -------------------------------------------
	ControlGetFocus, CurrentFocus, A
	if (CurrentFocus != "ListBox1")
	{
	  ; -------------------------------------------
	  ReturnedAnswer := EditFeildCheck("Edit_RecordName", Array_CurrentRecord) ; CheckThisEdit = Edit_ObjectName > (0) Empty Feild -OR- (ThisEditValue)
	  ; -------------------------------------------
	}
	; -------------------------------------------
}
return
; -------------------------------------------
Label_E_SubName: ; Edit Feild
{
	; -------------------------------------------
	ControlGetFocus, CurrentFocus, A
	if (CurrentFocus != "ListBox1")
	{
	  ; -------------------------------------------
	  ReturnedAnswer := EditFeildCheck("Edit_SubName", Array_CurrentRecord) ; CheckThisEdit = Edit_ObjectName > (0) Empty Feild -OR- (ThisEditValue)
	  ; -------------------------------------------
	}
	; -------------------------------------------
}
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Label_C_Notes: ; Clipboard Image
{
	; -------------------------------------------
	OnClipBoard := Clipboard_OnOff("Notes", OnClipBoard) ; > OnClipBoard
	; -------------------------------------------
}
return
; -------------------------------------------
Label_E_Notes: ; Edit Feild
{
	; -------------------------------------------
	ControlGetFocus, CurrentFocus, A
	if (CurrentFocus != "ListBox1")
	{
	  ; -------------------------------------------
	  ReturnedAnswer := EditFeildCheck("Edit_Notes", Array_CurrentRecord) ; CheckThisEdit = Edit_ObjectName > (0) Empty Feild -OR- (ThisEditValue)
	  ; -------------------------------------------
	  if (ReturnedAnswer == 0) ; Field is Empty
	  {
  		; -------------------------------------------
		  OnOff_Notes := 0
		  ; -------------------------------------------
		  GuiControl, Tracker:+c000000, Radio_Notes ; Black Color
		  ; -------------------------------------------
		  GuiControl, Tracker:, Edit_Notes, ; Empty Edit Feild
		  ; -------------------------------------------
	  }
	  ; -------------------------------------------
	  else ; Field is NOT Empty | (ReturnedAnswer) = Value of Edit Feild
	  {
  		; -------------------------------------------
		  OnOff_Notes := 1
		  ; -------------------------------------------
		  GuiControl, Tracker:+cc42424, Radio_Notes ; Red Color
		  ; -------------------------------------------
	  }
	  ; -------------------------------------------
	  GuiControl, Tracker:, Radio_Password, %OnOff_Notes%
	  GuiControl, Tracker:MoveDraw, Radio_Notes
	  ; -------------------------------------------
	}
	; -------------------------------------------
}
return
; -------------------------------------------
Label_R_Notes: ; Main Radio
{
	; -------------------------------------------
	ControlGetFocus, CurrentFocus, A
	if (CurrentFocus != "ListBox1")
	{
  	; -------------------------------------------
  	if (OnOff_Notes == "")
  	{
		  GuiControlGet, OnOff_Notes, Tracker:, Radio_Notes
	  }
	  ; -------------------------------------------
	  if (OnOff_Notes == 0)
	  {
  		; -------------------------------------------
		  OnOff_Notes := 1
		  ; -------------------------------------------
		  GuiControl, Tracker:+cc42424, Radio_Notes ; Red Color
		  ; -------------------------------------------
	  }
	  else if (OnOff_Notes == 1)
	  {
  		; -------------------------------------------
		  OnOff_Notes := 0
		  ; -------------------------------------------
		  GuiControl, Tracker:+c000000, Radio_Notes ; Black Color
		  ; -------------------------------------------
  	  GuiControl, Tracker:, Edit_Notes,
		  ; -------------------------------------------
	  }
		; -------------------------------------------
		EditFeildCheck("", Array_CurrentRecord) ; CheckThisEdit = Edit_ObjectName > (0) Empty Feild -OR- (ThisEditValue)
		; -------------------------------------------
	  GuiControl, Tracker:, Radio_Notes, %OnOff_Notes%
	  ; -------------------------------------------
	  GuiControl, Tracker:MoveDraw, Radio_Notes
	  ; -------------------------------------------
	}
}
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Label_C_Password: ; Clipboard Image
{
	; -------------------------------------------
	OnClipBoard := Clipboard_OnOff("Password", OnClipBoard) ; > OnClipBoard
	; -------------------------------------------
}
return
; -------------------------------------------
Label_E_Password: ; Edit Feild
{
	; -------------------------------------------
	ControlGetFocus, CurrentFocus, A
	if (CurrentFocus != "ListBox1")
	{
	  ; -------------------------------------------
	  ReturnedAnswer := EditFeildCheck("Edit_Password", Array_CurrentRecord) ; CheckThisEdit = Edit_ObjectName > (0) Empty Feild -OR- (ThisEditValue)
	  ; -------------------------------------------
	  if (ReturnedAnswer == 0) ; Field is Empty
	  {
  		; -------------------------------------------
		  OnOff_Password := 0
		  ; -------------------------------------------
		  GuiControl, Tracker:+c000000, Radio_Password ; Black Color
		  ; -------------------------------------------
		  GuiControl, Tracker:, Edit_Password, ; Empty Edit Feild
		  ; -------------------------------------------
	  }
	  else ; Field is NOT Empty | (ReturnedAnswer) = Value of Edit Feild
	  {
  		; -------------------------------------------
		  OnOff_Password := 1
		  ; -------------------------------------------
		  GuiControl, Tracker:+cc42424, Radio_Password ; Red Color
		  ; -------------------------------------------
	  }
	  ; -------------------------------------------
	  GuiControl, Tracker:, Radio_Password, %OnOff_Password%
	  GuiControl, Tracker:MoveDraw, Radio_Password
	  ; -------------------------------------------
	}
}
return
; -------------------------------------------
Label_R_Password: ; Main Radio
{
	; -------------------------------------------
	if (OnOff_Password == "")
	{
		GuiControlGet, OnOff_Password, Tracker:, Radio_Password
	}
	; -------------------------------------------
	if (OnOff_Password == 0)
	{
		; -------------------------------------------
		OnOff_Password := 1
		; -------------------------------------------
		GuiControl, Tracker:+cc42424, Radio_Password ; Red Color
		; -------------------------------------------
	}
	else if (OnOff_Password == 1)
	{
		; -------------------------------------------
		OnOff_Password := 0
		; -------------------------------------------
		GuiControl, Tracker:+c000000, Radio_Password ; Black Color
		; -------------------------------------------
		GuiControl, Tracker:, Edit_Password,
		; -------------------------------------------
	}
	; -------------------------------------------
	EditFeildCheck("", Array_CurrentRecord) ; CheckThisEdit = Edit_ObjectName > (0) Empty Feild -OR- (ThisEditValue)
	; -------------------------------------------
	GuiControl, Tracker:, Radio_Password, %OnOff_Password%
	; -------------------------------------------
	GuiControl, Tracker:MoveDraw, Radio_Password
	; -------------------------------------------
}
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Label_FirstEmail_1:
{
	; -------------------------------------------
	ArrayThisPreSet := GetPreSet("FirstEmail", "Radio_FirstEmail_1") ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_FirstEmail_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
	PresetValue_FirstEmail_1 := ArrayThisPreSet.1
	PresetValue_FirstEmail_2 := ArrayThisPreSet.2
	PresetValue_FirstEmail_3 := ArrayThisPreSet.3
	; -------------------------------------------
	;
	; -------------------------------------------
	GuiControl, Tracker:Enable, Update_FirstEmail
	; -------------------------------------------
	if (StrLen(PresetValue_FirstEmail_1) > 0)
	{
		GuiControl, Tracker:, Edit_FirstEmail, %PresetValue_FirstEmail_1%
	}
	; --------------------------------------------
}
return
; -------------------------------------------
Label_FirstEmail_2:
{
	; -------------------------------------------
	ArrayThisPreSet := GetPreSet("FirstEmail", "Radio_FirstEmail_2") ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_FirstEmail_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
	PresetValue_FirstEmail_1 := ArrayThisPreSet.1
	PresetValue_FirstEmail_2 := ArrayThisPreSet.2
	PresetValue_FirstEmail_3 := ArrayThisPreSet.3
	; -------------------------------------------
	;
	; -------------------------------------------
	GuiControl, Tracker:Enable, Update_FirstEmail
	; -------------------------------------------
	if (StrLen(PresetValue_FirstEmail_2) > 0)
	{
		GuiControl, Tracker:, Edit_FirstEmail, %PresetValue_FirstEmail_2%
	}
	; --------------------------------------------
}
return
; -------------------------------------------
Label_FirstEmail_3:
{
	; -------------------------------------------
	ArrayThisPreSet := GetPreSet("FirstEmail", "Radio_FirstEmail_3") ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_FirstEmail_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
	PresetValue_FirstEmail_1 := ArrayThisPreSet.1
	PresetValue_FirstEmail_2 := ArrayThisPreSet.2
	PresetValue_FirstEmail_3 := ArrayThisPreSet.3
	; -------------------------------------------
	;
	; -------------------------------------------
	GuiControl, Tracker:Enable, Update_FirstEmail
	; -------------------------------------------
	if (StrLen(PresetValue_FirstEmail_3) > 0)
	{
		GuiControl, Tracker:, Edit_FirstEmail, %PresetValue_FirstEmail_3%
	}
	; --------------------------------------------
}
return
; -------------------------------------------
Label_U_FirstEmail: ; Update
{
	; -------------------------------------------
	GuiControlGet, OnOff_FirstEmail_1, Tracker:, Radio_FirstEmail_1
	GuiControlGet, OnOff_FirstEmail_2, Tracker:, Radio_FirstEmail_2
	GuiControlGet, OnOff_FirstEmail_3, Tracker:, Radio_FirstEmail_3
	; -------------------------------------------
	if (OnOff_FirstEmail_1 == 1)
	{
		GuiControlGet, PresetValue_FirstEmail_1, Tracker:, Edit_FirstEmail
	}
	else if (OnOff_FirstEmail_2 == 1)
	{
		GuiControlGet, PresetValue_FirstEmail_2, Tracker:, Edit_FirstEmail
	}
	else if (OnOff_FirstEmail_3 == 1)
	{
		GuiControlGet, PresetValue_FirstEmail_3, Tracker:, Edit_FirstEmail
	}
	; -------------------------------------------
	File_FirstEmail := Path_DAT "\Presets\FirstEmail.txt"
	; -------------------------------------------
	if FileExist(File_FirstEmail)
	{
		FileDelete, %File_FirstEmail%
		Sleep, 100
	}
	; -------------------------------------------
	FileAppend, %PresetValue_FirstEmail_1%`n, %File_FirstEmail%, UTF-8
	FileAppend, %PresetValue_FirstEmail_2%`n, %File_FirstEmail%, UTF-8
	FileAppend, %PresetValue_FirstEmail_3%`n, %File_FirstEmail%, UTF-8
	; -------------------------------------------
	Array_Preset := GetPreSet("FirstEmail", 1) ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_FirstEmail_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
	; -------------------------------------------
}
return
; -------------------------------------------
Label_C_FirstEmail: ; Clipboard Image
{
	; -------------------------------------------
	;~ ControlGetFocus, CurrentFocus, A
	;~ if (CurrentFocus != "ListBox1")
	;~ {
	  ; -------------------------------------------
	  OnClipBoard := Clipboard_OnOff("FirstEmail", OnClipBoard) ; > OnClipBoard
	  ; -------------------------------------------
	;~ } ; if (CurrentFocus != "ListBox1")
	; -------------------------------------------
}
return
; -------------------------------------------
Label_E_FirstEmail: ; Edit Feild
{
	; -------------------------------------------
	ControlGetFocus, CurrentFocus, A
	if (CurrentFocus != "ListBox1")
	{
	  ; -------------------------------------------
	  ReturnedAnswer := EditFeildCheck("Edit_FirstEmail", Array_CurrentRecord) ; CheckThisEdit = Edit_ObjectName > (0) Empty Feild -OR- (ThisEditValue)
	  ; -------------------------------------------
	  if (ReturnedAnswer == 0) ; Field is Empty
	  {
  		; -------------------------------------------
		  OnOff_FirstEmail := 0
		  ; -------------------------------------------
		  GuiControl, Tracker:+c000000, Radio_FirstEmail ; Black Color
		  ; -------------------------------------------
		  GuiControl, Tracker:, Edit_FirstEmail, ; Empty Edit Feild
		  ; -------------------------------------------
	  }
	  else ; Field is NOT Empty | (ReturnedAnswer) = Value of Edit Feild
	  {
  		; -------------------------------------------
		  OnOff_FirstEmail := 1
		  ; -------------------------------------------
		  GuiControl, Tracker:+cc42424, Radio_FirstEmail ; Red Color
		  ; -------------------------------------------
	  }
	  ; -------------------------------------------
	  GuiControl, Tracker:, Radio_FirstEmail, %OnOff_FirstEmail%
	  GuiControl, Tracker:MoveDraw, Radio_FirstEmail
	  ; -------------------------------------------
	  PreSetEditCheck("Edit_FirstEmail", PresetValue_FirstEmail_1, PresetValue_FirstEmail_2, PresetValue_FirstEmail_3)
	  ; -------------------------------------------
 	} ; if (CurrentFocus != "ListBox1")
 	; -------------------------------------------
}
return
; -------------------------------------------
Label_R_FirstEmail: ; Main Radio
{
	; -------------------------------------------
	if (OnOff_FirstEmail == "")
	{
		GuiControlGet, OnOff_FirstEmail, Tracker:, Radio_FirstEmail
	}
	; -------------------------------------------
	if (OnOff_FirstEmail == 0) ; Is UnSelected > Select (Red) 
	{
		; -------------------------------------------
		OnOff_FirstEmail := 1
		; -------------------------------------------
		GuiControl, Tracker:+cc42424, Radio_FirstEmail ; Red Color
		; -------------------------------------------
	}
	else if (OnOff_FirstEmail == 1) ; Is Selected > UnSelect (Black)
	{
		; -------------------------------------------
		OnOff_FirstEmail := 0
		; -------------------------------------------
		GuiControl, Tracker:+c000000, Radio_FirstEmail ; Black Color
		; -------------------------------------------
		GuiControl, Tracker:, Edit_FirstEmail,
		; -------------------------------------------
		GuiControl, Tracker:Disable, Update_FirstEmail
		; -------------------------------------------
		GuiControl, Tracker:, Radio_FirstEmail_1, 0
		GuiControl, Tracker:MoveDraw, Radio_FirstEmail_1
		GuiControl, Tracker:, Radio_FirstEmail_2, 0
		GuiControl, Tracker:MoveDraw, Radio_FirstEmail_2
		GuiControl, Tracker:, Radio_FirstEmail_3, 0
		GuiControl, Tracker:MoveDraw, Radio_FirstEmail_3
		; -------------------------------------------
		Array_Preset := GetPreSet("FirstEmail", 0) ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_FirstEmail_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
		; -------------------------------------------
	}
	; -------------------------------------------
	EditFeildCheck("", Array_CurrentRecord) ; CheckThisEdit = Edit_ObjectName > (0) Empty Feild -OR- (ThisEditValue)
	; -------------------------------------------
	GuiControl, Tracker:, Radio_FirstEmail, %OnOff_FirstEmail%
	; -------------------------------------------
	GuiControl, Tracker:MoveDraw, Radio_FirstEmail
	; -------------------------------------------
}
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Label_SecondEmail_1:
{
	; -------------------------------------------
	ArrayThisPreSet := GetPreSet("SecondEmail", "Radio_SecondEmail_1") ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_SecondEmail_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
	PresetValue_SecondEmail_1 := ArrayThisPreSet.1
	PresetValue_SecondEmail_2 := ArrayThisPreSet.2
	PresetValue_SecondEmail_3 := ArrayThisPreSet.3
	; -------------------------------------------
	;
	; -------------------------------------------
	GuiControl, Tracker:Enable, Update_SecondEmail
	; -------------------------------------------
	if (StrLen(PresetValue_SecondEmail_1) > 0)
	{
		GuiControl, Tracker:, Edit_SecondEmail, %PresetValue_SecondEmail_1%
	}
	; --------------------------------------------
}
return
; -------------------------------------------
Label_SecondEmail_2:
{
	; -------------------------------------------
	ArrayThisPreSet := GetPreSet("SecondEmail", "Radio_SecondEmail_2") ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_SecondEmail_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
	PresetValue_SecondEmail_1 := ArrayThisPreSet.1
	PresetValue_SecondEmail_2 := ArrayThisPreSet.2
	PresetValue_SecondEmail_3 := ArrayThisPreSet.3
	; -------------------------------------------
	;
	; -------------------------------------------
	GuiControl, Tracker:Enable, Update_SecondEmail
	; -------------------------------------------
	if (StrLen(PresetValue_SecondEmail_2) > 0)
	{
		GuiControl, Tracker:, Edit_SecondEmail, %PresetValue_SecondEmail_2%
	}
	; --------------------------------------------
}
return
; -------------------------------------------
Label_SecondEmail_3:
{
	; -------------------------------------------
	ArrayThisPreSet := GetPreSet("SecondEmail", "Radio_SecondEmail_3") ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_SecondEmail_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
	PresetValue_SecondEmail_1 := ArrayThisPreSet.1
	PresetValue_SecondEmail_2 := ArrayThisPreSet.2
	PresetValue_SecondEmail_3 := ArrayThisPreSet.3
	; -------------------------------------------
	;
	; -------------------------------------------
	GuiControl, Tracker:Enable, Update_SecondEmail
	; -------------------------------------------
	if (StrLen(PresetValue_SecondEmail_3) > 0)
	{
		GuiControl, Tracker:, Edit_SecondEmail, %PresetValue_SecondEmail_3%
	}
	; --------------------------------------------
}
return
; -------------------------------------------
Label_U_SecondEmail: ; Update
{
	; -------------------------------------------
	GuiControlGet, OnOff_SecondEmail_1, Tracker:, Radio_SecondEmail_1
	GuiControlGet, OnOff_SecondEmail_2, Tracker:, Radio_SecondEmail_2
	GuiControlGet, OnOff_SecondEmail_3, Tracker:, Radio_SecondEmail_3
	; -------------------------------------------
	if (OnOff_SecondEmail_1 == 1)
	{
		GuiControlGet, PresetValue_SecondEmail_1, Tracker:, Edit_SecondEmail
	}
	else if (OnOff_SecondEmail_2 == 1)
	{
		GuiControlGet, PresetValue_SecondEmail_2, Tracker:, Edit_SecondEmail
	}
	else if (OnOff_SecondEmail_3 == 1)
	{
		GuiControlGet, PresetValue_SecondEmail_3, Tracker:, Edit_SecondEmail
	}
	; -------------------------------------------
	File_SecondEmail := Path_DAT "\Presets\SecondEmail.txt"
	; -------------------------------------------
	if FileExist(File_SecondEmail)
	{
		FileDelete, %File_SecondEmail%
		Sleep, 100
	}
	; -------------------------------------------
	FileAppend, %PresetValue_SecondEmail_1%`n, %File_SecondEmail%, UTF-8
	FileAppend, %PresetValue_SecondEmail_2%`n, %File_SecondEmail%, UTF-8
	FileAppend, %PresetValue_SecondEmail_3%`n, %File_SecondEmail%, UTF-8
	; -------------------------------------------
	Array_Preset := GetPreSet("SecondEmail", 1) ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_SecondEmail_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
	; -------------------------------------------
}
return
; -------------------------------------------
Label_C_SecondEmail: ; Clipboard Image
{
	; -------------------------------------------
	ControlGetFocus, CurrentFocus, A
	if (CurrentFocus != "ListBox1")
	{
	  ; -------------------------------------------
	  OnClipBoard := Clipboard_OnOff("SecondEmail", OnClipBoard) ; > OnClipBoard
	  ; -------------------------------------------
	} ; if (CurrentFocus != "ListBox1")
	; -------------------------------------------
}
return
; -------------------------------------------
Label_E_SecondEmail: ; Edit Feild
{
	; -------------------------------------------
	ControlGetFocus, CurrentFocus, A
	if (CurrentFocus != "ListBox1")
	{
	  ; -------------------------------------------
	  ReturnedAnswer := EditFeildCheck("Edit_SecondEmail", Array_CurrentRecord) ; CheckThisEdit = Edit_ObjectName > (0) Empty Feild -OR- (ThisEditValue)
	  ; -------------------------------------------
	  if (ReturnedAnswer == 0) ; Field is Empty
	  {
  		; -------------------------------------------
		  OnOff_SecondEmail := 0
		  ; -------------------------------------------
		  GuiControl, Tracker:+c000000, Radio_SecondEmail ; Black Color
		  ; -------------------------------------------
		  GuiControl, Tracker:, Edit_SecondEmail, ; Empty Edit Feild
		  ; -------------------------------------------
	  }
	  else ; Field is NOT Empty | (ReturnedAnswer) = Value of Edit Feild
	  {
  		; -------------------------------------------
		  OnOff_SecondEmail := 1
		  ; -------------------------------------------
		  GuiControl, Tracker:+cc42424, Radio_SecondEmail ; Red Color
		  ; -------------------------------------------
	  }
	  ; -------------------------------------------
	  GuiControl, Tracker:, Radio_SecondEmail, %OnOff_SecondEmail%
	  GuiControl, Tracker:MoveDraw, Radio_SecondEmail
	  ; -------------------------------------------
	  PreSetEditCheck("Edit_SecondEmail", PresetValue_SecondEmail_1, PresetValue_SecondEmail_2, PresetValue_SecondEmail_3)
	  ; -------------------------------------------
 	} ; if (CurrentFocus != "ListBox1")
 	; -------------------------------------------
}
return
; -------------------------------------------
Label_R_SecondEmail: ; Main Radio
{
	; -------------------------------------------
	if (OnOff_SecondEmail == "")
	{
		GuiControlGet, OnOff_SecondEmail, Tracker:, Radio_SecondEmail
	}
	; -------------------------------------------
	if (OnOff_SecondEmail == 0) ; Is UnSelected > Select (Red) 
	{
		; -------------------------------------------
		OnOff_SecondEmail := 1
		; -------------------------------------------
		GuiControl, Tracker:+cc42424, Radio_SecondEmail ; Red Color
		; -------------------------------------------
	}
	else if (OnOff_SecondEmail == 1) ; Is Selected > UnSelect (Black)
	{
		; -------------------------------------------
		OnOff_SecondEmail := 0
		; -------------------------------------------
		GuiControl, Tracker:+c000000, Radio_SecondEmail ; Black Color
		; -------------------------------------------
		GuiControl, Tracker:, Edit_SecondEmail,
		; -------------------------------------------
		GuiControl, Tracker:Disable, Update_SecondEmail
		; -------------------------------------------
		GuiControl, Tracker:, Radio_SecondEmail_1, 0
		GuiControl, Tracker:MoveDraw, Radio_SecondEmail_1
		GuiControl, Tracker:, Radio_SecondEmail_2, 0
		GuiControl, Tracker:MoveDraw, Radio_SecondEmail_2
		GuiControl, Tracker:, Radio_SecondEmail_3, 0
		GuiControl, Tracker:MoveDraw, Radio_SecondEmail_3
		; -------------------------------------------
		Array_Preset := GetPreSet("SecondEmail", 0) ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_SecondEmail_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
		; -------------------------------------------
	}
	; -------------------------------------------
	EditFeildCheck("", Array_CurrentRecord) ; CheckThisEdit = Edit_ObjectName > (0) Empty Feild -OR- (ThisEditValue)
	; -------------------------------------------
	GuiControl, Tracker:, Radio_SecondEmail, %OnOff_SecondEmail%
	; -------------------------------------------
	GuiControl, Tracker:MoveDraw, Radio_SecondEmail
	; -------------------------------------------
}
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Label_LoginName_1:
{
	; -------------------------------------------
	ArrayThisPreSet := GetPreSet("LoginName", "Radio_LoginName_1") ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_LoginName_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
	PresetValue_LoginName_1 := ArrayThisPreSet.1
	PresetValue_LoginName_2 := ArrayThisPreSet.2
	PresetValue_LoginName_3 := ArrayThisPreSet.3
	; -------------------------------------------
	;
	; -------------------------------------------
	GuiControl, Tracker:Enable, Update_LoginName
	; -------------------------------------------
	if (StrLen(PresetValue_LoginName_1) > 0)
	{
		GuiControl, Tracker:, Edit_LoginName, %PresetValue_LoginName_1%
	}
	; --------------------------------------------
}
return
; -------------------------------------------
Label_LoginName_2:
{
	; -------------------------------------------
	ArrayThisPreSet := GetPreSet("LoginName", "Radio_LoginName_2") ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_LoginName_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
	PresetValue_LoginName_1 := ArrayThisPreSet.1
	PresetValue_LoginName_2 := ArrayThisPreSet.2
	PresetValue_LoginName_3 := ArrayThisPreSet.3
	; -------------------------------------------
	;
	; -------------------------------------------
	GuiControl, Tracker:Enable, Update_LoginName
	; -------------------------------------------
	if (StrLen(PresetValue_LoginName_2) > 0)
	{
		GuiControl, Tracker:, Edit_LoginName, %PresetValue_LoginName_2%
	}
	; --------------------------------------------
}
return
; -------------------------------------------
Label_LoginName_3:
{
	; -------------------------------------------
	ArrayThisPreSet := GetPreSet("LoginName", "Radio_LoginName_3") ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_LoginName_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
	PresetValue_LoginName_1 := ArrayThisPreSet.1
	PresetValue_LoginName_2 := ArrayThisPreSet.2
	PresetValue_LoginName_3 := ArrayThisPreSet.3
	; -------------------------------------------
	;
	; -------------------------------------------
	GuiControl, Tracker:Enable, Update_LoginName
	; -------------------------------------------
	if (StrLen(PresetValue_LoginName_3) > 0)
	{
		GuiControl, Tracker:, Edit_LoginName, %PresetValue_LoginName_3%
	}
	; --------------------------------------------
}
return
; -------------------------------------------
Label_U_LoginName: ; Update
{
	; -------------------------------------------
	GuiControlGet, OnOff_LoginName_1, Tracker:, Radio_LoginName_1
	GuiControlGet, OnOff_LoginName_2, Tracker:, Radio_LoginName_2
	GuiControlGet, OnOff_LoginName_3, Tracker:, Radio_LoginName_3
	; -------------------------------------------
	if (OnOff_LoginName_1 == 1)
	{
		GuiControlGet, PresetValue_LoginName_1, Tracker:, Edit_LoginName
	}
	else if (OnOff_LoginName_2 == 1)
	{
		GuiControlGet, PresetValue_LoginName_2, Tracker:, Edit_LoginName
	}
	else if (OnOff_LoginName_3 == 1)
	{
		GuiControlGet, PresetValue_LoginName_3, Tracker:, Edit_LoginName
	}
	; -------------------------------------------
	File_LoginName := Path_DAT "\Presets\LoginName.txt"
	; -------------------------------------------
	if FileExist(File_LoginName)
	{
		FileDelete, %File_LoginName%
		Sleep, 100
	}
	; -------------------------------------------
	FileAppend, %PresetValue_LoginName_1%`n, %File_LoginName%, UTF-8
	FileAppend, %PresetValue_LoginName_2%`n, %File_LoginName%, UTF-8
	FileAppend, %PresetValue_LoginName_3%`n, %File_LoginName%, UTF-8
	; -------------------------------------------
	Array_Preset := GetPreSet("LoginName", 1) ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_LoginName_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
	; -------------------------------------------
}
return
; -------------------------------------------
Label_C_LoginName: ; Clipboard Image
{
	; -------------------------------------------
	ControlGetFocus, CurrentFocus, A
	if (CurrentFocus != "ListBox1")
	{
	  ; -------------------------------------------
	  OnClipBoard := Clipboard_OnOff("LoginName", OnClipBoard) ; > OnClipBoard
	  ; -------------------------------------------
	} ; if (CurrentFocus != "ListBox1")
	; -------------------------------------------
}
return
; -------------------------------------------
Label_E_LoginName: ; Edit Feild
{
	; -------------------------------------------
	ControlGetFocus, CurrentFocus, A
	if (CurrentFocus != "ListBox1")
	{
	  ; -------------------------------------------
	  ReturnedAnswer := EditFeildCheck("Edit_LoginName", Array_CurrentRecord) ; CheckThisEdit = Edit_ObjectName > (0) Empty Feild -OR- (ThisEditValue)
	  ; -------------------------------------------
	  if (ReturnedAnswer == 0) ; Field is Empty
	  {
  		; -------------------------------------------
		  OnOff_LoginName := 0
		  ; -------------------------------------------
		  GuiControl, Tracker:+c000000, Radio_LoginName ; Black Color
		  ; -------------------------------------------
		  GuiControl, Tracker:, Edit_LoginName, ; Empty Edit Feild
		  ; -------------------------------------------
	  }
	  else ; Field is NOT Empty | (ReturnedAnswer) = Value of Edit Feild
	  {
  		; -------------------------------------------
		  OnOff_LoginName := 1
		  ; -------------------------------------------
		  GuiControl, Tracker:+cc42424, Radio_LoginName ; Red Color
		  ; -------------------------------------------
	  }
	  ; -------------------------------------------
	  GuiControl, Tracker:, Radio_LoginName, %OnOff_LoginName%
	  GuiControl, Tracker:MoveDraw, Radio_LoginName
	  ; -------------------------------------------
	  PreSetEditCheck("Edit_LoginName", PresetValue_LoginName_1, PresetValue_LoginName_2, PresetValue_LoginName_3)
	  ; -------------------------------------------
 	} ; if (CurrentFocus != "ListBox1")
 	; -------------------------------------------
}
return
; -------------------------------------------
Label_R_LoginName: ; Main Radio
{
	; -------------------------------------------
	if (OnOff_LoginName == "")
	{
		GuiControlGet, OnOff_LoginName, Tracker:, Radio_LoginName
	}
	; -------------------------------------------
	if (OnOff_LoginName == 0) ; Is UnSelected > Select (Red) 
	{
		; -------------------------------------------
		OnOff_LoginName := 1
		; -------------------------------------------
		GuiControl, Tracker:+cc42424, Radio_LoginName ; Red Color
		; -------------------------------------------
	}
	else if (OnOff_LoginName == 1) ; Is Selected > UnSelect (Black)
	{
		; -------------------------------------------
		OnOff_LoginName := 0
		; -------------------------------------------
		GuiControl, Tracker:+c000000, Radio_LoginName ; Black Color
		; -------------------------------------------
		GuiControl, Tracker:, Edit_LoginName,
		; -------------------------------------------
		GuiControl, Tracker:Disable, Update_LoginName
		; -------------------------------------------
		GuiControl, Tracker:, Radio_LoginName_1, 0
		GuiControl, Tracker:MoveDraw, Radio_LoginName_1
		GuiControl, Tracker:, Radio_LoginName_2, 0
		GuiControl, Tracker:MoveDraw, Radio_LoginName_2
		GuiControl, Tracker:, Radio_LoginName_3, 0
		GuiControl, Tracker:MoveDraw, Radio_LoginName_3
		; -------------------------------------------
		Array_Preset := GetPreSet("LoginName", 0) ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_LoginName_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
		; -------------------------------------------
	}
	; -------------------------------------------
	EditFeildCheck("", Array_CurrentRecord) ; CheckThisEdit = Edit_ObjectName > (0) Empty Feild -OR- (ThisEditValue)
	; -------------------------------------------
	GuiControl, Tracker:, Radio_LoginName, %OnOff_LoginName%
	; -------------------------------------------
	GuiControl, Tracker:MoveDraw, Radio_LoginName
	; -------------------------------------------
}
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Label_BusinessName_1:
{
	; -------------------------------------------
	ArrayThisPreSet := GetPreSet("BusinessName", "Radio_BusinessName_1") ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_BusinessName_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
	PresetValue_BusinessName_1 := ArrayThisPreSet.1
	PresetValue_BusinessName_2 := ArrayThisPreSet.2
	PresetValue_BusinessName_3 := ArrayThisPreSet.3
	; -------------------------------------------
	;
	; -------------------------------------------
	GuiControl, Tracker:Enable, Update_BusinessName
	; -------------------------------------------
	if (StrLen(PresetValue_BusinessName_1) > 0)
	{
		GuiControl, Tracker:, Edit_BusinessName, %PresetValue_BusinessName_1%
	}
	; --------------------------------------------
}
return
; -------------------------------------------
Label_BusinessName_2:
{
	; -------------------------------------------
	ArrayThisPreSet := GetPreSet("BusinessName", "Radio_BusinessName_2") ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_BusinessName_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
	PresetValue_BusinessName_1 := ArrayThisPreSet.1
	PresetValue_BusinessName_2 := ArrayThisPreSet.2
	PresetValue_BusinessName_3 := ArrayThisPreSet.3
	; -------------------------------------------
	;
	; -------------------------------------------
	GuiControl, Tracker:Enable, Update_BusinessName
	; -------------------------------------------
	if (StrLen(PresetValue_BusinessName_2) > 0)
	{
		GuiControl, Tracker:, Edit_BusinessName, %PresetValue_BusinessName_2%
	}
	; --------------------------------------------
}
return
; -------------------------------------------
Label_BusinessName_3:
{
	; -------------------------------------------
	ArrayThisPreSet := GetPreSet("BusinessName", "Radio_BusinessName_3") ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_BusinessName_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
	PresetValue_BusinessName_1 := ArrayThisPreSet.1
	PresetValue_BusinessName_2 := ArrayThisPreSet.2
	PresetValue_BusinessName_3 := ArrayThisPreSet.3
	; -------------------------------------------
	;
	; -------------------------------------------
	GuiControl, Tracker:Enable, Update_BusinessName
	; -------------------------------------------
	if (StrLen(PresetValue_BusinessName_3) > 0)
	{
		GuiControl, Tracker:, Edit_BusinessName, %PresetValue_BusinessName_3%
	}
	; --------------------------------------------
}
return
; -------------------------------------------
Label_U_BusinessName: ; Update
{
	; -------------------------------------------
	GuiControlGet, OnOff_BusinessName_1, Tracker:, Radio_BusinessName_1
	GuiControlGet, OnOff_BusinessName_2, Tracker:, Radio_BusinessName_2
	GuiControlGet, OnOff_BusinessName_3, Tracker:, Radio_BusinessName_3
	; -------------------------------------------
	if (OnOff_BusinessName_1 == 1)
	{
		GuiControlGet, PresetValue_BusinessName_1, Tracker:, Edit_BusinessName
	}
	else if (OnOff_BusinessName_2 == 1)
	{
		GuiControlGet, PresetValue_BusinessName_2, Tracker:, Edit_BusinessName
	}
	else if (OnOff_BusinessName_3 == 1)
	{
		GuiControlGet, PresetValue_BusinessName_3, Tracker:, Edit_BusinessName
	}
	; -------------------------------------------
	File_BusinessName := Path_DAT "\Presets\BusinessName.txt"
	; -------------------------------------------
	if FileExist(File_BusinessName)
	{
		FileDelete, %File_BusinessName%
		Sleep, 100
	}
	; -------------------------------------------
	FileAppend, %PresetValue_BusinessName_1%`n, %File_BusinessName%, UTF-8
	FileAppend, %PresetValue_BusinessName_2%`n, %File_BusinessName%, UTF-8
	FileAppend, %PresetValue_BusinessName_3%`n, %File_BusinessName%, UTF-8
	; -------------------------------------------
	Array_Preset := GetPreSet("BusinessName", 1) ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_BusinessName_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
	; -------------------------------------------
}
return
; -------------------------------------------
Label_C_BusinessName: ; Clipboard Image
{
	; -------------------------------------------
	ControlGetFocus, CurrentFocus, A
	if (CurrentFocus != "ListBox1")
	{
	  ; -------------------------------------------
	  OnClipBoard := Clipboard_OnOff("BusinessName", OnClipBoard) ; > OnClipBoard
	  ; -------------------------------------------
	} ; if (CurrentFocus != "ListBox1")
	; -------------------------------------------
}
return
; -------------------------------------------
Label_E_BusinessName: ; Edit Feild
{
	; -------------------------------------------
	ControlGetFocus, CurrentFocus, A
	if (CurrentFocus != "ListBox1")
	{
	  ; -------------------------------------------
	  ReturnedAnswer := EditFeildCheck("Edit_BusinessName", Array_CurrentRecord) ; CheckThisEdit = Edit_ObjectName > (0) Empty Feild -OR- (ThisEditValue)
	  ; -------------------------------------------
	  if (ReturnedAnswer == 0) ; Field is Empty
	  {
  		; -------------------------------------------
		  OnOff_BusinessName := 0
		  ; -------------------------------------------
		  GuiControl, Tracker:+c000000, Radio_BusinessName ; Black Color
		  ; -------------------------------------------
		  GuiControl, Tracker:, Edit_BusinessName, ; Empty Edit Feild
		  ; -------------------------------------------
	  }
	  else ; Field is NOT Empty | (ReturnedAnswer) = Value of Edit Feild
	  {
  		; -------------------------------------------
		  OnOff_BusinessName := 1
		  ; -------------------------------------------
		  GuiControl, Tracker:+cc42424, Radio_BusinessName ; Red Color
		  ; -------------------------------------------
	  }
	  ; -------------------------------------------
	  GuiControl, Tracker:, Radio_BusinessName, %OnOff_BusinessName%
	  GuiControl, Tracker:MoveDraw, Radio_BusinessName
	  ; -------------------------------------------
	  PreSetEditCheck("Edit_BusinessName", PresetValue_BusinessName_1, PresetValue_BusinessName_2, PresetValue_BusinessName_3)
	  ; -------------------------------------------
 	} ; if (CurrentFocus != "ListBox1")
 	; -------------------------------------------
}
return
; -------------------------------------------
Label_R_BusinessName: ; Main Radio
{
	; -------------------------------------------
	if (OnOff_BusinessName == "")
	{
		GuiControlGet, OnOff_BusinessName, Tracker:, Radio_BusinessName
	}
	; -------------------------------------------
	if (OnOff_BusinessName == 0) ; Is UnSelected > Select (Red) 
	{
		; -------------------------------------------
		OnOff_BusinessName := 1
		; -------------------------------------------
		GuiControl, Tracker:+cc42424, Radio_BusinessName ; Red Color
		; -------------------------------------------
	}
	else if (OnOff_BusinessName == 1) ; Is Selected > UnSelect (Black)
	{
		; -------------------------------------------
		OnOff_BusinessName := 0
		; -------------------------------------------
		GuiControl, Tracker:+c000000, Radio_BusinessName ; Black Color
		; -------------------------------------------
		GuiControl, Tracker:, Edit_BusinessName,
		; -------------------------------------------
		GuiControl, Tracker:Disable, Update_BusinessName
		; -------------------------------------------
		GuiControl, Tracker:, Radio_BusinessName_1, 0
		GuiControl, Tracker:MoveDraw, Radio_BusinessName_1
		GuiControl, Tracker:, Radio_BusinessName_2, 0
		GuiControl, Tracker:MoveDraw, Radio_BusinessName_2
		GuiControl, Tracker:, Radio_BusinessName_3, 0
		GuiControl, Tracker:MoveDraw, Radio_BusinessName_3
		; -------------------------------------------
		Array_Preset := GetPreSet("BusinessName", 0) ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_BusinessName_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
		; -------------------------------------------
	}
	; -------------------------------------------
	EditFeildCheck("", Array_CurrentRecord) ; CheckThisEdit = Edit_ObjectName > (0) Empty Feild -OR- (ThisEditValue)
	; -------------------------------------------
	GuiControl, Tracker:, Radio_BusinessName, %OnOff_BusinessName%
	; -------------------------------------------
	GuiControl, Tracker:MoveDraw, Radio_BusinessName
	; -------------------------------------------
}
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Label_FirstName_1:
{
	; -------------------------------------------
	ArrayThisPreSet := GetPreSet("FirstName", "Radio_FirstName_1") ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_FirstName_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
	PresetValue_FirstName_1 := ArrayThisPreSet.1
	PresetValue_FirstName_2 := ArrayThisPreSet.2
	PresetValue_FirstName_3 := ArrayThisPreSet.3
	; -------------------------------------------
	;
	; -------------------------------------------
	GuiControl, Tracker:Enable, Update_FirstName
	; -------------------------------------------
	if (StrLen(PresetValue_FirstName_1) > 0)
	{
		GuiControl, Tracker:, Edit_FirstName, %PresetValue_FirstName_1%
	}
	; --------------------------------------------
}
return
; -------------------------------------------
Label_FirstName_2:
{
	; -------------------------------------------
	ArrayThisPreSet := GetPreSet("FirstName", "Radio_FirstName_2") ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_FirstName_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
	PresetValue_FirstName_1 := ArrayThisPreSet.1
	PresetValue_FirstName_2 := ArrayThisPreSet.2
	PresetValue_FirstName_3 := ArrayThisPreSet.3
	; -------------------------------------------
	;
	; -------------------------------------------
	GuiControl, Tracker:Enable, Update_FirstName
	; -------------------------------------------
	if (StrLen(PresetValue_FirstName_2) > 0)
	{
		GuiControl, Tracker:, Edit_FirstName, %PresetValue_FirstName_2%
	}
	; --------------------------------------------
}
return
; -------------------------------------------
Label_FirstName_3:
{
	; -------------------------------------------
	ArrayThisPreSet := GetPreSet("FirstName", "Radio_FirstName_3") ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_FirstName_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
	PresetValue_FirstName_1 := ArrayThisPreSet.1
	PresetValue_FirstName_2 := ArrayThisPreSet.2
	PresetValue_FirstName_3 := ArrayThisPreSet.3
	; -------------------------------------------
	;
	; -------------------------------------------
	GuiControl, Tracker:Enable, Update_FirstName
	; -------------------------------------------
	if (StrLen(PresetValue_FirstName_3) > 0)
	{
		GuiControl, Tracker:, Edit_FirstName, %PresetValue_FirstName_3%
	}
	; --------------------------------------------
}
return
; -------------------------------------------
Label_U_FirstName: ; Update
{
	; -------------------------------------------
	GuiControlGet, OnOff_FirstName_1, Tracker:, Radio_FirstName_1
	GuiControlGet, OnOff_FirstName_2, Tracker:, Radio_FirstName_2
	GuiControlGet, OnOff_FirstName_3, Tracker:, Radio_FirstName_3
	; -------------------------------------------
	if (OnOff_FirstName_1 == 1)
	{
		GuiControlGet, PresetValue_FirstName_1, Tracker:, Edit_FirstName
	}
	else if (OnOff_FirstName_2 == 1)
	{
		GuiControlGet, PresetValue_FirstName_2, Tracker:, Edit_FirstName
	}
	else if (OnOff_FirstName_3 == 1)
	{
		GuiControlGet, PresetValue_FirstName_3, Tracker:, Edit_FirstName
	}
	; -------------------------------------------
	File_FirstName := Path_DAT "\Presets\FirstName.txt"
	; -------------------------------------------
	if FileExist(File_FirstName)
	{
		FileDelete, %File_FirstName%
		Sleep, 100
	}
	; -------------------------------------------
	FileAppend, %PresetValue_FirstName_1%`n, %File_FirstName%, UTF-8
	FileAppend, %PresetValue_FirstName_2%`n, %File_FirstName%, UTF-8
	FileAppend, %PresetValue_FirstName_3%`n, %File_FirstName%, UTF-8
	; -------------------------------------------
	Array_Preset := GetPreSet("FirstName", 1) ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_FirstName_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
	; -------------------------------------------
}
return
; -------------------------------------------
Label_C_FirstName: ; Clipboard Image
{
	; -------------------------------------------
	ControlGetFocus, CurrentFocus, A
	if (CurrentFocus != "ListBox1")
	{
	  ; -------------------------------------------
	  OnClipBoard := Clipboard_OnOff("FirstName", OnClipBoard) ; > OnClipBoard
	  ; -------------------------------------------
	} ; if (CurrentFocus != "ListBox1")
	; -------------------------------------------
}
return
; -------------------------------------------
Label_E_FirstName: ; Edit Feild
{
	; -------------------------------------------
	ControlGetFocus, CurrentFocus, A
	if (CurrentFocus != "ListBox1")
	{
	  ; -------------------------------------------
	  ReturnedAnswer := EditFeildCheck("Edit_FirstName", Array_CurrentRecord) ; CheckThisEdit = Edit_ObjectName > (0) Empty Feild -OR- (ThisEditValue)
	  ; -------------------------------------------
	  if (ReturnedAnswer == 0) ; Field is Empty
	  {
  		; -------------------------------------------
		  OnOff_FirstName := 0
		  ; -------------------------------------------
		  GuiControl, Tracker:+c000000, Radio_FirstName ; Black Color
		  ; -------------------------------------------
		  GuiControl, Tracker:, Edit_FirstName, ; Empty Edit Feild
		  ; -------------------------------------------
	  }
	  else ; Field is NOT Empty | (ReturnedAnswer) = Value of Edit Feild
	  {
  		; -------------------------------------------
		  OnOff_FirstName := 1
		  ; -------------------------------------------
		  GuiControl, Tracker:+cc42424, Radio_FirstName ; Red Color
		  ; -------------------------------------------
	  }
	  ; -------------------------------------------
	  GuiControl, Tracker:, Radio_FirstName, %OnOff_FirstName%
	  GuiControl, Tracker:MoveDraw, Radio_FirstName
	  ; -------------------------------------------
	  PreSetEditCheck("Edit_FirstName", PresetValue_FirstName_1, PresetValue_FirstName_2, PresetValue_FirstName_3)
	  ; -------------------------------------------
 	} ; if (CurrentFocus != "ListBox1")
 	; -------------------------------------------
}
return
; -------------------------------------------
Label_R_FirstName: ; Main Radio
{
	; -------------------------------------------
	if (OnOff_FirstName == "")
	{
		GuiControlGet, OnOff_FirstName, Tracker:, Radio_FirstName
	}
	; -------------------------------------------
	if (OnOff_FirstName == 0) ; Is UnSelected > Select (Red) 
	{
		; -------------------------------------------
		OnOff_FirstName := 1
		; -------------------------------------------
		GuiControl, Tracker:+cc42424, Radio_FirstName ; Red Color
		; -------------------------------------------
	}
	else if (OnOff_FirstName == 1) ; Is Selected > UnSelect (Black)
	{
		; -------------------------------------------
		OnOff_FirstName := 0
		; -------------------------------------------
		GuiControl, Tracker:+c000000, Radio_FirstName ; Black Color
		; -------------------------------------------
		GuiControl, Tracker:, Edit_FirstName,
		; -------------------------------------------
		GuiControl, Tracker:Disable, Update_FirstName
		; -------------------------------------------
		GuiControl, Tracker:, Radio_FirstName_1, 0
		GuiControl, Tracker:MoveDraw, Radio_FirstName_1
		GuiControl, Tracker:, Radio_FirstName_2, 0
		GuiControl, Tracker:MoveDraw, Radio_FirstName_2
		GuiControl, Tracker:, Radio_FirstName_3, 0
		GuiControl, Tracker:MoveDraw, Radio_FirstName_3
		; -------------------------------------------
		Array_Preset := GetPreSet("FirstName", 0) ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_FirstName_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
		; -------------------------------------------
	}
	; -------------------------------------------
	EditFeildCheck("", Array_CurrentRecord) ; CheckThisEdit = Edit_ObjectName > (0) Empty Feild -OR- (ThisEditValue)
	; -------------------------------------------
	GuiControl, Tracker:, Radio_FirstName, %OnOff_FirstName%
	; -------------------------------------------
	GuiControl, Tracker:MoveDraw, Radio_FirstName
	; -------------------------------------------
}
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Label_LastName_1:
{
	; -------------------------------------------
	ArrayThisPreSet := GetPreSet("LastName", "Radio_LastName_1") ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_LastName_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
	PresetValue_LastName_1 := ArrayThisPreSet.1
	PresetValue_LastName_2 := ArrayThisPreSet.2
	PresetValue_LastName_3 := ArrayThisPreSet.3
	; -------------------------------------------
	;
	; -------------------------------------------
	GuiControl, Tracker:Enable, Update_LastName
	; -------------------------------------------
	if (StrLen(PresetValue_LastName_1) > 0)
	{
		GuiControl, Tracker:, Edit_LastName, %PresetValue_LastName_1%
	}
	; --------------------------------------------
}
return
; -------------------------------------------
Label_LastName_2:
{
	; -------------------------------------------
	ArrayThisPreSet := GetPreSet("LastName", "Radio_LastName_2") ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_LastName_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
	PresetValue_LastName_1 := ArrayThisPreSet.1
	PresetValue_LastName_2 := ArrayThisPreSet.2
	PresetValue_LastName_3 := ArrayThisPreSet.3
	; -------------------------------------------
	;
	; -------------------------------------------
	GuiControl, Tracker:Enable, Update_LastName
	; -------------------------------------------
	if (StrLen(PresetValue_LastName_2) > 0)
	{
		GuiControl, Tracker:, Edit_LastName, %PresetValue_LastName_2%
	}
	; --------------------------------------------
}
return
; -------------------------------------------
Label_LastName_3:
{
	; -------------------------------------------
	ArrayThisPreSet := GetPreSet("LastName", "Radio_LastName_3") ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_LastName_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
	PresetValue_LastName_1 := ArrayThisPreSet.1
	PresetValue_LastName_2 := ArrayThisPreSet.2
	PresetValue_LastName_3 := ArrayThisPreSet.3
	; -------------------------------------------
	;
	; -------------------------------------------
	GuiControl, Tracker:Enable, Update_LastName
	; -------------------------------------------
	if (StrLen(PresetValue_LastName_3) > 0)
	{
		GuiControl, Tracker:, Edit_LastName, %PresetValue_LastName_3%
	}
	; --------------------------------------------
}
return
; -------------------------------------------
Label_U_LastName: ; Update
{
	; -------------------------------------------
	GuiControlGet, OnOff_LastName_1, Tracker:, Radio_LastName_1
	GuiControlGet, OnOff_LastName_2, Tracker:, Radio_LastName_2
	GuiControlGet, OnOff_LastName_3, Tracker:, Radio_LastName_3
	; -------------------------------------------
	if (OnOff_LastName_1 == 1)
	{
		GuiControlGet, PresetValue_LastName_1, Tracker:, Edit_LastName
	}
	else if (OnOff_LastName_2 == 1)
	{
		GuiControlGet, PresetValue_LastName_2, Tracker:, Edit_LastName
	}
	else if (OnOff_LastName_3 == 1)
	{
		GuiControlGet, PresetValue_LastName_3, Tracker:, Edit_LastName
	}
	; -------------------------------------------
	File_LastName := Path_DAT "\Presets\LastName.txt"
	; -------------------------------------------
	if FileExist(File_LastName)
	{
		FileDelete, %File_LastName%
		Sleep, 100
	}
	; -------------------------------------------
	FileAppend, %PresetValue_LastName_1%`n, %File_LastName%, UTF-8
	FileAppend, %PresetValue_LastName_2%`n, %File_LastName%, UTF-8
	FileAppend, %PresetValue_LastName_3%`n, %File_LastName%, UTF-8
	; -------------------------------------------
	Array_Preset := GetPreSet("LastName", 1) ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_LastName_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
	; -------------------------------------------
}
return
; -------------------------------------------
Label_C_LastName: ; Clipboard Image
{
	; -------------------------------------------
	ControlGetFocus, CurrentFocus, A
	if (CurrentFocus != "ListBox1")
	{
	  ; -------------------------------------------
	  OnClipBoard := Clipboard_OnOff("LastName", OnClipBoard) ; > OnClipBoard
	  ; -------------------------------------------
	} ; if (CurrentFocus != "ListBox1")
	; -------------------------------------------
}
return
; -------------------------------------------
Label_E_LastName: ; Edit Feild
{
	; -------------------------------------------
	ControlGetFocus, CurrentFocus, A
	if (CurrentFocus != "ListBox1")
	{
	  ; -------------------------------------------
	  ReturnedAnswer := EditFeildCheck("Edit_LastName", Array_CurrentRecord) ; CheckThisEdit = Edit_ObjectName > (0) Empty Feild -OR- (ThisEditValue)
	  ; -------------------------------------------
	  if (ReturnedAnswer == 0) ; Field is Empty
	  {
  		; -------------------------------------------
		  OnOff_LastName := 0
		  ; -------------------------------------------
		  GuiControl, Tracker:+c000000, Radio_LastName ; Black Color
		  ; -------------------------------------------
		  GuiControl, Tracker:, Edit_LastName, ; Empty Edit Feild
		  ; -------------------------------------------
	  }
	  else ; Field is NOT Empty | (ReturnedAnswer) = Value of Edit Feild
	  {
  		; -------------------------------------------
		  OnOff_LastName := 1
		  ; -------------------------------------------
		  GuiControl, Tracker:+cc42424, Radio_LastName ; Red Color
		  ; -------------------------------------------
	  }
	  ; -------------------------------------------
	  GuiControl, Tracker:, Radio_LastName, %OnOff_LastName%
	  GuiControl, Tracker:MoveDraw, Radio_LastName
	  ; -------------------------------------------
	  PreSetEditCheck("Edit_LastName", PresetValue_LastName_1, PresetValue_LastName_2, PresetValue_LastName_3)
	  ; -------------------------------------------
 	} ; if (CurrentFocus != "ListBox1")
 	; -------------------------------------------
}
return
; -------------------------------------------
Label_R_LastName: ; Main Radio
{
	; -------------------------------------------
	if (OnOff_LastName == "")
	{
		GuiControlGet, OnOff_LastName, Tracker:, Radio_LastName
	}
	; -------------------------------------------
	if (OnOff_LastName == 0) ; Is UnSelected > Select (Red) 
	{
		; -------------------------------------------
		OnOff_LastName := 1
		; -------------------------------------------
		GuiControl, Tracker:+cc42424, Radio_LastName ; Red Color
		; -------------------------------------------
	}
	else if (OnOff_LastName == 1) ; Is Selected > UnSelect (Black)
	{
		; -------------------------------------------
		OnOff_LastName := 0
		; -------------------------------------------
		GuiControl, Tracker:+c000000, Radio_LastName ; Black Color
		; -------------------------------------------
		GuiControl, Tracker:, Edit_LastName,
		; -------------------------------------------
		GuiControl, Tracker:Disable, Update_LastName
		; -------------------------------------------
		GuiControl, Tracker:, Radio_LastName_1, 0
		GuiControl, Tracker:MoveDraw, Radio_LastName_1
		GuiControl, Tracker:, Radio_LastName_2, 0
		GuiControl, Tracker:MoveDraw, Radio_LastName_2
		GuiControl, Tracker:, Radio_LastName_3, 0
		GuiControl, Tracker:MoveDraw, Radio_LastName_3
		; -------------------------------------------
		Array_Preset := GetPreSet("LastName", 0) ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_LastName_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
		; -------------------------------------------
	}
	; -------------------------------------------
	EditFeildCheck("", Array_CurrentRecord) ; CheckThisEdit = Edit_ObjectName > (0) Empty Feild -OR- (ThisEditValue)
	; -------------------------------------------
	GuiControl, Tracker:, Radio_LastName, %OnOff_LastName%
	; -------------------------------------------
	GuiControl, Tracker:MoveDraw, Radio_LastName
	; -------------------------------------------
}
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Label_Phone_1:
{
	; -------------------------------------------
	ArrayThisPreSet := GetPreSet("Phone", "Radio_Phone_1") ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_Phone_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
	PresetValue_Phone_1 := ArrayThisPreSet.1
	PresetValue_Phone_2 := ArrayThisPreSet.2
	PresetValue_Phone_3 := ArrayThisPreSet.3
	; -------------------------------------------
	;
	; -------------------------------------------
	GuiControl, Tracker:Enable, Update_Phone
	; -------------------------------------------
	if (StrLen(PresetValue_Phone_1) > 0)
	{
		GuiControl, Tracker:, Edit_Phone, %PresetValue_Phone_1%
	}
	; --------------------------------------------
}
return
; -------------------------------------------
Label_Phone_2:
{
	; -------------------------------------------
	ArrayThisPreSet := GetPreSet("Phone", "Radio_Phone_2") ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_Phone_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
	PresetValue_Phone_1 := ArrayThisPreSet.1
	PresetValue_Phone_2 := ArrayThisPreSet.2
	PresetValue_Phone_3 := ArrayThisPreSet.3
	; -------------------------------------------
	;
	; -------------------------------------------
	GuiControl, Tracker:Enable, Update_Phone
	; -------------------------------------------
	if (StrLen(PresetValue_Phone_2) > 0)
	{
		GuiControl, Tracker:, Edit_Phone, %PresetValue_Phone_2%
	}
	; --------------------------------------------
}
return
; -------------------------------------------
Label_Phone_3:
{
	; -------------------------------------------
	ArrayThisPreSet := GetPreSet("Phone", "Radio_Phone_3") ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_Phone_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
	PresetValue_Phone_1 := ArrayThisPreSet.1
	PresetValue_Phone_2 := ArrayThisPreSet.2
	PresetValue_Phone_3 := ArrayThisPreSet.3
	; -------------------------------------------
	;
	; -------------------------------------------
	GuiControl, Tracker:Enable, Update_Phone
	; -------------------------------------------
	if (StrLen(PresetValue_Phone_3) > 0)
	{
		GuiControl, Tracker:, Edit_Phone, %PresetValue_Phone_3%
	}
	; --------------------------------------------
}
return
; -------------------------------------------
Label_U_Phone: ; Update
{
	; -------------------------------------------
	GuiControlGet, OnOff_Phone_1, Tracker:, Radio_Phone_1
	GuiControlGet, OnOff_Phone_2, Tracker:, Radio_Phone_2
	GuiControlGet, OnOff_Phone_3, Tracker:, Radio_Phone_3
	; -------------------------------------------
	if (OnOff_Phone_1 == 1)
	{
		GuiControlGet, PresetValue_Phone_1, Tracker:, Edit_Phone
	}
	else if (OnOff_Phone_2 == 1)
	{
		GuiControlGet, PresetValue_Phone_2, Tracker:, Edit_Phone
	}
	else if (OnOff_Phone_3 == 1)
	{
		GuiControlGet, PresetValue_Phone_3, Tracker:, Edit_Phone
	}
	; -------------------------------------------
	File_Phone := Path_DAT "\Presets\Phone.txt"
	; -------------------------------------------
	if FileExist(File_Phone)
	{
		FileDelete, %File_Phone%
		Sleep, 100
	}
	; -------------------------------------------
	FileAppend, %PresetValue_Phone_1%`n, %File_Phone%, UTF-8
	FileAppend, %PresetValue_Phone_2%`n, %File_Phone%, UTF-8
	FileAppend, %PresetValue_Phone_3%`n, %File_Phone%, UTF-8
	; -------------------------------------------
	Array_Preset := GetPreSet("Phone", 1) ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_Phone_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
	; -------------------------------------------
}
return
; -------------------------------------------
Label_C_Phone: ; Clipboard Image
{
	; -------------------------------------------
	ControlGetFocus, CurrentFocus, A
	if (CurrentFocus != "ListBox1")
	{
	  ; -------------------------------------------
	  OnClipBoard := Clipboard_OnOff("Phone", OnClipBoard) ; > OnClipBoard
	  ; -------------------------------------------
	} ; if (CurrentFocus != "ListBox1")
	; -------------------------------------------
}
return
; -------------------------------------------
Label_E_Phone: ; Edit Feild
{
	; -------------------------------------------
	ControlGetFocus, CurrentFocus, A
	if (CurrentFocus != "ListBox1")
	{
	  ; -------------------------------------------
	  ReturnedAnswer := EditFeildCheck("Edit_Phone", Array_CurrentRecord) ; CheckThisEdit = Edit_ObjectName > (0) Empty Feild -OR- (ThisEditValue)
	  ; -------------------------------------------
	  if (ReturnedAnswer == 0) ; Field is Empty
	  {
  		; -------------------------------------------
		  OnOff_Phone := 0
		  ; -------------------------------------------
		  GuiControl, Tracker:+c000000, Radio_Phone ; Black Color
		  ; -------------------------------------------
		  GuiControl, Tracker:, Edit_Phone, ; Empty Edit Feild
		  ; -------------------------------------------
	  }
	  else ; Field is NOT Empty | (ReturnedAnswer) = Value of Edit Feild
	  {
  		; -------------------------------------------
		  OnOff_Phone := 1
		  ; -------------------------------------------
		  GuiControl, Tracker:+cc42424, Radio_Phone ; Red Color
		  ; -------------------------------------------
	  }
	  ; -------------------------------------------
	  GuiControl, Tracker:, Radio_Phone, %OnOff_Phone%
	  GuiControl, Tracker:MoveDraw, Radio_Phone
	  ; -------------------------------------------
	  PreSetEditCheck("Edit_Phone", PresetValue_Phone_1, PresetValue_Phone_2, PresetValue_Phone_3)
	  ; -------------------------------------------
 	} ; if (CurrentFocus != "ListBox1")
 	; -------------------------------------------
}
return
; -------------------------------------------
Label_R_Phone: ; Main Radio
{
	; -------------------------------------------
	if (OnOff_Phone == "")
	{
		GuiControlGet, OnOff_Phone, Tracker:, Radio_Phone
	}
	; -------------------------------------------
	if (OnOff_Phone == 0) ; Is UnSelected > Select (Red) 
	{
		; -------------------------------------------
		OnOff_Phone := 1
		; -------------------------------------------
		GuiControl, Tracker:+cc42424, Radio_Phone ; Red Color
		; -------------------------------------------
	}
	else if (OnOff_Phone == 1) ; Is Selected > UnSelect (Black)
	{
		; -------------------------------------------
		OnOff_Phone := 0
		; -------------------------------------------
		GuiControl, Tracker:+c000000, Radio_Phone ; Black Color
		; -------------------------------------------
		GuiControl, Tracker:, Edit_Phone,
		; -------------------------------------------
		GuiControl, Tracker:Disable, Update_Phone
		; -------------------------------------------
		GuiControl, Tracker:, Radio_Phone_1, 0
		GuiControl, Tracker:MoveDraw, Radio_Phone_1
		GuiControl, Tracker:, Radio_Phone_2, 0
		GuiControl, Tracker:MoveDraw, Radio_Phone_2
		GuiControl, Tracker:, Radio_Phone_3, 0
		GuiControl, Tracker:MoveDraw, Radio_Phone_3
		; -------------------------------------------
		Array_Preset := GetPreSet("Phone", 0) ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_Phone_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
		; -------------------------------------------
	}
	; -------------------------------------------
	EditFeildCheck("", Array_CurrentRecord) ; CheckThisEdit = Edit_ObjectName > (0) Empty Feild -OR- (ThisEditValue)
	; -------------------------------------------
	GuiControl, Tracker:, Radio_Phone, %OnOff_Phone%
	; -------------------------------------------
	GuiControl, Tracker:MoveDraw, Radio_Phone
	; -------------------------------------------
}
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Label_Country_1:
{
	; -------------------------------------------
	ArrayThisPreSet := GetPreSet("Country", "Radio_Country_1") ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_Country_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
	PresetValue_Country_1 := ArrayThisPreSet.1
	PresetValue_Country_2 := ArrayThisPreSet.2
	PresetValue_Country_3 := ArrayThisPreSet.3
	; -------------------------------------------
	;
	; -------------------------------------------
	GuiControl, Tracker:Enable, Update_Country
	; -------------------------------------------
	if (StrLen(PresetValue_Country_1) > 0)
	{
		GuiControl, Tracker:, Edit_Country, %PresetValue_Country_1%
	}
	; --------------------------------------------
}
return
; -------------------------------------------
Label_Country_2:
{
	; -------------------------------------------
	ArrayThisPreSet := GetPreSet("Country", "Radio_Country_2") ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_Country_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
	PresetValue_Country_1 := ArrayThisPreSet.1
	PresetValue_Country_2 := ArrayThisPreSet.2
	PresetValue_Country_3 := ArrayThisPreSet.3
	; -------------------------------------------
	;
	; -------------------------------------------
	GuiControl, Tracker:Enable, Update_Country
	; -------------------------------------------
	if (StrLen(PresetValue_Country_2) > 0)
	{
		GuiControl, Tracker:, Edit_Country, %PresetValue_Country_2%
	}
	; --------------------------------------------
}
return
; -------------------------------------------
Label_Country_3:
{
	; -------------------------------------------
	ArrayThisPreSet := GetPreSet("Country", "Radio_Country_3") ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_Country_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
	PresetValue_Country_1 := ArrayThisPreSet.1
	PresetValue_Country_2 := ArrayThisPreSet.2
	PresetValue_Country_3 := ArrayThisPreSet.3
	; -------------------------------------------
	;
	; -------------------------------------------
	GuiControl, Tracker:Enable, Update_Country
	; -------------------------------------------
	if (StrLen(PresetValue_Country_3) > 0)
	{
		GuiControl, Tracker:, Edit_Country, %PresetValue_Country_3%
	}
	; --------------------------------------------
}
return
; -------------------------------------------
Label_U_Country: ; Update
{
	; -------------------------------------------
	GuiControlGet, OnOff_Country_1, Tracker:, Radio_Country_1
	GuiControlGet, OnOff_Country_2, Tracker:, Radio_Country_2
	GuiControlGet, OnOff_Country_3, Tracker:, Radio_Country_3
	; -------------------------------------------
	if (OnOff_Country_1 == 1)
	{
		GuiControlGet, PresetValue_Country_1, Tracker:, Edit_Country
	}
	else if (OnOff_Country_2 == 1)
	{
		GuiControlGet, PresetValue_Country_2, Tracker:, Edit_Country
	}
	else if (OnOff_Country_3 == 1)
	{
		GuiControlGet, PresetValue_Country_3, Tracker:, Edit_Country
	}
	; -------------------------------------------
	File_Country := Path_DAT "\Presets\Country.txt"
	; -------------------------------------------
	if FileExist(File_Country)
	{
		FileDelete, %File_Country%
		Sleep, 100
	}
	; -------------------------------------------
	FileAppend, %PresetValue_Country_1%`n, %File_Country%, UTF-8
	FileAppend, %PresetValue_Country_2%`n, %File_Country%, UTF-8
	FileAppend, %PresetValue_Country_3%`n, %File_Country%, UTF-8
	; -------------------------------------------
	Array_Preset := GetPreSet("Country", 1) ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_Country_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
	; -------------------------------------------
}
return
; -------------------------------------------
Label_C_Country: ; Clipboard Image
{
	; -------------------------------------------
	ControlGetFocus, CurrentFocus, A
	if (CurrentFocus != "ListBox1")
	{
	  ; -------------------------------------------
	  OnClipBoard := Clipboard_OnOff("Country", OnClipBoard) ; > OnClipBoard
	  ; -------------------------------------------
	} ; if (CurrentFocus != "ListBox1")
	; -------------------------------------------
}
return
; -------------------------------------------
Label_E_Country: ; Edit Feild
{
	; -------------------------------------------
	ControlGetFocus, CurrentFocus, A
	if (CurrentFocus != "ListBox1")
	{
	  ; -------------------------------------------
	  ReturnedAnswer := EditFeildCheck("Edit_Country", Array_CurrentRecord) ; CheckThisEdit = Edit_ObjectName > (0) Empty Feild -OR- (ThisEditValue)
	  ; -------------------------------------------
	  if (ReturnedAnswer == 0) ; Field is Empty
	  {
  		; -------------------------------------------
		  OnOff_Country := 0
		  ; -------------------------------------------
		  GuiControl, Tracker:+c000000, Radio_Country ; Black Color
		  ; -------------------------------------------
		  GuiControl, Tracker:, Edit_Country, ; Empty Edit Feild
		  ; -------------------------------------------
	  }
	  else ; Field is NOT Empty | (ReturnedAnswer) = Value of Edit Feild
	  {
  		; -------------------------------------------
		  OnOff_Country := 1
		  ; -------------------------------------------
		  GuiControl, Tracker:+cc42424, Radio_Country ; Red Color
		  ; -------------------------------------------
	  }
	  ; -------------------------------------------
	  GuiControl, Tracker:, Radio_Country, %OnOff_Country%
	  GuiControl, Tracker:MoveDraw, Radio_Country
	  ; -------------------------------------------
	  PreSetEditCheck("Edit_Country", PresetValue_Country_1, PresetValue_Country_2, PresetValue_Country_3)
	  ; -------------------------------------------
 	} ; if (CurrentFocus != "ListBox1")
 	; -------------------------------------------
}
return
; -------------------------------------------
Label_R_Country: ; Main Radio
{
	; -------------------------------------------
	if (OnOff_Country == "")
	{
		GuiControlGet, OnOff_Country, Tracker:, Radio_Country
	}
	; -------------------------------------------
	if (OnOff_Country == 0) ; Is UnSelected > Select (Red) 
	{
		; -------------------------------------------
		OnOff_Country := 1
		; -------------------------------------------
		GuiControl, Tracker:+cc42424, Radio_Country ; Red Color
		; -------------------------------------------
	}
	else if (OnOff_Country == 1) ; Is Selected > UnSelect (Black)
	{
		; -------------------------------------------
		OnOff_Country := 0
		; -------------------------------------------
		GuiControl, Tracker:+c000000, Radio_Country ; Black Color
		; -------------------------------------------
		GuiControl, Tracker:, Edit_Country,
		; -------------------------------------------
		GuiControl, Tracker:Disable, Update_Country
		; -------------------------------------------
		GuiControl, Tracker:, Radio_Country_1, 0
		GuiControl, Tracker:MoveDraw, Radio_Country_1
		GuiControl, Tracker:, Radio_Country_2, 0
		GuiControl, Tracker:MoveDraw, Radio_Country_2
		GuiControl, Tracker:, Radio_Country_3, 0
		GuiControl, Tracker:MoveDraw, Radio_Country_3
		; -------------------------------------------
		Array_Preset := GetPreSet("Country", 0) ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_Country_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
		; -------------------------------------------
	}
	; -------------------------------------------
	EditFeildCheck("", Array_CurrentRecord) ; CheckThisEdit = Edit_ObjectName > (0) Empty Feild -OR- (ThisEditValue)
	; -------------------------------------------
	GuiControl, Tracker:, Radio_Country, %OnOff_Country%
	; -------------------------------------------
	GuiControl, Tracker:MoveDraw, Radio_Country
	; -------------------------------------------
}
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Label_City_1:
{
	; -------------------------------------------
	ArrayThisPreSet := GetPreSet("City", "Radio_City_1") ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_City_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
	PresetValue_City_1 := ArrayThisPreSet.1
	PresetValue_City_2 := ArrayThisPreSet.2
	PresetValue_City_3 := ArrayThisPreSet.3
	; -------------------------------------------
	;
	; -------------------------------------------
	GuiControl, Tracker:Enable, Update_City
	; -------------------------------------------
	if (StrLen(PresetValue_City_1) > 0)
	{
		GuiControl, Tracker:, Edit_City, %PresetValue_City_1%
	}
	; --------------------------------------------
}
return
; -------------------------------------------
Label_City_2:
{
	; -------------------------------------------
	ArrayThisPreSet := GetPreSet("City", "Radio_City_2") ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_City_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
	PresetValue_City_1 := ArrayThisPreSet.1
	PresetValue_City_2 := ArrayThisPreSet.2
	PresetValue_City_3 := ArrayThisPreSet.3
	; -------------------------------------------
	;
	; -------------------------------------------
	GuiControl, Tracker:Enable, Update_City
	; -------------------------------------------
	if (StrLen(PresetValue_City_2) > 0)
	{
		GuiControl, Tracker:, Edit_City, %PresetValue_City_2%
	}
	; --------------------------------------------
}
return
; -------------------------------------------
Label_City_3:
{
	; -------------------------------------------
	ArrayThisPreSet := GetPreSet("City", "Radio_City_3") ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_City_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
	PresetValue_City_1 := ArrayThisPreSet.1
	PresetValue_City_2 := ArrayThisPreSet.2
	PresetValue_City_3 := ArrayThisPreSet.3
	; -------------------------------------------
	;
	; -------------------------------------------
	GuiControl, Tracker:Enable, Update_City
	; -------------------------------------------
	if (StrLen(PresetValue_City_3) > 0)
	{
		GuiControl, Tracker:, Edit_City, %PresetValue_City_3%
	}
	; --------------------------------------------
}
return
; -------------------------------------------
Label_U_City: ; Update
{
	; -------------------------------------------
	GuiControlGet, OnOff_City_1, Tracker:, Radio_City_1
	GuiControlGet, OnOff_City_2, Tracker:, Radio_City_2
	GuiControlGet, OnOff_City_3, Tracker:, Radio_City_3
	; -------------------------------------------
	if (OnOff_City_1 == 1)
	{
		GuiControlGet, PresetValue_City_1, Tracker:, Edit_City
	}
	else if (OnOff_City_2 == 1)
	{
		GuiControlGet, PresetValue_City_2, Tracker:, Edit_City
	}
	else if (OnOff_City_3 == 1)
	{
		GuiControlGet, PresetValue_City_3, Tracker:, Edit_City
	}
	; -------------------------------------------
	File_City := Path_DAT "\Presets\City.txt"
	; -------------------------------------------
	if FileExist(File_City)
	{
		FileDelete, %File_City%
		Sleep, 100
	}
	; -------------------------------------------
	FileAppend, %PresetValue_City_1%`n, %File_City%, UTF-8
	FileAppend, %PresetValue_City_2%`n, %File_City%, UTF-8
	FileAppend, %PresetValue_City_3%`n, %File_City%, UTF-8
	; -------------------------------------------
	Array_Preset := GetPreSet("City", 1) ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_City_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
	; -------------------------------------------
}
return
; -------------------------------------------
Label_C_City: ; Clipboard Image
{
	; -------------------------------------------
	ControlGetFocus, CurrentFocus, A
	if (CurrentFocus != "ListBox1")
	{
	  ; -------------------------------------------
	  OnClipBoard := Clipboard_OnOff("City", OnClipBoard) ; > OnClipBoard
	  ; -------------------------------------------
	} ; if (CurrentFocus != "ListBox1")
	; -------------------------------------------
}
return
; -------------------------------------------
Label_E_City: ; Edit Feild
{
	; -------------------------------------------
	ControlGetFocus, CurrentFocus, A
	if (CurrentFocus != "ListBox1")
	{
	  ; -------------------------------------------
	  ReturnedAnswer := EditFeildCheck("Edit_City", Array_CurrentRecord) ; CheckThisEdit = Edit_ObjectName > (0) Empty Feild -OR- (ThisEditValue)
	  ; -------------------------------------------
	  if (ReturnedAnswer == 0) ; Field is Empty
	  {
  		; -------------------------------------------
		  OnOff_City := 0
		  ; -------------------------------------------
		  GuiControl, Tracker:+c000000, Radio_City ; Black Color
		  ; -------------------------------------------
		  GuiControl, Tracker:, Edit_City, ; Empty Edit Feild
		  ; -------------------------------------------
	  }
	  else ; Field is NOT Empty | (ReturnedAnswer) = Value of Edit Feild
	  {
  		; -------------------------------------------
		  OnOff_City := 1
		  ; -------------------------------------------
		  GuiControl, Tracker:+cc42424, Radio_City ; Red Color
		  ; -------------------------------------------
	  }
	  ; -------------------------------------------
	  GuiControl, Tracker:, Radio_City, %OnOff_City%
	  GuiControl, Tracker:MoveDraw, Radio_City
	  ; -------------------------------------------
	  PreSetEditCheck("Edit_City", PresetValue_City_1, PresetValue_City_2, PresetValue_City_3)
	  ; -------------------------------------------
 	} ; if (CurrentFocus != "ListBox1")
 	; -------------------------------------------
}
return
; -------------------------------------------
Label_R_City: ; Main Radio
{
	; -------------------------------------------
	if (OnOff_City == "")
	{
		GuiControlGet, OnOff_City, Tracker:, Radio_City
	}
	; -------------------------------------------
	if (OnOff_City == 0) ; Is UnSelected > Select (Red) 
	{
		; -------------------------------------------
		OnOff_City := 1
		; -------------------------------------------
		GuiControl, Tracker:+cc42424, Radio_City ; Red Color
		; -------------------------------------------
	}
	else if (OnOff_City == 1) ; Is Selected > UnSelect (Black)
	{
		; -------------------------------------------
		OnOff_City := 0
		; -------------------------------------------
		GuiControl, Tracker:+c000000, Radio_City ; Black Color
		; -------------------------------------------
		GuiControl, Tracker:, Edit_City,
		; -------------------------------------------
		GuiControl, Tracker:Disable, Update_City
		; -------------------------------------------
		GuiControl, Tracker:, Radio_City_1, 0
		GuiControl, Tracker:MoveDraw, Radio_City_1
		GuiControl, Tracker:, Radio_City_2, 0
		GuiControl, Tracker:MoveDraw, Radio_City_2
		GuiControl, Tracker:, Radio_City_3, 0
		GuiControl, Tracker:MoveDraw, Radio_City_3
		; -------------------------------------------
		Array_Preset := GetPreSet("City", 0) ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_City_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
		; -------------------------------------------
	}
	; -------------------------------------------
	EditFeildCheck("", Array_CurrentRecord) ; CheckThisEdit = Edit_ObjectName > (0) Empty Feild -OR- (ThisEditValue)
	; -------------------------------------------
	GuiControl, Tracker:, Radio_City, %OnOff_City%
	; -------------------------------------------
	GuiControl, Tracker:MoveDraw, Radio_City
	; -------------------------------------------
}
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Label_Street_1:
{
	; -------------------------------------------
	ArrayThisPreSet := GetPreSet("Street", "Radio_Street_1") ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_Street_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
	PresetValue_Street_1 := ArrayThisPreSet.1
	PresetValue_Street_2 := ArrayThisPreSet.2
	PresetValue_Street_3 := ArrayThisPreSet.3
	; -------------------------------------------
	;
	; -------------------------------------------
	GuiControl, Tracker:Enable, Update_Street
	; -------------------------------------------
	if (StrLen(PresetValue_Street_1) > 0)
	{
		GuiControl, Tracker:, Edit_Street, %PresetValue_Street_1%
	}
	; --------------------------------------------
}
return
; -------------------------------------------
Label_Street_2:
{
	; -------------------------------------------
	ArrayThisPreSet := GetPreSet("Street", "Radio_Street_2") ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_Street_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
	PresetValue_Street_1 := ArrayThisPreSet.1
	PresetValue_Street_2 := ArrayThisPreSet.2
	PresetValue_Street_3 := ArrayThisPreSet.3
	; -------------------------------------------
	;
	; -------------------------------------------
	GuiControl, Tracker:Enable, Update_Street
	; -------------------------------------------
	if (StrLen(PresetValue_Street_2) > 0)
	{
		GuiControl, Tracker:, Edit_Street, %PresetValue_Street_2%
	}
	; --------------------------------------------
}
return
; -------------------------------------------
Label_Street_3:
{
	; -------------------------------------------
	ArrayThisPreSet := GetPreSet("Street", "Radio_Street_3") ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_Street_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
	PresetValue_Street_1 := ArrayThisPreSet.1
	PresetValue_Street_2 := ArrayThisPreSet.2
	PresetValue_Street_3 := ArrayThisPreSet.3
	; -------------------------------------------
	;
	; -------------------------------------------
	GuiControl, Tracker:Enable, Update_Street
	; -------------------------------------------
	if (StrLen(PresetValue_Street_3) > 0)
	{
		GuiControl, Tracker:, Edit_Street, %PresetValue_Street_3%
	}
	; --------------------------------------------
}
return
; -------------------------------------------
Label_U_Street: ; Update
{
	; -------------------------------------------
	GuiControlGet, OnOff_Street_1, Tracker:, Radio_Street_1
	GuiControlGet, OnOff_Street_2, Tracker:, Radio_Street_2
	GuiControlGet, OnOff_Street_3, Tracker:, Radio_Street_3
	; -------------------------------------------
	if (OnOff_Street_1 == 1)
	{
		GuiControlGet, PresetValue_Street_1, Tracker:, Edit_Street
	}
	else if (OnOff_Street_2 == 1)
	{
		GuiControlGet, PresetValue_Street_2, Tracker:, Edit_Street
	}
	else if (OnOff_Street_3 == 1)
	{
		GuiControlGet, PresetValue_Street_3, Tracker:, Edit_Street
	}
	; -------------------------------------------
	File_Street := Path_DAT "\Presets\Street.txt"
	; -------------------------------------------
	if FileExist(File_Street)
	{
		FileDelete, %File_Street%
		Sleep, 100
	}
	; -------------------------------------------
	FileAppend, %PresetValue_Street_1%`n, %File_Street%, UTF-8
	FileAppend, %PresetValue_Street_2%`n, %File_Street%, UTF-8
	FileAppend, %PresetValue_Street_3%`n, %File_Street%, UTF-8
	; -------------------------------------------
	Array_Preset := GetPreSet("Street", 1) ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_Street_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
	; -------------------------------------------
}
return
; -------------------------------------------
Label_C_Street: ; Clipboard Image
{
	; -------------------------------------------
	ControlGetFocus, CurrentFocus, A
	if (CurrentFocus != "ListBox1")
	{
	  ; -------------------------------------------
	  OnClipBoard := Clipboard_OnOff("Street", OnClipBoard) ; > OnClipBoard
	  ; -------------------------------------------
	} ; if (CurrentFocus != "ListBox1")
	; -------------------------------------------
}
return
; -------------------------------------------
Label_E_Street: ; Edit Feild
{
	; -------------------------------------------
	ControlGetFocus, CurrentFocus, A
	if (CurrentFocus != "ListBox1")
	{
	  ; -------------------------------------------
	  ReturnedAnswer := EditFeildCheck("Edit_Street", Array_CurrentRecord) ; CheckThisEdit = Edit_ObjectName > (0) Empty Feild -OR- (ThisEditValue)
	  ; -------------------------------------------
	  if (ReturnedAnswer == 0) ; Field is Empty
	  {
  		; -------------------------------------------
		  OnOff_Street := 0
		  ; -------------------------------------------
		  GuiControl, Tracker:+c000000, Radio_Street ; Black Color
		  ; -------------------------------------------
		  GuiControl, Tracker:, Edit_Street, ; Empty Edit Feild
		  ; -------------------------------------------
	  }
	  else ; Field is NOT Empty | (ReturnedAnswer) = Value of Edit Feild
	  {
  		; -------------------------------------------
		  OnOff_Street := 1
		  ; -------------------------------------------
		  GuiControl, Tracker:+cc42424, Radio_Street ; Red Color
		  ; -------------------------------------------
	  }
	  ; -------------------------------------------
	  GuiControl, Tracker:, Radio_Street, %OnOff_Street%
	  GuiControl, Tracker:MoveDraw, Radio_Street
	  ; -------------------------------------------
	  PreSetEditCheck("Edit_Street", PresetValue_Street_1, PresetValue_Street_2, PresetValue_Street_3)
	  ; -------------------------------------------
 	} ; if (CurrentFocus != "ListBox1")
 	; -------------------------------------------
}
return
; -------------------------------------------
Label_R_Street: ; Main Radio
{
	; -------------------------------------------
	if (OnOff_Street == "")
	{
		GuiControlGet, OnOff_Street, Tracker:, Radio_Street
	}
	; -------------------------------------------
	if (OnOff_Street == 0) ; Is UnSelected > Select (Red) 
	{
		; -------------------------------------------
		OnOff_Street := 1
		; -------------------------------------------
		GuiControl, Tracker:+cc42424, Radio_Street ; Red Color
		; -------------------------------------------
	}
	else if (OnOff_Street == 1) ; Is Selected > UnSelect (Black)
	{
		; -------------------------------------------
		OnOff_Street := 0
		; -------------------------------------------
		GuiControl, Tracker:+c000000, Radio_Street ; Black Color
		; -------------------------------------------
		GuiControl, Tracker:, Edit_Street,
		; -------------------------------------------
		GuiControl, Tracker:Disable, Update_Street
		; -------------------------------------------
		GuiControl, Tracker:, Radio_Street_1, 0
		GuiControl, Tracker:MoveDraw, Radio_Street_1
		GuiControl, Tracker:, Radio_Street_2, 0
		GuiControl, Tracker:MoveDraw, Radio_Street_2
		GuiControl, Tracker:, Radio_Street_3, 0
		GuiControl, Tracker:MoveDraw, Radio_Street_3
		; -------------------------------------------
		Array_Preset := GetPreSet("Street", 0) ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_Street_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
		; -------------------------------------------
	}
	; -------------------------------------------
	EditFeildCheck("", Array_CurrentRecord) ; CheckThisEdit = Edit_ObjectName > (0) Empty Feild -OR- (ThisEditValue)
	; -------------------------------------------
	GuiControl, Tracker:, Radio_Street, %OnOff_Street%
	; -------------------------------------------
	GuiControl, Tracker:MoveDraw, Radio_Street
	; -------------------------------------------
}
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Label_ZipCode_1:
{
	; -------------------------------------------
	ArrayThisPreSet := GetPreSet("ZipCode", "Radio_ZipCode_1") ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_ZipCode_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
	PresetValue_ZipCode_1 := ArrayThisPreSet.1
	PresetValue_ZipCode_2 := ArrayThisPreSet.2
	PresetValue_ZipCode_3 := ArrayThisPreSet.3
	; -------------------------------------------
	;
	; -------------------------------------------
	GuiControl, Tracker:Enable, Update_ZipCode
	; -------------------------------------------
	if (StrLen(PresetValue_ZipCode_1) > 0)
	{
		GuiControl, Tracker:, Edit_ZipCode, %PresetValue_ZipCode_1%
	}
	; --------------------------------------------
}
return
; -------------------------------------------
Label_ZipCode_2:
{
	; -------------------------------------------
	ArrayThisPreSet := GetPreSet("ZipCode", "Radio_ZipCode_2") ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_ZipCode_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
	PresetValue_ZipCode_1 := ArrayThisPreSet.1
	PresetValue_ZipCode_2 := ArrayThisPreSet.2
	PresetValue_ZipCode_3 := ArrayThisPreSet.3
	; -------------------------------------------
	;
	; -------------------------------------------
	GuiControl, Tracker:Enable, Update_ZipCode
	; -------------------------------------------
	if (StrLen(PresetValue_ZipCode_2) > 0)
	{
		GuiControl, Tracker:, Edit_ZipCode, %PresetValue_ZipCode_2%
	}
	; --------------------------------------------
}
return
; -------------------------------------------
Label_ZipCode_3:
{
	; -------------------------------------------
	ArrayThisPreSet := GetPreSet("ZipCode", "Radio_ZipCode_3") ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_ZipCode_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
	PresetValue_ZipCode_1 := ArrayThisPreSet.1
	PresetValue_ZipCode_2 := ArrayThisPreSet.2
	PresetValue_ZipCode_3 := ArrayThisPreSet.3
	; -------------------------------------------
	;
	; -------------------------------------------
	GuiControl, Tracker:Enable, Update_ZipCode
	; -------------------------------------------
	if (StrLen(PresetValue_ZipCode_3) > 0)
	{
		GuiControl, Tracker:, Edit_ZipCode, %PresetValue_ZipCode_3%
	}
	; --------------------------------------------
}
return
; -------------------------------------------
Label_U_ZipCode: ; Update
{
	; -------------------------------------------
	GuiControlGet, OnOff_ZipCode_1, Tracker:, Radio_ZipCode_1
	GuiControlGet, OnOff_ZipCode_2, Tracker:, Radio_ZipCode_2
	GuiControlGet, OnOff_ZipCode_3, Tracker:, Radio_ZipCode_3
	; -------------------------------------------
	if (OnOff_ZipCode_1 == 1)
	{
		GuiControlGet, PresetValue_ZipCode_1, Tracker:, Edit_ZipCode
	}
	else if (OnOff_ZipCode_2 == 1)
	{
		GuiControlGet, PresetValue_ZipCode_2, Tracker:, Edit_ZipCode
	}
	else if (OnOff_ZipCode_3 == 1)
	{
		GuiControlGet, PresetValue_ZipCode_3, Tracker:, Edit_ZipCode
	}
	; -------------------------------------------
	File_ZipCode := Path_DAT "\Presets\ZipCode.txt"
	; -------------------------------------------
	if FileExist(File_ZipCode)
	{
		FileDelete, %File_ZipCode%
		Sleep, 100
	}
	; -------------------------------------------
	FileAppend, %PresetValue_ZipCode_1%`n, %File_ZipCode%, UTF-8
	FileAppend, %PresetValue_ZipCode_2%`n, %File_ZipCode%, UTF-8
	FileAppend, %PresetValue_ZipCode_3%`n, %File_ZipCode%, UTF-8
	; -------------------------------------------
	Array_Preset := GetPreSet("ZipCode", 1) ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_ZipCode_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
	; -------------------------------------------
}
return
; -------------------------------------------
Label_C_ZipCode: ; Clipboard Image
{
	; -------------------------------------------
	ControlGetFocus, CurrentFocus, A
	if (CurrentFocus != "ListBox1")
	{
	  ; -------------------------------------------
	  OnClipBoard := Clipboard_OnOff("ZipCode", OnClipBoard) ; > OnClipBoard
	  ; -------------------------------------------
	} ; if (CurrentFocus != "ListBox1")
	; -------------------------------------------
}
return
; -------------------------------------------
Label_E_ZipCode: ; Edit Feild
{
	; -------------------------------------------
	ControlGetFocus, CurrentFocus, A
	if (CurrentFocus != "ListBox1")
	{
	  ; -------------------------------------------
	  ReturnedAnswer := EditFeildCheck("Edit_ZipCode", Array_CurrentRecord) ; CheckThisEdit = Edit_ObjectName > (0) Empty Feild -OR- (ThisEditValue)
	  ; -------------------------------------------
	  if (ReturnedAnswer == 0) ; Field is Empty
	  {
  		; -------------------------------------------
		  OnOff_ZipCode := 0
		  ; -------------------------------------------
		  GuiControl, Tracker:+c000000, Radio_ZipCode ; Black Color
		  ; -------------------------------------------
		  GuiControl, Tracker:, Edit_ZipCode, ; Empty Edit Feild
		  ; -------------------------------------------
	  }
	  else ; Field is NOT Empty | (ReturnedAnswer) = Value of Edit Feild
	  {
  		; -------------------------------------------
		  OnOff_ZipCode := 1
		  ; -------------------------------------------
		  GuiControl, Tracker:+cc42424, Radio_ZipCode ; Red Color
		  ; -------------------------------------------
	  }
	  ; -------------------------------------------
	  GuiControl, Tracker:, Radio_ZipCode, %OnOff_ZipCode%
	  GuiControl, Tracker:MoveDraw, Radio_ZipCode
	  ; -------------------------------------------
	  PreSetEditCheck("Edit_ZipCode", PresetValue_ZipCode_1, PresetValue_ZipCode_2, PresetValue_ZipCode_3)
	  ; -------------------------------------------
 	} ; if (CurrentFocus != "ListBox1")
 	; -------------------------------------------
}
return
; -------------------------------------------
Label_R_ZipCode: ; Main Radio
{
	; -------------------------------------------
	if (OnOff_ZipCode == "")
	{
		GuiControlGet, OnOff_ZipCode, Tracker:, Radio_ZipCode
	}
	; -------------------------------------------
	if (OnOff_ZipCode == 0) ; Is UnSelected > Select (Red) 
	{
		; -------------------------------------------
		OnOff_ZipCode := 1
		; -------------------------------------------
		GuiControl, Tracker:+cc42424, Radio_ZipCode ; Red Color
		; -------------------------------------------
	}
	else if (OnOff_ZipCode == 1) ; Is Selected > UnSelect (Black)
	{
		; -------------------------------------------
		OnOff_ZipCode := 0
		; -------------------------------------------
		GuiControl, Tracker:+c000000, Radio_ZipCode ; Black Color
		; -------------------------------------------
		GuiControl, Tracker:, Edit_ZipCode,
		; -------------------------------------------
		GuiControl, Tracker:Disable, Update_ZipCode
		; -------------------------------------------
		GuiControl, Tracker:, Radio_ZipCode_1, 0
		GuiControl, Tracker:MoveDraw, Radio_ZipCode_1
		GuiControl, Tracker:, Radio_ZipCode_2, 0
		GuiControl, Tracker:MoveDraw, Radio_ZipCode_2
		GuiControl, Tracker:, Radio_ZipCode_3, 0
		GuiControl, Tracker:MoveDraw, Radio_ZipCode_3
		; -------------------------------------------
		Array_Preset := GetPreSet("ZipCode", 0) ; ([0] All UnSelect/[1] Select Current) -OR- ("Radio_ZipCode_1") > [PreSetValue_1, PreSetValue_2, PreSetValue_3]
		; -------------------------------------------
	}
	; -------------------------------------------
	EditFeildCheck("", Array_CurrentRecord) ; CheckThisEdit = Edit_ObjectName > (0) Empty Feild -OR- (ThisEditValue)
	; -------------------------------------------
	GuiControl, Tracker:, Radio_ZipCode, %OnOff_ZipCode%
	; -------------------------------------------
	GuiControl, Tracker:MoveDraw, Radio_ZipCode
	; -------------------------------------------
}
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Label_CatBrowser:
{
	; -------------------------------------------
	BlockInput, On
	BlockInput, MouseMove
	; -------------------------------------------		
	;
	; -------------------------------------------
	RecordHasChanged := HasRecordChanged(Array_CurrentRecord) ; > 0 -OR- 1
	; -------------------------------------------
	if (RecordHasChanged == 1) ; Record Has Changed
	{
		; -------------------------------------------
		if (Array_CurrentRecord != "")
		{
			; -------------------------------------------
			GuiControlGet, Value_Button_Accept, Tracker:, Button_Accept
			; -------------------------------------------
			if (Value_Button_Accept != "Update Record")
			{
				; -------------------------------------------
				ControlGetFocus, CurrentFocus, A
				if (CurrentFocus != "ListBox1")
				{
					; -------------------------------------------
					Gui, Tracker:Color, eceba9 ; Yellow Color
					; -------------------------------------------
					;
					; -------------------------------------------
					GuiControl, Tracker:, Button_Accept, Update Record
					GuiControl, Tracker:MoveDraw, %Button_Accept%
					GuiControl, Tracker:Show, Button_Accept
					; -------------------------------------------
					;
					; -------------------------------------------
					Value_TitleTextDisplay := "Changing Record"
					Value_TextDisplay      := "X"
					Color_TitleTextDisplay := "Red"
					Color_TextDisplay      := "X"
					GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
					; -------------------------------------------
				} ; if (CurrentFocus != "ListBox1")
				; -------------------------------------------
			} ; if (Value_Button_Accept != "Update Record")
			; -------------------------------------------
		} ; if (Array_CurrentRecord != "")
		; -------------------------------------------
	} ; if (RecordHasChanged == 1) ; Record Has Changed
	; -------------------------------------------
	else ; Record Has NOT Changed
	{
		; -------------------------------------------
		if (Array_CurrentRecord != "") ; Array_CurrentRecord is NOT Empty
		{
			; -------------------------------------------
			GuiControlGet, Value_Button_Accept, Tracker:, Button_Accept
			; -------------------------------------------
			if (Value_Button_Accept != "Delete Record") ; EditFeildCheck
			{
				; -------------------------------------------
				ControlGetFocus, CurrentFocus, A
				if (CurrentFocus != "ListBox1")
				{
					; -------------------------------------------
					Gui, Tracker:Color, edbaba ; Red Color
					; -------------------------------------------
					;
					; -------------------------------------------
					GuiControl, Tracker:, Button_Accept, Delete Record
					GuiControl, Tracker:MoveDraw, %Button_Accept%
					GuiControl, Tracker:Show, Button_Accept
					; -------------------------------------------
					;
					; -------------------------------------------
					Value_TitleTextDisplay := "Existing Record"
					Value_TextDisplay      := "X"
					Color_TitleTextDisplay := "Green"
					Color_TextDisplay      := "X"
					GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
					; -------------------------------------------
				} ; if (CurrentFocus != "ListBox1")
				; -------------------------------------------
			} ; if (Value_Button_Accept != "Delete Record") ; EditFeildCheck
			; -------------------------------------------
		} ; if (Array_CurrentRecord != "") ; Array_CurrentRecord is NOT Empty
		; -------------------------------------------
		else ; Array_CurrentRecord is Empty
		{
			; -------------------------------------------
			GuiControlGet, Show_Button_Accept, Tracker:Visible , Button_Accept
			; -------------------------------------------
			if (Show_Button_Accept == 1)
			{
				; -------------------------------------------
				Gui, Tracker:Color, e7d8fe ; Purple Color
				; -------------------------------------------
			} ; if (Show_Button_Accept == 1)
			; -------------------------------------------
			;
			; -------------------------------------------
			GuiControl, Tracker:, Button_Accept,
			GuiControl, Tracker:Hide, Button_Accept
			; -------------------------------------------
		} ; else ; Array_CurrentRecord is Empty
		; -------------------------------------------
	} ; else ; Record Has NOT Changed
	; -------------------------------------------
	;
	; -------------------------------------------
	SelectCategoryRadio("")
	; -------------------------------------------
	GuiControlGet, OnOff_ChangePassword, Tracker:, Radio_ExistingRecord
	; -------------------------------------------
	if (OnOff_ChangePassword == 0)
	{
		; -------------------------------------------
		Value_TitleTextDisplay := "New Record"
		Value_TextDisplay      := ""
		Color_TitleTextDisplay := "Green"
		Color_TextDisplay      := "X"
		GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
		; -------------------------------------------
	} ; if (OnOff_ChangePassword == 0)
	; -------------------------------------------
	;
	; -------------------------------------------
	BlockInput, Off
	BlockInput, MouseMoveOff
	; -------------------------------------------
}
return
; -------------------------------------------
Label_S_CatBrowser:
{
	; -------------------------------------------
	BlockInput, On
	BlockInput, MouseMove
	; -------------------------------------------
	;
	; -------------------------------------------
	Array_CurrentRecord := ""
	; -------------------------------------------
	EditFeildCheck("", Array_CurrentRecord) ; CheckThisEdit = Edit_ObjectName > (0) Empty Feild -OR- (ThisEditValue)
	; -------------------------------------------
	;
	; -------------------------------------------
	SelectCategoryRadio("Radio_CatBrowser")
	; -------------------------------------------
	GuiControlGet, OnOff_ChangePassword, Tracker:, Radio_ExistingRecord
	; -------------------------------------------
	if (OnOff_ChangePassword == 1)
	{
		; -------------------------------------------
		Value_TitleTextDisplay := "Loading Records"
		Value_TextDisplay      := ""
		Color_TitleTextDisplay := "Blue"
		Color_TextDisplay      := "X"
		GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
		; -------------------------------------------
		;
		; -------------------------------------------
		ListBox_Search_Clear := "|"
		GuiControl, Tracker:, ListBox_Search, %ListBox_Search_Clear%
		; -------------------------------------------
		Array_Returned := CategorySearch(ArrayAllRecords) ; > [ListBox_Search_List, Array_SearchList]
		ListBox_Search_List := Array_Returned.1
		Array_SearchList := Array_Returned.2
		; -------------------------------------------
		GuiControl, Tracker:, ListBox_Search, %ListBox_Search_List%
		; -------------------------------------------
		;
		; -------------------------------------------
		Value_TitleTextDisplay := "Select Record"
		Value_TextDisplay      := ""
		Color_TitleTextDisplay := "Blue"
		Color_TextDisplay      := "X"
		GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
		; -------------------------------------------
	} ; if (OnOff_ChangePassword == 1)
	; -------------------------------------------
	;
	; -------------------------------------------
	BlockInput, Off
	BlockInput, MouseMoveOff
	; -------------------------------------------
}
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Label_CatBuySell:
{
	; -------------------------------------------
	BlockInput, On
	BlockInput, MouseMove
	; -------------------------------------------		
	;
	; -------------------------------------------
	RecordHasChanged := HasRecordChanged(Array_CurrentRecord) ; > 0 -OR- 1
	; -------------------------------------------
	if (RecordHasChanged == 1) ; Record Has Changed
	{
		; -------------------------------------------
		if (Array_CurrentRecord != "")
		{
			; -------------------------------------------
			GuiControlGet, Value_Button_Accept, Tracker:, Button_Accept
			; -------------------------------------------
			if (Value_Button_Accept != "Update Record")
			{
				; -------------------------------------------
				ControlGetFocus, CurrentFocus, A
				if (CurrentFocus != "ListBox1")
				{
					; -------------------------------------------
					Gui, Tracker:Color, eceba9 ; Yellow Color
					; -------------------------------------------
					;
					; -------------------------------------------
					GuiControl, Tracker:, Button_Accept, Update Record
					GuiControl, Tracker:MoveDraw, %Button_Accept%
					GuiControl, Tracker:Show, Button_Accept
					; -------------------------------------------
					;
					; -------------------------------------------
					Value_TitleTextDisplay := "Changing Record"
					Value_TextDisplay      := "X"
					Color_TitleTextDisplay := "Red"
					Color_TextDisplay      := "X"
					GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
					; -------------------------------------------
				} ; if (CurrentFocus != "ListBox1")
				; -------------------------------------------
			} ; if (Value_Button_Accept != "Update Record")
			; -------------------------------------------
		} ; if (Array_CurrentRecord != "")
		; -------------------------------------------
	} ; if (RecordHasChanged == 1) ; Record Has Changed
	; -------------------------------------------
	else ; Record Has NOT Changed
	{
		; -------------------------------------------
		if (Array_CurrentRecord != "") ; Array_CurrentRecord is NOT Empty
		{
			; -------------------------------------------
			GuiControlGet, Value_Button_Accept, Tracker:, Button_Accept
			; -------------------------------------------
			if (Value_Button_Accept != "Delete Record") ; EditFeildCheck
			{
				; -------------------------------------------
				ControlGetFocus, CurrentFocus, A
				if (CurrentFocus != "ListBox1")
				{
					; -------------------------------------------
					Gui, Tracker:Color, edbaba ; Red Color
					; -------------------------------------------
					;
					; -------------------------------------------
					GuiControl, Tracker:, Button_Accept, Delete Record
					GuiControl, Tracker:MoveDraw, %Button_Accept%
					GuiControl, Tracker:Show, Button_Accept
					; -------------------------------------------
					;
					; -------------------------------------------
					Value_TitleTextDisplay := "Existing Record"
					Value_TextDisplay      := "X"
					Color_TitleTextDisplay := "Green"
					Color_TextDisplay      := "X"
					GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
					; -------------------------------------------
				} ; if (CurrentFocus != "ListBox1")
				; -------------------------------------------
			} ; if (Value_Button_Accept != "Delete Record") ; EditFeildCheck
			; -------------------------------------------
		} ; if (Array_CurrentRecord != "") ; Array_CurrentRecord is NOT Empty
		; -------------------------------------------
		else ; Array_CurrentRecord is Empty
		{
			; -------------------------------------------
			GuiControlGet, Show_Button_Accept, Tracker:Visible , Button_Accept
			; -------------------------------------------
			if (Show_Button_Accept == 1)
			{
				; -------------------------------------------
				Gui, Tracker:Color, e7d8fe ; Purple Color
				; -------------------------------------------
			} ; if (Show_Button_Accept == 1)
			; -------------------------------------------
			;
			; -------------------------------------------
			GuiControl, Tracker:, Button_Accept,
			GuiControl, Tracker:Hide, Button_Accept
			; -------------------------------------------
		} ; else ; Array_CurrentRecord is Empty
		; -------------------------------------------
	} ; else ; Record Has NOT Changed
	; -------------------------------------------
	;
	; -------------------------------------------
	SelectCategoryRadio("")
	; -------------------------------------------
	GuiControlGet, OnOff_ChangePassword, Tracker:, Radio_ExistingRecord
	; -------------------------------------------
	if (OnOff_ChangePassword == 0)
	{
		; -------------------------------------------
		Value_TitleTextDisplay := "New Record"
		Value_TextDisplay      := ""
		Color_TitleTextDisplay := "Green"
		Color_TextDisplay      := "X"
		GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
		; -------------------------------------------
	} ; if (OnOff_ChangePassword == 0)
	; -------------------------------------------
	;
	; -------------------------------------------
	BlockInput, Off
	BlockInput, MouseMoveOff
	; -------------------------------------------
}
return
; -------------------------------------------
Label_S_CatBuySell:
{
	; -------------------------------------------
	BlockInput, On
	BlockInput, MouseMove
	; -------------------------------------------
	;
	; -------------------------------------------
	Array_CurrentRecord := ""
	; -------------------------------------------
	EditFeildCheck("", Array_CurrentRecord) ; CheckThisEdit = Edit_ObjectName > (0) Empty Feild -OR- (ThisEditValue)
	; -------------------------------------------
	;
	; -------------------------------------------
	SelectCategoryRadio("Radio_CatBuySell")
	; -------------------------------------------
	GuiControlGet, OnOff_ChangePassword, Tracker:, Radio_ExistingRecord
	; -------------------------------------------
	if (OnOff_ChangePassword == 1)
	{
		; -------------------------------------------
		Value_TitleTextDisplay := "Loading Records"
		Value_TextDisplay      := ""
		Color_TitleTextDisplay := "Blue"
		Color_TextDisplay      := "X"
		GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
		; -------------------------------------------
		;
		; -------------------------------------------
		ListBox_Search_Clear := "|"
		GuiControl, Tracker:, ListBox_Search, %ListBox_Search_Clear%
		; -------------------------------------------
		Array_Returned := CategorySearch(ArrayAllRecords) ; > [ListBox_Search_List, Array_SearchList]
		ListBox_Search_List := Array_Returned.1
		Array_SearchList := Array_Returned.2
		; -------------------------------------------
		GuiControl, Tracker:, ListBox_Search, %ListBox_Search_List%
		; -------------------------------------------
		;
		; -------------------------------------------
		Value_TitleTextDisplay := "Select Record"
		Value_TextDisplay      := ""
		Color_TitleTextDisplay := "Blue"
		Color_TextDisplay      := "X"
		GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
		; -------------------------------------------
	} ; if (OnOff_ChangePassword == 1)
	; -------------------------------------------
	;
	; -------------------------------------------
	BlockInput, Off
	BlockInput, MouseMoveOff
	; -------------------------------------------
}
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Label_CatContact:
{
	; -------------------------------------------
	BlockInput, On
	BlockInput, MouseMove
	; -------------------------------------------		
	;
	; -------------------------------------------
	RecordHasChanged := HasRecordChanged(Array_CurrentRecord) ; > 0 -OR- 1
	; -------------------------------------------
	if (RecordHasChanged == 1) ; Record Has Changed
	{
		; -------------------------------------------
		if (Array_CurrentRecord != "")
		{
			; -------------------------------------------
			GuiControlGet, Value_Button_Accept, Tracker:, Button_Accept
			; -------------------------------------------
			if (Value_Button_Accept != "Update Record")
			{
				; -------------------------------------------
				ControlGetFocus, CurrentFocus, A
				if (CurrentFocus != "ListBox1")
				{
					; -------------------------------------------
					Gui, Tracker:Color, eceba9 ; Yellow Color
					; -------------------------------------------
					;
					; -------------------------------------------
					GuiControl, Tracker:, Button_Accept, Update Record
					GuiControl, Tracker:MoveDraw, %Button_Accept%
					GuiControl, Tracker:Show, Button_Accept
					; -------------------------------------------
					;
					; -------------------------------------------
					Value_TitleTextDisplay := "Changing Record"
					Value_TextDisplay      := "X"
					Color_TitleTextDisplay := "Red"
					Color_TextDisplay      := "X"
					GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
					; -------------------------------------------
				} ; if (CurrentFocus != "ListBox1")
				; -------------------------------------------
			} ; if (Value_Button_Accept != "Update Record")
			; -------------------------------------------
		} ; if (Array_CurrentRecord != "")
		; -------------------------------------------
	} ; if (RecordHasChanged == 1) ; Record Has Changed
	; -------------------------------------------
	else ; Record Has NOT Changed
	{
		; -------------------------------------------
		if (Array_CurrentRecord != "") ; Array_CurrentRecord is NOT Empty
		{
			; -------------------------------------------
			GuiControlGet, Value_Button_Accept, Tracker:, Button_Accept
			; -------------------------------------------
			if (Value_Button_Accept != "Delete Record") ; EditFeildCheck
			{
				; -------------------------------------------
				ControlGetFocus, CurrentFocus, A
				if (CurrentFocus != "ListBox1")
				{
					; -------------------------------------------
					Gui, Tracker:Color, edbaba ; Red Color
					; -------------------------------------------
					;
					; -------------------------------------------
					GuiControl, Tracker:, Button_Accept, Delete Record
					GuiControl, Tracker:MoveDraw, %Button_Accept%
					GuiControl, Tracker:Show, Button_Accept
					; -------------------------------------------
					;
					; -------------------------------------------
					Value_TitleTextDisplay := "Existing Record"
					Value_TextDisplay      := "X"
					Color_TitleTextDisplay := "Green"
					Color_TextDisplay      := "X"
					GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
					; -------------------------------------------
				} ; if (CurrentFocus != "ListBox1")
				; -------------------------------------------
			} ; if (Value_Button_Accept != "Delete Record") ; EditFeildCheck
			; -------------------------------------------
		} ; if (Array_CurrentRecord != "") ; Array_CurrentRecord is NOT Empty
		; -------------------------------------------
		else ; Array_CurrentRecord is Empty
		{
			; -------------------------------------------
			GuiControlGet, Show_Button_Accept, Tracker:Visible , Button_Accept
			; -------------------------------------------
			if (Show_Button_Accept == 1)
			{
				; -------------------------------------------
				Gui, Tracker:Color, e7d8fe ; Purple Color
				; -------------------------------------------
			} ; if (Show_Button_Accept == 1)
			; -------------------------------------------
			;
			; -------------------------------------------
			GuiControl, Tracker:, Button_Accept,
			GuiControl, Tracker:Hide, Button_Accept
			; -------------------------------------------
		} ; else ; Array_CurrentRecord is Empty
		; -------------------------------------------
	} ; else ; Record Has NOT Changed
	; -------------------------------------------
	;
	; -------------------------------------------
	SelectCategoryRadio("")
	; -------------------------------------------
	GuiControlGet, OnOff_ChangePassword, Tracker:, Radio_ExistingRecord
	; -------------------------------------------
	if (OnOff_ChangePassword == 0)
	{
		; -------------------------------------------
		Value_TitleTextDisplay := "New Record"
		Value_TextDisplay      := ""
		Color_TitleTextDisplay := "Green"
		Color_TextDisplay      := "X"
		GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
		; -------------------------------------------
	} ; if (OnOff_ChangePassword == 0)
	; -------------------------------------------
	;
	; -------------------------------------------
	BlockInput, Off
	BlockInput, MouseMoveOff
	; -------------------------------------------
}
return
; -------------------------------------------
Label_S_CatContact:
{
	; -------------------------------------------
	BlockInput, On
	BlockInput, MouseMove
	; -------------------------------------------
	;
	; -------------------------------------------
	Array_CurrentRecord := ""
	; -------------------------------------------
	EditFeildCheck("", Array_CurrentRecord) ; CheckThisEdit = Edit_ObjectName > (0) Empty Feild -OR- (ThisEditValue)
	; -------------------------------------------
	;
	; -------------------------------------------
	SelectCategoryRadio("Radio_CatContact")
	; -------------------------------------------
	GuiControlGet, OnOff_ChangePassword, Tracker:, Radio_ExistingRecord
	; -------------------------------------------
	if (OnOff_ChangePassword == 1)
	{
		; -------------------------------------------
		Value_TitleTextDisplay := "Loading Records"
		Value_TextDisplay      := ""
		Color_TitleTextDisplay := "Blue"
		Color_TextDisplay      := "X"
		GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
		; -------------------------------------------
		;
		; -------------------------------------------
		ListBox_Search_Clear := "|"
		GuiControl, Tracker:, ListBox_Search, %ListBox_Search_Clear%
		; -------------------------------------------
		Array_Returned := CategorySearch(ArrayAllRecords) ; > [ListBox_Search_List, Array_SearchList]
		ListBox_Search_List := Array_Returned.1
		Array_SearchList := Array_Returned.2
		; -------------------------------------------
		GuiControl, Tracker:, ListBox_Search, %ListBox_Search_List%
		; -------------------------------------------
		;
		; -------------------------------------------
		Value_TitleTextDisplay := "Select Record"
		Value_TextDisplay      := ""
		Color_TitleTextDisplay := "Blue"
		Color_TextDisplay      := "X"
		GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
		; -------------------------------------------
	} ; if (OnOff_ChangePassword == 1)
	; -------------------------------------------
	;
	; -------------------------------------------
	BlockInput, Off
	BlockInput, MouseMoveOff
	; -------------------------------------------
}
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Label_CatDownLoad:
{
	; -------------------------------------------
	BlockInput, On
	BlockInput, MouseMove
	; -------------------------------------------		
	;
	; -------------------------------------------
	RecordHasChanged := HasRecordChanged(Array_CurrentRecord) ; > 0 -OR- 1
	; -------------------------------------------
	if (RecordHasChanged == 1) ; Record Has Changed
	{
		; -------------------------------------------
		if (Array_CurrentRecord != "")
		{
			; -------------------------------------------
			GuiControlGet, Value_Button_Accept, Tracker:, Button_Accept
			; -------------------------------------------
			if (Value_Button_Accept != "Update Record")
			{
				; -------------------------------------------
				ControlGetFocus, CurrentFocus, A
				if (CurrentFocus != "ListBox1")
				{
					; -------------------------------------------
					Gui, Tracker:Color, eceba9 ; Yellow Color
					; -------------------------------------------
					;
					; -------------------------------------------
					GuiControl, Tracker:, Button_Accept, Update Record
					GuiControl, Tracker:MoveDraw, %Button_Accept%
					GuiControl, Tracker:Show, Button_Accept
					; -------------------------------------------
					;
					; -------------------------------------------
					Value_TitleTextDisplay := "Changing Record"
					Value_TextDisplay      := "X"
					Color_TitleTextDisplay := "Red"
					Color_TextDisplay      := "X"
					GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
					; -------------------------------------------
				} ; if (CurrentFocus != "ListBox1")
				; -------------------------------------------
			} ; if (Value_Button_Accept != "Update Record")
			; -------------------------------------------
		} ; if (Array_CurrentRecord != "")
		; -------------------------------------------
	} ; if (RecordHasChanged == 1) ; Record Has Changed
	; -------------------------------------------
	else ; Record Has NOT Changed
	{
		; -------------------------------------------
		if (Array_CurrentRecord != "") ; Array_CurrentRecord is NOT Empty
		{
			; -------------------------------------------
			GuiControlGet, Value_Button_Accept, Tracker:, Button_Accept
			; -------------------------------------------
			if (Value_Button_Accept != "Delete Record") ; EditFeildCheck
			{
				; -------------------------------------------
				ControlGetFocus, CurrentFocus, A
				if (CurrentFocus != "ListBox1")
				{
					; -------------------------------------------
					Gui, Tracker:Color, edbaba ; Red Color
					; -------------------------------------------
					;
					; -------------------------------------------
					GuiControl, Tracker:, Button_Accept, Delete Record
					GuiControl, Tracker:MoveDraw, %Button_Accept%
					GuiControl, Tracker:Show, Button_Accept
					; -------------------------------------------
					;
					; -------------------------------------------
					Value_TitleTextDisplay := "Existing Record"
					Value_TextDisplay      := "X"
					Color_TitleTextDisplay := "Green"
					Color_TextDisplay      := "X"
					GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
					; -------------------------------------------
				} ; if (CurrentFocus != "ListBox1")
				; -------------------------------------------
			} ; if (Value_Button_Accept != "Delete Record") ; EditFeildCheck
			; -------------------------------------------
		} ; if (Array_CurrentRecord != "") ; Array_CurrentRecord is NOT Empty
		; -------------------------------------------
		else ; Array_CurrentRecord is Empty
		{
			; -------------------------------------------
			GuiControlGet, Show_Button_Accept, Tracker:Visible , Button_Accept
			; -------------------------------------------
			if (Show_Button_Accept == 1)
			{
				; -------------------------------------------
				Gui, Tracker:Color, e7d8fe ; Purple Color
				; -------------------------------------------
			} ; if (Show_Button_Accept == 1)
			; -------------------------------------------
			;
			; -------------------------------------------
			GuiControl, Tracker:, Button_Accept,
			GuiControl, Tracker:Hide, Button_Accept
			; -------------------------------------------
		} ; else ; Array_CurrentRecord is Empty
		; -------------------------------------------
	} ; else ; Record Has NOT Changed
	; -------------------------------------------
	;
	; -------------------------------------------
	SelectCategoryRadio("")
	; -------------------------------------------
	GuiControlGet, OnOff_ChangePassword, Tracker:, Radio_ExistingRecord
	; -------------------------------------------
	if (OnOff_ChangePassword == 0)
	{
		; -------------------------------------------
		Value_TitleTextDisplay := "New Record"
		Value_TextDisplay      := ""
		Color_TitleTextDisplay := "Green"
		Color_TextDisplay      := "X"
		GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
		; -------------------------------------------
	} ; if (OnOff_ChangePassword == 0)
	; -------------------------------------------
	;
	; -------------------------------------------
	BlockInput, Off
	BlockInput, MouseMoveOff
	; -------------------------------------------
}
return
; -------------------------------------------
Label_S_CatDownLoad:
{
	; -------------------------------------------
	BlockInput, On
	BlockInput, MouseMove
	; -------------------------------------------
	;
	; -------------------------------------------
	Array_CurrentRecord := ""
	; -------------------------------------------
	EditFeildCheck("", Array_CurrentRecord) ; CheckThisEdit = Edit_ObjectName > (0) Empty Feild -OR- (ThisEditValue)
	; -------------------------------------------
	;
	; -------------------------------------------
	SelectCategoryRadio("Radio_CatDownLoad")
	; -------------------------------------------
	GuiControlGet, OnOff_ChangePassword, Tracker:, Radio_ExistingRecord
	; -------------------------------------------
	if (OnOff_ChangePassword == 1)
	{
		; -------------------------------------------
		Value_TitleTextDisplay := "Loading Records"
		Value_TextDisplay      := ""
		Color_TitleTextDisplay := "Blue"
		Color_TextDisplay      := "X"
		GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
		; -------------------------------------------
		;
		; -------------------------------------------
		ListBox_Search_Clear := "|"
		GuiControl, Tracker:, ListBox_Search, %ListBox_Search_Clear%
		; -------------------------------------------
		Array_Returned := CategorySearch(ArrayAllRecords) ; > [ListBox_Search_List, Array_SearchList]
		ListBox_Search_List := Array_Returned.1
		Array_SearchList := Array_Returned.2
		; -------------------------------------------
		GuiControl, Tracker:, ListBox_Search, %ListBox_Search_List%
		; -------------------------------------------
		;
		; -------------------------------------------
		Value_TitleTextDisplay := "Select Record"
		Value_TextDisplay      := ""
		Color_TitleTextDisplay := "Blue"
		Color_TextDisplay      := "X"
		GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
		; -------------------------------------------
	} ; if (OnOff_ChangePassword == 1)
	; -------------------------------------------
	;
	; -------------------------------------------
	BlockInput, Off
	BlockInput, MouseMoveOff
	; -------------------------------------------
}
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Label_CatEmail:
{
	; -------------------------------------------
	BlockInput, On
	BlockInput, MouseMove
	; -------------------------------------------		
	;
	; -------------------------------------------
	RecordHasChanged := HasRecordChanged(Array_CurrentRecord) ; > 0 -OR- 1
	; -------------------------------------------
	if (RecordHasChanged == 1) ; Record Has Changed
	{
		; -------------------------------------------
		if (Array_CurrentRecord != "")
		{
			; -------------------------------------------
			GuiControlGet, Value_Button_Accept, Tracker:, Button_Accept
			; -------------------------------------------
			if (Value_Button_Accept != "Update Record")
			{
				; -------------------------------------------
				ControlGetFocus, CurrentFocus, A
				if (CurrentFocus != "ListBox1")
				{
					; -------------------------------------------
					Gui, Tracker:Color, eceba9 ; Yellow Color
					; -------------------------------------------
					;
					; -------------------------------------------
					GuiControl, Tracker:, Button_Accept, Update Record
					GuiControl, Tracker:MoveDraw, %Button_Accept%
					GuiControl, Tracker:Show, Button_Accept
					; -------------------------------------------
					;
					; -------------------------------------------
					Value_TitleTextDisplay := "Changing Record"
					Value_TextDisplay      := "X"
					Color_TitleTextDisplay := "Red"
					Color_TextDisplay      := "X"
					GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
					; -------------------------------------------
				} ; if (CurrentFocus != "ListBox1")
				; -------------------------------------------
			} ; if (Value_Button_Accept != "Update Record")
			; -------------------------------------------
		} ; if (Array_CurrentRecord != "")
		; -------------------------------------------
	} ; if (RecordHasChanged == 1) ; Record Has Changed
	; -------------------------------------------
	else ; Record Has NOT Changed
	{
		; -------------------------------------------
		if (Array_CurrentRecord != "") ; Array_CurrentRecord is NOT Empty
		{
			; -------------------------------------------
			GuiControlGet, Value_Button_Accept, Tracker:, Button_Accept
			; -------------------------------------------
			if (Value_Button_Accept != "Delete Record") ; EditFeildCheck
			{
				; -------------------------------------------
				ControlGetFocus, CurrentFocus, A
				if (CurrentFocus != "ListBox1")
				{
					; -------------------------------------------
					Gui, Tracker:Color, edbaba ; Red Color
					; -------------------------------------------
					;
					; -------------------------------------------
					GuiControl, Tracker:, Button_Accept, Delete Record
					GuiControl, Tracker:MoveDraw, %Button_Accept%
					GuiControl, Tracker:Show, Button_Accept
					; -------------------------------------------
					;
					; -------------------------------------------
					Value_TitleTextDisplay := "Existing Record"
					Value_TextDisplay      := "X"
					Color_TitleTextDisplay := "Green"
					Color_TextDisplay      := "X"
					GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
					; -------------------------------------------
				} ; if (CurrentFocus != "ListBox1")
				; -------------------------------------------
			} ; if (Value_Button_Accept != "Delete Record") ; EditFeildCheck
			; -------------------------------------------
		} ; if (Array_CurrentRecord != "") ; Array_CurrentRecord is NOT Empty
		; -------------------------------------------
		else ; Array_CurrentRecord is Empty
		{
			; -------------------------------------------
			GuiControlGet, Show_Button_Accept, Tracker:Visible , Button_Accept
			; -------------------------------------------
			if (Show_Button_Accept == 1)
			{
				; -------------------------------------------
				Gui, Tracker:Color, e7d8fe ; Purple Color
				; -------------------------------------------
			} ; if (Show_Button_Accept == 1)
			; -------------------------------------------
			;
			; -------------------------------------------
			GuiControl, Tracker:, Button_Accept,
			GuiControl, Tracker:Hide, Button_Accept
			; -------------------------------------------
		} ; else ; Array_CurrentRecord is Empty
		; -------------------------------------------
	} ; else ; Record Has NOT Changed
	; -------------------------------------------
	;
	; -------------------------------------------
	SelectCategoryRadio("")
	; -------------------------------------------
	GuiControlGet, OnOff_ChangePassword, Tracker:, Radio_ExistingRecord
	; -------------------------------------------
	if (OnOff_ChangePassword == 0)
	{
		; -------------------------------------------
		Value_TitleTextDisplay := "New Record"
		Value_TextDisplay      := ""
		Color_TitleTextDisplay := "Green"
		Color_TextDisplay      := "X"
		GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
		; -------------------------------------------
	} ; if (OnOff_ChangePassword == 0)
	; -------------------------------------------
	;
	; -------------------------------------------
	BlockInput, Off
	BlockInput, MouseMoveOff
	; -------------------------------------------
}
return
; -------------------------------------------
Label_S_CatEmail:
{
	; -------------------------------------------
	BlockInput, On
	BlockInput, MouseMove
	; -------------------------------------------
	;
	; -------------------------------------------
	Array_CurrentRecord := ""
	; -------------------------------------------
	EditFeildCheck("", Array_CurrentRecord) ; CheckThisEdit = Edit_ObjectName > (0) Empty Feild -OR- (ThisEditValue)
	; -------------------------------------------
	;
	; -------------------------------------------
	SelectCategoryRadio("Radio_CatEmail")
	; -------------------------------------------
	GuiControlGet, OnOff_ChangePassword, Tracker:, Radio_ExistingRecord
	; -------------------------------------------
	if (OnOff_ChangePassword == 1)
	{
		; -------------------------------------------
		Value_TitleTextDisplay := "Loading Records"
		Value_TextDisplay      := ""
		Color_TitleTextDisplay := "Blue"
		Color_TextDisplay      := "X"
		GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
		; -------------------------------------------
		;
		; -------------------------------------------
		ListBox_Search_Clear := "|"
		GuiControl, Tracker:, ListBox_Search, %ListBox_Search_Clear%
		; -------------------------------------------
		Array_Returned := CategorySearch(ArrayAllRecords) ; > [ListBox_Search_List, Array_SearchList]
		ListBox_Search_List := Array_Returned.1
		Array_SearchList := Array_Returned.2
		; -------------------------------------------
		GuiControl, Tracker:, ListBox_Search, %ListBox_Search_List%
		; -------------------------------------------
		;
		; -------------------------------------------
		Value_TitleTextDisplay := "Select Record"
		Value_TextDisplay      := ""
		Color_TitleTextDisplay := "Blue"
		Color_TextDisplay      := "X"
		GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
		; -------------------------------------------
	} ; if (OnOff_ChangePassword == 1)
	; -------------------------------------------
	;
	; -------------------------------------------
	BlockInput, Off
	BlockInput, MouseMoveOff
	; -------------------------------------------
}
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Label_CatForum:
{
	; -------------------------------------------
	BlockInput, On
	BlockInput, MouseMove
	; -------------------------------------------		
	;
	; -------------------------------------------
	RecordHasChanged := HasRecordChanged(Array_CurrentRecord) ; > 0 -OR- 1
	; -------------------------------------------
	if (RecordHasChanged == 1) ; Record Has Changed
	{
		; -------------------------------------------
		if (Array_CurrentRecord != "")
		{
			; -------------------------------------------
			GuiControlGet, Value_Button_Accept, Tracker:, Button_Accept
			; -------------------------------------------
			if (Value_Button_Accept != "Update Record")
			{
				; -------------------------------------------
				ControlGetFocus, CurrentFocus, A
				if (CurrentFocus != "ListBox1")
				{
					; -------------------------------------------
					Gui, Tracker:Color, eceba9 ; Yellow Color
					; -------------------------------------------
					;
					; -------------------------------------------
					GuiControl, Tracker:, Button_Accept, Update Record
					GuiControl, Tracker:MoveDraw, %Button_Accept%
					GuiControl, Tracker:Show, Button_Accept
					; -------------------------------------------
					;
					; -------------------------------------------
					Value_TitleTextDisplay := "Changing Record"
					Value_TextDisplay      := "X"
					Color_TitleTextDisplay := "Red"
					Color_TextDisplay      := "X"
					GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
					; -------------------------------------------
				} ; if (CurrentFocus != "ListBox1")
				; -------------------------------------------
			} ; if (Value_Button_Accept != "Update Record")
			; -------------------------------------------
		} ; if (Array_CurrentRecord != "")
		; -------------------------------------------
	} ; if (RecordHasChanged == 1) ; Record Has Changed
	; -------------------------------------------
	else ; Record Has NOT Changed
	{
		; -------------------------------------------
		if (Array_CurrentRecord != "") ; Array_CurrentRecord is NOT Empty
		{
			; -------------------------------------------
			GuiControlGet, Value_Button_Accept, Tracker:, Button_Accept
			; -------------------------------------------
			if (Value_Button_Accept != "Delete Record") ; EditFeildCheck
			{
				; -------------------------------------------
				ControlGetFocus, CurrentFocus, A
				if (CurrentFocus != "ListBox1")
				{
					; -------------------------------------------
					Gui, Tracker:Color, edbaba ; Red Color
					; -------------------------------------------
					;
					; -------------------------------------------
					GuiControl, Tracker:, Button_Accept, Delete Record
					GuiControl, Tracker:MoveDraw, %Button_Accept%
					GuiControl, Tracker:Show, Button_Accept
					; -------------------------------------------
					;
					; -------------------------------------------
					Value_TitleTextDisplay := "Existing Record"
					Value_TextDisplay      := "X"
					Color_TitleTextDisplay := "Green"
					Color_TextDisplay      := "X"
					GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
					; -------------------------------------------
				} ; if (CurrentFocus != "ListBox1")
				; -------------------------------------------
			} ; if (Value_Button_Accept != "Delete Record") ; EditFeildCheck
			; -------------------------------------------
		} ; if (Array_CurrentRecord != "") ; Array_CurrentRecord is NOT Empty
		; -------------------------------------------
		else ; Array_CurrentRecord is Empty
		{
			; -------------------------------------------
			GuiControlGet, Show_Button_Accept, Tracker:Visible , Button_Accept
			; -------------------------------------------
			if (Show_Button_Accept == 1)
			{
				; -------------------------------------------
				Gui, Tracker:Color, e7d8fe ; Purple Color
				; -------------------------------------------
			} ; if (Show_Button_Accept == 1)
			; -------------------------------------------
			;
			; -------------------------------------------
			GuiControl, Tracker:, Button_Accept,
			GuiControl, Tracker:Hide, Button_Accept
			; -------------------------------------------
		} ; else ; Array_CurrentRecord is Empty
		; -------------------------------------------
	} ; else ; Record Has NOT Changed
	; -------------------------------------------
	;
	; -------------------------------------------
	SelectCategoryRadio("")
	; -------------------------------------------
	GuiControlGet, OnOff_ChangePassword, Tracker:, Radio_ExistingRecord
	; -------------------------------------------
	if (OnOff_ChangePassword == 0)
	{
		; -------------------------------------------
		Value_TitleTextDisplay := "New Record"
		Value_TextDisplay      := ""
		Color_TitleTextDisplay := "Green"
		Color_TextDisplay      := "X"
		GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
		; -------------------------------------------
	} ; if (OnOff_ChangePassword == 0)
	; -------------------------------------------
	;
	; -------------------------------------------
	BlockInput, Off
	BlockInput, MouseMoveOff
	; -------------------------------------------
}
return
; -------------------------------------------
Label_S_CatForum:
{
	; -------------------------------------------
	BlockInput, On
	BlockInput, MouseMove
	; -------------------------------------------
	;
	; -------------------------------------------
	Array_CurrentRecord := ""
	; -------------------------------------------
	EditFeildCheck("", Array_CurrentRecord) ; CheckThisEdit = Edit_ObjectName > (0) Empty Feild -OR- (ThisEditValue)
	; -------------------------------------------
	;
	; -------------------------------------------
	SelectCategoryRadio("Radio_CatForum")
	; -------------------------------------------
	GuiControlGet, OnOff_ChangePassword, Tracker:, Radio_ExistingRecord
	; -------------------------------------------
	if (OnOff_ChangePassword == 1)
	{
		; -------------------------------------------
		Value_TitleTextDisplay := "Loading Records"
		Value_TextDisplay      := ""
		Color_TitleTextDisplay := "Blue"
		Color_TextDisplay      := "X"
		GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
		; -------------------------------------------
		;
		; -------------------------------------------
		ListBox_Search_Clear := "|"
		GuiControl, Tracker:, ListBox_Search, %ListBox_Search_Clear%
		; -------------------------------------------
		Array_Returned := CategorySearch(ArrayAllRecords) ; > [ListBox_Search_List, Array_SearchList]
		ListBox_Search_List := Array_Returned.1
		Array_SearchList := Array_Returned.2
		; -------------------------------------------
		GuiControl, Tracker:, ListBox_Search, %ListBox_Search_List%
		; -------------------------------------------
		;
		; -------------------------------------------
		Value_TitleTextDisplay := "Select Record"
		Value_TextDisplay      := ""
		Color_TitleTextDisplay := "Blue"
		Color_TextDisplay      := "X"
		GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
		; -------------------------------------------
	} ; if (OnOff_ChangePassword == 1)
	; -------------------------------------------
	;
	; -------------------------------------------
	BlockInput, Off
	BlockInput, MouseMoveOff
	; -------------------------------------------
}
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Label_CatGame:
{
	; -------------------------------------------
	BlockInput, On
	BlockInput, MouseMove
	; -------------------------------------------		
	;
	; -------------------------------------------
	RecordHasChanged := HasRecordChanged(Array_CurrentRecord) ; > 0 -OR- 1
	; -------------------------------------------
	if (RecordHasChanged == 1) ; Record Has Changed
	{
		; -------------------------------------------
		if (Array_CurrentRecord != "")
		{
			; -------------------------------------------
			GuiControlGet, Value_Button_Accept, Tracker:, Button_Accept
			; -------------------------------------------
			if (Value_Button_Accept != "Update Record")
			{
				; -------------------------------------------
				ControlGetFocus, CurrentFocus, A
				if (CurrentFocus != "ListBox1")
				{
					; -------------------------------------------
					Gui, Tracker:Color, eceba9 ; Yellow Color
					; -------------------------------------------
					;
					; -------------------------------------------
					GuiControl, Tracker:, Button_Accept, Update Record
					GuiControl, Tracker:MoveDraw, %Button_Accept%
					GuiControl, Tracker:Show, Button_Accept
					; -------------------------------------------
					;
					; -------------------------------------------
					Value_TitleTextDisplay := "Changing Record"
					Value_TextDisplay      := "X"
					Color_TitleTextDisplay := "Red"
					Color_TextDisplay      := "X"
					GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
					; -------------------------------------------
				} ; if (CurrentFocus != "ListBox1")
				; -------------------------------------------
			} ; if (Value_Button_Accept != "Update Record")
			; -------------------------------------------
		} ; if (Array_CurrentRecord != "")
		; -------------------------------------------
	} ; if (RecordHasChanged == 1) ; Record Has Changed
	; -------------------------------------------
	else ; Record Has NOT Changed
	{
		; -------------------------------------------
		if (Array_CurrentRecord != "") ; Array_CurrentRecord is NOT Empty
		{
			; -------------------------------------------
			GuiControlGet, Value_Button_Accept, Tracker:, Button_Accept
			; -------------------------------------------
			if (Value_Button_Accept != "Delete Record") ; EditFeildCheck
			{
				; -------------------------------------------
				ControlGetFocus, CurrentFocus, A
				if (CurrentFocus != "ListBox1")
				{
					; -------------------------------------------
					Gui, Tracker:Color, edbaba ; Red Color
					; -------------------------------------------
					;
					; -------------------------------------------
					GuiControl, Tracker:, Button_Accept, Delete Record
					GuiControl, Tracker:MoveDraw, %Button_Accept%
					GuiControl, Tracker:Show, Button_Accept
					; -------------------------------------------
					;
					; -------------------------------------------
					Value_TitleTextDisplay := "Existing Record"
					Value_TextDisplay      := "X"
					Color_TitleTextDisplay := "Green"
					Color_TextDisplay      := "X"
					GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
					; -------------------------------------------
				} ; if (CurrentFocus != "ListBox1")
				; -------------------------------------------
			} ; if (Value_Button_Accept != "Delete Record") ; EditFeildCheck
			; -------------------------------------------
		} ; if (Array_CurrentRecord != "") ; Array_CurrentRecord is NOT Empty
		; -------------------------------------------
		else ; Array_CurrentRecord is Empty
		{
			; -------------------------------------------
			GuiControlGet, Show_Button_Accept, Tracker:Visible , Button_Accept
			; -------------------------------------------
			if (Show_Button_Accept == 1)
			{
				; -------------------------------------------
				Gui, Tracker:Color, e7d8fe ; Purple Color
				; -------------------------------------------
			} ; if (Show_Button_Accept == 1)
			; -------------------------------------------
			;
			; -------------------------------------------
			GuiControl, Tracker:, Button_Accept,
			GuiControl, Tracker:Hide, Button_Accept
			; -------------------------------------------
		} ; else ; Array_CurrentRecord is Empty
		; -------------------------------------------
	} ; else ; Record Has NOT Changed
	; -------------------------------------------
	;
	; -------------------------------------------
	SelectCategoryRadio("")
	; -------------------------------------------
	GuiControlGet, OnOff_ChangePassword, Tracker:, Radio_ExistingRecord
	; -------------------------------------------
	if (OnOff_ChangePassword == 0)
	{
		; -------------------------------------------
		Value_TitleTextDisplay := "New Record"
		Value_TextDisplay      := ""
		Color_TitleTextDisplay := "Green"
		Color_TextDisplay      := "X"
		GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
		; -------------------------------------------
	} ; if (OnOff_ChangePassword == 0)
	; -------------------------------------------
	;
	; -------------------------------------------
	BlockInput, Off
	BlockInput, MouseMoveOff
	; -------------------------------------------
}
return
; -------------------------------------------
Label_S_CatGame:
{
	; -------------------------------------------
	BlockInput, On
	BlockInput, MouseMove
	; -------------------------------------------
	;
	; -------------------------------------------
	Array_CurrentRecord := ""
	; -------------------------------------------
	EditFeildCheck("", Array_CurrentRecord) ; CheckThisEdit = Edit_ObjectName > (0) Empty Feild -OR- (ThisEditValue)
	; -------------------------------------------
	;
	; -------------------------------------------
	SelectCategoryRadio("Radio_CatGame")
	; -------------------------------------------
	GuiControlGet, OnOff_ChangePassword, Tracker:, Radio_ExistingRecord
	; -------------------------------------------
	if (OnOff_ChangePassword == 1)
	{
		; -------------------------------------------
		Value_TitleTextDisplay := "Loading Records"
		Value_TextDisplay      := ""
		Color_TitleTextDisplay := "Blue"
		Color_TextDisplay      := "X"
		GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
		; -------------------------------------------
		;
		; -------------------------------------------
		ListBox_Search_Clear := "|"
		GuiControl, Tracker:, ListBox_Search, %ListBox_Search_Clear%
		; -------------------------------------------
		Array_Returned := CategorySearch(ArrayAllRecords) ; > [ListBox_Search_List, Array_SearchList]
		ListBox_Search_List := Array_Returned.1
		Array_SearchList := Array_Returned.2
		; -------------------------------------------
		GuiControl, Tracker:, ListBox_Search, %ListBox_Search_List%
		; -------------------------------------------
		;
		; -------------------------------------------
		Value_TitleTextDisplay := "Select Record"
		Value_TextDisplay      := ""
		Color_TitleTextDisplay := "Blue"
		Color_TextDisplay      := "X"
		GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
		; -------------------------------------------
	} ; if (OnOff_ChangePassword == 1)
	; -------------------------------------------
	;
	; -------------------------------------------
	BlockInput, Off
	BlockInput, MouseMoveOff
	; -------------------------------------------
}
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Label_CatInternet:
{
	; -------------------------------------------
	BlockInput, On
	BlockInput, MouseMove
	; -------------------------------------------		
	;
	; -------------------------------------------
	RecordHasChanged := HasRecordChanged(Array_CurrentRecord) ; > 0 -OR- 1
	; -------------------------------------------
	if (RecordHasChanged == 1) ; Record Has Changed
	{
		; -------------------------------------------
		if (Array_CurrentRecord != "")
		{
			; -------------------------------------------
			GuiControlGet, Value_Button_Accept, Tracker:, Button_Accept
			; -------------------------------------------
			if (Value_Button_Accept != "Update Record")
			{
				; -------------------------------------------
				ControlGetFocus, CurrentFocus, A
				if (CurrentFocus != "ListBox1")
				{
					; -------------------------------------------
					Gui, Tracker:Color, eceba9 ; Yellow Color
					; -------------------------------------------
					;
					; -------------------------------------------
					GuiControl, Tracker:, Button_Accept, Update Record
					GuiControl, Tracker:MoveDraw, %Button_Accept%
					GuiControl, Tracker:Show, Button_Accept
					; -------------------------------------------
					;
					; -------------------------------------------
					Value_TitleTextDisplay := "Changing Record"
					Value_TextDisplay      := "X"
					Color_TitleTextDisplay := "Red"
					Color_TextDisplay      := "X"
					GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
					; -------------------------------------------
				} ; if (CurrentFocus != "ListBox1")
				; -------------------------------------------
			} ; if (Value_Button_Accept != "Update Record")
			; -------------------------------------------
		} ; if (Array_CurrentRecord != "")
		; -------------------------------------------
	} ; if (RecordHasChanged == 1) ; Record Has Changed
	; -------------------------------------------
	else ; Record Has NOT Changed
	{
		; -------------------------------------------
		if (Array_CurrentRecord != "") ; Array_CurrentRecord is NOT Empty
		{
			; -------------------------------------------
			GuiControlGet, Value_Button_Accept, Tracker:, Button_Accept
			; -------------------------------------------
			if (Value_Button_Accept != "Delete Record") ; EditFeildCheck
			{
				; -------------------------------------------
				ControlGetFocus, CurrentFocus, A
				if (CurrentFocus != "ListBox1")
				{
					; -------------------------------------------
					Gui, Tracker:Color, edbaba ; Red Color
					; -------------------------------------------
					;
					; -------------------------------------------
					GuiControl, Tracker:, Button_Accept, Delete Record
					GuiControl, Tracker:MoveDraw, %Button_Accept%
					GuiControl, Tracker:Show, Button_Accept
					; -------------------------------------------
					;
					; -------------------------------------------
					Value_TitleTextDisplay := "Existing Record"
					Value_TextDisplay      := "X"
					Color_TitleTextDisplay := "Green"
					Color_TextDisplay      := "X"
					GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
					; -------------------------------------------
				} ; if (CurrentFocus != "ListBox1")
				; -------------------------------------------
			} ; if (Value_Button_Accept != "Delete Record") ; EditFeildCheck
			; -------------------------------------------
		} ; if (Array_CurrentRecord != "") ; Array_CurrentRecord is NOT Empty
		; -------------------------------------------
		else ; Array_CurrentRecord is Empty
		{
			; -------------------------------------------
			GuiControlGet, Show_Button_Accept, Tracker:Visible , Button_Accept
			; -------------------------------------------
			if (Show_Button_Accept == 1)
			{
				; -------------------------------------------
				Gui, Tracker:Color, e7d8fe ; Purple Color
				; -------------------------------------------
			} ; if (Show_Button_Accept == 1)
			; -------------------------------------------
			;
			; -------------------------------------------
			GuiControl, Tracker:, Button_Accept,
			GuiControl, Tracker:Hide, Button_Accept
			; -------------------------------------------
		} ; else ; Array_CurrentRecord is Empty
		; -------------------------------------------
	} ; else ; Record Has NOT Changed
	; -------------------------------------------
	;
	; -------------------------------------------
	SelectCategoryRadio("")
	; -------------------------------------------
	GuiControlGet, OnOff_ChangePassword, Tracker:, Radio_ExistingRecord
	; -------------------------------------------
	if (OnOff_ChangePassword == 0)
	{
		; -------------------------------------------
		Value_TitleTextDisplay := "New Record"
		Value_TextDisplay      := ""
		Color_TitleTextDisplay := "Green"
		Color_TextDisplay      := "X"
		GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
		; -------------------------------------------
	} ; if (OnOff_ChangePassword == 0)
	; -------------------------------------------
	;
	; -------------------------------------------
	BlockInput, Off
	BlockInput, MouseMoveOff
	; -------------------------------------------
}
return
; -------------------------------------------
Label_S_CatInternet:
{
	; -------------------------------------------
	BlockInput, On
	BlockInput, MouseMove
	; -------------------------------------------
	;
	; -------------------------------------------
	Array_CurrentRecord := ""
	; -------------------------------------------
	EditFeildCheck("", Array_CurrentRecord) ; CheckThisEdit = Edit_ObjectName > (0) Empty Feild -OR- (ThisEditValue)
	; -------------------------------------------
	;
	; -------------------------------------------
	SelectCategoryRadio("Radio_CatInternet")
	; -------------------------------------------
	GuiControlGet, OnOff_ChangePassword, Tracker:, Radio_ExistingRecord
	; -------------------------------------------
	if (OnOff_ChangePassword == 1)
	{
		; -------------------------------------------
		Value_TitleTextDisplay := "Loading Records"
		Value_TextDisplay      := ""
		Color_TitleTextDisplay := "Blue"
		Color_TextDisplay      := "X"
		GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
		; -------------------------------------------
		;
		; -------------------------------------------
		ListBox_Search_Clear := "|"
		GuiControl, Tracker:, ListBox_Search, %ListBox_Search_Clear%
		; -------------------------------------------
		Array_Returned := CategorySearch(ArrayAllRecords) ; > [ListBox_Search_List, Array_SearchList]
		ListBox_Search_List := Array_Returned.1
		Array_SearchList := Array_Returned.2
		; -------------------------------------------
		GuiControl, Tracker:, ListBox_Search, %ListBox_Search_List%
		; -------------------------------------------
		;
		; -------------------------------------------
		Value_TitleTextDisplay := "Select Record"
		Value_TextDisplay      := ""
		Color_TitleTextDisplay := "Blue"
		Color_TextDisplay      := "X"
		GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
		; -------------------------------------------
	} ; if (OnOff_ChangePassword == 1)
	; -------------------------------------------
	;
	; -------------------------------------------
	BlockInput, Off
	BlockInput, MouseMoveOff
	; -------------------------------------------
}
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Label_CatMailer:
{
	; -------------------------------------------
	BlockInput, On
	BlockInput, MouseMove
	; -------------------------------------------		
	;
	; -------------------------------------------
	RecordHasChanged := HasRecordChanged(Array_CurrentRecord) ; > 0 -OR- 1
	; -------------------------------------------
	if (RecordHasChanged == 1) ; Record Has Changed
	{
		; -------------------------------------------
		if (Array_CurrentRecord != "")
		{
			; -------------------------------------------
			GuiControlGet, Value_Button_Accept, Tracker:, Button_Accept
			; -------------------------------------------
			if (Value_Button_Accept != "Update Record")
			{
				; -------------------------------------------
				ControlGetFocus, CurrentFocus, A
				if (CurrentFocus != "ListBox1")
				{
					; -------------------------------------------
					Gui, Tracker:Color, eceba9 ; Yellow Color
					; -------------------------------------------
					;
					; -------------------------------------------
					GuiControl, Tracker:, Button_Accept, Update Record
					GuiControl, Tracker:MoveDraw, %Button_Accept%
					GuiControl, Tracker:Show, Button_Accept
					; -------------------------------------------
					;
					; -------------------------------------------
					Value_TitleTextDisplay := "Changing Record"
					Value_TextDisplay      := "X"
					Color_TitleTextDisplay := "Red"
					Color_TextDisplay      := "X"
					GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
					; -------------------------------------------
				} ; if (CurrentFocus != "ListBox1")
				; -------------------------------------------
			} ; if (Value_Button_Accept != "Update Record")
			; -------------------------------------------
		} ; if (Array_CurrentRecord != "")
		; -------------------------------------------
	} ; if (RecordHasChanged == 1) ; Record Has Changed
	; -------------------------------------------
	else ; Record Has NOT Changed
	{
		; -------------------------------------------
		if (Array_CurrentRecord != "") ; Array_CurrentRecord is NOT Empty
		{
			; -------------------------------------------
			GuiControlGet, Value_Button_Accept, Tracker:, Button_Accept
			; -------------------------------------------
			if (Value_Button_Accept != "Delete Record") ; EditFeildCheck
			{
				; -------------------------------------------
				ControlGetFocus, CurrentFocus, A
				if (CurrentFocus != "ListBox1")
				{
					; -------------------------------------------
					Gui, Tracker:Color, edbaba ; Red Color
					; -------------------------------------------
					;
					; -------------------------------------------
					GuiControl, Tracker:, Button_Accept, Delete Record
					GuiControl, Tracker:MoveDraw, %Button_Accept%
					GuiControl, Tracker:Show, Button_Accept
					; -------------------------------------------
					;
					; -------------------------------------------
					Value_TitleTextDisplay := "Existing Record"
					Value_TextDisplay      := "X"
					Color_TitleTextDisplay := "Green"
					Color_TextDisplay      := "X"
					GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
					; -------------------------------------------
				} ; if (CurrentFocus != "ListBox1")
				; -------------------------------------------
			} ; if (Value_Button_Accept != "Delete Record") ; EditFeildCheck
			; -------------------------------------------
		} ; if (Array_CurrentRecord != "") ; Array_CurrentRecord is NOT Empty
		; -------------------------------------------
		else ; Array_CurrentRecord is Empty
		{
			; -------------------------------------------
			GuiControlGet, Show_Button_Accept, Tracker:Visible , Button_Accept
			; -------------------------------------------
			if (Show_Button_Accept == 1)
			{
				; -------------------------------------------
				Gui, Tracker:Color, e7d8fe ; Purple Color
				; -------------------------------------------
			} ; if (Show_Button_Accept == 1)
			; -------------------------------------------
			;
			; -------------------------------------------
			GuiControl, Tracker:, Button_Accept,
			GuiControl, Tracker:Hide, Button_Accept
			; -------------------------------------------
		} ; else ; Array_CurrentRecord is Empty
		; -------------------------------------------
	} ; else ; Record Has NOT Changed
	; -------------------------------------------
	;
	; -------------------------------------------
	SelectCategoryRadio("")
	; -------------------------------------------
	GuiControlGet, OnOff_ChangePassword, Tracker:, Radio_ExistingRecord
	; -------------------------------------------
	if (OnOff_ChangePassword == 0)
	{
		; -------------------------------------------
		Value_TitleTextDisplay := "New Record"
		Value_TextDisplay      := ""
		Color_TitleTextDisplay := "Green"
		Color_TextDisplay      := "X"
		GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
		; -------------------------------------------
	} ; if (OnOff_ChangePassword == 0)
	; -------------------------------------------
	;
	; -------------------------------------------
	BlockInput, Off
	BlockInput, MouseMoveOff
	; -------------------------------------------
}
return
; -------------------------------------------
Label_S_CatMailer:
{
	; -------------------------------------------
	BlockInput, On
	BlockInput, MouseMove
	; -------------------------------------------
	;
	; -------------------------------------------
	Array_CurrentRecord := ""
	; -------------------------------------------
	EditFeildCheck("", Array_CurrentRecord) ; CheckThisEdit = Edit_ObjectName > (0) Empty Feild -OR- (ThisEditValue)
	; -------------------------------------------
	;
	; -------------------------------------------
	SelectCategoryRadio("Radio_CatMailer")
	; -------------------------------------------
	GuiControlGet, OnOff_ChangePassword, Tracker:, Radio_ExistingRecord
	; -------------------------------------------
	if (OnOff_ChangePassword == 1)
	{
		; -------------------------------------------
		Value_TitleTextDisplay := "Loading Records"
		Value_TextDisplay      := ""
		Color_TitleTextDisplay := "Blue"
		Color_TextDisplay      := "X"
		GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
		; -------------------------------------------
		;
		; -------------------------------------------
		ListBox_Search_Clear := "|"
		GuiControl, Tracker:, ListBox_Search, %ListBox_Search_Clear%
		; -------------------------------------------
		Array_Returned := CategorySearch(ArrayAllRecords) ; > [ListBox_Search_List, Array_SearchList]
		ListBox_Search_List := Array_Returned.1
		Array_SearchList := Array_Returned.2
		; -------------------------------------------
		GuiControl, Tracker:, ListBox_Search, %ListBox_Search_List%
		; -------------------------------------------
		;
		; -------------------------------------------
		Value_TitleTextDisplay := "Select Record"
		Value_TextDisplay      := ""
		Color_TitleTextDisplay := "Blue"
		Color_TextDisplay      := "X"
		GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
		; -------------------------------------------
	} ; if (OnOff_ChangePassword == 1)
	; -------------------------------------------
	;
	; -------------------------------------------
	BlockInput, Off
	BlockInput, MouseMoveOff
	; -------------------------------------------
}
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Label_CatMoney:
{
	; -------------------------------------------
	BlockInput, On
	BlockInput, MouseMove
	; -------------------------------------------		
	;
	; -------------------------------------------
	RecordHasChanged := HasRecordChanged(Array_CurrentRecord) ; > 0 -OR- 1
	; -------------------------------------------
	if (RecordHasChanged == 1) ; Record Has Changed
	{
		; -------------------------------------------
		if (Array_CurrentRecord != "")
		{
			; -------------------------------------------
			GuiControlGet, Value_Button_Accept, Tracker:, Button_Accept
			; -------------------------------------------
			if (Value_Button_Accept != "Update Record")
			{
				; -------------------------------------------
				ControlGetFocus, CurrentFocus, A
				if (CurrentFocus != "ListBox1")
				{
					; -------------------------------------------
					Gui, Tracker:Color, eceba9 ; Yellow Color
					; -------------------------------------------
					;
					; -------------------------------------------
					GuiControl, Tracker:, Button_Accept, Update Record
					GuiControl, Tracker:MoveDraw, %Button_Accept%
					GuiControl, Tracker:Show, Button_Accept
					; -------------------------------------------
					;
					; -------------------------------------------
					Value_TitleTextDisplay := "Changing Record"
					Value_TextDisplay      := "X"
					Color_TitleTextDisplay := "Red"
					Color_TextDisplay      := "X"
					GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
					; -------------------------------------------
				} ; if (CurrentFocus != "ListBox1")
				; -------------------------------------------
			} ; if (Value_Button_Accept != "Update Record")
			; -------------------------------------------
		} ; if (Array_CurrentRecord != "")
		; -------------------------------------------
	} ; if (RecordHasChanged == 1) ; Record Has Changed
	; -------------------------------------------
	else ; Record Has NOT Changed
	{
		; -------------------------------------------
		if (Array_CurrentRecord != "") ; Array_CurrentRecord is NOT Empty
		{
			; -------------------------------------------
			GuiControlGet, Value_Button_Accept, Tracker:, Button_Accept
			; -------------------------------------------
			if (Value_Button_Accept != "Delete Record") ; EditFeildCheck
			{
				; -------------------------------------------
				ControlGetFocus, CurrentFocus, A
				if (CurrentFocus != "ListBox1")
				{
					; -------------------------------------------
					Gui, Tracker:Color, edbaba ; Red Color
					; -------------------------------------------
					;
					; -------------------------------------------
					GuiControl, Tracker:, Button_Accept, Delete Record
					GuiControl, Tracker:MoveDraw, %Button_Accept%
					GuiControl, Tracker:Show, Button_Accept
					; -------------------------------------------
					;
					; -------------------------------------------
					Value_TitleTextDisplay := "Existing Record"
					Value_TextDisplay      := "X"
					Color_TitleTextDisplay := "Green"
					Color_TextDisplay      := "X"
					GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
					; -------------------------------------------
				} ; if (CurrentFocus != "ListBox1")
				; -------------------------------------------
			} ; if (Value_Button_Accept != "Delete Record") ; EditFeildCheck
			; -------------------------------------------
		} ; if (Array_CurrentRecord != "") ; Array_CurrentRecord is NOT Empty
		; -------------------------------------------
		else ; Array_CurrentRecord is Empty
		{
			; -------------------------------------------
			GuiControlGet, Show_Button_Accept, Tracker:Visible , Button_Accept
			; -------------------------------------------
			if (Show_Button_Accept == 1)
			{
				; -------------------------------------------
				Gui, Tracker:Color, e7d8fe ; Purple Color
				; -------------------------------------------
			} ; if (Show_Button_Accept == 1)
			; -------------------------------------------
			;
			; -------------------------------------------
			GuiControl, Tracker:, Button_Accept,
			GuiControl, Tracker:Hide, Button_Accept
			; -------------------------------------------
		} ; else ; Array_CurrentRecord is Empty
		; -------------------------------------------
	} ; else ; Record Has NOT Changed
	; -------------------------------------------
	;
	; -------------------------------------------
	SelectCategoryRadio("")
	; -------------------------------------------
	GuiControlGet, OnOff_ChangePassword, Tracker:, Radio_ExistingRecord
	; -------------------------------------------
	if (OnOff_ChangePassword == 0)
	{
		; -------------------------------------------
		Value_TitleTextDisplay := "New Record"
		Value_TextDisplay      := ""
		Color_TitleTextDisplay := "Green"
		Color_TextDisplay      := "X"
		GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
		; -------------------------------------------
	} ; if (OnOff_ChangePassword == 0)
	; -------------------------------------------
	;
	; -------------------------------------------
	BlockInput, Off
	BlockInput, MouseMoveOff
	; -------------------------------------------
}
return
; -------------------------------------------
Label_S_CatMoney:
{
	; -------------------------------------------
	BlockInput, On
	BlockInput, MouseMove
	; -------------------------------------------
	;
	; -------------------------------------------
	Array_CurrentRecord := ""
	; -------------------------------------------
	EditFeildCheck("", Array_CurrentRecord) ; CheckThisEdit = Edit_ObjectName > (0) Empty Feild -OR- (ThisEditValue)
	; -------------------------------------------
	;
	; -------------------------------------------
	SelectCategoryRadio("Radio_CatMoney")
	; -------------------------------------------
	GuiControlGet, OnOff_ChangePassword, Tracker:, Radio_ExistingRecord
	; -------------------------------------------
	if (OnOff_ChangePassword == 1)
	{
		; -------------------------------------------
		Value_TitleTextDisplay := "Loading Records"
		Value_TextDisplay      := ""
		Color_TitleTextDisplay := "Blue"
		Color_TextDisplay      := "X"
		GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
		; -------------------------------------------
		;
		; -------------------------------------------
		ListBox_Search_Clear := "|"
		GuiControl, Tracker:, ListBox_Search, %ListBox_Search_Clear%
		; -------------------------------------------
		Array_Returned := CategorySearch(ArrayAllRecords) ; > [ListBox_Search_List, Array_SearchList]
		ListBox_Search_List := Array_Returned.1
		Array_SearchList := Array_Returned.2
		; -------------------------------------------
		GuiControl, Tracker:, ListBox_Search, %ListBox_Search_List%
		; -------------------------------------------
		;
		; -------------------------------------------
		Value_TitleTextDisplay := "Select Record"
		Value_TextDisplay      := ""
		Color_TitleTextDisplay := "Blue"
		Color_TextDisplay      := "X"
		GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
		; -------------------------------------------
	} ; if (OnOff_ChangePassword == 1)
	; -------------------------------------------
	;
	; -------------------------------------------
	BlockInput, Off
	BlockInput, MouseMoveOff
	; -------------------------------------------
}
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Label_CatProgram:
{
	; -------------------------------------------
	BlockInput, On
	BlockInput, MouseMove
	; -------------------------------------------		
	;
	; -------------------------------------------
	RecordHasChanged := HasRecordChanged(Array_CurrentRecord) ; > 0 -OR- 1
	; -------------------------------------------
	if (RecordHasChanged == 1) ; Record Has Changed
	{
		; -------------------------------------------
		if (Array_CurrentRecord != "")
		{
			; -------------------------------------------
			GuiControlGet, Value_Button_Accept, Tracker:, Button_Accept
			; -------------------------------------------
			if (Value_Button_Accept != "Update Record")
			{
				; -------------------------------------------
				ControlGetFocus, CurrentFocus, A
				if (CurrentFocus != "ListBox1")
				{
					; -------------------------------------------
					Gui, Tracker:Color, eceba9 ; Yellow Color
					; -------------------------------------------
					;
					; -------------------------------------------
					GuiControl, Tracker:, Button_Accept, Update Record
					GuiControl, Tracker:MoveDraw, %Button_Accept%
					GuiControl, Tracker:Show, Button_Accept
					; -------------------------------------------
					;
					; -------------------------------------------
					Value_TitleTextDisplay := "Changing Record"
					Value_TextDisplay      := "X"
					Color_TitleTextDisplay := "Red"
					Color_TextDisplay      := "X"
					GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
					; -------------------------------------------
				} ; if (CurrentFocus != "ListBox1")
				; -------------------------------------------
			} ; if (Value_Button_Accept != "Update Record")
			; -------------------------------------------
		} ; if (Array_CurrentRecord != "")
		; -------------------------------------------
	} ; if (RecordHasChanged == 1) ; Record Has Changed
	; -------------------------------------------
	else ; Record Has NOT Changed
	{
		; -------------------------------------------
		if (Array_CurrentRecord != "") ; Array_CurrentRecord is NOT Empty
		{
			; -------------------------------------------
			GuiControlGet, Value_Button_Accept, Tracker:, Button_Accept
			; -------------------------------------------
			if (Value_Button_Accept != "Delete Record") ; EditFeildCheck
			{
				; -------------------------------------------
				ControlGetFocus, CurrentFocus, A
				if (CurrentFocus != "ListBox1")
				{
					; -------------------------------------------
					Gui, Tracker:Color, edbaba ; Red Color
					; -------------------------------------------
					;
					; -------------------------------------------
					GuiControl, Tracker:, Button_Accept, Delete Record
					GuiControl, Tracker:MoveDraw, %Button_Accept%
					GuiControl, Tracker:Show, Button_Accept
					; -------------------------------------------
					;
					; -------------------------------------------
					Value_TitleTextDisplay := "Existing Record"
					Value_TextDisplay      := "X"
					Color_TitleTextDisplay := "Green"
					Color_TextDisplay      := "X"
					GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
					; -------------------------------------------
				} ; if (CurrentFocus != "ListBox1")
				; -------------------------------------------
			} ; if (Value_Button_Accept != "Delete Record") ; EditFeildCheck
			; -------------------------------------------
		} ; if (Array_CurrentRecord != "") ; Array_CurrentRecord is NOT Empty
		; -------------------------------------------
		else ; Array_CurrentRecord is Empty
		{
			; -------------------------------------------
			GuiControlGet, Show_Button_Accept, Tracker:Visible , Button_Accept
			; -------------------------------------------
			if (Show_Button_Accept == 1)
			{
				; -------------------------------------------
				Gui, Tracker:Color, e7d8fe ; Purple Color
				; -------------------------------------------
			} ; if (Show_Button_Accept == 1)
			; -------------------------------------------
			;
			; -------------------------------------------
			GuiControl, Tracker:, Button_Accept,
			GuiControl, Tracker:Hide, Button_Accept
			; -------------------------------------------
		} ; else ; Array_CurrentRecord is Empty
		; -------------------------------------------
	} ; else ; Record Has NOT Changed
	; -------------------------------------------
	;
	; -------------------------------------------
	SelectCategoryRadio("")
	; -------------------------------------------
	GuiControlGet, OnOff_ChangePassword, Tracker:, Radio_ExistingRecord
	; -------------------------------------------
	if (OnOff_ChangePassword == 0)
	{
		; -------------------------------------------
		Value_TitleTextDisplay := "New Record"
		Value_TextDisplay      := ""
		Color_TitleTextDisplay := "Green"
		Color_TextDisplay      := "X"
		GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
		; -------------------------------------------
	} ; if (OnOff_ChangePassword == 0)
	; -------------------------------------------
	;
	; -------------------------------------------
	BlockInput, Off
	BlockInput, MouseMoveOff
	; -------------------------------------------
}
return
; -------------------------------------------
Label_S_CatProgram:
{
	; -------------------------------------------
	BlockInput, On
	BlockInput, MouseMove
	; -------------------------------------------
	;
	; -------------------------------------------
	Array_CurrentRecord := ""
	; -------------------------------------------
	EditFeildCheck("", Array_CurrentRecord) ; CheckThisEdit = Edit_ObjectName > (0) Empty Feild -OR- (ThisEditValue)
	; -------------------------------------------
	;
	; -------------------------------------------
	SelectCategoryRadio("Radio_CatProgram")
	; -------------------------------------------
	GuiControlGet, OnOff_ChangePassword, Tracker:, Radio_ExistingRecord
	; -------------------------------------------
	if (OnOff_ChangePassword == 1)
	{
		; -------------------------------------------
		Value_TitleTextDisplay := "Loading Records"
		Value_TextDisplay      := ""
		Color_TitleTextDisplay := "Blue"
		Color_TextDisplay      := "X"
		GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
		; -------------------------------------------
		;
		; -------------------------------------------
		ListBox_Search_Clear := "|"
		GuiControl, Tracker:, ListBox_Search, %ListBox_Search_Clear%
		; -------------------------------------------
		Array_Returned := CategorySearch(ArrayAllRecords) ; > [ListBox_Search_List, Array_SearchList]
		ListBox_Search_List := Array_Returned.1
		Array_SearchList := Array_Returned.2
		; -------------------------------------------
		GuiControl, Tracker:, ListBox_Search, %ListBox_Search_List%
		; -------------------------------------------
		;
		; -------------------------------------------
		Value_TitleTextDisplay := "Select Record"
		Value_TextDisplay      := ""
		Color_TitleTextDisplay := "Blue"
		Color_TextDisplay      := "X"
		GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
		; -------------------------------------------
	} ; if (OnOff_ChangePassword == 1)
	; -------------------------------------------
	;
	; -------------------------------------------
	BlockInput, Off
	BlockInput, MouseMoveOff
	; -------------------------------------------
}
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Label_CatSocial:
{
	; -------------------------------------------
	BlockInput, On
	BlockInput, MouseMove
	; -------------------------------------------		
	;
	; -------------------------------------------
	RecordHasChanged := HasRecordChanged(Array_CurrentRecord) ; > 0 -OR- 1
	; -------------------------------------------
	if (RecordHasChanged == 1) ; Record Has Changed
	{
		; -------------------------------------------
		if (Array_CurrentRecord != "")
		{
			; -------------------------------------------
			GuiControlGet, Value_Button_Accept, Tracker:, Button_Accept
			; -------------------------------------------
			if (Value_Button_Accept != "Update Record")
			{
				; -------------------------------------------
				ControlGetFocus, CurrentFocus, A
				if (CurrentFocus != "ListBox1")
				{
					; -------------------------------------------
					Gui, Tracker:Color, eceba9 ; Yellow Color
					; -------------------------------------------
					;
					; -------------------------------------------
					GuiControl, Tracker:, Button_Accept, Update Record
					GuiControl, Tracker:MoveDraw, %Button_Accept%
					GuiControl, Tracker:Show, Button_Accept
					; -------------------------------------------
					;
					; -------------------------------------------
					Value_TitleTextDisplay := "Changing Record"
					Value_TextDisplay      := "X"
					Color_TitleTextDisplay := "Red"
					Color_TextDisplay      := "X"
					GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
					; -------------------------------------------
				} ; if (CurrentFocus != "ListBox1")
				; -------------------------------------------
			} ; if (Value_Button_Accept != "Update Record")
			; -------------------------------------------
		} ; if (Array_CurrentRecord != "")
		; -------------------------------------------
	} ; if (RecordHasChanged == 1) ; Record Has Changed
	; -------------------------------------------
	else ; Record Has NOT Changed
	{
		; -------------------------------------------
		if (Array_CurrentRecord != "") ; Array_CurrentRecord is NOT Empty
		{
			; -------------------------------------------
			GuiControlGet, Value_Button_Accept, Tracker:, Button_Accept
			; -------------------------------------------
			if (Value_Button_Accept != "Delete Record") ; EditFeildCheck
			{
				; -------------------------------------------
				ControlGetFocus, CurrentFocus, A
				if (CurrentFocus != "ListBox1")
				{
					; -------------------------------------------
					Gui, Tracker:Color, edbaba ; Red Color
					; -------------------------------------------
					;
					; -------------------------------------------
					GuiControl, Tracker:, Button_Accept, Delete Record
					GuiControl, Tracker:MoveDraw, %Button_Accept%
					GuiControl, Tracker:Show, Button_Accept
					; -------------------------------------------
					;
					; -------------------------------------------
					Value_TitleTextDisplay := "Existing Record"
					Value_TextDisplay      := "X"
					Color_TitleTextDisplay := "Green"
					Color_TextDisplay      := "X"
					GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
					; -------------------------------------------
				} ; if (CurrentFocus != "ListBox1")
				; -------------------------------------------
			} ; if (Value_Button_Accept != "Delete Record") ; EditFeildCheck
			; -------------------------------------------
		} ; if (Array_CurrentRecord != "") ; Array_CurrentRecord is NOT Empty
		; -------------------------------------------
		else ; Array_CurrentRecord is Empty
		{
			; -------------------------------------------
			GuiControlGet, Show_Button_Accept, Tracker:Visible , Button_Accept
			; -------------------------------------------
			if (Show_Button_Accept == 1)
			{
				; -------------------------------------------
				Gui, Tracker:Color, e7d8fe ; Purple Color
				; -------------------------------------------
			} ; if (Show_Button_Accept == 1)
			; -------------------------------------------
			;
			; -------------------------------------------
			GuiControl, Tracker:, Button_Accept,
			GuiControl, Tracker:Hide, Button_Accept
			; -------------------------------------------
		} ; else ; Array_CurrentRecord is Empty
		; -------------------------------------------
	} ; else ; Record Has NOT Changed
	; -------------------------------------------
	;
	; -------------------------------------------
	SelectCategoryRadio("")
	; -------------------------------------------
	GuiControlGet, OnOff_ChangePassword, Tracker:, Radio_ExistingRecord
	; -------------------------------------------
	if (OnOff_ChangePassword == 0)
	{
		; -------------------------------------------
		Value_TitleTextDisplay := "New Record"
		Value_TextDisplay      := ""
		Color_TitleTextDisplay := "Green"
		Color_TextDisplay      := "X"
		GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
		; -------------------------------------------
	} ; if (OnOff_ChangePassword == 0)
	; -------------------------------------------
	;
	; -------------------------------------------
	BlockInput, Off
	BlockInput, MouseMoveOff
	; -------------------------------------------
}
return
; -------------------------------------------
Label_S_CatSocial:
{
	; -------------------------------------------
	BlockInput, On
	BlockInput, MouseMove
	; -------------------------------------------
	;
	; -------------------------------------------
	Array_CurrentRecord := ""
	; -------------------------------------------
	EditFeildCheck("", Array_CurrentRecord) ; CheckThisEdit = Edit_ObjectName > (0) Empty Feild -OR- (ThisEditValue)
	; -------------------------------------------
	;
	; -------------------------------------------
	SelectCategoryRadio("Radio_CatSocial")
	; -------------------------------------------
	GuiControlGet, OnOff_ChangePassword, Tracker:, Radio_ExistingRecord
	; -------------------------------------------
	if (OnOff_ChangePassword == 1)
	{
		; -------------------------------------------
		Value_TitleTextDisplay := "Loading Records"
		Value_TextDisplay      := ""
		Color_TitleTextDisplay := "Blue"
		Color_TextDisplay      := "X"
		GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
		; -------------------------------------------
		;
		; -------------------------------------------
		ListBox_Search_Clear := "|"
		GuiControl, Tracker:, ListBox_Search, %ListBox_Search_Clear%
		; -------------------------------------------
		Array_Returned := CategorySearch(ArrayAllRecords) ; > [ListBox_Search_List, Array_SearchList]
		ListBox_Search_List := Array_Returned.1
		Array_SearchList := Array_Returned.2
		; -------------------------------------------
		GuiControl, Tracker:, ListBox_Search, %ListBox_Search_List%
		; -------------------------------------------
		;
		; -------------------------------------------
		Value_TitleTextDisplay := "Select Record"
		Value_TextDisplay      := ""
		Color_TitleTextDisplay := "Blue"
		Color_TextDisplay      := "X"
		GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
		; -------------------------------------------
	} ; if (OnOff_ChangePassword == 1)
	; -------------------------------------------
	;
	; -------------------------------------------
	BlockInput, Off
	BlockInput, MouseMoveOff
	; -------------------------------------------
}
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Label_CatWebHosting:
{
	; -------------------------------------------
	BlockInput, On
	BlockInput, MouseMove
	; -------------------------------------------		
	;
	; -------------------------------------------
	RecordHasChanged := HasRecordChanged(Array_CurrentRecord) ; > 0 -OR- 1
	; -------------------------------------------
	if (RecordHasChanged == 1) ; Record Has Changed
	{
		; -------------------------------------------
		if (Array_CurrentRecord != "")
		{
			; -------------------------------------------
			GuiControlGet, Value_Button_Accept, Tracker:, Button_Accept
			; -------------------------------------------
			if (Value_Button_Accept != "Update Record")
			{
				; -------------------------------------------
				ControlGetFocus, CurrentFocus, A
				if (CurrentFocus != "ListBox1")
				{
					; -------------------------------------------
					Gui, Tracker:Color, eceba9 ; Yellow Color
					; -------------------------------------------
					;
					; -------------------------------------------
					GuiControl, Tracker:, Button_Accept, Update Record
					GuiControl, Tracker:MoveDraw, %Button_Accept%
					GuiControl, Tracker:Show, Button_Accept
					; -------------------------------------------
					;
					; -------------------------------------------
					Value_TitleTextDisplay := "Changing Record"
					Value_TextDisplay      := "X"
					Color_TitleTextDisplay := "Red"
					Color_TextDisplay      := "X"
					GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
					; -------------------------------------------
				} ; if (CurrentFocus != "ListBox1")
				; -------------------------------------------
			} ; if (Value_Button_Accept != "Update Record")
			; -------------------------------------------
		} ; if (Array_CurrentRecord != "")
		; -------------------------------------------
	} ; if (RecordHasChanged == 1) ; Record Has Changed
	; -------------------------------------------
	else ; Record Has NOT Changed
	{
		; -------------------------------------------
		if (Array_CurrentRecord != "") ; Array_CurrentRecord is NOT Empty
		{
			; -------------------------------------------
			GuiControlGet, Value_Button_Accept, Tracker:, Button_Accept
			; -------------------------------------------
			if (Value_Button_Accept != "Delete Record") ; EditFeildCheck
			{
				; -------------------------------------------
				ControlGetFocus, CurrentFocus, A
				if (CurrentFocus != "ListBox1")
				{
					; -------------------------------------------
					Gui, Tracker:Color, edbaba ; Red Color
					; -------------------------------------------
					;
					; -------------------------------------------
					GuiControl, Tracker:, Button_Accept, Delete Record
					GuiControl, Tracker:MoveDraw, %Button_Accept%
					GuiControl, Tracker:Show, Button_Accept
					; -------------------------------------------
					;
					; -------------------------------------------
					Value_TitleTextDisplay := "Existing Record"
					Value_TextDisplay      := "X"
					Color_TitleTextDisplay := "Green"
					Color_TextDisplay      := "X"
					GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
					; -------------------------------------------
				} ; if (CurrentFocus != "ListBox1")
				; -------------------------------------------
			} ; if (Value_Button_Accept != "Delete Record") ; EditFeildCheck
			; -------------------------------------------
		} ; if (Array_CurrentRecord != "") ; Array_CurrentRecord is NOT Empty
		; -------------------------------------------
		else ; Array_CurrentRecord is Empty
		{
			; -------------------------------------------
			GuiControlGet, Show_Button_Accept, Tracker:Visible , Button_Accept
			; -------------------------------------------
			if (Show_Button_Accept == 1)
			{
				; -------------------------------------------
				Gui, Tracker:Color, e7d8fe ; Purple Color
				; -------------------------------------------
			} ; if (Show_Button_Accept == 1)
			; -------------------------------------------
			;
			; -------------------------------------------
			GuiControl, Tracker:, Button_Accept,
			GuiControl, Tracker:Hide, Button_Accept
			; -------------------------------------------
		} ; else ; Array_CurrentRecord is Empty
		; -------------------------------------------
	} ; else ; Record Has NOT Changed
	; -------------------------------------------
	;
	; -------------------------------------------
	SelectCategoryRadio("")
	; -------------------------------------------
	GuiControlGet, OnOff_ChangePassword, Tracker:, Radio_ExistingRecord
	; -------------------------------------------
	if (OnOff_ChangePassword == 0)
	{
		; -------------------------------------------
		Value_TitleTextDisplay := "New Record"
		Value_TextDisplay      := ""
		Color_TitleTextDisplay := "Green"
		Color_TextDisplay      := "X"
		GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
		; -------------------------------------------
	} ; if (OnOff_ChangePassword == 0)
	; -------------------------------------------
	;
	; -------------------------------------------
	BlockInput, Off
	BlockInput, MouseMoveOff
	; -------------------------------------------
}
return
; -------------------------------------------
Label_S_CatWebHosting:
{
	; -------------------------------------------
	BlockInput, On
	BlockInput, MouseMove
	; -------------------------------------------
	;
	; -------------------------------------------
	Array_CurrentRecord := ""
	; -------------------------------------------
	EditFeildCheck("", Array_CurrentRecord) ; CheckThisEdit = Edit_ObjectName > (0) Empty Feild -OR- (ThisEditValue)
	; -------------------------------------------
	;
	; -------------------------------------------
	SelectCategoryRadio("Radio_CatWebHosting")
	; -------------------------------------------
	GuiControlGet, OnOff_ChangePassword, Tracker:, Radio_ExistingRecord
	; -------------------------------------------
	if (OnOff_ChangePassword == 1)
	{
		; -------------------------------------------
		Value_TitleTextDisplay := "Loading Records"
		Value_TextDisplay      := ""
		Color_TitleTextDisplay := "Blue"
		Color_TextDisplay      := "X"
		GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
		; -------------------------------------------
		;
		; -------------------------------------------
		ListBox_Search_Clear := "|"
		GuiControl, Tracker:, ListBox_Search, %ListBox_Search_Clear%
		; -------------------------------------------
		Array_Returned := CategorySearch(ArrayAllRecords) ; > [ListBox_Search_List, Array_SearchList]
		ListBox_Search_List := Array_Returned.1
		Array_SearchList := Array_Returned.2
		; -------------------------------------------
		GuiControl, Tracker:, ListBox_Search, %ListBox_Search_List%
		; -------------------------------------------
		;
		; -------------------------------------------
		Value_TitleTextDisplay := "Select Record"
		Value_TextDisplay      := ""
		Color_TitleTextDisplay := "Blue"
		Color_TextDisplay      := "X"
		GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
		; -------------------------------------------
	} ; if (OnOff_ChangePassword == 1)
	; -------------------------------------------
	;
	; -------------------------------------------
	BlockInput, Off
	BlockInput, MouseMoveOff
	; -------------------------------------------
}
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Label_CatWebTempletes:
{
	; -------------------------------------------
	BlockInput, On
	BlockInput, MouseMove
	; -------------------------------------------		
	;
	; -------------------------------------------
	RecordHasChanged := HasRecordChanged(Array_CurrentRecord) ; > 0 -OR- 1
	; -------------------------------------------
	if (RecordHasChanged == 1) ; Record Has Changed
	{
		; -------------------------------------------
		if (Array_CurrentRecord != "")
		{
			; -------------------------------------------
			GuiControlGet, Value_Button_Accept, Tracker:, Button_Accept
			; -------------------------------------------
			if (Value_Button_Accept != "Update Record")
			{
				; -------------------------------------------
				ControlGetFocus, CurrentFocus, A
				if (CurrentFocus != "ListBox1")
				{
					; -------------------------------------------
					Gui, Tracker:Color, eceba9 ; Yellow Color
					; -------------------------------------------
					;
					; -------------------------------------------
					GuiControl, Tracker:, Button_Accept, Update Record
					GuiControl, Tracker:MoveDraw, %Button_Accept%
					GuiControl, Tracker:Show, Button_Accept
					; -------------------------------------------
					;
					; -------------------------------------------
					Value_TitleTextDisplay := "Changing Record"
					Value_TextDisplay      := "X"
					Color_TitleTextDisplay := "Red"
					Color_TextDisplay      := "X"
					GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
					; -------------------------------------------
				} ; if (CurrentFocus != "ListBox1")
				; -------------------------------------------
			} ; if (Value_Button_Accept != "Update Record")
			; -------------------------------------------
		} ; if (Array_CurrentRecord != "")
		; -------------------------------------------
	} ; if (RecordHasChanged == 1) ; Record Has Changed
	; -------------------------------------------
	else ; Record Has NOT Changed
	{
		; -------------------------------------------
		if (Array_CurrentRecord != "") ; Array_CurrentRecord is NOT Empty
		{
			; -------------------------------------------
			GuiControlGet, Value_Button_Accept, Tracker:, Button_Accept
			; -------------------------------------------
			if (Value_Button_Accept != "Delete Record") ; EditFeildCheck
			{
				; -------------------------------------------
				ControlGetFocus, CurrentFocus, A
				if (CurrentFocus != "ListBox1")
				{
					; -------------------------------------------
					Gui, Tracker:Color, edbaba ; Red Color
					; -------------------------------------------
					;
					; -------------------------------------------
					GuiControl, Tracker:, Button_Accept, Delete Record
					GuiControl, Tracker:MoveDraw, %Button_Accept%
					GuiControl, Tracker:Show, Button_Accept
					; -------------------------------------------
					;
					; -------------------------------------------
					Value_TitleTextDisplay := "Existing Record"
					Value_TextDisplay      := "X"
					Color_TitleTextDisplay := "Green"
					Color_TextDisplay      := "X"
					GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
					; -------------------------------------------
				} ; if (CurrentFocus != "ListBox1")
				; -------------------------------------------
			} ; if (Value_Button_Accept != "Delete Record") ; EditFeildCheck
			; -------------------------------------------
		} ; if (Array_CurrentRecord != "") ; Array_CurrentRecord is NOT Empty
		; -------------------------------------------
		else ; Array_CurrentRecord is Empty
		{
			; -------------------------------------------
			GuiControlGet, Show_Button_Accept, Tracker:Visible , Button_Accept
			; -------------------------------------------
			if (Show_Button_Accept == 1)
			{
				; -------------------------------------------
				Gui, Tracker:Color, e7d8fe ; Purple Color
				; -------------------------------------------
			} ; if (Show_Button_Accept == 1)
			; -------------------------------------------
			;
			; -------------------------------------------
			GuiControl, Tracker:, Button_Accept,
			GuiControl, Tracker:Hide, Button_Accept
			; -------------------------------------------
		} ; else ; Array_CurrentRecord is Empty
		; -------------------------------------------
	} ; else ; Record Has NOT Changed
	; -------------------------------------------
	;
	; -------------------------------------------
	SelectCategoryRadio("")
	; -------------------------------------------
	GuiControlGet, OnOff_ChangePassword, Tracker:, Radio_ExistingRecord
	; -------------------------------------------
	if (OnOff_ChangePassword == 0)
	{
		; -------------------------------------------
		Value_TitleTextDisplay := "New Record"
		Value_TextDisplay      := ""
		Color_TitleTextDisplay := "Green"
		Color_TextDisplay      := "X"
		GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
		; -------------------------------------------
	} ; if (OnOff_ChangePassword == 0)
	; -------------------------------------------
	;
	; -------------------------------------------
	BlockInput, Off
	BlockInput, MouseMoveOff
	; -------------------------------------------
}
return
; -------------------------------------------
Label_S_CatWebTempletes:
{
	; -------------------------------------------
	BlockInput, On
	BlockInput, MouseMove
	; -------------------------------------------
	;
	; -------------------------------------------
	Array_CurrentRecord := ""
	; -------------------------------------------
	EditFeildCheck("", Array_CurrentRecord) ; CheckThisEdit = Edit_ObjectName > (0) Empty Feild -OR- (ThisEditValue)
	; -------------------------------------------
	;
	; -------------------------------------------
	SelectCategoryRadio("Radio_CatWebTempletes")
	; -------------------------------------------
	GuiControlGet, OnOff_ChangePassword, Tracker:, Radio_ExistingRecord
	; -------------------------------------------
	if (OnOff_ChangePassword == 1)
	{
		; -------------------------------------------
		Value_TitleTextDisplay := "Loading Records"
		Value_TextDisplay      := ""
		Color_TitleTextDisplay := "Blue"
		Color_TextDisplay      := "X"
		GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
		; -------------------------------------------
		;
		; -------------------------------------------
		ListBox_Search_Clear := "|"
		GuiControl, Tracker:, ListBox_Search, %ListBox_Search_Clear%
		; -------------------------------------------
		Array_Returned := CategorySearch(ArrayAllRecords) ; > [ListBox_Search_List, Array_SearchList]
		ListBox_Search_List := Array_Returned.1
		Array_SearchList := Array_Returned.2
		; -------------------------------------------
		GuiControl, Tracker:, ListBox_Search, %ListBox_Search_List%
		; -------------------------------------------
		;
		; -------------------------------------------
		Value_TitleTextDisplay := "Select Record"
		Value_TextDisplay      := ""
		Color_TitleTextDisplay := "Blue"
		Color_TextDisplay      := "X"
		GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
		; -------------------------------------------
	} ; if (OnOff_ChangePassword == 1)
	; -------------------------------------------
	;
	; -------------------------------------------
	BlockInput, Off
	BlockInput, MouseMoveOff
	; -------------------------------------------
}
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Label_CatWebSite:
{
	; -------------------------------------------
	BlockInput, On
	BlockInput, MouseMove
	; -------------------------------------------		
	;
	; -------------------------------------------
	RecordHasChanged := HasRecordChanged(Array_CurrentRecord) ; > 0 -OR- 1
	; -------------------------------------------
	if (RecordHasChanged == 1) ; Record Has Changed
	{
		; -------------------------------------------
		if (Array_CurrentRecord != "")
		{
			; -------------------------------------------
			GuiControlGet, Value_Button_Accept, Tracker:, Button_Accept
			; -------------------------------------------
			if (Value_Button_Accept != "Update Record")
			{
				; -------------------------------------------
				ControlGetFocus, CurrentFocus, A
				if (CurrentFocus != "ListBox1")
				{
					; -------------------------------------------
					Gui, Tracker:Color, eceba9 ; Yellow Color
					; -------------------------------------------
					;
					; -------------------------------------------
					GuiControl, Tracker:, Button_Accept, Update Record
					GuiControl, Tracker:MoveDraw, %Button_Accept%
					GuiControl, Tracker:Show, Button_Accept
					; -------------------------------------------
					;
					; -------------------------------------------
					Value_TitleTextDisplay := "Changing Record"
					Value_TextDisplay      := "X"
					Color_TitleTextDisplay := "Red"
					Color_TextDisplay      := "X"
					GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
					; -------------------------------------------
				} ; if (CurrentFocus != "ListBox1")
				; -------------------------------------------
			} ; if (Value_Button_Accept != "Update Record")
			; -------------------------------------------
		} ; if (Array_CurrentRecord != "")
		; -------------------------------------------
	} ; if (RecordHasChanged == 1) ; Record Has Changed
	; -------------------------------------------
	else ; Record Has NOT Changed
	{
		; -------------------------------------------
		if (Array_CurrentRecord != "") ; Array_CurrentRecord is NOT Empty
		{
			; -------------------------------------------
			GuiControlGet, Value_Button_Accept, Tracker:, Button_Accept
			; -------------------------------------------
			if (Value_Button_Accept != "Delete Record") ; EditFeildCheck
			{
				; -------------------------------------------
				ControlGetFocus, CurrentFocus, A
				if (CurrentFocus != "ListBox1")
				{
					; -------------------------------------------
					Gui, Tracker:Color, edbaba ; Red Color
					; -------------------------------------------
					;
					; -------------------------------------------
					GuiControl, Tracker:, Button_Accept, Delete Record
					GuiControl, Tracker:MoveDraw, %Button_Accept%
					GuiControl, Tracker:Show, Button_Accept
					; -------------------------------------------
					;
					; -------------------------------------------
					Value_TitleTextDisplay := "Existing Record"
					Value_TextDisplay      := "X"
					Color_TitleTextDisplay := "Green"
					Color_TextDisplay      := "X"
					GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
					; -------------------------------------------
				} ; if (CurrentFocus != "ListBox1")
				; -------------------------------------------
			} ; if (Value_Button_Accept != "Delete Record") ; EditFeildCheck
			; -------------------------------------------
		} ; if (Array_CurrentRecord != "") ; Array_CurrentRecord is NOT Empty
		; -------------------------------------------
		else ; Array_CurrentRecord is Empty
		{
			; -------------------------------------------
			GuiControlGet, Show_Button_Accept, Tracker:Visible , Button_Accept
			; -------------------------------------------
			if (Show_Button_Accept == 1)
			{
				; -------------------------------------------
				Gui, Tracker:Color, e7d8fe ; Purple Color
				; -------------------------------------------
			} ; if (Show_Button_Accept == 1)
			; -------------------------------------------
			;
			; -------------------------------------------
			GuiControl, Tracker:, Button_Accept,
			GuiControl, Tracker:Hide, Button_Accept
			; -------------------------------------------
		} ; else ; Array_CurrentRecord is Empty
		; -------------------------------------------
	} ; else ; Record Has NOT Changed
	; -------------------------------------------
	;
	; -------------------------------------------
	SelectCategoryRadio("")
	; -------------------------------------------
	GuiControlGet, OnOff_ChangePassword, Tracker:, Radio_ExistingRecord
	; -------------------------------------------
	if (OnOff_ChangePassword == 0)
	{
		; -------------------------------------------
		Value_TitleTextDisplay := "New Record"
		Value_TextDisplay      := ""
		Color_TitleTextDisplay := "Green"
		Color_TextDisplay      := "X"
		GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
		; -------------------------------------------
	} ; if (OnOff_ChangePassword == 0)
	; -------------------------------------------
	;
	; -------------------------------------------
	BlockInput, Off
	BlockInput, MouseMoveOff
	; -------------------------------------------
}
return
; -------------------------------------------
Label_S_CatWebSite:
{
	; -------------------------------------------
	BlockInput, On
	BlockInput, MouseMove
	; -------------------------------------------
	;
	; -------------------------------------------
	Array_CurrentRecord := ""
	; -------------------------------------------
	EditFeildCheck("", Array_CurrentRecord) ; CheckThisEdit = Edit_ObjectName > (0) Empty Feild -OR- (ThisEditValue)
	; -------------------------------------------
	;
	; -------------------------------------------
	SelectCategoryRadio("Radio_CatWebSite")
	; -------------------------------------------
	GuiControlGet, OnOff_ChangePassword, Tracker:, Radio_ExistingRecord
	; -------------------------------------------
	if (OnOff_ChangePassword == 1)
	{
		; -------------------------------------------
		Value_TitleTextDisplay := "Loading Records"
		Value_TextDisplay      := ""
		Color_TitleTextDisplay := "Blue"
		Color_TextDisplay      := "X"
		GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
		; -------------------------------------------
		;
		; -------------------------------------------
		ListBox_Search_Clear := "|"
		GuiControl, Tracker:, ListBox_Search, %ListBox_Search_Clear%
		; -------------------------------------------
		Array_Returned := CategorySearch(ArrayAllRecords) ; > [ListBox_Search_List, Array_SearchList]
		ListBox_Search_List := Array_Returned.1
		Array_SearchList := Array_Returned.2
		; -------------------------------------------
		GuiControl, Tracker:, ListBox_Search, %ListBox_Search_List%
		; -------------------------------------------
		;
		; -------------------------------------------
		Value_TitleTextDisplay := "Select Record"
		Value_TextDisplay      := ""
		Color_TitleTextDisplay := "Blue"
		Color_TextDisplay      := "X"
		GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
		; -------------------------------------------
	} ; if (OnOff_ChangePassword == 1)
	; -------------------------------------------
	;
	; -------------------------------------------
	BlockInput, Off
	BlockInput, MouseMoveOff
	; -------------------------------------------
}
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Label_CatNone:
{
	; -------------------------------------------
	ControlGetFocus, CurrentFocus, A
	if (CurrentFocus != "ListBox1")
	{
		; -------------------------------------------
	  BlockInput, On
	  BlockInput, MouseMove
	  ; -------------------------------------------
	  ;
	  ; -------------------------------------------
	  Array_CurrentRecord := ""
	  ; -------------------------------------------
	  EditFeildCheck("", Array_CurrentRecord) ; CheckThisEdit = Edit_ObjectName > (0) Empty Feild -OR- (ThisEditValue)
	  ; -------------------------------------------
    ;
	  ; -------------------------------------------
	  SelectCategoryRadio("Radio_CatNone")
	  ; -------------------------------------------
	  GuiControlGet, OnOff_ChangePassword, Tracker:, Radio_ExistingRecord
	  ; -------------------------------------------
	  if (OnOff_ChangePassword == 1)
	  {
  		; -------------------------------------------
	    Value_TitleTextDisplay := "Loading Records"
	    Value_TextDisplay      := ""
	    Color_TitleTextDisplay := "Blue"
	    Color_TextDisplay      := "X"
	    GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
		  ; -------------------------------------------
		  ;
		  ; -------------------------------------------
		  ListBox_Search_Clear := "|"
  	  GuiControl, Tracker:, ListBox_Search, %ListBox_Search_Clear%
		  ; -------------------------------------------
	    Array_Returned := CategorySearch(ArrayAllRecords) ; > [ListBox_Search_List, Array_SearchList]
	    ListBox_Search_List := Array_Returned.1
	    Array_SearchList := Array_Returned.2
	    ; -------------------------------------------
  	  GuiControl, Tracker:, ListBox_Search, %ListBox_Search_List%
  	  ; -------------------------------------------
		  ;
		  ; -------------------------------------------
	    Value_TitleTextDisplay := "Select Record"
	    Value_TextDisplay      := ""
	    Color_TitleTextDisplay := "Blue"
	    Color_TextDisplay      := "X"
	    GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
		  ; -------------------------------------------
	  } ; if (OnOff_ChangePassword == 1)
		; -------------------------------------------
	  ;
	  ; -------------------------------------------
	  BlockInput, Off
	  BlockInput, MouseMoveOff
	  ; -------------------------------------------
	} ; if (CurrentFocus != "ListBox1")
	; -------------------------------------------
}
return
; -------------------------------------------
Label_S_CatNone:
{
	; -------------------------------------------
	ControlGetFocus, CurrentFocus, A
	if (CurrentFocus != "ListBox1")
	{
	  ; -------------------------------------------
	  BlockInput, On
	  BlockInput, MouseMove
	  ; -------------------------------------------
	  ;
	  ; -------------------------------------------
	  Array_CurrentRecord := ""
	  ; -------------------------------------------
	  EditFeildCheck("", Array_CurrentRecord) ; CheckThisEdit = Edit_ObjectName > (0) Empty Feild -OR- (ThisEditValue)
	  ; -------------------------------------------
    ;
	  ; -------------------------------------------
	  SelectCategoryRadio("Radio_CatNone")
	  ; -------------------------------------------
	  GuiControlGet, OnOff_ChangePassword, Tracker:, Radio_ExistingRecord
	  ; -------------------------------------------
	  if (OnOff_ChangePassword == 1)
	  {
  		; -------------------------------------------
	    Value_TitleTextDisplay := "Loading Records"
	    Value_TextDisplay      := ""
	    Color_TitleTextDisplay := "Blue"
	    Color_TextDisplay      := "X"
	    GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
		  ; -------------------------------------------
		  ;
		  ; -------------------------------------------
		  ListBox_Search_Clear := "|"
  	  GuiControl, Tracker:, ListBox_Search, %ListBox_Search_Clear%
		  ; -------------------------------------------
	    Array_Returned := CategorySearch(ArrayAllRecords) ; > [ListBox_Search_List, Array_SearchList]
	    ListBox_Search_List := Array_Returned.1
	    Array_SearchList := Array_Returned.2
	    ; -------------------------------------------
  	  GuiControl, Tracker:, ListBox_Search, %ListBox_Search_List%
  	  ; -------------------------------------------
		  ;
		  ; -------------------------------------------
	    Value_TitleTextDisplay := "Select Record"
	    Value_TextDisplay      := ""
	    Color_TitleTextDisplay := "Blue"
	    Color_TextDisplay      := "X"
	    GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
		  ; -------------------------------------------
	  }
	  ;
	  ; -------------------------------------------
	  BlockInput, Off
	  BlockInput, MouseMoveOff
	  ; -------------------------------------------
	} ; if (CurrentFocus != "ListBox1")
	; -------------------------------------------
}
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
;
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Label_Accept:
{
	; -------------------------------------------
	GuiControlGet, Value_Button_Accept, Tracker:, Button_Accept
	; -------------------------------------------
  if (Value_Button_Accept == "Save New Record")
	{
		; -------------------------------------------
		RecordName := ConvertTime("") ; "" > ("2023.07.10.15.12.29") | ("2023.07.10.15.12.29") > "10 Jul, 2023 @ 15:12:29"
		; -------------------------------------------
		FolderCheck := Path_DAT "\Files"
		if !FileExist(FolderCheck)
		{
			FileCreateDir, %FolderCheck%
		}
		; -------------------------------------------
		NewRecordFile := Path_DAT "\Files\" RecordName ".txt"
		; -------------------------------------------
		GuiControlGet, OnOff_CatNone, Tracker:, Radio_CatNone
		if (OnOff_CatNone == 1) ; ***************** ERROR CHECK *****************
		{
			; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
			Msg := Msg "ERROR None Category is Selected`n"
			MsgBox, 0, , %Msg%
			Msg := ""
			; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
		}
		else ; NO Error Continue
		{
			; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
			; Get Category
			; -------------------------------------------
		  Array_Category := ["Radio_CatBrowser", "Radio_CatBuySell", "Radio_CatContact", "Radio_CatDownLoad", "Radio_CatEmail", "Radio_CatForum", "Radio_CatGame", "Radio_CatInternet", "Radio_CatMailer", "Radio_CatMoney", "Radio_CatProgram", "Radio_CatSocial", "Radio_CatWebHosting", "Radio_CatWebTempletes", "Radio_CatWebSite"]
			; -------------------------------------------
			for Index, ThisCategory in Array_Category
			{
				; -------------------------------------------
				GuiControlGet, OnOff_ThisCategory, Tracker:, %ThisCategory%
				; -------------------------------------------
				if (OnOff_ThisCategory == 1)
				{
					; -------------------------------------------
  			  if (ThisCategory == "Radio_CatBrowser")
			    {
    			  Value_Category := "browser"
			    }
			    else if (ThisCategory == "Radio_CatBuySell")
			    {
    			  Value_Category := "buysell"
			    }
			    else if (ThisCategory == "Radio_CatContact")
			    {
    			  Value_Category := "contact"
			    }
			    else if (ThisCategory == "Radio_CatDownLoad")
			    {
    			  Value_Category := "downLoad"
			    }
			    else if (ThisCategory == "Radio_CatEmail")
			    {
    			  Value_Category := "email"
			    }
			    else if (ThisCategory == "Radio_CatForum")
			    {
    			  Value_Category := "forum"
			    }
			    else if (ThisCategory == "Radio_CatGame")
			    {
      		  Value_Category := "game"
			    }
			    else if (ThisCategory == "Radio_CatInternet")
			    {
    		    Value_Category := "internet"
			    }
			    else if (ThisCategory == "Radio_CatMailer")
			    {
    			  Value_Category := "mailer"
			    }
			    else if (ThisCategory == "Radio_CatMoney")
			    {
    			  Value_Category := "money"
			    }
			    else if (ThisCategory == "Radio_CatProgram")
			    {
    			  Value_Category := "program"
			    }
			    else if (ThisCategory == "Radio_CatSocial")
			    {
    			  Value_Category := "social"
			    }
			    else if (ThisCategory == "Radio_CatWebHosting")
			    {
    			  Value_Category := "webhosting"
			    }
			    else if (ThisCategory == "Radio_CatWebTempletes")
			    {
    			  Value_Category := "webtempletes"
			    }
			    else if (ThisCategory == "Radio_CatWebSite")
			    {
    			  Value_Category := "website"
			    }
					; -------------------------------------------
					if (StrLen(Value_Category) == 0) ; ***************** ERROR CHECK *****************
					{
						; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
						Msg := Msg "ERROR No Category is Selected`n"
						MsgBox, 0, , %Msg%
						Msg := ""
						; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
					}
					; -------------------------------------------
					break
					; -------------------------------------------
				} ; if (OnOff_ThisCategory == 1)
				; -------------------------------------------
			} ; for Index, ThisCategory in Array_Category
			; -------------------------------------------
			; Get Category
			; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
			;
			; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
			; Get Edit Feild Values
			; -------------------------------------------
			GuiControlGet, Value_RecordName, Tracker:, Edit_RecordName
			Value_RecordName := RemoveTabSpace(Value_RecordName) ; > ThisText (With Out Leading or Ending, Spaces or Tabs)
			; -------------------------------------------
			if (StrLen(Value_RecordName) == 0 or Value_RecordName == "") ; ***************** ERROR CHECK *****************
			{
				; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
			  Msg := Msg "ERROR Value_RecordName is Empty`n"
			  MsgBox, 0, , %Msg%
			  Msg := ""
				; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
			}
			; -------------------------------------------
			else ; NO Error (Value_RecordName) is NOT Empty
			{
			  ; -------------------------------------------
			  GuiControlGet, Value_SubName, Tracker:, Edit_SubName
			  Value_SubName := RemoveTabSpace(Value_SubName) ; > ThisText (With Out Leading or Ending, Spaces or Tabs)
			  ; -------------------------------------------
			  GuiControlGet, Value_Password, Tracker:, Edit_Password
			  Value_Password := StrReplace(Value_Password, A_Space, "")
			  Value_Password := StrReplace(Value_Password, A_Tab, "")
			  ; -------------------------------------------
			  GuiControlGet, Value_FirstEmail, Tracker:, Edit_FirstEmail
			  Value_FirstEmail := RemoveTabSpace(Value_FirstEmail) ; > ThisText (With Out Leading or Ending, Spaces or Tabs)
			  ; -------------------------------------------
			  GuiControlGet, Value_SecondEmail, Tracker:, Edit_SecondEmail
			  Value_SecondEmail := RemoveTabSpace(Value_SecondEmail) ; > ThisText (With Out Leading or Ending, Spaces or Tabs)
			  ; -------------------------------------------
			  GuiControlGet, Value_LoginName, Tracker:, Edit_LoginName
			  Value_LoginName := RemoveTabSpace(Value_LoginName) ; > ThisText (With Out Leading or Ending, Spaces or Tabs)
			  ; -------------------------------------------
			  GuiControlGet, Value_BusinessName, Tracker:, Edit_BusinessName
			  Value_BusinessName := RemoveTabSpace(Value_BusinessName) ; > ThisText (With Out Leading or Ending, Spaces or Tabs)
			  ; -------------------------------------------
			  GuiControlGet, Value_FirstName, Tracker:, Edit_FirstName
			  Value_FirstName := RemoveTabSpace(Value_FirstName) ; > ThisText (With Out Leading or Ending, Spaces or Tabs)
			  ; -------------------------------------------
			  GuiControlGet, Value_LastName, Tracker:, Edit_LastName
			  Value_LastName := RemoveTabSpace(Value_LastName) ; > ThisText (With Out Leading or Ending, Spaces or Tabs)
			  ; -------------------------------------------
			  GuiControlGet, Value_Phone, Tracker:, Edit_Phone
			  Value_Phone := RemoveTabSpace(Value_Phone) ; > ThisText (With Out Leading or Ending, Spaces or Tabs)
			  ; -------------------------------------------
			  GuiControlGet, Value_Country, Tracker:, Edit_Country
			  Value_Country := RemoveTabSpace(Value_Country) ; > ThisText (With Out Leading or Ending, Spaces or Tabs)
			  ; -------------------------------------------
			  GuiControlGet, Value_City, Tracker:, Edit_City
			  Value_City := RemoveTabSpace(Value_City) ; > ThisText (With Out Leading or Ending, Spaces or Tabs)
			  ; -------------------------------------------
			  GuiControlGet, Value_Street, Tracker:, Edit_Street
			  Value_Street := RemoveTabSpace(Value_Street) ; > ThisText (With Out Leading or Ending, Spaces or Tabs)
			  ; -------------------------------------------
			  GuiControlGet, Value_ZipCode, Tracker:, Edit_ZipCode
			  Value_ZipCode := RemoveTabSpace(Value_ZipCode) ; > ThisText (With Out Leading or Ending, Spaces or Tabs)
			  ; -------------------------------------------
			  GuiControlGet, Value_Notes, Tracker:, Edit_Notes
			  ; -------------------------------------------
			  ; Get Edit Feild Values
			  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
			  ;
			  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
			  ; (if) Value is Blank Add "<EMPTY>"
    		; -------------------------------------------
        Array_EditValue := ["Value_SubName", "Value_Password", "Value_FirstEmail", "Value_SecondEmail", "Value_LoginName", "Value_BusinessName", "Value_FirstName", "Value_LastName", "Value_Phone", "Value_Country", "Value_City", "Value_Street", "Value_ZipCode", "Value_Notes"]
        for Index, CheckValue in Array_EditValue
        {
      	  if (%CheckValue% == "")
  	      {
      		  %CheckValue% := "<EMPTY>"
	        }
        }
			  ; -------------------------------------------
		    ; (if) Value is Blank Add "<EMPTY>"
			  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
			  ;
			  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
			  ; Write Record
			  ; -------------------------------------------
			  FileAppend, (_PopUpMenu_Tracker_)_Category`n, %NewRecordFile%, UTF-8
			  FileAppend, %Value_Category%`n, %NewRecordFile%, UTF-8
  			; -------------------------------------------
			  FileAppend, (_PopUpMenu_Tracker_)_RecordName`n, %NewRecordFile%, UTF-8
			  FileAppend, %Value_RecordName%`n, %NewRecordFile%, UTF-8
  			; -------------------------------------------
			  FileAppend, (_PopUpMenu_Tracker_)_SubName`n, %NewRecordFile%, UTF-8
			  FileAppend, %Value_SubName%`n, %NewRecordFile%, UTF-8
  			; -------------------------------------------
			  FileAppend, (_PopUpMenu_Tracker_)_Password`n, %NewRecordFile%, UTF-8
			  FileAppend, %Value_Password%`n, %NewRecordFile%, UTF-8
  			; -------------------------------------------
			  FileAppend, (_PopUpMenu_Tracker_)_FirstEmail`n, %NewRecordFile%, UTF-8
			  FileAppend, %Value_FirstEmail%`n, %NewRecordFile%, UTF-8
  			; -------------------------------------------
			  FileAppend, (_PopUpMenu_Tracker_)_SecondEmail`n, %NewRecordFile%, UTF-8
			  FileAppend, %Value_SecondEmail%`n, %NewRecordFile%, UTF-8
  			; -------------------------------------------
			  FileAppend, (_PopUpMenu_Tracker_)_LoginName`n, %NewRecordFile%, UTF-8
			  FileAppend, %Value_LoginName%`n, %NewRecordFile%, UTF-8
  			; -------------------------------------------
			  FileAppend, (_PopUpMenu_Tracker_)_BusinessName`n, %NewRecordFile%, UTF-8
			  FileAppend, %Value_BusinessName%`n, %NewRecordFile%, UTF-8
  			; -------------------------------------------
			  FileAppend, (_PopUpMenu_Tracker_)_FirstName`n, %NewRecordFile%, UTF-8
			  FileAppend, %Value_FirstName%`n, %NewRecordFile%, UTF-8
  			; -------------------------------------------
			  FileAppend, (_PopUpMenu_Tracker_)_LastName`n, %NewRecordFile%, UTF-8
			  FileAppend, %Value_LastName%`n, %NewRecordFile%, UTF-8
  			; -------------------------------------------
			  FileAppend, (_PopUpMenu_Tracker_)_Phone`n, %NewRecordFile%, UTF-8
			  FileAppend, %Value_Phone%`n, %NewRecordFile%, UTF-8
  			; -------------------------------------------
			  FileAppend, (_PopUpMenu_Tracker_)_Country`n, %NewRecordFile%, UTF-8
			  FileAppend, %Value_Country%`n, %NewRecordFile%, UTF-8
  			; -------------------------------------------
			  FileAppend, (_PopUpMenu_Tracker_)_City`n, %NewRecordFile%, UTF-8
			  FileAppend, %Value_City%`n, %NewRecordFile%, UTF-8
  			; -------------------------------------------
			  FileAppend, (_PopUpMenu_Tracker_)_Street`n, %NewRecordFile%, UTF-8
			  FileAppend, %Value_Street%`n, %NewRecordFile%, UTF-8
  			; -------------------------------------------
			  FileAppend, (_PopUpMenu_Tracker_)_ZipCode`n, %NewRecordFile%, UTF-8
			  FileAppend, %Value_ZipCode%`n, %NewRecordFile%, UTF-8
  			; -------------------------------------------
			  FileAppend, (_PopUpMenu_Tracker_)_Notes`n, %NewRecordFile%, UTF-8
			  FileAppend, %Value_Notes%`n, %NewRecordFile%, UTF-8
			  ; -------------------------------------------
			  ; Write Record
			  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
				;
				; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
				; Copy Back to DropBox
				; -------------------------------------------
				CheckDropBox := "C:\Users\" A_UserName "\Dropbox"
				if FileExist(CheckDropBox)
				{
					; -------------------------------------------
					DropBox_Path_DAT := CheckDropBox "\PopUpMenu_Tracker\Files"
					if !FileExist(DropBox_Path_DAT)
					{
						FileCreateDir, %DropBox_Path_DAT%
						Sleep, 100
					}
					; -------------------------------------------
					FileCopy, %NewRecordFile%, %DropBox_Path_DAT%\, 1
					; -------------------------------------------
				}
				; -------------------------------------------
				; Copy Back to DropBox
				; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
				;
				; -------------------------------------------
				ExitApp
				; -------------------------------------------
			} ; else ; NO Error (Value_RecordName) is NOT Empty
			; -------------------------------------------
		} ; else ; NO Error Continue
		; -------------------------------------------
	}
	; -------------------------------------------
	else if (Value_Button_Accept == "Update Record")
	{
		; -------------------------------------------
		FullFilePath := Array_CurrentRecord.1		
		while FileExist(FullFilePath)
		{
			; -------------------------------------------
			FileDelete, %FullFilePath%
			Sleep, 100
			; -------------------------------------------
		}
		; -------------------------------------------
		;
		; -------------------------------------------
		RecordName := ConvertTime("") ; "" > ("2023.07.10.15.12.29") | ("2023.07.10.15.12.29") > "10 Jul, 2023 @ 15:12:29"
		NewRecordFile := Path_DAT "\Files\" RecordName ".txt"
		; -------------------------------------------
		GuiControlGet, OnOff_CatNone, Tracker:, Radio_CatNone
		if (OnOff_CatNone == 1) ; ***************** ERROR CHECK *****************
		{
			; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
			Msg := Msg "ERROR None Category is Selected`n"
			MsgBox, 0, , %Msg%
			Msg := ""
			; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
		}
		else ; NO Error Continue
		{
			; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
			; Get Category
			; -------------------------------------------
		  Array_Category := ["Radio_CatBrowser", "Radio_CatBuySell", "Radio_CatContact", "Radio_CatDownLoad", "Radio_CatEmail", "Radio_CatForum", "Radio_CatGame", "Radio_CatInternet", "Radio_CatMailer", "Radio_CatMoney", "Radio_CatProgram", "Radio_CatSocial", "Radio_CatWebHosting", "Radio_CatWebTempletes", "Radio_CatWebSite"]
			; -------------------------------------------
			for Index, ThisCategory in Array_Category
			{
				; -------------------------------------------
				GuiControlGet, OnOff_ThisCategory, Tracker:, %ThisCategory%
				; -------------------------------------------
				if (OnOff_ThisCategory == 1)
				{
					; -------------------------------------------
  			  if (ThisCategory == "Radio_CatBrowser")
			    {
    			  Value_Category := "browser"
			    }
			    else if (ThisCategory == "Radio_CatBuySell")
			    {
    			  Value_Category := "buysell"
			    }
			    else if (ThisCategory == "Radio_CatContact")
			    {
    			  Value_Category := "contact"
			    }
			    else if (ThisCategory == "Radio_CatDownLoad")
			    {
    			  Value_Category := "downLoad"
			    }
			    else if (ThisCategory == "Radio_CatEmail")
			    {
    			  Value_Category := "email"
			    }
			    else if (ThisCategory == "Radio_CatForum")
			    {
    			  Value_Category := "forum"
			    }
			    else if (ThisCategory == "Radio_CatGame")
			    {
      		  Value_Category := "game"
			    }
			    else if (ThisCategory == "Radio_CatInternet")
			    {
    		    Value_Category := "internet"
			    }
			    else if (ThisCategory == "Radio_CatMailer")
			    {
    			  Value_Category := "mailer"
			    }
			    else if (ThisCategory == "Radio_CatMoney")
			    {
    			  Value_Category := "money"
			    }
			    else if (ThisCategory == "Radio_CatProgram")
			    {
    			  Value_Category := "program"
			    }
			    else if (ThisCategory == "Radio_CatSocial")
			    {
    			  Value_Category := "social"
			    }
			    else if (ThisCategory == "Radio_CatWebHosting")
			    {
    			  Value_Category := "webhosting"
			    }
			    else if (ThisCategory == "Radio_CatWebTempletes")
			    {
    			  Value_Category := "webtempletes"
			    }
			    else if (ThisCategory == "Radio_CatWebSite")
			    {
    			  Value_Category := "website"
			    }
					; -------------------------------------------
					if (StrLen(Value_Category) == 0) ; ***************** ERROR CHECK *****************
					{
						; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
						Msg := Msg "ERROR No Category is Selected`n"
						MsgBox, 0, , %Msg%
						Msg := ""
						; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
					}
					; -------------------------------------------
					break
					; -------------------------------------------
				} ; if (OnOff_ThisCategory == 1)
				; -------------------------------------------
			} ; for Index, ThisCategory in Array_Category
			; -------------------------------------------
			; Get Category
			; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
			;
			; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
			; Get Edit Feild Values
			; -------------------------------------------
			GuiControlGet, Value_RecordName, Tracker:, Edit_RecordName
			Value_RecordName := RemoveTabSpace(Value_RecordName) ; > ThisText (With Out Leading or Ending, Spaces or Tabs)
			; -------------------------------------------
			if (StrLen(Value_RecordName) == 0 or Value_RecordName == "") ; ***************** ERROR CHECK *****************
			{
				; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
			  Msg := Msg "ERROR Value_RecordName is Empty`n"
			  MsgBox, 0, , %Msg%
			  Msg := ""
				; @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
			}
			; -------------------------------------------
			else ; NO Error (Value_RecordName) is NOT Empty
			{
			  ; -------------------------------------------
			  GuiControlGet, Value_SubName, Tracker:, Edit_SubName
			  Value_SubName := RemoveTabSpace(Value_SubName) ; > ThisText (With Out Leading or Ending, Spaces or Tabs)
			  ; -------------------------------------------
			  GuiControlGet, Value_Password, Tracker:, Edit_Password
			  Value_Password := StrReplace(Value_Password, A_Space, "")
			  Value_Password := StrReplace(Value_Password, A_Tab, "")
			  ; -------------------------------------------
			  GuiControlGet, Value_FirstEmail, Tracker:, Edit_FirstEmail
			  Value_FirstEmail := RemoveTabSpace(Value_FirstEmail) ; > ThisText (With Out Leading or Ending, Spaces or Tabs)
			  ; -------------------------------------------
			  GuiControlGet, Value_SecondEmail, Tracker:, Edit_SecondEmail
			  Value_SecondEmail := RemoveTabSpace(Value_SecondEmail) ; > ThisText (With Out Leading or Ending, Spaces or Tabs)
			  ; -------------------------------------------
			  GuiControlGet, Value_LoginName, Tracker:, Edit_LoginName
			  Value_LoginName := RemoveTabSpace(Value_LoginName) ; > ThisText (With Out Leading or Ending, Spaces or Tabs)
			  ; -------------------------------------------
			  GuiControlGet, Value_BusinessName, Tracker:, Edit_BusinessName
			  Value_BusinessName := RemoveTabSpace(Value_BusinessName) ; > ThisText (With Out Leading or Ending, Spaces or Tabs)
			  ; -------------------------------------------
			  GuiControlGet, Value_FirstName, Tracker:, Edit_FirstName
			  Value_FirstName := RemoveTabSpace(Value_FirstName) ; > ThisText (With Out Leading or Ending, Spaces or Tabs)
			  ; -------------------------------------------
			  GuiControlGet, Value_LastName, Tracker:, Edit_LastName
			  Value_LastName := RemoveTabSpace(Value_LastName) ; > ThisText (With Out Leading or Ending, Spaces or Tabs)
			  ; -------------------------------------------
			  GuiControlGet, Value_Phone, Tracker:, Edit_Phone
			  Value_Phone := RemoveTabSpace(Value_Phone) ; > ThisText (With Out Leading or Ending, Spaces or Tabs)
			  ; -------------------------------------------
			  GuiControlGet, Value_Country, Tracker:, Edit_Country
			  Value_Country := RemoveTabSpace(Value_Country) ; > ThisText (With Out Leading or Ending, Spaces or Tabs)
			  ; -------------------------------------------
			  GuiControlGet, Value_City, Tracker:, Edit_City
			  Value_City := RemoveTabSpace(Value_City) ; > ThisText (With Out Leading or Ending, Spaces or Tabs)
			  ; -------------------------------------------
			  GuiControlGet, Value_Street, Tracker:, Edit_Street
			  Value_Street := RemoveTabSpace(Value_Street) ; > ThisText (With Out Leading or Ending, Spaces or Tabs)
			  ; -------------------------------------------
			  GuiControlGet, Value_ZipCode, Tracker:, Edit_ZipCode
			  Value_ZipCode := RemoveTabSpace(Value_ZipCode) ; > ThisText (With Out Leading or Ending, Spaces or Tabs)
			  ; -------------------------------------------
			  GuiControlGet, Value_Notes, Tracker:, Edit_Notes
			  ; -------------------------------------------
			  ; Get Edit Feild Values
			  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
			  ;
			  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
			  ; (if) Value is Blank Add "<EMPTY>"
    		; -------------------------------------------
        Array_EditValue := ["Value_SubName", "Value_Password", "Value_FirstEmail", "Value_SecondEmail", "Value_LoginName", "Value_BusinessName", "Value_FirstName", "Value_LastName", "Value_Phone", "Value_Country", "Value_City", "Value_Street", "Value_ZipCode", "Value_Notes"]
        for Index, CheckValue in Array_EditValue
        {
      	  if (%CheckValue% == "")
  	      {
      		  %CheckValue% := "<EMPTY>"
	        }
        }
			  ; -------------------------------------------
		    ; (if) Value is Blank Add "<EMPTY>"
			  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
			  ;
			  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
			  ; Write Record
			  ; -------------------------------------------
			  FileAppend, (_PopUpMenu_Tracker_)_Category`n, %NewRecordFile%, UTF-8
			  FileAppend, %Value_Category%`n, %NewRecordFile%, UTF-8
  			; -------------------------------------------
			  FileAppend, (_PopUpMenu_Tracker_)_RecordName`n, %NewRecordFile%, UTF-8
			  FileAppend, %Value_RecordName%`n, %NewRecordFile%, UTF-8
  			; -------------------------------------------
			  FileAppend, (_PopUpMenu_Tracker_)_SubName`n, %NewRecordFile%, UTF-8
			  FileAppend, %Value_SubName%`n, %NewRecordFile%, UTF-8
  			; -------------------------------------------
			  FileAppend, (_PopUpMenu_Tracker_)_Password`n, %NewRecordFile%, UTF-8
			  FileAppend, %Value_Password%`n, %NewRecordFile%, UTF-8
  			; -------------------------------------------
			  FileAppend, (_PopUpMenu_Tracker_)_FirstEmail`n, %NewRecordFile%, UTF-8
			  FileAppend, %Value_FirstEmail%`n, %NewRecordFile%, UTF-8
  			; -------------------------------------------
			  FileAppend, (_PopUpMenu_Tracker_)_SecondEmail`n, %NewRecordFile%, UTF-8
			  FileAppend, %Value_SecondEmail%`n, %NewRecordFile%, UTF-8
  			; -------------------------------------------
			  FileAppend, (_PopUpMenu_Tracker_)_LoginName`n, %NewRecordFile%, UTF-8
			  FileAppend, %Value_LoginName%`n, %NewRecordFile%, UTF-8
  			; -------------------------------------------
			  FileAppend, (_PopUpMenu_Tracker_)_BusinessName`n, %NewRecordFile%, UTF-8
			  FileAppend, %Value_BusinessName%`n, %NewRecordFile%, UTF-8
  			; -------------------------------------------
			  FileAppend, (_PopUpMenu_Tracker_)_FirstName`n, %NewRecordFile%, UTF-8
			  FileAppend, %Value_FirstName%`n, %NewRecordFile%, UTF-8
  			; -------------------------------------------
			  FileAppend, (_PopUpMenu_Tracker_)_LastName`n, %NewRecordFile%, UTF-8
			  FileAppend, %Value_LastName%`n, %NewRecordFile%, UTF-8
  			; -------------------------------------------
			  FileAppend, (_PopUpMenu_Tracker_)_Phone`n, %NewRecordFile%, UTF-8
			  FileAppend, %Value_Phone%`n, %NewRecordFile%, UTF-8
  			; -------------------------------------------
			  FileAppend, (_PopUpMenu_Tracker_)_Country`n, %NewRecordFile%, UTF-8
			  FileAppend, %Value_Country%`n, %NewRecordFile%, UTF-8
  			; -------------------------------------------
			  FileAppend, (_PopUpMenu_Tracker_)_City`n, %NewRecordFile%, UTF-8
			  FileAppend, %Value_City%`n, %NewRecordFile%, UTF-8
  			; -------------------------------------------
			  FileAppend, (_PopUpMenu_Tracker_)_Street`n, %NewRecordFile%, UTF-8
			  FileAppend, %Value_Street%`n, %NewRecordFile%, UTF-8
  			; -------------------------------------------
			  FileAppend, (_PopUpMenu_Tracker_)_ZipCode`n, %NewRecordFile%, UTF-8
			  FileAppend, %Value_ZipCode%`n, %NewRecordFile%, UTF-8
  			; -------------------------------------------
			  FileAppend, (_PopUpMenu_Tracker_)_Notes`n, %NewRecordFile%, UTF-8
			  FileAppend, %Value_Notes%`n, %NewRecordFile%, UTF-8
			  ; -------------------------------------------
			  ; Write Record
			  ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
				;
				; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
				; Copy Back to DropBox
				; -------------------------------------------
				CheckDropBox := "C:\Users\" A_UserName "\Dropbox"
				if FileExist(CheckDropBox)
				{
					; -------------------------------------------
					DropBox_Path_DAT := CheckDropBox "\PopUpMenu_Tracker\Files"
					if !FileExist(DropBox_Path_DAT)
					{
						FileCreateDir, %DropBox_Path_DAT%
						Sleep, 100
					}
					; -------------------------------------------
					FileCopy, %NewRecordFile%, %DropBox_Path_DAT%\, 1
					; -------------------------------------------
				}
				; -------------------------------------------
				; Copy Back to DropBox
				; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
				;
				; -------------------------------------------
				ExitApp
				; -------------------------------------------
			} ; else ; NO Error (Value_RecordName) is NOT Empty
			; -------------------------------------------
		} ; else ; NO Error Continue
		; -------------------------------------------
	}
	; -------------------------------------------
	else if (Value_Button_Accept == "Delete Record")
	{
		; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		; DeleteFile pum Dir
		; -------------------------------------------
		FullFilePath := Array_CurrentRecord.1		
		while FileExist(FullFilePath)
		{
			; -------------------------------------------
			FileDelete, %FullFilePath%
			Sleep, 100
			; -------------------------------------------
		}
		; -------------------------------------------
		; DeleteFile pum Dir
		; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		;
		; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		; Delete From DropBox
		; -------------------------------------------
		CheckDropBox := "C:\Users\" A_UserName "\Dropbox"
		if FileExist(CheckDropBox)
		{
			; -------------------------------------------
			SplitPath, FullFilePath, OutFileName
			; -------------------------------------------
			DropBox_FullFilePath := CheckDropBox "\PopUpMenu_Tracker\Files\" OutFileName
		  while FileExist(DropBox_FullFilePath)
		  {
  			; -------------------------------------------
			  FileDelete, %DropBox_FullFilePath%
			  Sleep, 100
			  ; -------------------------------------------
		  }
		  ; -------------------------------------------
		}
		; -------------------------------------------
		; Delete From DropBox
		; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		;
		; -------------------------------------------
		Value_TitleTextDisplay := "Loading Records"
		Value_TextDisplay      := ""
		Color_TitleTextDisplay := "Blue"
		Color_TextDisplay      := "X"
		GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
		; -------------------------------------------
		;
		; -------------------------------------------
		ListBox_Search_Clear := "|"
		GuiControl, Tracker:, ListBox_Search, %ListBox_Search_Clear%
		GuiControl, Tracker:MoveDraw, %ListBox_Search%
		; -------------------------------------------
		;
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    ; StartUp (ArrayAllRecords)
    ; -------------------------------------------
    ; ArrayThisRecord := [A_LoopFileFullPath, Value_Category, Value_RecordName, Value_SubName]
    ; ArrayAllRecords := [ArrayThisRecord, ArrayThisRecord, etc]
    ; -------------------------------------------
		ArrayAllRecords := ""
		; -------------------------------------------
    Loop, Files, %Path_DAT%\Files\*.txt
    {
  	  ; -------------------------------------------
  	  FileReadLine, Value_Category, %A_LoopFileFullPath%, 2
  	  FileReadLine, Value_RecordName, %A_LoopFileFullPath%, 4
  	  FileReadLine, Value_SubName, %A_LoopFileFullPath%, 6
  	  ; -------------------------------------------
  	  ArrayThisRecord := [A_LoopFileFullPath, Value_Category, Value_RecordName, Value_SubName]
  	  ArrayAllRecords := Array_Add(ArrayAllRecords, ArrayThisRecord, "End") ; > ThisArray
  	  ; -------------------------------------------
    }
    ; -------------------------------------------
    ; StartUp (ArrayAllRecords)
    ; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		;
		Array_Returned := CategorySearch(ArrayAllRecords) ; > [ListBox_Search_List, Array_SearchList]
		ListBox_Search_List := Array_Returned.1
		Array_SearchList := Array_Returned.2
		; -------------------------------------------
		GuiControl, Tracker:, ListBox_Search, %ListBox_Search_List%
		; -------------------------------------------
		;
		; -------------------------------------------
		Value_TitleTextDisplay := "Select Record"
		Value_TextDisplay      := ""
		Color_TitleTextDisplay := "Blue"
		Color_TextDisplay      := "X"
		GhangeTextDisplay(Value_TitleTextDisplay, Value_TextDisplay, Color_TitleTextDisplay, Color_TextDisplay) ; X=NoChange ("Green" "Red" "Blue", "" = Black)
		; -------------------------------------------
		Sleep, 100
    Gui, Tracker:Color, e7d8fe ; Purple Color
		; -------------------------------------------
	} ; else if (Value_Button_Accept == "Delete Record")
	; -------------------------------------------
}
return
; -------------------------------------------
Label_Cancel:
{
	; -------------------------------------------
	ExitApp
	; -------------------------------------------
} ; [End] Label_Button_Cancel:
return
; -------------------------------------------
Esc::
{
	ExitApp
}
return
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
; END OF FILE
; >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
